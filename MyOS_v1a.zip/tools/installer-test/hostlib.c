#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <fcntl.h>
#include <unistd.h>
void *host_malloc(unsigned n){ return malloc(n); }
void host_free(void *p){ free(p); }
void *host_realloc(void *p, unsigned n){ return realloc(p, n); }
unsigned host_ms(void){ struct timeval tv; gettimeofday(&tv,0); return (unsigned)(tv.tv_sec*1000+tv.tv_usec/1000); }
static int fd=-1;
int host_disk_open(const char *p){ fd=open(p,O_RDWR); return fd; }
long long host_disk_size(void){ return lseek(fd,0,SEEK_END); }
int host_disk_rw(int w, unsigned long long lba, unsigned count, void *buf){
    off_t off=(off_t)lba*512; size_t n=(size_t)count*512;
    ssize_t r = w ? pwrite(fd,buf,n,off) : pread(fd,buf,n,off);
    return r==(ssize_t)n ? 0 : -1;
}
unsigned char *host_load(const char *p, unsigned *len){
    FILE *f=fopen(p,"rb"); if(!f) return 0; fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,0,SEEK_SET);
    unsigned char *b=malloc(n?n:1); if(fread(b,1,n,f)!=(size_t)n){} fclose(f); *len=(unsigned)n; return b;
}
void host_out(const char *s){ fputs(s,stdout); fflush(stdout); }
int host_readline(char *buf, int max){ return fgets(buf,max,stdin)?1:0; }
