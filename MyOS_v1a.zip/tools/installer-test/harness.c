#include "stdint.h"
#include "fat32.h"
#include "ata_pio_drv.h"
#include "installer.h"
#include "common.h"
#include "kheap.h"
#include "rtc.h"
extern void *host_malloc(unsigned); extern void host_free(void*); extern void *host_realloc(void*,unsigned);
extern unsigned host_ms(void); extern int host_disk_open(const char*); extern long long host_disk_size(void);
extern int host_disk_rw(int,unsigned long long,unsigned,void*);
extern unsigned char *host_load(const char*,unsigned*); extern void host_out(const char*); extern int host_readline(char*,int);

int k_toupper(int c){ return (c>=97&&c<=122)?c-32:c; } int k_tolower(int c){ return (c>=65&&c<=90)?c+32:c; }
void *kmalloc(uint32_t n){ return host_malloc(n); }
void kfree(void *p){ host_free(p); }
void *krealloc(void *p, uint32_t n){ return host_realloc(p,n); }
void fastcp(char *d, char *s, uint32_t n){ memcpy(d,s,n); }
uint32_t pit_get_ms(void){ return host_ms(); }
void rtc_read_date(rtc_date_t *d){ memset(d,0,sizeof(*d)); d->year=2026; d->month=10; d->day=22; }
void rtc_read_time(rtc_time_t *t){ memset(t,0,sizeof(*t)); t->hours=12; }
void PANIC(char *e){ host_out("PANIC\n"); host_out(e); for(;;); }

static ata_info_t info;
int ata_probe_all(void){ return 1; }
const ata_info_t *ata_device_info(int d){
    static ata_info_t none;
    if(d != 0) return &none;
    info.present=1; info.sectors=host_disk_size()/512; info.lba48=1;
    memcpy(info.model,"TEST DISK",10); return &info;
}
int ata_dev_read(int d,uint64_t l,uint32_t c,void*b){ return d==0 ? host_disk_rw(0,l,c,b) : -1; }
int ata_dev_write(int d,uint64_t l,uint32_t c,const void*b){ return d==0 ? host_disk_rw(1,l,c,(void*)b) : -1; }
void ata_set_default_device(int d){} int ata_get_default_device(void){ return 0; }

static void say(const char *fmt, int a, int b){ char buf[200]; extern int sprintf(char*,const char*,...); }

int main(int argc, char **argv){
    /* argv: live.img target.img */
    unsigned len; unsigned char *live = host_load(argv[1], &len);
    fat32_set_memory_backend(live, len);
    master_fs = makeFilesystem("");
    if(!master_fs){ host_out("live mount failed\n"); return 1; }
    host_disk_open(argv[2]);
    if(argc>3){
        uint32_t part=999; int r=fat32_probe_volume(0,&part); char b[200]; extern int sprintf(char*,const char*,...);
        sprintf(b,"probe: found=%d part_lba=%u\n",r,part); host_out(b);
        if(r){ f32 *t=makeFilesystemOn(0,part); sprintf(b,"mount: %s\n",t?"OK":"FAILED"); host_out(b);
            if(t){ struct directory d; populate_root_dir(t,&d); for(uint32_t i=0;i<d.num_entries;i++) if(d.entries[i].name){ sprintf(b,"  /%s%s\n",d.entries[i].name,(d.entries[i].dir_attrs&DIRECTORY)?"/":""); host_out(b);} } }
        return 0;
    }

    /* manifest on stdin: "D|/guest/dir" or "F|host path|/guest/file" */
    char line[1024];
    while(host_readline(line, sizeof line)){
        int n=strlen(line); while(n && (line[n-1]=='\n'||line[n-1]=='\r')) line[--n]=0;
        if(!n) continue;
        if(line[0]=='D'){
            const char *g=line+2; char parent[256], name[128]; int last=0;
            for(int i=0;g[i];i++) if(g[i]=='/') last=i;
            memcpy(parent,g,last); parent[last]=0; if(!last){parent[0]='/';parent[1]=0;}
            strcpy(name,g+last+1);
            struct directory d; populate_root_dir(master_fs,&d);
            /* walk parent */
            char *p=parent;
            while(*p){ while(*p=='/') p++; if(!*p) break; char comp[128]; int k=0; while(*p&&*p!='/') comp[k++]=*p++; comp[k]=0;
                int idx=-1; for(uint32_t i=0;i<d.num_entries;i++) if(d.entries[i].name && !strcasecmp(d.entries[i].name,comp)) idx=i;
                if(idx<0){ host_out("manifest: parent missing\n"); return 2; }
                uint32_t c=d.entries[idx].first_cluster; free_directory(master_fs,&d); populate_dir(master_fs,&d,c); }
            mkdir(master_fs,&d,name); free_directory(master_fs,&d);
        } else {
            char *sep=strchr(line+2,'|'); *sep=0; const char *host=line+2, *g=sep+1;
            unsigned flen; unsigned char *data=host_load(host,&flen);
            if(!data){ host_out("manifest: cannot read host file\n"); return 3; }
            char parent[256], name[128]; int last=0;
            for(int i=0;g[i];i++) if(g[i]=='/') last=i;
            memcpy(parent,g,last); parent[last]=0; if(!last){parent[0]='/';parent[1]=0;}
            strcpy(name,g+last+1);
            struct directory d; populate_root_dir(master_fs,&d);
            char *p=parent;
            while(*p){ while(*p=='/') p++; if(!*p) break; char comp[128]; int k=0; while(*p&&*p!='/') comp[k++]=*p++; comp[k]=0;
                int idx=-1; for(uint32_t i=0;i<d.num_entries;i++) if(d.entries[i].name && !strcasecmp(d.entries[i].name,comp)) idx=i;
                if(idx<0){ host_out("manifest: parent missing\n"); return 2; }
                uint32_t c=d.entries[idx].first_cluster; free_directory(master_fs,&d); populate_dir(master_fs,&d,c); }
            writeFile(master_fs,&d,data,name,flen); free_directory(master_fs,&d); host_free(data);
        }
    }

    myos_diskinfo_t di;
    int rc = installer_disk_info(0,&di);
    { char b[200]; extern int sprintf(char*,const char*,...);
      sprintf(b,"disk info rc=%d model=%s size_mb=%u usable=%u part_mb=%u has_fs=%u\n",rc,di.model,di.size_mb,di.usable,di.part_mb,di.has_filesystem); host_out(b); }
    rc = installer_begin(0);
    myos_install_status_t st; int steps=0, lastp=-1;
    do {
        rc = installer_step(&st); steps++;
        if((int)st.percent!=lastp){ char b[200]; extern int sprintf(char*,const char*,...);
            sprintf(b,"[%3u%%] %s  (%u/%u) %s\n",st.percent,st.stage,st.files_done,st.files_total,st.detail); host_out(b); lastp=st.percent; }
    } while(st.state==MYOS_INST_RUNNING && steps<100000);
    { char b[200]; extern int sprintf(char*,const char*,...);
      sprintf(b,"final state=%u error=%d steps=%d detail=%s\n",st.state,st.error,steps,st.detail); host_out(b); }
    return st.state==MYOS_INST_DONE ? 0 : 10;
}
