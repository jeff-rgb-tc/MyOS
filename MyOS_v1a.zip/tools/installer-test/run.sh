#!/bin/sh
# Host-side test of the installer: runs the REAL kernel FAT32 driver and
# installer.c against file-backed disks (no VM needed), then checks the
# result with an independent FAT32 parser (verify.py). Needs gcc + python3.
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
K="$HERE/../../SYSTEM/kernel"
T=/tmp/myos-insttest; mkdir -p $T
F="-m64 -w -O1 -fno-strict-aliasing -fno-builtin -I$K -I$K/../desktop -I$K/../apps-sdk/include"
gcc $F -c "$HERE/harness.c" -o $T/harness.o
gcc $F -c "$K/fat32.c" -o $T/fat32.o
gcc $F -c "$K/installer.c" -o $T/installer.o
gcc -m64 -w -O1 -c "$HERE/hostlib.c" -o $T/hostlib.o
gcc -m64 $T/harness.o $T/fat32.o $T/installer.o $T/hostlib.o -o $T/harness
python3 "$HERE/drive.py"
python3 "$HERE/verify.py"
