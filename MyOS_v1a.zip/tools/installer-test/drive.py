import os, struct, subprocess, sys, random
ROOT=os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),"..",".."))

def mkfs_live(path, size_mb=100, spc=1):
    total=size_mb*2048; reserved=32
    spf=1
    for _ in range(40):
        clusters=(total-reserved-2*spf)//spc
        need=((clusters+2)*4+511)//512
        if need==spf: break
        spf=need
    clusters=(total-reserved-2*spf)//spc
    with open(path,"wb") as f: f.truncate(total*512)
    bs=bytearray(512)
    bs[0:3]=b"\xeb\x58\x90"; bs[3:11]=b"MSWIN4.1"
    struct.pack_into("<HBHBHHBHHHII",bs,11,512,spc,reserved,2,0,0,0xF8,0,63,255,0,total)
    struct.pack_into("<IHHI",bs,36,spf,0,0,2); struct.pack_into("<HH",bs,48,1,6)
    bs[66]=0x29; bs[71:82]=b"NO NAME    "; bs[82:90]=b"FAT32   "; bs[510:512]=b"\x55\xaa"
    fsi=bytearray(512); struct.pack_into("<I",fsi,0,0x41615252); struct.pack_into("<III",fsi,484,0x61417272,clusters-1,3); struct.pack_into("<I",fsi,508,0xAA550000)
    fat0=bytearray(512); struct.pack_into("<III",fat0,0,0x0FFFFFF8,0x0FFFFFFF,0x0FFFFFFF)
    with open(path,"r+b") as f:
        for s in (0,6): f.seek(s*512); f.write(bs)
        for s in (1,7): f.seek(s*512); f.write(fsi)
        for k in range(2): f.seek((reserved+k*spf)*512); f.write(fat0)

def build_manifest():
    lines=[]
    def add_tree(host_root, guest_root):
        lines.append("D|"+guest_root)
        for dp,dn,fn in os.walk(host_root):
            dn.sort(); fn.sort()
            rel=os.path.relpath(dp,host_root)
            g=guest_root if rel=="." else guest_root+"/"+rel
            if rel!=".": lines.append("D|"+g)
            for n in fn:
                if n.endswith((".o",".elf")) or "/build" in dp: continue
                lines.append("F|%s|%s/%s"%(os.path.join(dp,n),g,n))
    for d in ("/SYSTEM","/SYSTEM/install","/boot","/boot/grub","/Users","/Users/User","/Users/User/Desktop"):
        lines.append("D|"+d)
    # use real project content
    for sub in ("res",):
        for dp,dn,fn in os.walk(ROOT+"/SYSTEM/"+sub):
            dn.sort()
            rel=os.path.relpath(dp,ROOT+"/SYSTEM")
            lines.append("D|/SYSTEM/"+rel)
            for n in sorted(fn): lines.append("F|%s|/SYSTEM/%s/%s"%(os.path.join(dp,n),rel,n))
    lines.append("D|/APPS")
    for dp,dn,fn in os.walk(ROOT+"/APPS"):
        dn.sort(); rel=os.path.relpath(dp,ROOT+"/APPS")
        if rel!=".": lines.append("D|/APPS/"+rel)
        for n in sorted(fn): lines.append("F|%s|/APPS/%s"%(os.path.join(dp,n),n if rel=="." else rel+"/"+n))
    # SDK (many small files, nested dirs)
    sdk=[]
    for dp,dn,fn in os.walk(ROOT+"/SYSTEM/apps-sdk"):
        dn[:]=sorted(d for d in dn if d not in("build","__pycache__")); rel=os.path.relpath(dp,ROOT+"/SYSTEM")
        lines.append("D|/SYSTEM/"+rel)
        for n in sorted(fn):
            if n.endswith((".o",".elf",".pyc")): continue
            lines.append("F|%s|/SYSTEM/%s/%s"%(os.path.join(dp,n),rel,n))
    # synthetic: fake kernel + payload + cfg
    random.seed(1)
    open("/tmp/myos-insttest/fake_myos.bin","wb").write(bytes(random.getrandbits(8) for _ in range(1500000)))
    payload=bytearray(2048*512); 
    for i in range(0,1024*512,7): payload[i]=(i*31)&0xFF
    payload[510:512]=b"\x55\xaa"; payload[0]=0xEB
    open("/tmp/myos-insttest/fake_bootsect.bin","wb").write(payload)
    lines.append("F|/tmp/myos-insttest/fake_myos.bin|/boot/myos.bin")
    lines.append("F|%s|/boot/grub/grub.cfg"%(ROOT+"/BOOT/grub/grub-installed.cfg"))
    lines.append("F|/tmp/myos-insttest/fake_bootsect.bin|/SYSTEM/install/bootsect.bin")
    lines.append("D|/Users/User/Music")
    return lines

if __name__=="__main__":
    mkfs_live("/tmp/myos-insttest/live.img")
    with open("/tmp/myos-insttest/target.img","wb") as f: f.truncate(1024*1024*1024)  # 1 GiB target
    man="\n".join(build_manifest())+"\n"
    open("/tmp/myos-insttest/manifest.txt","w").write(man)
    r=subprocess.run(["/tmp/myos-insttest/harness","/tmp/myos-insttest/live.img","/tmp/myos-insttest/target.img"],input=man,text=True,capture_output=True)
    sys.stdout.write(r.stdout[-3000:]); sys.stderr.write(r.stderr[-2000:])
    print("harness exit:",r.returncode)
