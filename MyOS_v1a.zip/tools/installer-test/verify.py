import struct, sys, os, hashlib
img=open("/tmp/myos-insttest/target.img","rb")
def rd(sec,n=1): img.seek(sec*512); return img.read(512*n)
mbr=rd(0)
assert mbr[510:512]==b"\x55\xaa"
pe=mbr[446:462]; boot,_,typ=pe[0],pe[1:4],pe[4]; start,size=struct.unpack("<II",pe[8:16])
print("partition: boot=%#x type=%#x start=%d size=%d (%d MiB)"%(boot,typ,start,size,size//2048))
assert boot==0x80 and typ==0x0C and start==2048 and size==1048576
payload=open("/tmp/myos-insttest/fake_bootsect.bin","rb").read()
assert mbr[:440]==payload[:440], "MBR boot code differs"
assert rd(1,2047)==payload[512:2048*512], "embedded core area differs"
for e in range(1,4): assert mbr[446+16*e:462+16*e]==b"\0"*16
print("MBR + embedded boot area: OK")

B=rd(start)
bps,spc,res,nf=struct.unpack("<HBHB",B[11:17]); total=struct.unpack("<I",B[32:36])[0]; spf=struct.unpack("<I",B[36:40])[0]; root=struct.unpack("<I",B[44:48])[0]
hidden=struct.unpack("<I",B[28:32])[0]
assert B[82:90]==b"FAT32   " and bps==512 and nf==2 and root==2 and hidden==start and total==size
assert rd(start+6)==B, "backup boot sector differs"
fsi=rd(start+1); assert struct.unpack("<I",fsi[0:4])[0]==0x41615252 and struct.unpack("<I",fsi[484:488])[0]==0x61417272 and fsi[508:512]==b"\0\0\x55\xaa"
data0=res+nf*spf
nclusters=(size-data0)//spc
print("spc=%d spf=%d clusters=%d"%(spc,spf,nclusters))
assert nclusters>=65525
fat1=rd(start+res,spf); fat2=rd(start+res+spf,spf)
assert fat1==fat2, "FAT copies differ"
FAT=struct.unpack("<%dI"%(spf*128),fat1)
assert FAT[0]&0x0FFFFFFF==0x0FFFFFF8 and FAT[1]&0x0FFFFFFF>=0x0FFFFFF8
for c in range(nclusters+2,spf*128): assert FAT[c]==0x0FFFFFF7, "slack entry %d not marked bad"%c
print("FAT copies identical, slack entries reserved: OK")

def chain(c):
    out=[]; seen=set()
    while 2<=c<0x0FFFFFF8:
        assert c not in seen, "loop in chain"; seen.add(c); out.append(c); c=FAT[c]&0x0FFFFFFF
        assert c!=0, "chain ends in free cluster"
        assert c!=0x0FFFFFF7, "chain hits bad cluster"
    return out
def cl_data(chn,size=None):
    d=b"".join(rd(start+data0+(c-2)*spc,spc) for c in chn)
    return d if size is None else d[:size]

owner={}
def claim(chn,what):
    for c in chn:
        assert c not in owner, "cross-linked cluster %d: %s vs %s"%(c,what,owner[c])
        owner[c]=what

def lfn_chk(short11):
    s=0
    for ch in short11: s=(((s&1)<<7)+(s>>1)+ch)&0xFF
    return s

def read_dir(c,path):
    chn=chain(c); claim(chn,path); d=cl_data(chn); ents=[]; lfn=[]
    for i in range(0,len(d),32):
        e=d[i:i+32]
        if e[0]==0: break
        if e[0]==0xE5: lfn=[]; continue
        attr=e[11]
        if attr==0x0F:
            lfn.append(e); continue
        if attr&0x08: lfn=[]; continue
        short=e[:11]
        if lfn:
            parts=sorted(lfn,key=lambda x:x[0]&0x3F)
            for p in parts: assert p[13]==lfn_chk(short), "LFN checksum mismatch in %s"%path
            name=b""
            for p in parts: name+=p[1:11]+p[14:26]+p[28:32]
            name=name.decode("utf-16-le").split("\x00")[0].split("\uffff")[0]
        else:
            n=short[:8].decode("latin1").rstrip(); x=short[8:11].decode("latin1").rstrip()
            name=n+("."+x if x else "")
        lfn=[]
        hi,lo=struct.unpack("<H",e[20:22])[0],struct.unpack("<H",e[26:28])[0]
        cl=(hi<<16)|lo; size=struct.unpack("<I",e[28:32])[0]
        ents.append((name,attr,cl,size))
    return ents

files={}; dirs=[]
def walk(c,path):
    for name,attr,cl,size in read_dir(c,path):
        if name in(".",".."): continue
        p=path+"/"+name if path!="/" else "/"+name
        if attr&0x10: dirs.append(p); walk(cl,p)
        else:
            chn=chain(cl) if cl else []
            assert len(chn)*spc*512>=size and (len(chn)-1)*spc*512<size or size==0, "bad chain length for %s"%p
            claim(chn,p); files[p]=cl_data(chn,size)
walk(2,"/")
print("target: %d dirs, %d files, %d clusters in use"%(len(dirs),len(files),len(owner)))
# every non-free FAT entry must belong to something we found (no leaks)
used={c for c in range(2,nclusters+2) if FAT[c]!=0}
assert used==set(owner)|{2}, "FAT has allocated clusters that no file owns: %d"%len(used-set(owner)-{2})

# expected from manifest (minus /SYSTEM/install)
exp={}; edirs=set()
for l in open("/tmp/myos-insttest/manifest.txt").read().splitlines():
    if l.startswith("D|"):
        edirs.add(l[2:])
    elif l.startswith("F|"):
        _,h,g=l.split("|"); exp[g]=h
missing=[]
bad=[]
for g,h in exp.items():
    if g.lower().startswith("/system/install"): 
        assert g not in files; continue
    key=[k for k in files if k.lower()==g.lower()]
    if not key: missing.append(g); continue
    if files[key[0]]!=open(h,"rb").read(): bad.append(g)
print("missing files:",missing[:10],len(missing)); print("content mismatches:",bad[:10],len(bad))
assert not missing and not bad
dl={d.lower() for d in dirs}
for d in edirs:
    if d.lower().startswith("/system/install") or d.lower() in("/users/user/music",): continue
    assert d.lower() in dl, "dir missing: "+d
assert not any(k.lower().startswith("/system/install") for k in files)
print("ALL CHECKS PASSED")
