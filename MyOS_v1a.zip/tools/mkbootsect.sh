#!/bin/sh
# mkbootsect.sh <out.bin>
#
# Produces the boot loader "payload" the installer writes to a new disk: the
# first 2048 sectors (1 MiB) of a disk that has GRUB installed for an MBR
# disk with one partition starting at LBA 2048 -- i.e. the MBR (GRUB's
# boot.img + partition table) and core.img embedded in the gap before the
# partition. Nothing in it depends on the disk's size; the installer only
# rewrites the partition-table entry.
#
# Needs the GRUB BIOS tools:  sudo apt install grub-pc-bin   (python3 too)
# No root, no loop devices.
set -e

OUT="$1"
[ -n "$OUT" ] || { echo "usage: mkbootsect.sh <out.bin>" >&2; exit 1; }
HERE=$(cd "$(dirname "$0")" && pwd)

find_tool() { for n in "$@"; do command -v "$n" >/dev/null 2>&1 && { command -v "$n"; return 0; }; done; return 1; }
LIBDIR=""
for d in /usr/lib/grub/i386-pc /usr/share/grub/i386-pc /usr/lib/grub2/i386-pc; do
    [ -f "$d/boot.img" ] && { LIBDIR="$d"; break; }
done
[ -n "$LIBDIR" ] || { echo "mkbootsect: boot.img not found (install grub-pc-bin)" >&2; exit 1; }

MKIMAGE=$(find_tool grub-mkimage grub2-mkimage) || { echo "mkbootsect: grub-mkimage not found (install grub-common / grub-pc-bin)" >&2; exit 1; }
# On Debian/Ubuntu grub-bios-setup is NOT in PATH: it lives next to boot.img.
SETUP=$(find_tool grub-bios-setup grub2-bios-setup "$LIBDIR/grub-bios-setup" "$LIBDIR/grub2-bios-setup") \
    || { echo "mkbootsect: grub-bios-setup not found (install grub-pc-bin; looked in PATH and $LIBDIR)" >&2; exit 1; }
echo "mkbootsect: using $SETUP and $MKIMAGE, files from $LIBDIR"

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
IMG="$TMP/scratch.img"
CORE="$TMP/core.img"
MAP="$TMP/device.map"

dd if=/dev/zero of="$IMG" bs=1M count=16 2>/dev/null
python3 "$HERE/mkmbr.py" "$IMG"

# multiboot + boot are needed by grub.cfg; the rest is to read FAT32 on an
# MBR disk. The prefix "(,msdos1)" means "partition 1 of the disk GRUB booted from".
"$MKIMAGE" -O i386-pc -d "$LIBDIR" -o "$CORE" -p '(,msdos1)/boot/grub' \
    biosdisk part_msdos fat normal configfile multiboot boot echo ls

echo "(hd0) $IMG" > "$MAP"

# grub-bios-setup looks for boot.img AND the core image inside the -d
# directory (it joins "-d" and "-c" into one path), so an absolute -c path
# elsewhere fails with "cannot open '/usr/lib/grub/i386-pc//tmp/.../core.img'".
# Give it a private directory holding both files.
SETUPDIR="$TMP/setup"
mkdir -p "$SETUPDIR"
cp "$LIBDIR/boot.img" "$SETUPDIR/boot.img"
cp "$CORE" "$SETUPDIR/core.img"

# 1) The official tool. On some systems (GRUB 2.12 on Ubuntu, with -d in /tmp) it
#    cannot "guess the root device" of the scratch directory and has no -r
#    option to override that, so it may fail -- then step 2 takes over.
OK=0
n=0
for DEV in "$IMG" "(hd0)"; do
    n=$((n + 1))
    if "$SETUP" -d "$SETUPDIR" -c core.img -m "$MAP" -s "$DEV" 2>"$TMP/err$n"; then
        OK=1; break
    fi
done

# 2) Fallback: do by hand what grub-bios-setup does for "embed core.img right
#    after the MBR", which is all this layout needs:
#      - bytes 0..439 of the MBR  <- boot.img   (its defaults already mean
#        "core.img starts at LBA 1" and "boot from the BIOS drive number")
#      - LBA 1..                  <- core.img
#      - core.img's first sector holds a block list {start=2, len, seg}; only
#        len (= remaining sectors) has to be filled in.
#    The partition table written by mkmbr.py (bytes 446..511) is kept.
if [ "$OK" != 1 ]; then
    echo "mkbootsect: grub-bios-setup could not run here ($(head -n1 "$TMP/err1")); embedding GRUB by hand." >&2
    python3 - "$IMG" "$LIBDIR/boot.img" "$CORE" <<'PY' || exit 1
import struct, sys
img, boot, core = sys.argv[1:4]
b = open(boot, "rb").read()
c = bytearray(open(core, "rb").read())
if len(b) != 512 or b[510:512] != b"\x55\xaa":
    sys.exit("mkbootsect: boot.img is not a 512-byte boot sector")
if len(c) % 512:
    c += b"\0" * (512 - len(c) % 512)
n = len(c) // 512
if n < 2 or n > 2000:
    sys.exit("mkbootsect: core.img has an unexpected size (%d sectors)" % n)
off = 512 - 12                                   # block list at the end of sector 0 of core.img
start = struct.unpack_from("<Q", c, off)[0]
if start != 2:
    sys.exit("mkbootsect: unexpected block list in core.img (start=%d, want 2) -- "
             "this GRUB build is laid out differently, please report it" % start)
struct.pack_into("<H", c, off + 8, n - 1)
ks = struct.unpack_from("<Q", b, 0x5C)[0]       # boot.img's kernel sector (default 1)
if ks != 1:
    print("mkbootsect: WARNING boot.img kernel sector is %d, expected 1" % ks, file=sys.stderr)
with open(img, "r+b") as f:
    mbr = bytearray(f.read(512))
    mbr[0:440] = b[0:440]
    mbr[510:512] = b"\x55\xaa"
    f.seek(0); f.write(mbr)
    f.seek(512); f.write(c)
print("mkbootsect: embedded core.img (%d sectors) at LBA 1" % n)
PY
fi

# Sanity: boot code in the MBR, core.img in sector 1, partition table intact.
python3 - "$IMG" <<'PY'
import sys
d = open(sys.argv[1], "rb").read(2048 * 512)
assert d[510:512] == b"\x55\xaa", "MBR signature missing"
assert any(d[0:440]), "MBR has no boot code"
assert any(d[512:1024]), "core.img not embedded in sector 1"
assert d[446] == 0x80 and d[450] == 0x0C, "partition entry was damaged"
PY

head -c $((2048 * 512)) "$IMG" > "$OUT"
echo "mkbootsect: wrote $OUT"
