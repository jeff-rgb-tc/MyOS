#!/usr/bin/env python3
"""mkmbr.py <image> -- write an MBR partition table with ONE bootable FAT32
(LBA, type 0x0C) partition starting at LBA 2048 and covering the rest of the
image. Used on the scratch image from which mkbootsect.sh extracts GRUB's
boot sectors; the installer rewrites the partition size for the real disk."""
import os, struct, sys

img = sys.argv[1]
total = os.path.getsize(img) // 512
start = 2048
entry = struct.pack("<B3sB3sII", 0x80, b"\xfe\xff\xff", 0x0C, b"\xfe\xff\xff", start, total - start)
mbr = bytearray(512)
mbr[446:446 + 16] = entry
mbr[510:512] = b"\x55\xaa"
with open(img, "r+b") as f:
    f.write(mbr)
