# x64 and Rust: what exists and what is needed

**Nothing of x64 or Rust is in v8.** It was not possible to start honestly: the build machine used for v7/v8 has
no `nasm`, no cross compiler for x86-64, no `rustc`/`cargo`, no QEMU, so no line of 64-bit or Rust code could even
be compiled, let alone booted. The installer's "x64" button is shown and clearly refused instead of pretending.
What v8 does add for it: CPUID detection (Settings > System shows whether the CPU is 64-bit capable),
the installer flag `INST_FLAG_X64` (reserved, rejected), and a host test rig (tools/hosttest) that makes
porting filesystem/parsing code to Rust testable.

## Plan, in the order that works
1. Toolchain on the build machine: `nasm`, `x86_64-elf-gcc`, `rustup` (nightly, `x86_64-unknown-none` and
   `i686-unknown-none` targets), `qemu-system-x86_64`, `grub-mkrescue`+`grub-efi-amd64-bin`, `ovmf`.
2. Rust first, still 32-bit: a `no_std` staticlib linked into the existing kernel through the C ABI
   (`extern "C"`), `#[panic_handler]` calling `PANIC()`, allocator = `kmalloc`/`kfree`. Port leaf code with host
   tests: `fsx.c` (already has a test rig), PNG/inflate, MP3 decoder, blit/scaler loops. Rust gives bounds checks
   exactly where the fuzzer found trouble.
3. 64-bit kernel: long-mode entry (multiboot -> PAE + PML4 identity map -> GDT64 -> `lretq`), `-mcmodel=kernel`,
   64-bit ISR stubs, fix the many `(uint32_t)pointer` casts (DMA tables, `app_ptr_valid`, ELF-less `.app` loader),
   syscall ABI for apps stays 32-bit until the loader runs them in compatibility mode.
4. UEFI: a GRUB `x86_64-efi` image on a FAT32 ESP + GPT in the installer (`/EFI/BOOT/BOOTX64.EFI`),
   keeping the BIOS/MBR path for x86. The installer page already has the x86 / x64 choice.
5. Switch at run time: a 32-bit stage-1 that checks `cpu_has_long_mode()` (kernel/cpuinfo.c) and jumps to the
   64-bit kernel when present.

## Measured today (v8, fourth round)
* `gcc -m64 -ffreestanding -Wpointer-to-int-cast` over kernel/ + desktop/: **110 pointer<->int casts in 18 files**
  block a 64-bit build (idt.c 50, syscall.c 19, kheap.c 6, ahci.c 5, startmenu.c 5, vesa.c 4, ...). The host
  compiler *can* target x86-64, so this count is real, and fixing them can be checked by compiling.
* What cannot be checked here: booting. No QEMU/Bochs, no GRUB tools, no nasm (GNU `as` exists).
* Apps are 32-bit code run inside the kernel; a 64-bit kernel needs a compatibility-mode loader for them.
* `SYSTEM/rust/` holds an experimental, never-compiled `no_std` crate (rs_fnv1a, rs_read_le32) as a starting
  point; it is not part of the default build.
