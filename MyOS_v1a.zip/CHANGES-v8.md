# MyOS v8 -- changes (base: v7_1 + hw-fix-3 + hdd-perf-fix-2)

NOT boot-tested: only compile-checked (gcc -m32) and SDK apps built. Test in QEMU first.

1. Perf: includes hdd-perf-fix-2 (ATA read cache, deferred FAT flush).
2. Boot splash: bigger "MyOS", smaller spinner, timer-IRQ driven (pit_set_hook), stopped before desktop / on fatal error.
3. installer.app is not copied to the hard disk (installer.c skip_paths).
4. Start menu: "Pinned" block, Pin to Start / Unpin (Start menu + Explorer context menu).
5. Taskbar docking bottom/top/left/right (taskbar right-click menu), saved in settings.ini [taskbar] dock=.
6. New apps: Stopwatch (+timer), Minesweeper, 2048 (apps-sdk/examples).
7. Explorer restyled to the system dark theme; file icons for text / music / picture (res/icons/file_*.png).
8. My PC lists every volume: ATA partitions (MBR, logical, GPT) and CD/DVD (ATAPI) with detected filesystem
   (FAT12/16/32, exFAT, NTFS, ext2/3/4, ISO9660, swap, Btrfs, XFS, HFS+, BitLocker). Only the system FAT32 volume is browsable.
   USB flash drives: not possible, there is no USB stack in the kernel.
9. update.app (APPS/update): from the Live ISO updates an installed MyOS in place, no partitioning/formatting,
   /Users untouched, existing /Drivers/*.drv kept. New syscall SYS_UPDATE_BEGIN (86).

## Second round (still NOT boot-tested)
- Slow HDD boot: ATA bus-master DMA (64 KiB per command, automatic fallback to PIO); the boot splash now keeps
  spinning through the desktop's own start-up instead of freezing before it.
- Sound lag (VirtualBox AC97): ring 8 -> 16 buffers, 50 ms timer keep-alive so the DMA engine never runs into
  the "last valid index" and halts, underrun resync so audio is not delayed by a whole ring after a stall.
- Shortcuts: Alt+Tab, Win key / Ctrl+Esc (Start menu), Print Screen (BMP in Pictures/Screenshots),
  window snapping (drag to left/right edge = half screen, top = maximize, with preview),
  click the far end of the taskbar = show desktop.
- Animations: windows glide in, Start menu slides up.
- Paint: dark UI, Fill / Pick (eyedropper) / Spray tools, undo/redo (Ctrl+Z / Ctrl+Y, 8 deep), hue strip,
  [ ] brush size, Ctrl+S, much faster canvas drawing.
- Drivers: Serial COM1 (kernel log mirror), PC speaker; new /Drivers/system category.
- SDK: myos_blit_scaled, myos_toast, myos_speaker_beep, <myos/anim.h>, <myos/gfx3d.h> (software 3D),
  example apps stopwatch / minesweeper / game2048 / cube3d (cube3d verified in the host simulator).
- "2D/3D acceleration" here means optimised software rendering. There is no GPU driver.

## Third round
- ROOT CAUSE of missing update.app / icons / .ani cursors: the FAT32 driver dropped every directory entry after
  a long name that crossed a cluster boundary (512-byte clusters => /APPS, /SYSTEM/res/icons, /SYSTEM/res/cursors
  were truncated). Fixed in fat32.c (found with the new host test rig tools/hosttest).
- Also fixed: fsu_find/installer skipped read-only/hidden/system files; NT lowercase flags for 8.3 names are honoured;
  FAT chain lookups are bounds-checked.
- Boot hang from disk: ATA DMA (my change) is now OFF by default (Drivers/system/ata.drv dma=0); the splash shows
  the current boot step with seconds, and the same lines go to COM1. If it still stalls, the last line says where.
- Cursor: drawn from the mouse interrupt, follows the hand even if a program hangs; after 0.7 s without a
  desktop heartbeat the animated busy pointer is shown automatically.
- Other drives in My PC are now openable (read-only): ext2/3/4, ISO 9660 (+Joliet), FAT12/16/32 (kernel/fsx.c).
  Files are copied to /Users/User/Downloads before opening. NTFS, exFAT, Btrfs, XFS: recognised only.
- Installer: optional "Keep my files" (backs up /Users to RAM, up to 48 MB, restores after the format; off by
  default) and a system-type choice (x86 default; x64 refused, see ROADMAP-x64-rust.md).
- Settings: processor / 64-bit info, taskbar position, animations toggle, PC speaker test.
- fat32.c: a directory whose cluster number is impossible (damaged entry, text read as a directory) is shown as
  empty instead of being read; the remaining fuzz crash is gone.

## Fourth round
- SATA: new AHCI driver (kernel/ahci.c). VirtualBox's default disk controller is SATA/AHCI, which the kernel did
  not support (boot_fatal said so). SATA disks appear as ata devices 4..9; FAT32, installer, My PC all work on them.
  Tested only against a software model of an AHCI controller (strict about structure sizes/alignment), not real hardware.
- Update from the installed system: update.app now takes the new files from the ISO in the CD/DVD drive
  (/boot/f32.disk mounted through a loop device, kernel/loopdev.c) and updates the running disk in place; /Users and
  edited /Drivers/*.drv stay. Verified with the real installer.c on a fake disk (tools/hosttest/installtest.c).
- NTFS and exFAT are now readable (read-only) in My PC (fsx.c). NTFS: MFT fixups, resident/non-resident/sparse data,
  attribute lists, directory B-tree; compressed/encrypted files are not readable. Verified on generated images + fuzz.
- Disk-boot hang: the ATA driver was run against an IDE controller model (4 MiB read = 27k port accesses) and the
  installer's output and FAT32 write path were checked on fake disks: none of that can take minutes, so the cause is
  NOT in the PIO driver, FAT32 or the installer. Most likely candidates left: SATA disk (now supported), GRUB
  hand-over, or the DMA I had enabled (now off). The boot-step line on the splash will say where it stops.
- Rust scaffold (experimental, uncompiled) in SYSTEM/rust; roadmap updated with measured 64-bit porting numbers.
