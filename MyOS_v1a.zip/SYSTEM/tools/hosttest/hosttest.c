/* Host test harness: runs the kernel's REAL fat32.c / fs_util.c against a disk image file
 * (build one with fatimg.py) and reports what the boot-time access pattern costs.
 * Freestanding 32-bit static program (no libc): uses Linux int 0x80 directly. */
#include "stdint.h"
#include "fat32.h"
#include "fs_util.h"
#include "ata_pio_drv.h"
#include "common.h"
#include "fsx.h"

static int sys3(int n, int a, int b, int c) { int r; __asm__ volatile("int $0x80" : "=a"(r) : "0"(n), "b"(a), "c"(b), "d"(c) : "memory"); return r; }
static void out(const char *s) { int n = 0; while(s[n]) n++; sys3(4, 1, (int)s, n); }

/* ---- stubs for kernel services ---- */
static char heap[200 * 1024 * 1024]; static uint32_t heap_pos;
void *kmalloc(uint32_t n) { n = (n + 15) & ~15u; if(heap_pos + n > sizeof(heap)) return 0; void *p = heap + heap_pos; heap_pos += n; return p; }
void kfree(void *p) { (void)p; }
void *krealloc(void *p, uint32_t n) { void *q = kmalloc(n); if(q && p) memcpy(q, p, n); return q; }
void fastcp(char *d, char *s, uint32_t n) { memcpy(d, s, n); }
void halt(void) { sys3(1, 1, 0, 0); }
static void host_putchar(char c) { sys3(4, 1, (int)&c, 1); }
void (*terminal_putchar)(char c) = host_putchar;
void make_vesa_color(void) {} void set_vesa_background(void) {} void set_vesa_color(void) {}
void terminal_set_cursor(void) {} void terminal_set_status(void) {} void terminal_write_dec(int v) { char b[16]; int n = 0; if(v < 0) { out("-"); v = -v; } char t[12]; int k = 0; if(!v) t[k++] = '0'; while(v) { t[k++] = '0' + v % 10; v /= 10; } while(k) b[n++] = t[--k]; b[n] = 0; out(b); }
void terminal_write_hex(void) {} void terminal_writestring(const char *s) { out(s); }
void rtc_read_date(void *d) { memset(d, 0, 4); } void rtc_read_time(void *t) { memset(t, 0, 3); }

/* ---- fake ATA disk backed by the image file, with counters ---- */
static int img_fd = -1;
static uint32_t reads, sectors_read, writes, sectors_written;
int ata_dev_read(int d, uint64_t lba, uint32_t n, void *buf) {
    (void)d; reads++; sectors_read += n;
    sys3(19, img_fd, (int)((lba) * 512), 0);
    return sys3(3, img_fd, (int)buf, (int)(n * 512)) == (int)(n * 512) ? 0 : -1;
}
int ata_dev_read_stream(int d, uint64_t lba, uint32_t n, void *buf) { return ata_dev_read(d, lba, n, buf); }
int ata_dev_write(int d, uint64_t lba, uint32_t n, const void *buf) {
    (void)d; writes++; sectors_written += n;
    sys3(19, img_fd, (int)(lba * 512), 0);
    return sys3(4, img_fd, (int)buf, (int)(n * 512)) == (int)(n * 512) ? 0 : -1;
}
int ata_atapi_read(int d, uint32_t lba, uint32_t n, void *buf) {
    (void)d; reads++; sectors_read += n;
    sys3(19, img_fd, (int)(lba * 2048), 0);
    return sys3(3, img_fd, (int)buf, (int)(n * 2048)) == (int)(n * 2048) ? 0 : -1;
}
void ata_defer_flush(int on) { (void)on; }
void ata_set_default_device(int d) { (void)d; }

static void num(const char *label, uint32_t v) {
    char b[48]; int n = 0; char t[12]; int k = 0;
    if(!v) t[k++] = '0'; while(v) { t[k++] = '0' + v % 10; v /= 10; }
    while(k) b[n++] = t[--k]; b[n++] = '\n'; b[n] = 0;
    out(label); out(b);
}

static int list(const char *path, int depth) {
    struct directory d;
    if(!fsu_open_dir(path, &d)) { out("  !! cannot open "); out(path); out("\n"); return 0; }
    int count = 0;
    for(uint32_t i = 0; i < d.num_entries; i++) {
        struct dir_entry *e = &d.entries[i];
        if(!e->name || (e->dir_attrs & LFN) == LFN || e->name[0] == '.') continue;
        for(int k = 0; k < depth; k++) out("  ");
        out(e->name); out((e->dir_attrs & DIRECTORY) ? "/\n" : "\n");
        count++;
        if(e->dir_attrs & DIRECTORY) {
            char sub[128]; int n = 0;
            for(const char *p = path; *p; p++) sub[n++] = *p;
            if(n > 1) sub[n++] = '/';
            for(const char *p = e->name; *p; p++) sub[n++] = *p;
            sub[n] = 0;
            count += list(sub, depth + 1);
        }
    }
    free_directory(master_fs, &d);
    return count;
}

static uint32_t fnv(const uint8_t *p, uint32_t n) { uint32_t h = 2166136261u; for(uint32_t i = 0; i < n; i++) { h ^= p[i]; h *= 16777619u; } return h; }

static void hexnum(const char *label, uint32_t v) { char b[16]; for(int i = 0; i < 8; i++) b[i] = "0123456789abcdef"[(v >> (28 - 4 * i)) & 15]; b[8] = '\n'; b[9] = 0; out(label); out(b); }

static uint32_t part_off = 0;
static int dump_depth = 0;
static void dump(const char *path) {
    struct directory d;
    if(dump_depth > 12) return;            /* a corrupted image can make a directory contain itself */
    dump_depth++;
    if(!fsu_open_dir(path, &d)) { out("!! cannot open dir "); out(path); out("\n"); return; }
    for(uint32_t i = 0; i < d.num_entries; i++) {
        struct dir_entry *e = &d.entries[i];
        if(!e->name || (e->dir_attrs & LFN) == LFN || e->name[0] == '.' ) continue;
        char sub[300]; int n = 0;
        for(const char *p = path; *p; p++) sub[n++] = *p;
        if(n > 1) sub[n++] = '/';
        for(const char *p = e->name; *p && n < 290; p++) sub[n++] = *p;
        sub[n] = 0;
        if(e->dir_attrs & DIRECTORY) { out("D "); out(sub); out("\n"); dump(sub); }
        else {
            uint32_t size = 0; uint8_t *data = fsu_read_file(sub, &size);
            out("F "); out(sub); out(" "); num("", size);
            if(data) { out("H "); hexnum("", fnv(data, size)); } else out("H READFAIL\n");
        }
    }
    free_directory(master_fs, &d);
    dump_depth--;
}

static int xmode(const char *type, const char *cmd) {
    volume_t v; memset(&v, 0, sizeof(v));
    v.dev = 0; v.part_lba = part_off; v.sectors = 1 << 20;
    if(!strcmp(type, "fat32")) v.fs = FS_FAT32; else if(!strcmp(type, "fat16")) v.fs = FS_FAT16; else if(!strcmp(type, "fat12")) v.fs = FS_FAT12;
    else if(!strcmp(type, "ext2")) v.fs = FS_EXT2; else if(!strcmp(type, "ext3")) v.fs = FS_EXT3; else if(!strcmp(type, "ext4")) v.fs = FS_EXT4;
    else if(!strcmp(type, "iso")) { v.fs = FS_ISO9660; v.optical = 1; }
    else if(!strcmp(type, "exfat")) v.fs = FS_EXFAT; else if(!strcmp(type, "ntfs")) v.fs = FS_NTFS;
    master_fs = fsx_mount(&v);
    if(!master_fs) { out("MOUNT FAILED\n"); return 2; }
    out("MOUNTED\n");
    if(!strcmp(cmd, "all")) dump("/");
    if(!strcmp(cmd, "ls")) {
        struct directory d; fsu_open_dir("/", &d); num("n=", d.num_entries);
        for(uint32_t i = 0; i < d.num_entries; i++) { out(d.entries[i].name); out(" size="); num("", d.entries[i].file_size); out(" lba="); num("", d.entries[i].first_cluster); }
        int idx = d.num_entries ? fsu_find(&d, d.entries[0].name) : -9; num("find first=", idx);
        if(d.num_entries) { uint8_t *p = readFile(master_fs, &d.entries[1]); out(p ? "readFile ok\n" : "readFile NULL\n"); }
    }
    return 0;
}

int main(int argc, char **argv) {
    if(argc > 3 && argv[2][0] == '-' && argv[2][1] == 'p') { uint32_t v = 0; for(const char *q = argv[3]; *q; q++) v = v * 10 + (*q - '0'); part_off = v; argv[2] = argv[0]; argv[3] = argv[1]; argv += 2; argc -= 2; }
    if(argc < 2) { out("usage: hosttest image [path-to-read ...]\n"); return 1; }
    img_fd = sys3(5, (int)argv[1], 2, 0);
    if(img_fd < 0) { out("cannot open image\n"); return 1; }
    fat32_set_ata_backend(0, part_off);
    if(argc > 3 && argv[2][0] == '-' && argv[2][1] == 'x') return xmode(argv[3], argv[4]);
    master_fs = makeFilesystemOn(0, part_off);
    if(!master_fs) { out("MOUNT FAILED\n"); return 2; }
    num("mount: sector reads=", reads); num("mount: sectors=", sectors_read);

    if(argc > 2 && argv[2][0] == '-' && argv[2][1] == 'l') {      /* -l <dir>: flat listing with attrs */
        struct directory d;
        if(!fsu_open_dir(argv[3], &d)) { out("cannot open\n"); return 3; }
        num("num_entries=", d.num_entries);
        for(uint32_t i = 0; i < d.num_entries; i++) { num("  attr=", d.entries[i].dir_attrs); out("    "); out(d.entries[i].name ? d.entries[i].name : "(null)"); out("\n"); }
        return 0;
    }
    if(argc > 2 && argv[2][0] == '-' && argv[2][1] == 'w') {          /* -w: one small file write, count the disk traffic */
        uint32_t w0 = sectors_written, c0 = writes;
        static uint8_t small[200]; memset(small, 'x', sizeof(small));
        fsu_write_file("/settings_probe.ini", small, sizeof(small));
        num("one 200-byte file: sectors written=", sectors_written - w0); num("   write calls=", writes - c0);
        w0 = sectors_written; c0 = writes;
        fsu_write_file("/settings_probe.ini", small, 100);
        num("overwrite it: sectors written=", sectors_written - w0); num("   write calls=", writes - c0);
        return 0;
    }
    if(argc > 2 && argv[2][0] == '-' && argv[2][1] == 't') {      /* write/delete stress test */
        int fails = 0;
        if(!fsu_mkdir("/WTEST")) { out("mkdir failed\n"); fails++; }
        static uint8_t buf[3000];
        for(int i = 0; i < 40; i++) {
            char path[64] = "/WTEST/long_file_name_number_", t[4];
            int n = 29; t[0] = '0' + i / 10; t[1] = '0' + i % 10; t[2] = 0;
            path[n++] = t[0]; path[n++] = t[1]; path[n++] = '.'; path[n++] = 't'; path[n++] = 'x'; path[n++] = 't'; path[n] = 0;
            for(int k = 0; k < (int)sizeof(buf); k++) buf[k] = (uint8_t)(i * 7 + k);
            if(!fsu_write_file(path, buf, 1000 + i * 40)) { out("write failed: "); out(path); out("\n"); fails++; }
        }
        struct directory d; int cnt = 0;
        fsu_open_dir("/WTEST", &d);
        for(uint32_t i = 0; i < d.num_entries; i++) if(d.entries[i].name && d.entries[i].name[0] != '.') cnt++;
        num("files in /WTEST after writing 40 (expect 40) = ", cnt);
        /* read back and verify a few */
        for(int i = 0; i < 40; i += 7) {
            char path[64] = "/WTEST/long_file_name_number_"; int n = 29;
            path[n++] = '0' + i / 10; path[n++] = '0' + i % 10; path[n++] = '.'; path[n++] = 't'; path[n++] = 'x'; path[n++] = 't'; path[n] = 0;
            uint32_t size = 0; uint8_t *data = fsu_read_file(path, &size);
            int ok = data && size == (uint32_t)(1000 + i * 40);
            for(uint32_t k = 0; ok && k < size; k++) if(data[k] != (uint8_t)(i * 7 + k)) ok = 0;
            if(!ok) { out("verify FAILED: "); out(path); out("\n"); fails++; }
        }
        for(int i = 0; i < 40; i += 2) {
            char path[64] = "/WTEST/long_file_name_number_"; int n = 29;
            path[n++] = '0' + i / 10; path[n++] = '0' + i % 10; path[n++] = '.'; path[n++] = 't'; path[n++] = 'x'; path[n++] = 't'; path[n] = 0;
            if(!fsu_delete_file(path)) { out("delete failed: "); out(path); out("\n"); fails++; }
        }
        cnt = 0; fsu_open_dir("/WTEST", &d);
        for(uint32_t i = 0; i < d.num_entries; i++) if(d.entries[i].name && d.entries[i].name[0] != '.') cnt++;
        num("files after deleting 20 (expect 20) = ", cnt);
        num("FAILS = ", fails);
        num("total sectors written = ", sectors_written); num("write calls = ", writes);
        return fails;
    }
    out("--- tree ---\n");
    uint32_t r0 = reads, s0 = sectors_read;
    int n = list("/", 0);
    num("entries listed=", n); num("listing reads=", reads - r0); num("listing sectors=", sectors_read - s0);

    for(int i = 2; i < argc; i++) {
        uint32_t size = 0, rr = reads;
        uint8_t *data = fsu_read_file(argv[i], &size);
        out("read "); out(argv[i]); out(data ? " ok size=" : " FAILED size=");
        num("", size); num("   reads=", reads - rr);
    }
    num("TOTAL reads=", reads); num("TOTAL sectors=", sectors_read);
    return 0;
}

void _real_start(int argc, char **argv) { int r = main(argc, argv); sys3(1, r, 0, 0); }
__asm__(".global _start\n_start:\n xor %ebp,%ebp\n mov (%esp),%eax\n lea 4(%esp),%edx\n push %edx\n push %eax\n call _real_start\n");
