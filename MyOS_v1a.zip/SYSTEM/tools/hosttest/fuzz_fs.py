#!/usr/bin/env python3
"""Corrupts images at random and checks that the drivers never crash or hang (exit by signal / timeout)."""
import os, random, shutil, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
ALL = [('/tmp/ext2-1024.img','ext2'),('/tmp/ext3-4096.img','ext3'),('/tmp/ext4-1024.img','ext4'),('/tmp/ext4-4096.img','ext4'),
         ('/tmp/f16.img','fat16'),('/tmp/f12.img','fat12'),('/tmp/plain.iso','iso'),('/tmp/joliet.iso','iso'),('/tmp/test.img','fat32'),('/tmp/exfat.img','exfat'),('/tmp/ntfs.img','ntfs')]
cases = [c for c in ALL if len(sys.argv) < 3 or sys.argv[2] in c[0]]
TRIALS = int(sys.argv[3]) if len(sys.argv) > 3 else 40
random.seed(int(sys.argv[1]) if len(sys.argv) > 1 else 1)
bad = 0; runs = 0
for img, typ in cases:
    size = os.path.getsize(img)
    for trial in range(TRIALS):
        work = '/tmp/fuzz.img'; shutil.copy(img, work)
        with open(work, 'r+b') as f:
            data_end = min(size, 1200 * 1024)               # metadata-heavy region + start of data
            for _ in range(random.choice([1, 4, 16, 64, 256])):
                f.seek(random.randrange(0, data_end)); f.write(bytes([random.randrange(256)]))
            if trial % 5 == 0:                               # also zero a whole block
                f.seek(random.randrange(0, data_end) & ~511); f.write(b'\0' * random.choice([512, 2048, 4096]))
        runs += 1
        try:
            r = subprocess.run([os.path.join(HERE, 'hosttest-bin'), work, '-x', typ, 'all'], capture_output=True, timeout=8)
            if r.returncode < 0 or r.returncode == 139:
                print('CRASH', typ, img, 'trial', trial, 'rc', r.returncode); bad += 1; shutil.copy(work, '/tmp/crash_%s_%d.img' % (typ, trial))
        except subprocess.TimeoutExpired:
            print('HANG', typ, img, 'trial', trial); bad += 1; shutil.copy(work, '/tmp/hang_%s_%d.img' % (typ, trial))
print('runs=%d problems=%d' % (runs, bad))
sys.exit(1 if bad else 0)
