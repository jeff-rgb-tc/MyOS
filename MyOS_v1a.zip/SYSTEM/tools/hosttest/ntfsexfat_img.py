#!/usr/bin/env python3
"""Generators for exFAT and NTFS test images (written from the on-disk specs, including the awkward parts:
exFAT NoFatChain + FAT chains, NTFS fixups, resident/non-resident/sparse data, index B-tree, attribute list).
usage: ntfsexfat_img.py exfat|ntfs <out.img> <src-dir>"""
import os, struct, sys

# ============================ exFAT ============================
def build_exfat(src, out, size_mb=64):
    SS = 9; SPC = 3; CS = 512 << SPC                                   # 4 KiB clusters
    total = size_mb * 2048
    fat_off, fat_len = 24, 0
    heap_off = 0
    clusters = 0
    for fl in range(1, 4096):                                          # settle FAT length / heap offset
        heap = ((fat_off + fl + 7) // 8) * 8
        cl = (total - heap) >> SPC
        if (cl + 2) * 4 <= fl * 512: fat_len, heap_off, clusters = fl, heap, cl; break
    img = bytearray(total * 512)
    fat = [0] * (clusters + 2); fat[0] = 0xFFFFFFF8; fat[1] = 0xFFFFFFFF
    nxt = [2]
    def alloc_contig(n):
        c = nxt[0]; nxt[0] += n; assert nxt[0] <= clusters + 2; return c
    def write(c, data):
        o = (heap_off + ((c - 2) << SPC)) * 512; img[o:o + len(data)] = data
    def chain_alloc(n, interleave):
        cl = []
        for i in range(n):
            cl.append(alloc_contig(1))
            if interleave: alloc_contig(1)                              # leave a gap -> a fragmented FAT chain
        for a, b in zip(cl, cl[1:]): fat[a] = b
        fat[cl[-1]] = 0xFFFFFFFF
        return cl
    def entry_set(name, is_dir, first, size, nofat):
        nb = [name[i:i + 15] for i in range(0, len(name), 15)]
        sec = 1 + len(nb)
        f = bytearray(32); f[0] = 0x85; f[1] = sec; struct.pack_into('<H', f, 4, 0x10 if is_dir else 0x20)
        st = bytearray(32); st[0] = 0xC0; st[1] = 0x01 | (0x02 if nofat else 0); st[3] = len(name)
        struct.pack_into('<H', st, 4, 0x1234); struct.pack_into('<Q', st, 8, size); struct.pack_into('<I', st, 20, first); struct.pack_into('<Q', st, 24, size)
        names = []
        for part in nb:
            e = bytearray(32); e[0] = 0xC1; e[2:2 + len(part) * 2] = part.encode('utf-16-le'); names.append(e)
        blob = bytes(f) + bytes(st) + b''.join(bytes(n) for n in names)
        ck = 0
        for i, b in enumerate(blob):
            if i in (2, 3): continue
            ck = (((ck << 15) | (ck >> 1)) + b) & 0xFFFF
        b2 = bytearray(blob); struct.pack_into('<H', b2, 2, ck)
        return bytes(b2)
    counter = [0]
    def build_dir(path, is_root=False):
        ents = bytearray()
        if is_root:
            lab = bytearray(32); lab[0] = 0x83; lab[1] = 4; lab[2:10] = 'TEST'.encode('utf-16-le'); ents += lab
            bm = bytearray(32); bm[0] = 0x81; ents += bm
            up = bytearray(32); up[0] = 0x82; ents += up
        for n in sorted(os.listdir(path)):
            p = os.path.join(path, n)
            counter[0] += 1
            if os.path.isdir(p):
                first, size, nofat = build_dir(p)
                ents += entry_set(n, True, first, size, nofat)
            else:
                d = open(p, 'rb').read()
                if not d: ents += entry_set(n, False, 0, 0, False); continue
                nclu = (len(d) + CS - 1) // CS
                frag = counter[0] % 3 == 0 and nclu > 1                  # every 3rd file uses a fragmented FAT chain
                if frag:
                    cl = chain_alloc(nclu, True)
                    for i, c in enumerate(cl): write(c, d[i * CS:(i + 1) * CS])
                    ents += entry_set(n, False, cl[0], len(d), False)
                else:
                    c = alloc_contig(nclu); write(c, d); ents += entry_set(n, False, c, len(d), True)
        ents += b'\0' * 32
        nclu = max(1, (len(ents) + CS - 1) // CS)
        if is_root or counter[0] % 2:                                    # root and some dirs: FAT chain
            cl = chain_alloc(nclu, False)
            for i, c in enumerate(cl): write(c, bytes(ents[i * CS:(i + 1) * CS]))
            return cl[0], len(ents), False
        c = alloc_contig(nclu); write(c, bytes(ents)); return c, nclu * CS, True
    root, _, _ = build_dir(src, True)
    vbr = bytearray(512); vbr[0:3] = b'\xEB\x76\x90'; vbr[3:11] = b'EXFAT   '
    struct.pack_into('<QQIIIIIIHH', vbr, 64, 0, total, fat_off, fat_len, heap_off, clusters, root, 0x12345678, 0x0100, 0)
    vbr[108] = SS; vbr[109] = SPC; vbr[110] = 1; vbr[510] = 0x55; vbr[511] = 0xAA
    img[0:512] = vbr
    raw = b''.join(struct.pack('<I', v) for v in fat)
    img[fat_off * 512:fat_off * 512 + len(raw)] = raw
    open(out, 'wb').write(img)

# ============================ NTFS ============================
REC = 1024; CLS = 4096; IDX = 4096
def align8(n): return (n + 7) & ~7

def utf16(s): return s.encode('utf-16-le')

def attr_res(atype, name, value, aid):
    nb = utf16(name) if name else b''
    voff = align8(24 + len(nb))
    total = align8(voff + len(value))
    a = bytearray(total)
    struct.pack_into('<IIBBHHH', a, 0, atype, total, 0, len(name or ''), 24 if nb else 0, 0, aid)
    struct.pack_into('<IHBB', a, 16, len(value), voff, 0, 0)
    a[24:24 + len(nb)] = nb; a[voff:voff + len(value)] = value
    return bytes(a)

def encode_runs(runs):
    out = bytearray(); prev = 0
    for (length, lcn) in runs:                                           # lcn None = sparse
        ls = (max(length.bit_length(), 1) + 7) // 8
        if lcn is None:
            out.append(ls); out += length.to_bytes(ls, 'little'); continue
        delta = lcn - prev; prev = lcn
        os_ = 1
        while not (-(1 << (8 * os_ - 1)) <= delta < (1 << (8 * os_ - 1))): os_ += 1
        out.append(ls | (os_ << 4)); out += length.to_bytes(ls, 'little'); out += delta.to_bytes(os_, 'little', signed=True)
    out.append(0)
    return bytes(out)

def attr_nonres(atype, name, runs, real, init, alloc, aid, svcn=0, evcn=None, flags=0):
    nb = utf16(name) if name else b''
    rl = encode_runs(runs)
    roff = align8(64 + len(nb))
    total = align8(roff + len(rl))
    a = bytearray(total)
    nclu = sum(l for l, _ in runs)
    struct.pack_into('<IIBBHHH', a, 0, atype, total, 1, len(name or ''), 64 if nb else 0, flags, aid)
    struct.pack_into('<QQHHIQQQ', a, 16, svcn, (svcn + nclu - 1) if evcn is None else evcn, roff, 0, 0, alloc, real, init)
    a[64:64 + len(nb)] = nb; a[roff:roff + len(rl)] = rl
    return bytes(a)

def build_record(no, attrs, is_dir, base=0, in_use=True):
    rec = bytearray(REC)
    rec[0:4] = b'FILE'; struct.pack_into('<HH', rec, 4, 48, REC // 512 + 1)
    struct.pack_into('<HHH', rec, 16, 1, 1, 56)
    struct.pack_into('<H', rec, 22, (1 if in_use else 0) | (2 if is_dir else 0))
    body = b''.join(attrs) + struct.pack('<I', 0xFFFFFFFF) + b'\0' * 4
    used = 56 + len(body)
    assert used <= REC, 'record %d overflows (%d)' % (no, used)
    struct.pack_into('<II', rec, 24, used, REC)
    struct.pack_into('<QHHI', rec, 32, base, 4 + len(attrs), 0, no)
    rec[56:56 + len(body)] = body
    usn = 0x0007
    usa = bytearray(2 * (REC // 512 + 1)); struct.pack_into('<H', usa, 0, usn)
    for i in range(1, REC // 512 + 1):
        usa[2 * i:2 * i + 2] = rec[i * 512 - 2:i * 512]; struct.pack_into('<H', rec, i * 512 - 2, usn)
    rec[48:48 + len(usa)] = usa
    return bytes(rec)

def fname_value(parent, name, size, is_dir):
    v = bytearray(66 + 2 * len(name))
    struct.pack_into('<Q', v, 0, parent | (1 << 48))
    struct.pack_into('<QQ', v, 40, size, size); struct.pack_into('<I', v, 56, 0x10000000 if is_dir else 0x20)
    v[64] = len(name); v[65] = 1; v[66:] = utf16(name)
    return bytes(v)

def index_entry(fileref, key, subvcn=None, last=False):
    klen = 0 if last else len(key)
    elen = align8(16 + klen) + (8 if subvcn is not None else 0)
    e = bytearray(elen)
    struct.pack_into('<QHHH', e, 0, 0 if last else fileref | (1 << 48), elen, klen, (1 if subvcn is not None else 0) | (2 if last else 0))
    e[16:16 + klen] = key
    if subvcn is not None: struct.pack_into('<Q', e, elen - 8, subvcn)
    return bytes(e)

def build_ntfs(src, out, size_mb=64):
    total = size_mb * 2048
    img = bytearray(total * 512)
    nclusters = total // 8
    MFT_LCN = 4; MFT_CL = 100                                            # 400 records of 1 KiB
    NREC = MFT_CL * CLS // REC
    next_cluster = [128]
    def alloc(n):
        c = next_cluster[0]; next_cluster[0] += n; assert next_cluster[0] < nclusters; return c
    def put(lcn, data): img[lcn * CLS:lcn * CLS + len(data)] = data
    records = {}
    next_rec = [24]
    def new_rec():
        n = next_rec[0]; next_rec[0] += 1; assert n < 64 + 0 or True; return n
    ext_note = []

    def data_attrs(data, aid=3, force_ext=False):
        """-> (attribute bytes, is_nonres, size)."""
        if len(data) <= 500 and not force_ext:
            return attr_res(0x80, None, data, aid), len(data)
        ncl = (len(data) + CLS - 1) // CLS
        # sparse: any fully-zero, cluster-aligned cluster becomes a hole; fragment into runs
        runs = []; i = 0
        while i < ncl:
            chunk = data[i * CLS:(i + 1) * CLS].ljust(CLS, b'\0')
            hole = (not any(chunk)) and (i + 1) * CLS <= len(data)
            j = i + 1
            while j < ncl:
                c2 = data[j * CLS:(j + 1) * CLS].ljust(CLS, b'\0')
                h2 = (not any(c2)) and (j + 1) * CLS <= len(data)
                if h2 != hole or (not hole and (j - i) >= 5): break           # fragment real data every 5 clusters
                j += 1
            if hole: runs.append((j - i, None))
            else:
                lcn = alloc(j - i); put(lcn, data[i * CLS:j * CLS]); runs.append((j - i, lcn)); alloc(1)   # gap -> fragmented
            i = j
        return attr_nonres(0x80, None, runs, len(data), len(data), ncl * CLS, aid), len(data)

    def build_dir(path, rec_no, parent):
        entries = []
        for n in sorted(os.listdir(path), key=str.upper):
            p = os.path.join(path, n)
            rno = new_rec()
            if os.path.isdir(p):
                build_dir(p, rno, rec_no); entries.append((rno, fname_value(rec_no, n, 0, True)))
            else:
                d = open(p, 'rb').read()
                std = attr_res(0x10, None, b'\0' * 72, 0)
                fn = attr_res(0x30, None, fname_value(rec_no, n, len(d), False), 1)
                if n.startswith('ATTRLIST_'):                              # DATA lives in an extension record
                    ext = new_rec()
                    da, _ = data_attrs(d, 3, True)
                    records[ext] = build_record(ext, [da], False, base=rno)
                    ent = bytearray()
                    def le(t, rno_, aid): 
                        e = bytearray(32); struct.pack_into('<IHBBQQH', e, 0, t, 32, 0, 26, 0, rno_ | (1 << 48), aid); return bytes(e)
                    lst = le(0x10, rno, 0) + le(0x30, rno, 1) + le(0x80, ext, 3)
                    records[rno] = build_record(rno, [std, fn, attr_res(0x20, None, lst, 2)], False)
                else:
                    da, _ = data_attrs(d)
                    records[rno] = build_record(rno, [std, fn, da], False)
                entries.append((rno, fname_value(rec_no, n, len(d), False)))
        # ---- directory index
        std = attr_res(0x10, None, b'\0' * 72, 0)
        fn = attr_res(0x30, None, fname_value(parent, '.' if rec_no == 5 else os.path.basename(path), 0, True), 1)
        if rec_no == 5:                                                   # the root lists some $ system files, like Windows
            for sysno, sname in [(0, '$MFT'), (6, '$Bitmap'), (11, '$Extend')]:
                entries.append((sysno, fname_value(5, sname, 0, False)))
            entries.sort(key=lambda e: e[1][66:].decode('utf-16-le').upper())
        ents = [index_entry(r, k) for r, k in entries]
        small = sum(len(e) for e in ents) + 16 <= 600
        if small:
            body = b''.join(ents) + index_entry(0, b'', None, True)
            nh = struct.pack('<IIII', 16, 16 + len(body), 16 + len(body), 0)
            root = struct.pack('<IIIB3x', 0x30, 1, IDX, 1) + nh + body
            records[rec_no] = build_record(rec_no, [std, fn, attr_res(0x90, '$I30', root, 2)], True)
        else:
            # split into INDX blocks; B-tree: separators move up into the root
            per = 30; chunks = [entries[i:i + per] for i in range(0, len(entries), per)]
            root_ents = []; blocks = []
            for bi, ch in enumerate(chunks):
                sep = None
                if bi + 1 < len(chunks): sep = chunks[bi + 1].pop(0)
                blocks.append(ch)
                if sep: root_ents.append((sep, bi))
            body = b''
            for (r, k), vcn in root_ents: body += index_entry(r, k, vcn)
            body += index_entry(0, b'', len(blocks) - 1, True)
            nh = struct.pack('<IIII', 16, 16 + len(body), 16 + len(body), 1)
            root = struct.pack('<IIIB3x', 0x30, 1, IDX, 1) + nh + body
            runs = []; cl = alloc(len(blocks)); alloc(1)
            for bi, ch in enumerate(blocks):
                es = b''.join(index_entry(r, k) for r, k in ch) + index_entry(0, b'', None, True)
                blk = bytearray(IDX); blk[0:4] = b'INDX'; struct.pack_into('<HH', blk, 4, 40, IDX // 512 + 1)
                struct.pack_into('<Q', blk, 16, bi)
                eoff = 40 + 18 - 24 + 6 if False else 64 - 24                # entries start at byte 64
                struct.pack_into('<IIII', blk, 24, eoff, eoff + len(es), IDX - 24, 0)
                assert 64 + len(es) <= IDX
                blk[64:64 + len(es)] = es
                usn = 0x0009; usa = bytearray(2 * (IDX // 512 + 1)); struct.pack_into('<H', usa, 0, usn)
                for i in range(1, IDX // 512 + 1):
                    usa[2 * i:2 * i + 2] = blk[i * 512 - 2:i * 512]; struct.pack_into('<H', blk, i * 512 - 2, usn)
                blk[40:40 + len(usa)] = usa
                put(cl + bi, bytes(blk))
            alloc_attr = attr_nonres(0xA0, '$I30', [(len(blocks), cl)], len(blocks) * IDX, len(blocks) * IDX, len(blocks) * IDX, 3)
            bm = attr_res(0xB0, '$I30', b'\xff' * 8, 4)
            records[rec_no] = build_record(rec_no, [std, fn, attr_res(0x90, '$I30', root, 2), alloc_attr, bm], True)
    build_dir(src, 5, 5)
    # $MFT (record 0): its DATA is the run list of the whole MFT
    mft_data = attr_nonres(0x80, None, [(MFT_CL, MFT_LCN)], NREC * REC, NREC * REC, MFT_CL * CLS, 3)
    records[0] = build_record(0, [attr_res(0x10, None, b'\0' * 72, 0), attr_res(0x30, None, fname_value(5, '$MFT', NREC * REC, False), 1), mft_data], False)
    for n, r in records.items():
        assert n < NREC, 'too many records for the MFT'
        put(MFT_LCN, b'') ; img[MFT_LCN * CLS + n * REC:MFT_LCN * CLS + (n + 1) * REC] = r
    b = bytearray(512); b[0:3] = b'\xEB\x52\x90'; b[3:11] = b'NTFS    '
    struct.pack_into('<HBHBHBHHHI', b, 11, 512, 8, 0, 0, 0, 0xF8, 0, 63, 255, 0)
    struct.pack_into('<I', b, 36, 0x800080); struct.pack_into('<QQQ', b, 40, total - 1, MFT_LCN, 2)
    b[64] = 0xF6; b[68] = 1; struct.pack_into('<Q', b, 72, 0x1122334455667788); b[510] = 0x55; b[511] = 0xAA
    img[0:512] = b
    open(out, 'wb').write(img)

if __name__ == '__main__':
    kind, out, src = sys.argv[1], sys.argv[2], sys.argv[3]
    (build_exfat if kind == 'exfat' else build_ntfs)(src, out)
    print('wrote', out)
