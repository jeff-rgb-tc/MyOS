#!/bin/sh
# Builds every host test and runs them all. Needs: gcc (-m32 freestanding), python3, mke2fs (e2fsprogs).
# Prints one line per check; exit status != 0 if anything failed.
set -u
HERE=$(cd "$(dirname "$0")" && pwd); SYS=$(cd "$HERE/.." && pwd)/..; SYS=$(cd "$SYS" && pwd); cd "$HERE"
T=${TMPDIR:-/tmp}/myos_ht; rm -rf "$T"; mkdir -p "$T/ft" "$T/xt" "$T/isot" "$T/tree"; fail=0
EXTRA_SRC=$SYS/kernel/fsx.c ./build.sh || exit 1; ./build_install.sh || exit 1
python3 - "$T" <<'PY'
import os, random, sys
T = sys.argv[1]; random.seed(7)
def w(p, n):
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'wb').write(bytes(random.getrandbits(8) for _ in range(n)))
for base in ('ft', 'xt'):
    b = os.path.join(T, base)
    w(b + '/readme.txt', 100); w(b + '/empty.bin', 0); w(b + '/big_file_with_long_name_12345.dat', 300000)
    w(b + '/docs/a.txt', 5000); w(b + '/docs/deep/er/leaf.bin', 70000); w(b + '/Music/song one.mp3', 100000)
    for i in range(40): w(b + '/docs/file_%03d.txt' % i, 10 + i * 50)
for n, sz in (('README.TXT', 100), ('BIG.DAT', 500000), ('DOCS/A.TXT', 5000), ('DOCS/DEEP/LEAF.BIN', 70000)): w(os.path.join(T, 'isot', n), sz)
PY
ok() { if "$@"; then :; else fail=1; fi; }
for t in ext2 ext3 ext4; do for bs in 1024 4096; do
  mke2fs -q -F -t $t -b $bs -d "$T/xt" "$T/$t-$bs.img" 24M >/dev/null 2>&1 && ok python3 verify_fs.py "$T/$t-$bs.img" $t "$T/xt"; done; done
python3 otherimg.py fat16 "$T/f16.img" "$T/ft" >/dev/null && ok python3 verify_fs.py "$T/f16.img" fat16 "$T/ft"
python3 otherimg.py fat12 "$T/f12.img" "$T/ft" >/dev/null && ok python3 verify_fs.py "$T/f12.img" fat12 "$T/ft"
python3 otherimg.py iso "$T/p.iso" "$T/isot" >/dev/null && ok python3 verify_fs.py "$T/p.iso" iso "$T/isot" ci
python3 otherimg.py joliet "$T/j.iso" "$T/ft" >/dev/null && ok python3 verify_fs.py "$T/j.iso" iso "$T/ft"
python3 ntfsexfat_img.py exfat "$T/x.img" "$T/xt" >/dev/null && ok python3 verify_fs.py "$T/x.img" exfat "$T/xt"
python3 ntfsexfat_img.py ntfs "$T/n.img" "$T/xt" >/dev/null && ok python3 verify_fs.py "$T/n.img" ntfs "$T/xt"
python3 fatimg.py "$T/f32.img" 64 1 "$T/ft" >/dev/null && ok python3 verify_fs.py "$T/f32.img" fat32 "$T/ft"
echo "(fuzz: python3 fuzz_fs.py <seed> [filter] [trials] -- edit the image paths at the top first)"
exit $fail
