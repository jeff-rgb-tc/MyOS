#!/usr/bin/env python3
"""verify_fs.py <image> <type> <source-dir>: mounts the image with the kernel's own driver (hosttest-bin -x)
and compares every directory and every file (size + FNV-1a checksum) with the source tree."""
import os, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
def fnv(b):
    h = 2166136261
    for c in b: h = ((h ^ c) * 16777619) & 0xFFFFFFFF
    return h
def expected(root):
    out = set()
    def walk(d, rel):
        for n in sorted(os.listdir(d)):
            p = os.path.join(d, n); r = rel + '/' + n
            if os.path.isdir(p): out.add(('D', r)); walk(p, r)
            else:
                b = open(p, 'rb').read(); out.add(('F', r, len(b), '%08x' % fnv(b)))
    walk(root, '')
    return out
def check(img, typ, src, case_insensitive=False):
    part = os.environ.get('PART')
    cmd = [os.path.join(HERE, 'hosttest-bin'), img] + (['-p', part] if part else []) + ['-x', typ, 'all']
    r = subprocess.run(cmd, capture_output=True)
    txt = r.stdout.decode('latin1')
    if 'MOUNTED' not in txt: print('%-6s %-22s MOUNT FAILED' % (typ, os.path.basename(img))); return False
    got = set(); lines = txt.split('\n'); i = 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith('D '): got.add(('D', ln[2:]))
        elif ln.startswith('F '):
            parts = ln[2:].rsplit(' ', 1)
            hx = lines[i + 1][2:] if i + 1 < len(lines) and lines[i + 1].startswith('H ') else None
            got.add(('F', parts[0], int(parts[1]), hx))
        i += 1
    exp = expected(src)
    if case_insensitive:
        norm = lambda s: set((t[0], t[1].lower()) + t[2:] for t in s)
        exp, got = norm(exp), norm(got)
    got -= {('D', '/lost+found'), ('D', '/LOST+FOUND')}
    missing, extra = exp - got, got - exp
    ok = not missing and not extra
    print('%-6s %-22s %s  files+dirs expected=%d got=%d missing=%d extra=%d' % (typ, os.path.basename(img), 'OK ' if ok else 'BAD', len(exp), len(got), len(missing), len(extra)))
    for m in list(missing)[:5]: print('    missing', m)
    for m in list(extra)[:5]: print('    extra  ', m)
    return ok
if __name__ == '__main__':
    sys.exit(0 if check(sys.argv[1], sys.argv[2], sys.argv[3], len(sys.argv) > 4) else 1)
