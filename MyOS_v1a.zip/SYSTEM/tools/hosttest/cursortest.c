#include "stdint.h"
#include "cursor.h"
#include "cursor_ani.h"
#include "common.h"
static int sys3(int n,int a,int b,int c){int r;__asm__ volatile("int $0x80":"=a"(r):"0"(n),"b"(a),"c"(b),"d"(c):"memory");return r;}
static void out(const char*s){int n=0;while(s[n])n++;sys3(4,1,(int)s,n);}
static void num(const char*l,int v){char b[16],t[12];int n=0,k=0;if(v<0){out("-");v=-v;}if(!v)t[k++]='0';while(v){t[k++]='0'+v%10;v/=10;}while(k)b[n++]=t[--k];b[n++]='\n';b[n]=0;out(l);out(b);}
static char heap[64*1024*1024]; static uint32_t hp;
void *kmalloc(uint32_t n){n=(n+15)&~15u;if(hp+n>sizeof(heap))return 0;void*p=heap+hp;hp+=n;return p;}
void kfree(void*p){(void)p;} void *krealloc(void*p,uint32_t n){void*q=kmalloc(n);if(q&&p)memcpy(q,p,n);return q;}
void terminal_set_cursor(void){} void make_vesa_color(void){} void set_vesa_color(void){} void set_vesa_background(void){} void printf(const char*f,...){out(f);}
void fastcp(char*d,char*s,uint32_t n){memcpy(d,s,n);} void halt(void){sys3(1,1,0,0);}
static uint8_t file[2*1024*1024];
int main(int argc,char**argv){
    for(int i=1;i<argc;i++){
        int fd=sys3(5,(int)argv[i],0,0); if(fd<0){out("open fail\n");continue;}
        int n=sys3(3,fd,(int)file,sizeof(file)); sys3(6,fd,0,0);
        out(argv[i]); num("  bytes=",n);
        int len=0; while(argv[i][len])len++;
        if(argv[i][len-1]=='i'){
            cursor_anim_t a; int ok=cursor_ani_load_from_memory(file,n,&a);
            num("  ani load ok=",ok);
            if(ok){ num("  frames=",a.frame_count); num("  steps=",a.step_count); num("  total_ms=",a.total_ms);
                    num("  frame0 w=",a.frames[0].width); num("  frame0 h=",a.frames[0].height); }
        } else {
            cursor_image_t c; int ok=cursor_load_from_memory(file,n,&c); num("  cur load ok=",ok);
            if(ok){num("  w=",c.width);num("  h=",c.height);}
        }
    }
    return 0;
}
void _real_start(int argc,char**argv){int r=main(argc,argv);sys3(1,r,0,0);}
__asm__(".global _start\n_start:\n xor %ebp,%ebp\n mov (%esp),%eax\n lea 4(%esp),%edx\n push %edx\n push %eax\n call _real_start\n");
