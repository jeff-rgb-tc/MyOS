#!/bin/sh
# Builds the host test harness: ./build.sh  ->  ./hosttest-bin
set -e
HERE=$(cd "$(dirname "$0")" && pwd); SYS=$(cd "$HERE/../.." && pwd); W=$(mktemp -d)
KF="-m32 -O1 -fno-strict-aliasing -fwrapv -ffreestanding -fno-stack-protector -fno-pic -fno-pie -std=gnu99 -w -I$SYS/kernel -I$SYS/desktop -I$SYS/apps-sdk/include -DNO_LIBC_STUBS $EXTRA_CFLAGS"
for f in $SYS/kernel/fat32.c $SYS/kernel/common.c $SYS/kernel/kernio.c $SYS/desktop/fs_util.c $HERE/hosttest.c $EXTRA_SRC; do
  gcc $KF -c $f -o $W/$(basename $f).o
done
LG=$(gcc -m32 -print-libgcc-file-name 2>/dev/null || true); [ -f "$LG" ] || LG=
gcc -m32 -nostdlib -static -no-pie -Wl,--build-id=none -o "${OUT:-$HERE/hosttest-bin}" $W/*.o $LG
rm -rf $W
