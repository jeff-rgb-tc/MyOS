/* Runs the REAL ahci.c against a software model of an AHCI controller (strict about the structures it parses). */
#include "stdint.h"
#include "ahci.h"
#include "pci.h"
#include "paging.h"
#include "common.h"

static int sys3(int n, int a, int b, int c) { int r; __asm__ volatile("int $0x80" : "=a"(r) : "0"(n), "b"(a), "c"(b), "d"(c) : "memory"); return r; }
static void out(const char *s) { int n = 0; while(s[n]) n++; sys3(4, 1, (int)s, n); }
static void num(const char *l, uint32_t v) { char b[16], t[12]; int n = 0, k = 0; if(!v) t[k++] = '0'; while(v) { t[k++] = '0' + v % 10; v /= 10; } while(k) b[n++] = t[--k]; b[n++] = '\n'; b[n] = 0; out(l); out(b); }
static void host_putchar(char c) { sys3(4, 1, (int)&c, 1); }
void (*terminal_putchar)(char c) = host_putchar;
void halt(void) { sys3(1, 1, 0, 0); }
void fastcp(char *d, char *s, uint32_t n) { memcpy(d, s, n); }
void terminal_set_cursor(void) {} void make_vesa_color(void) {} void set_vesa_color(void) {} void set_vesa_background(void) {}
void terminal_set_status(void) {} void terminal_write_dec(void) {} void terminal_write_hex(void) {} void terminal_writestring(const char *s) { out(s); }
void *kmalloc(uint32_t n) { static char h[1 << 20]; static uint32_t p; void *r = h + p; p += (n + 15) & ~15u; return r; }
void kfree(void *p) { (void)p; }

struct page_directory *kernel_directory;
struct page *get_page(uint32_t a, int make, struct page_directory *d) { static struct page dummy; (void)a; (void)make; (void)d; return &dummy; }

/* ---- fake PCI ---- */
static uint8_t hba[0x2000] __attribute__((aligned(4096)));
int pci_find_device_by_class(uint8_t c, uint8_t s, pci_device_t *o) { if(c != 1 || s != 6) return 0; memset(o, 0, sizeof(*o)); o->prog_if = 1; return 1; }
uint32_t pci_config_read32(uint8_t b, uint8_t d, uint8_t f, uint8_t o) { (void)b; (void)d; (void)f; (void)o; return 0; }
void pci_config_write32(uint8_t b, uint8_t d, uint8_t f, uint8_t o, uint32_t v) { (void)b; (void)d; (void)f; (void)o; (void)v; }
uint32_t pci_get_bar(pci_device_t *d, int i) { (void)d; return i == 5 ? (uint32_t)hba : 0; }

/* ---- the model ---- */
static int img_fd; static uint32_t errors, cmds;
static uint32_t *R(uint32_t off) { return (uint32_t *)(hba + off); }
#define PREG(r) R(0x100 + (r))
static int started_ok;
static void complete_error(const char *why) { out("MODEL: "); out(why); out("\n"); errors++; *PREG(0x10) |= 1u << 30; *PREG(0x38) = 0; *PREG(0x20) = 0x51; }

void ahci_test_hook(void) {
    if(*PREG(0x10) == 0xFFFFFFFFu) *PREG(0x10) = 0;          /* write-1-to-clear register: the driver wrote all ones */
    if(*PREG(0x30) == 0xFFFFFFFFu) *PREG(0x30) = 0;
    uint32_t cmd = *PREG(0x18);
    *PREG(0x18) = (cmd & ~((1u << 15) | (1u << 14))) | ((cmd & 1) ? (1u << 15) : 0) | ((cmd & 0x10) ? (1u << 14) : 0);   /* CR follows ST, FR follows FRE */
    if(!(*PREG(0x38) & 1)) return;
    cmds++;
    if(!(cmd & 1) || !(cmd & 0x10)) { complete_error("command issued while the port is not started"); return; }
    uint8_t *hdr = (uint8_t *)*PREG(0x00);
    if(!hdr || ((uint32_t)hdr & 1023)) { complete_error("command list base missing/unaligned"); return; }
    if(!*PREG(0x08) || ((uint32_t)*PREG(0x08) & 255)) { complete_error("FIS base missing/unaligned"); return; }
    uint32_t dw0 = *(uint32_t *)hdr, ctba = *(uint32_t *)(hdr + 8);
    int cfl = dw0 & 31, write = (dw0 >> 6) & 1, prdtl = dw0 >> 16;
    if(cfl != 5) { complete_error("CFL != 5"); return; }
    if(prdtl != 1) { complete_error("PRDTL != 1"); return; }
    if(ctba & 127) { complete_error("command table unaligned"); return; }
    uint8_t *t = (uint8_t *)ctba;
    if(t[0] != 0x27 || !(t[1] & 0x80)) { complete_error("bad H2D FIS"); return; }
    uint8_t op = t[2];
    uint64_t lba = t[4] | (t[5] << 8) | (t[6] << 16) | ((uint64_t)t[8] << 24) | ((uint64_t)t[9] << 32) | ((uint64_t)t[10] << 40);
    uint32_t count = t[12] | (t[13] << 8);
    uint32_t *prd = (uint32_t *)(t + 0x80);
    uint8_t *dba = (uint8_t *)prd[0]; uint32_t dbc = (prd[3] & 0x3FFFFF) + 1;
    if(op == 0xEC) {
        uint16_t id[256]; memset(id, 0, sizeof(id));
        const char *m = "AHCI MODEL DISK"; for(int i = 0; i < 40; i += 2) { char a = m[i] ? m[i] : ' ', b = (m[i] && m[i + 1]) ? m[i + 1] : ' '; id[27 + i / 2] = (uint16_t)((a << 8) | b); }
        int size = sys3(19, img_fd, 0, 2); uint64_t sec = (uint64_t)size / 512;
        id[83] = 1 << 10; id[100] = (uint16_t)sec; id[101] = (uint16_t)(sec >> 16); id[102] = (uint16_t)(sec >> 32); id[103] = (uint16_t)(sec >> 48);
        if(dbc != 512) { complete_error("IDENTIFY with wrong byte count"); return; }
        memcpy(dba, id, 512);
    } else if(op == 0x25 || op == 0x35) {
        if(t[7] != 0x40) { complete_error("device register not 0x40"); return; }
        if(dbc != count * 512 || count == 0 || count > 128) { complete_error("PRD byte count does not match sector count"); return; }
        if((op == 0x35) != write) { complete_error("W bit does not match the command"); return; }
        sys3(19, img_fd, (int)(lba * 512), 0);
        if(op == 0x25) { if(sys3(3, img_fd, (int)dba, (int)dbc) != (int)dbc) memset(dba, 0, dbc); }
        else sys3(4, img_fd, (int)dba, (int)dbc);
    } else { complete_error("unknown command"); return; }
    *PREG(0x38) = 0; *PREG(0x20) = 0x50; *PREG(0x10) |= 1;
}

int main(int argc, char **argv) {
    (void)argc;
    img_fd = sys3(5, (int)argv[1], 2, 0);
    *R(0x0C) = 1;                         /* PI: port 0 */
    *PREG(0x28) = 0x113;                  /* SSTS: DET=3, IPM=1 */
    *PREG(0x24) = 0x101;                  /* SIG: SATA disk */
    ata_info_t info[6];
    int n = ahci_probe(info, 6);
    num("ports found=", (uint32_t)n);
    if(n != 1) return 1;
    out("model: "); out(info[0].model); out("\n"); num("sectors=", (uint32_t)info[0].sectors);
    static uint8_t buf[300 * 512], ref[300 * 512];
    int bad = 0;
    for(uint32_t lba = 0; lba < 1000; lba += 137) {
        uint32_t cnt = (lba % 7) * 40 + 1;
        if(ahci_read(0, lba, cnt, buf) != 0) { out("read failed\n"); bad++; continue; }
        sys3(19, img_fd, (int)(lba * 512), 0); sys3(3, img_fd, (int)ref, (int)(cnt * 512));
        if(memcmp(buf, ref, cnt * 512)) { out("DATA MISMATCH\n"); bad++; }
    }
    for(uint32_t i = 0; i < sizeof(buf); i++) buf[i] = (uint8_t)(i * 31 + 7);
    if(ahci_write(0, 5000, 300, buf) != 0) { out("write failed\n"); bad++; }
    static uint8_t back[300 * 512];
    if(ahci_read(0, 5000, 300, back) != 0 || memcmp(back, buf, sizeof(buf))) { out("WRITE/READ-BACK MISMATCH\n"); bad++; }
    num("commands executed=", cmds); num("model complaints=", errors); num("test failures=", (uint32_t)bad);
    return bad || errors;
}
void _real_start(int argc, char **argv) { int r = main(argc, argv); sys3(1, r, 0, 0); }
__asm__(".global _start\n_start:\n xor %ebp,%ebp\n mov (%esp),%eax\n lea 4(%esp),%edx\n push %edx\n push %eax\n call _real_start\n");
