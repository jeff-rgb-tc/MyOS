#!/usr/bin/env python3
"""Builds a FAT32 image from a directory tree, laid out like mtools' mformat+mcopy
(32 reserved sectors, 2 FATs, NT lowercase flags, LFN entries for long names), so the
kernel's FAT32 driver can be exercised on the host.
usage: fatimg.py <out.img> <size_mb> <spc> <dir> [<dir>:<target> ...]"""
import os, struct, sys

SECT = 512

def lfn_checksum(short11):
    s = 0
    for c in short11:
        s = (((s & 1) << 7) + (s >> 1) + c) & 0xFF
    return s

class Img:
    def __init__(self, size_mb, spc):
        self.spc = spc
        self.total = size_mb * 2048
        self.res = 32
        self.fats = 2
        # fat size: iterate
        fatsz = 1
        while True:
            data = self.total - self.res - self.fats * fatsz
            clusters = data // spc
            need = ((clusters + 2) * 4 + SECT - 1) // SECT
            if need <= fatsz: break
            fatsz = need
        self.fatsz = fatsz
        self.clusters = (self.total - self.res - self.fats * fatsz) // spc
        self.data = bytearray(self.total * SECT)
        self.fat = [0] * (self.clusters + 2)
        self.fat[0] = 0x0FFFFFF8; self.fat[1] = 0x0FFFFFFF
        self.next = 2
        self.root = self.alloc(1)
        self.cbytes = spc * SECT

    def cl_off(self, c):
        return (self.res + self.fats * self.fatsz + (c - 2) * self.spc) * SECT

    def alloc(self, n):
        first = self.next
        for i in range(n):
            c = self.next; self.next += 1
            if self.next > self.clusters + 2: raise SystemExit("image full")
            self.fat[c] = 0x0FFFFFFF if i == n - 1 else c + 1
        return first

    def write_chain(self, first, data):
        c = first; pos = 0
        while True:
            off = self.cl_off(c)
            chunk = data[pos:pos + self.cbytes]
            self.data[off:off + len(chunk)] = chunk
            pos += self.cbytes
            nxt = self.fat[c]
            if nxt >= 0x0FFFFFF8: break
            c = nxt

    def finish(self, path):
        bs = bytearray(SECT)
        bs[0:3] = b'\xEB\x58\x90'; bs[3:11] = b'MSWIN4.1'
        struct.pack_into('<HBHBHHBHHHII', bs, 11, SECT, self.spc, self.res, self.fats, 0, 0, 0xF8, 0, 63, 255, 0, self.total)
        struct.pack_into('<IHHIHH', bs, 36, self.fatsz, 0, 0, self.root, 1, 6)
        bs[64] = 0x80; bs[66] = 0x29; struct.pack_into('<I', bs, 67, 0x12345678)
        bs[71:82] = b'NO NAME    '; bs[82:90] = b'FAT32   '; bs[510] = 0x55; bs[511] = 0xAA
        self.data[0:SECT] = bs; self.data[6 * SECT:7 * SECT] = bs
        fs = bytearray(SECT); struct.pack_into('<I', fs, 0, 0x41615252); struct.pack_into('<I', fs, 484, 0x61417272)
        struct.pack_into('<II', fs, 488, 0xFFFFFFFF, 0xFFFFFFFF); fs[510] = 0x55; fs[511] = 0xAA
        self.data[SECT:2 * SECT] = fs
        raw = b''.join(struct.pack('<I', v) for v in self.fat)
        raw += b'\0' * (self.fatsz * SECT - len(raw))
        for i in range(self.fats):
            o = (self.res + i * self.fatsz) * SECT
            self.data[o:o + len(raw)] = raw
        open(path, 'wb').write(self.data)

def make_short(name, used):
    base, dot, ext = name.rpartition('.') if '.' in name else (name, '', '')
    if not dot: base, ext = name, ''
    up = lambda s: ''.join(c for c in s.upper() if c.isalnum() or c in '_-$~!#%&')
    b, e = up(base), up(ext)[:3]
    fits = (name.upper() == name or name.lower() == name) and len(base) <= 8 and len(ext) <= 3 and up(base) == base.upper() and ' ' not in name
    flags = 0
    if fits:
        if base.lower() == base and any(c.isalpha() for c in base): flags |= 0x08
        if ext.lower() == ext and any(c.isalpha() for c in ext): flags |= 0x10
        s = (b.ljust(8) + e.ljust(3)).encode()
        return s, flags, False
    n = 1
    while True:
        tail = '~%d' % n
        s = (b[:8 - len(tail)] + tail).ljust(8) + e.ljust(3)
        if s not in used: return s.encode(), 0, True
        n += 1

def dir_entries(img, entries, parent_cluster, self_cluster):
    out = bytearray(); used = set()
    def short(nm, attr, cl, size, flags=0):
        e = bytearray(32); e[0:11] = nm; e[11] = attr; e[12] = flags
        struct.pack_into('<HHHHHHHI', e, 14, 0, 0x5A21, 0x5A21, cl >> 16, 0, 0x5A21, cl & 0xFFFF, size)
        # layout: ctime(14) cdate(16) adate(18) clusterHi(20) mtime(22) mdate(24) clusterLo(26) size(28)
        struct.pack_into('<HHHHHHHI', e, 14, 0x6000, 0x5A21, 0x5A21, cl >> 16, 0x6000, 0x5A21, cl & 0xFFFF, size)
        return bytes(e)
    if self_cluster is not None:
        out += short(b'.          ', 0x10, self_cluster, 0)
        out += short(b'..         ', 0x10, parent_cluster if parent_cluster != img.root else 0, 0)
    for (nm, is_dir, cl, size) in entries:
        s, flags, need_lfn = make_short(nm, used); used.add(s.decode())
        if need_lfn:
            chk = lfn_checksum(s)
            u = nm.encode('utf-16-le') + (b'\0\0' if len(nm) % 13 else b'')
            u += b'\xff\xff' * ((13 - (len(u) // 2) % 13) % 13)
            n = len(u) // 26
            for i in range(n, 0, -1):
                ch = u[(i - 1) * 26:i * 26]
                e = bytearray(32); e[0] = i | (0x40 if i == n else 0); e[11] = 0x0F; e[13] = chk
                e[1:11] = ch[0:10]; e[14:26] = ch[10:22]; e[28:32] = ch[22:26]
                out += e
        out += short(s, 0x10 if is_dir else 0x20, cl, size, flags)
    return bytes(out)

def add_tree(img, host_dir, parent_cluster, self_cluster):
    entries = []
    for name in sorted(os.listdir(host_dir)):
        p = os.path.join(host_dir, name)
        if os.path.isdir(p):
            cl = img.alloc(1)
            add_tree(img, p, self_cluster, cl)
            entries.append((name, True, cl, 0))
        else:
            data = open(p, 'rb').read()
            n = max(1, (len(data) + img.cbytes - 1) // img.cbytes)
            cl = img.alloc(n) if data else 0
            if data: img.write_chain(cl, data)
            entries.append((name, False, cl, len(data)))
    blob = dir_entries(img, entries, parent_cluster, None if self_cluster == img.root else self_cluster)
    # directories may span several clusters
    need = max(1, (len(blob) + img.cbytes - 1) // img.cbytes)
    if need > 1:
        # extend chain of this directory
        c = self_cluster
        while img.fat[c] < 0x0FFFFFF8: c = img.fat[c]
        for _ in range(need - 1):
            n = img.alloc(1); img.fat[c] = n; c = n
    img.write_chain(self_cluster, blob)

if __name__ == '__main__':
    out, mb, spc, src = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
    img = Img(mb, spc)
    add_tree(img, src, img.root, img.root)
    img.finish(out)
    print("wrote", out)
