/* Runs the REAL ata_pio_drv.c against a software model of an IDE controller (ports 0x1F0/0x170),
 * counting every port access, to see what probing / reading costs in a VM (each access is a VM exit).
 * usage: idetest <image> [absent-reads-as-ff|absent-reads-as-00] */
#include "stdint.h"
#include "ata_pio_drv.h"
#include "common.h"

static int sys3(int n, int a, int b, int c) { int r; __asm__ volatile("int $0x80" : "=a"(r) : "0"(n), "b"(a), "c"(b), "d"(c) : "memory"); return r; }
static void out(const char *s) { int n = 0; while(s[n]) n++; sys3(4, 1, (int)s, n); }
static void num(const char *l, uint32_t v) { char b[16], t[12]; int n = 0, k = 0; if(!v) t[k++] = '0'; while(v) { t[k++] = '0' + v % 10; v /= 10; } while(k) b[n++] = t[--k]; b[n++] = '\n'; b[n] = 0; out(l); out(b); }
static void host_putchar(char c) { sys3(4, 1, (int)&c, 1); }
void (*terminal_putchar)(char c) = host_putchar;
void halt(void) { sys3(1, 1, 0, 0); }
void *kmalloc(uint32_t n) { static char h[1 << 24]; static uint32_t p; n = (n + 15) & ~15u; void *r = h + p; p += n; return r; }
void kfree(void *p) { (void)p; } void *krealloc(void *p, uint32_t n) { void *q = kmalloc(n); if(q && p) memcpy(q, p, n); return q; }
void fastcp(char *d, char *s, uint32_t n) { memcpy(d, s, n); }
void terminal_set_cursor(void) {} void make_vesa_color(void) {} void set_vesa_color(void) {} void set_vesa_background(void) {}
static uint32_t ticks; uint32_t pit_get_ms(void) { return ticks / 1000; }       /* 1 tick = 1 us of simulated time */

/* ---- the fake controller ---- */
static int img_fd; static uint32_t ops, pio_words, st_reads;
static uint32_t absent_value = 0xFF;
typedef struct { int sel; uint8_t status, err; uint8_t lba[4], count; uint32_t lba_cur; int remaining; int busy_polls; int drq_words_left; uint16_t buf[256]; int ident; int cmd; } chan_t;
static chan_t ch[2];
static uint32_t disk_sectors;
static int present(int c, int drv) { return c == 0 && drv == 0; }          /* only primary master exists */

static void fill_ident(uint16_t *id) {
    memset(id, 0, 512);
    const char *m = "FAKE IDE DISK"; for(int i = 0; i < 40; i += 2) { char a = m[i] ? m[i] : ' ', b = (m[i] && m[i+1]) ? m[i+1] : ' '; id[27 + i / 2] = (uint16_t)((a << 8) | b); }
    id[49] = 1 << 9; id[60] = (uint16_t)disk_sectors; id[61] = (uint16_t)(disk_sectors >> 16);
}
static void load_sector(chan_t *c) { sys3(19, img_fd, (int)(c->lba_cur * 512), 0); sys3(3, img_fd, (int)c->buf, 512); c->drq_words_left = 256; c->lba_cur++; }
static chan_t *chan_of(uint16_t p, int *reg) { if(p >= 0x1F0 && p <= 0x1F7) { *reg = p - 0x1F0; return &ch[0]; } if(p >= 0x170 && p <= 0x177) { *reg = p - 0x170; return &ch[1]; }
                                              if(p == 0x3F6) { *reg = 8; return &ch[0]; } if(p == 0x376) { *reg = 8; return &ch[1]; } return 0; }

uint8_t inb(uint16_t p) {
    ops++; ticks += 3;                                    /* ~3 us per trapped port access */
    int reg; chan_t *c = chan_of(p, &reg); if(!c) return 0xFF;
    int ci = (c == &ch[1]);
    if(!present(ci, c->sel)) return (uint8_t)absent_value;
    if(reg == 7 || reg == 8) {
        st_reads++;
        if(c->busy_polls > 0) { c->busy_polls--; return 0x80; }
        return c->status;
    }
    if(reg == 1) return c->err;
    if(reg == 4) return 0; if(reg == 5) return 0;
    return 0;
}
void outb(uint16_t p, uint8_t v) {
    ops++; ticks += 3;
    int reg; chan_t *c = chan_of(p, &reg); if(!c) return;
    int ci = (c == &ch[1]);
    switch(reg) {
        case 6: c->sel = (v >> 4) & 1; break;
        case 2: c->count = v; break;
        case 3: c->lba[0] = v; break; case 4: c->lba[1] = v; break; case 5: c->lba[2] = v; break;
        case 7:
            if(!present(ci, c->sel)) break;
            c->cmd = v; c->busy_polls = 2; c->status = 0x58;                      /* RDY | DSC | DRQ after the busy polls */
            if(v == 0xEC) { fill_ident(c->buf); c->drq_words_left = 256; }
            else if(v == 0x20 || v == 0x24) {
                c->lba_cur = c->lba[0] | (c->lba[1] << 8) | (c->lba[2] << 16) | ((uint32_t)(c->sel ? 0 : 0) << 24);
                c->remaining = c->count ? c->count : 256; load_sector(c);
            }
            break;
    }
}
void insw(uint16_t p, void *buf, uint32_t n) {
    ops++; ticks += 3; pio_words += n;                                           /* REP INS is one exit */
    int reg; chan_t *c = chan_of(p, &reg); if(!c || reg != 0) return;
    memcpy(buf, c->buf + (256 - c->drq_words_left), n * 2); c->drq_words_left -= (int)n;
    if(c->cmd == 0x20 || c->cmd == 0x24) {
        if(c->drq_words_left <= 0) { c->remaining--; if(c->remaining > 0) { load_sector(c); c->busy_polls = 1; } else c->status = 0x50; }
    } else c->status = 0x50;
}
void outsw(uint16_t p, void *b, uint32_t n) { (void)p; (void)b; (void)n; ops++; ticks += 3; }
uint16_t inw(uint16_t p) { ops++; ticks += 3; (void)p; return 0; }
void outw(uint16_t p, uint16_t v) { ops++; ticks += 3; (void)p; (void)v; }
uint32_t inl(uint16_t p) { ops++; ticks += 3; (void)p; return 0; }
void outl(uint16_t p, uint32_t v) { ops++; ticks += 3; (void)p; (void)v; }
int pci_find_device_by_class(int a, int b, void *c) { (void)a; (void)b; (void)c; return 0; }
uint32_t pci_config_read32(int a, int b, int c, int d) { (void)a; (void)b; (void)c; (void)d; return 0; }
void pci_config_write32(int a, int b, int c, int d, uint32_t v) { (void)a; (void)b; (void)c; (void)d; (void)v; }
void terminal_set_status(void) {} void terminal_write_dec(void) {} void terminal_write_hex(void) {} void terminal_writestring(const char *s) { out(s); }
void rtc_read_date(void *d) { (void)d; } void rtc_read_time(void *d) { (void)d; }
void sys_sti(void) {} void sys_cli(void) {}

int main(int argc, char **argv) {
    img_fd = sys3(5, (int)argv[1], 0, 0);
    int len = 0; while(argv[1][len]) len++;
    disk_sectors = 131072;
    for(int i = 0; i < 2; i++) ch[i].status = 0x50;
    if(argc > 2 && argv[2][0] == 'a' && argv[2][21] == '0') absent_value = 0x00;
    ops = 0; uint32_t t0 = ticks;
    int found = ata_probe_all();
    num("devices found=", (uint32_t)found); num("probe: port ops=", ops); num("probe: simulated ms=", (ticks - t0) / 1000);
    static uint8_t buf[512 * 64];
    ops = 0; t0 = ticks; st_reads = 0;
    for(uint32_t lba = 0; lba < 8192; lba += 64) if(ata_dev_read_stream(0, lba, 64, buf) != 0) { out("read failed\n"); break; }
    num("read 4 MiB (8192 sectors): port ops=", ops); num("   simulated ms=", (ticks - t0) / 1000);
    ops = 0; t0 = ticks;
    for(uint32_t lba = 0; lba < 400; lba++) if(ata_dev_read(0, lba * 3, 1, buf) != 0) { out("read failed\n"); break; }
    num("400 scattered single-sector reads: port ops=", ops); num("   simulated ms=", (ticks - t0) / 1000);
    return 0;
}
void _real_start(int argc, char **argv) { int r = main(argc, argv); sys3(1, r, 0, 0); }
__asm__(".global _start\n_start:\n xor %ebp,%ebp\n mov (%esp),%eax\n lea 4(%esp),%edx\n push %edx\n push %eax\n call _real_start\n");
