#!/bin/sh
# Builds installtest-bin (the real installer.c on a fake disk).
set -e
HERE=$(cd "$(dirname "$0")" && pwd); SYS=$(cd "$HERE/../.." && pwd); W=$(mktemp -d)
KF="-m32 -O1 -fno-strict-aliasing -fwrapv -ffreestanding -fno-stack-protector -fno-pic -fno-pie -std=gnu99 -w -I$SYS/kernel -I$SYS/desktop -I$SYS/apps-sdk/include"
for f in $SYS/kernel/fat32.c $SYS/kernel/common.c $SYS/kernel/kernio.c $SYS/kernel/installer.c $SYS/kernel/fsx.c $SYS/kernel/volumes.c $SYS/kernel/loopdev.c $HERE/installtest.c; do gcc $KF -c $f -o $W/$(basename $f).o; done
gcc -m32 -nostdlib -static -no-pie -Wl,--build-id=none -o "$HERE/installtest-bin" $W/*.o
rm -rf $W
