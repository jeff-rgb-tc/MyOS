#!/usr/bin/env python3
"""Image builders for the foreign-filesystem tests: ISO 9660 (optionally Joliet) and FAT12/FAT16.
usage: otherimg.py iso|joliet|fat16|fat12 <out> <src-dir>"""
import os, struct, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fatimg

# ---------------- ISO 9660 ----------------
def both32(v): return struct.pack('<I', v) + struct.pack('>I', v)
def both16(v): return struct.pack('<H', v) + struct.pack('>H', v)

def build_iso(src, out, joliet):
    secs = {}                     # lba -> bytes (2048 aligned blobs)
    next_lba = [20 if not joliet else 20]
    def alloc(nbytes):
        lba = next_lba[0]; next_lba[0] += max(1, (nbytes + 2047) // 2048); return lba
    def enc(name, is_dir):
        if joliet: return name.encode('utf-16-be')
        up = name.upper()
        return up.encode('ascii') if is_dir else (up + ';1').encode('ascii')
    def rec(name_bytes, lba, size, is_dir):
        n = len(name_bytes); l = 33 + n + (1 - n % 2)
        r = bytearray(l); r[0] = l; r[2:10] = both32(lba); r[10:18] = both32(size)
        r[18:25] = bytes([126, 1, 1, 0, 0, 0, 0]); r[25] = 2 if is_dir else 0
        r[28:32] = both16(1); r[32] = n; r[33:33 + n] = name_bytes
        return bytes(r)
    def pack_dir(records):
        out_ = bytearray(); cur = bytearray()
        for r in records:
            if len(cur) + len(r) > 2048: out_ += cur.ljust(2048, b'\0'); cur = bytearray()
            cur += r
        out_ += cur.ljust(2048, b'\0') if cur else b''
        return bytes(out_)
    def write_dir(path, parent_lba, my_lba=None):
        entries = sorted(os.listdir(path))
        est = 68 + sum(34 + len(enc(n, True)) + 2 for n in entries)          # generous size of the directory blob
        sectors = est // 2048 + 2
        lba = my_lba if my_lba is not None else alloc(sectors * 2048)
        if my_lba is not None and my_lba == next_lba[0] - 1:                  # the root: it already owns one sector, add the rest
            alloc((sectors - 1) * 2048)
        child = []
        for n in entries:
            p = os.path.join(path, n)
            if os.path.isdir(p):
                sz, sub_lba = write_dir(p, lba)
                child.append((n, True, sub_lba, sz))
            else:
                data = open(p, 'rb').read()
                f_lba = alloc(len(data)) if data else 0
                if data: secs[f_lba] = data
                child.append((n, False, f_lba, len(data)))
        # dot records need the final size: iterate once to know it
        def build(size):
            recs = [rec(b'\0', lba, size, True), rec(b'\1', parent_lba if parent_lba else lba, size, True)]
            for n, d, l, s in child: recs.append(rec(enc(n, d), l, s, d))
            return pack_dir(recs)
        blob = build(2048)
        blob = build(len(blob))
        # blob may span several sectors: make sure the allocation is big enough
        assert len(blob) // 2048 <= sectors, 'directory estimate too small'
        secs[lba] = blob
        return (len(blob), lba) if my_lba is None else len(blob)
    root_lba = alloc(2048)
    root_size = write_dir(src, root_lba, root_lba)
    total = next_lba[0] + 4
    img = bytearray(total * 2048)
    for lba, data in secs.items(): img[lba * 2048:lba * 2048 + len(data)] = data
    def vd(kind, esc=b''):
        v = bytearray(2048); v[0] = kind; v[1:6] = b'CD001'; v[6] = 1
        v[8:40] = b'MYOS'.ljust(32); v[40:72] = b'TESTDISC'.ljust(32) if not joliet or kind == 1 else 'TESTDISC'.encode('utf-16-be').ljust(32, b'\0')
        v[80:88] = both32(total); v[88:88 + len(esc)] = esc
        v[120:124] = both16(1); v[124:128] = both16(1); v[128:132] = both16(2048)
        v[156:190] = rec(b'\0', root_lba, root_size, True)[:34]; v[156] = 34
        v[881] = 1
        return v
    img[16 * 2048:17 * 2048] = vd(1)
    if joliet:
        img[17 * 2048:18 * 2048] = vd(2, b'%/E')
        term = bytearray(2048); term[0] = 255; term[1:6] = b'CD001'; term[6] = 1
        img[18 * 2048:19 * 2048] = term
    else:
        term = bytearray(2048); term[0] = 255; term[1:6] = b'CD001'; term[6] = 1
        img[17 * 2048:18 * 2048] = term
    open(out, 'wb').write(img)

# ---------------- FAT12 / FAT16 ----------------
class Fat16:
    def __init__(self, size_mb, spc, fat12):
        self.spc = spc; self.fat12 = fat12; self.total = size_mb * 2048; self.res = 1; self.fats = 2
        self.root_entries = 512; self.root_secs = 32
        spf = 1
        while True:
            data = self.total - self.res - self.fats * spf - self.root_secs
            clusters = data // spc
            need = ((clusters + 2) * (3 if fat12 else 4) // 2 + 511) // 512 if fat12 else ((clusters + 2) * 2 + 511) // 512
            if need <= spf: break
            spf = need
        self.spf = spf; self.clusters = (self.total - self.res - self.fats * spf - self.root_secs) // spc
        assert (self.clusters < 4085) == fat12, "cluster count %d does not match FAT type" % self.clusters
        self.data = bytearray(self.total * 512); self.fat = [0] * (self.clusters + 2)
        self.fat[0] = 0xFF8 if fat12 else 0xFFF8; self.fat[1] = 0xFFF if fat12 else 0xFFFF
        self.next = 2; self.cbytes = spc * 512
        self.root_lba = self.res + self.fats * spf; self.data_lba = self.root_lba + self.root_secs
    def alloc(self, n):
        first = self.next; eoc = 0xFFF if self.fat12 else 0xFFFF
        for i in range(n):
            c = self.next; self.next += 1
            assert self.next <= self.clusters + 2, 'full'
            self.fat[c] = eoc if i == n - 1 else c + 1
        return first
    def write_chain(self, first, data):
        c = first; pos = 0; eoc = 0xFF8 if self.fat12 else 0xFFF8
        while True:
            off = (self.data_lba + (c - 2) * self.spc) * 512
            chunk = data[pos:pos + self.cbytes]; self.data[off:off + len(chunk)] = chunk; pos += self.cbytes
            nxt = self.fat[c]
            if nxt >= eoc: break
            c = nxt
    def finish(self, path):
        bs = bytearray(512); bs[0:3] = b'\xEB\x3C\x90'; bs[3:11] = b'MSWIN4.1'
        struct.pack_into('<HBHBHHBHHHII', bs, 11, 512, self.spc, self.res, self.fats, self.root_entries, self.total if self.total < 65536 else 0, 0xF8, self.spf, 63, 255, 0, self.total if self.total >= 65536 else 0)
        bs[36] = 0x80; bs[38] = 0x29; bs[43:54] = b'NO NAME    '; bs[54:62] = (b'FAT12   ' if self.fat12 else b'FAT16   ')
        bs[510] = 0x55; bs[511] = 0xAA; self.data[0:512] = bs
        if self.fat12:
            raw = bytearray((len(self.fat) * 3 + 1) // 2 + 2)
            for i, v in enumerate(self.fat):
                o = i + i // 2
                if i & 1: raw[o] = (raw[o] & 0x0F) | ((v & 0xF) << 4); raw[o + 1] = (v >> 4) & 0xFF
                else: raw[o] = v & 0xFF; raw[o + 1] = (raw[o + 1] & 0xF0) | ((v >> 8) & 0xF)
            raw = bytes(raw)
        else: raw = b''.join(struct.pack('<H', v) for v in self.fat)
        raw = raw.ljust(self.spf * 512, b'\0')
        for i in range(self.fats): o = (self.res + i * self.spf) * 512; self.data[o:o + len(raw)] = raw
        open(path, 'wb').write(self.data)

def fat16_tree(img, host_dir, is_root, self_cluster, parent_cluster):
    entries = []
    for name in sorted(os.listdir(host_dir)):
        p = os.path.join(host_dir, name)
        if os.path.isdir(p):
            cl = img.alloc(1); fat16_tree(img, p, False, cl, 0 if is_root else self_cluster); entries.append((name, True, cl, 0))
        else:
            d = open(p, 'rb').read(); n = max(1, (len(d) + img.cbytes - 1) // img.cbytes)
            cl = img.alloc(n) if d else 0
            if d: img.write_chain(cl, d)
            entries.append((name, False, cl, len(d)))
    class Shim: root = 0
    shim = Shim(); shim.root = 0
    blob = fatimg.dir_entries(shim, entries, parent_cluster, None if is_root else self_cluster)
    # fatimg writes the high cluster word at offset 20; FAT12/16 must have it zero (it is, clusters < 65536)
    if is_root:
        assert len(blob) <= img.root_secs * 512, 'root directory too big'
        o = img.root_lba * 512; img.data[o:o + len(blob)] = blob
    else:
        need = max(1, (len(blob) + img.cbytes - 1) // img.cbytes)
        if need > 1:
            c = self_cluster
            while img.fat[c] < (0xFF8 if img.fat12 else 0xFFF8): c = img.fat[c]
            for _ in range(need - 1):
                n = img.alloc(1); img.fat[c] = n; c = n
        img.write_chain(self_cluster, blob)

if __name__ == '__main__':
    kind, out, src = sys.argv[1], sys.argv[2], sys.argv[3]
    if kind in ('iso', 'joliet'): build_iso(src, out, kind == 'joliet')
    else:
        img = Fat16(8 if kind == 'fat12' else 64, 4, kind == 'fat12')
        fat16_tree(img, src, True, 0, 0); img.finish(out)
    print('wrote', out)
