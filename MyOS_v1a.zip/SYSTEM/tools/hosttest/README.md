# Host tests for the filesystem code

These run the kernel's REAL `fat32.c`, `fsx.c` (ext2/3/4, ISO 9660, FAT12/16) and `fs_util.c` on the
build machine, against disk images, with a fake ATA layer. No VM needed.

    ./build.sh   EXTRA_SRC=../../kernel/fsx.c     (build hosttest-bin; needs gcc -m32, no libc)
    python3 fatimg.py out.img 64 1 <dir>             FAT32 image laid out like mtools (LFN, NT case flags)
    python3 otherimg.py iso|joliet|fat16|fat12 out <dir>
    mke2fs -t ext4 -d <dir> out.img 24M               real ext images (e2fsprogs)
    python3 verify_fs.py out.img ext4 <dir>           every file's size + checksum compared with <dir>
    python3 fuzz_fs.py <seed> [name-filter] [trials]  corrupt images, check for crashes / hangs
    hosttest-bin img -t                               FAT32 write/delete stress test

These tests found the FAT32 directory bug (long-name entries crossing a cluster boundary dropped the rest
The old FAT32 parser no longer crashed in the last fuzz runs (impossible cluster numbers are now rejected).

More rigs (all run the real kernel source on the host):
    ./run_all.sh                      builds everything, makes images, verifies ext2/3/4, FAT12/16/32, exFAT, NTFS, ISO
    ./build_install.sh; installtest-bin src.img target.img            the real installer.c on a fake 1 GB disk
    installtest-bin src.img target.img selfupdate update.iso          update the installed system from a disc
    idetest.c   the real ata_pio_drv.c against a software IDE controller (counts port accesses)
    ahcitest.c  the real ahci.c against a strict software AHCI controller (-DAHCI_HOST_TEST)
NTFS/exFAT images are made by ntfsexfat_img.py from the on-disk specs (no mkfs.ntfs/exfat tools here), so those two
are verified against my reading of the spec, not against a Windows-made volume.
