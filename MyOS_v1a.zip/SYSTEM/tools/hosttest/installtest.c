/* Runs the REAL installer.c (format + copy) on the host: source = a FAT32 image (the "live" system, dev 0),
 * target = a sparse file (dev 1). Afterwards the result is checked with hosttest-bin -p 2048 -x fat32 all.
 * usage: installtest <source.img> <target.img> [update] */
#include "stdint.h"
#include "fat32.h"
#include "ata_pio_drv.h"
#include "installer.h"
#include "common.h"
#include "myos/abi.h"
#include "loopdev.h"
#include "volumes.h"

static int sys3(int n, int a, int b, int c) { int r; __asm__ volatile("int $0x80" : "=a"(r) : "0"(n), "b"(a), "c"(b), "d"(c) : "memory"); return r; }
static void out(const char *s) { int n = 0; while(s[n]) n++; sys3(4, 1, (int)s, n); }
static void num(const char *l, uint32_t v) { char b[16], t[12]; int n = 0, k = 0; if(!v) t[k++] = '0'; while(v) { t[k++] = '0' + v % 10; v /= 10; } while(k) b[n++] = t[--k]; b[n++] = '\n'; b[n] = 0; out(l); out(b); }
static void host_putchar(char c) { sys3(4, 1, (int)&c, 1); }
void (*terminal_putchar)(char c) = host_putchar;
void halt(void) { sys3(1, 1, 0, 0); }
static char heap[400u * 1024 * 1024]; static uint32_t hp;
void *kmalloc(uint32_t n) { n = (n + 15) & ~15u; if(hp + n > sizeof(heap)) return 0; void *p = heap + hp; hp += n; return p; }
void kfree(void *p) { (void)p; } void *krealloc(void *p, uint32_t n) { void *q = kmalloc(n); if(q && p) memcpy(q, p, n); return q; }
void fastcp(char *d, char *s, uint32_t n) { memcpy(d, s, n); }
void terminal_set_cursor(void) {} void make_vesa_color(void) {} void set_vesa_color(void) {} void set_vesa_background(void) {}
void terminal_set_status(void) {} void terminal_write_dec(void) {} void terminal_write_hex(void) {} void terminal_writestring(const char *s) { out(s); }
void rtc_read_date(void *d) { (void)d; } void rtc_read_time(void *d) { (void)d; }
static uint32_t clock_ms; uint32_t pit_get_ms(void) { return clock_ms += 7; }

/* 64-bit division helpers (the kernel gets these from libgcc) */
uint64_t __udivdi3(uint64_t n, uint64_t d) { uint64_t q = 0, r = 0; for(int i = 63; i >= 0; i--) { r = (r << 1) | ((n >> i) & 1); if(r >= d) { r -= d; q |= 1ull << i; } } return q; }
uint64_t __umoddi3(uint64_t n, uint64_t d) { return n - __udivdi3(n, d) * d; }

static int fd[3] = { -1, -1, -1 };
static uint32_t disk_sectors[2];
static uint32_t wsec, rsec;
const ata_info_t *ata_device_info(int d) { static ata_info_t a[3]; if(d < 0 || d > 2) return 0; if(d == 2) { a[2].present = 0; a[2].atapi = 1; return fd[2] >= 0 ? &a[2] : 0; } a[d].present = 1; a[d].sectors = disk_sectors[d]; a[d].io = 0x1F0; memcpy(a[d].model, "FAKE", 5); return &a[d]; }
int ata_probe_all(void) { return 2; }
int ata_dev_read(int d, uint64_t lba, uint32_t n, void *buf) { if(d >= LOOP_BASE) return loop_read(d, lba, n, buf); if(d < 0 || d > 1) return -1; rsec += n; sys3(19, fd[d], (int)(lba * 512), 0); int r = sys3(3, fd[d], (int)buf, (int)(n * 512)); if(r < (int)(n * 512)) memset((char *)buf + (r > 0 ? r : 0), 0, n * 512 - (r > 0 ? r : 0)); return 0; }
int ata_dev_read_stream(int d, uint64_t lba, uint32_t n, void *buf) { return ata_dev_read(d, lba, n, buf); }
int ata_dev_write(int d, uint64_t lba, uint32_t n, const void *buf) { if(d >= LOOP_BASE || d < 0 || d > 1) return -1; wsec += n; sys3(19, fd[d], (int)(lba * 512), 0); return sys3(4, fd[d], (int)buf, (int)(n * 512)) == (int)(n * 512) ? 0 : -1; }
int ata_atapi_read(int d, uint32_t lba, uint32_t n, void *buf) { if(d != 2 || fd[2] < 0) return -1; sys3(19, fd[2], (int)(lba * 2048), 0); int want = (int)(n * 2048), r = sys3(3, fd[2], (int)buf, want); if(r < want) memset((char *)buf + (r > 0 ? r : 0), 0, want - (r > 0 ? r : 0)); return 0; }
uint32_t ata_atapi_capacity(int d) { if(d != 2 || fd[2] < 0) return 0; int sz = sys3(19, fd[2], 0, 2); return (uint32_t)sz / 2048; }
void ata_defer_flush(int on) { (void)on; } void ata_set_default_device(int d) { (void)d; }

int main(int argc, char **argv) {
    fd[0] = sys3(5, (int)argv[1], 2, 0); fd[1] = sys3(5, (int)argv[2], 2, 0);
    disk_sectors[0] = 131072; disk_sectors[1] = 2097152;                 /* source 64 MB, target 1 GB */
    int selfupd = argc > 4 && argv[3][0] == 's';          /* installtest src target selfupdate <update.iso> */
    if(selfupd) {
        fd[2] = sys3(5, (int)argv[4], 0, 0);
        fat32_set_ata_backend(1, 2048);
        master_fs = makeFilesystemOn(1, 2048);                /* the installed system, running */
    } else {
        fat32_set_ata_backend(0, 0);
        master_fs = makeFilesystemOn(0, 0);
    }
    if(!master_fs) { out("cannot mount the system image\n"); return 1; }
    int update = argc > 3;
    int rc = update ? installer_begin_update() : installer_begin(1, 0);
    if(rc < 0) { num("begin failed rc=", (uint32_t)-rc); return 2; }
    myos_install_status_t st; uint32_t steps = 0, last_pct = 999;
    for(;;) {
        rc = installer_step(&st); steps++;
        if(st.percent != last_pct && (st.percent % 10 == 0)) { last_pct = st.percent; out("  "); out(st.stage); out("\n"); }
        if(rc < 0 || st.state == MYOS_INST_FAILED) { out("FAILED: "); out(st.detail); out("\n"); num("error=", (uint32_t)st.error); return 3; }
        if(st.state == MYOS_INST_DONE) break;
        if(steps > 200000) { out("TOO MANY STEPS (stuck?)\n"); return 4; }
    }
    num("steps=", steps); num("target sectors written=", wsec); num("sectors read=", rsec);
    out("INSTALL OK\n");
    return 0;
}
void _real_start(int argc, char **argv) { int r = main(argc, argv); sys3(1, r, 0, 0); }
__asm__(".global _start\n_start:\n xor %ebp,%ebp\n mov (%esp),%eax\n lea 4(%esp),%edx\n push %edx\n push %eax\n call _real_start\n");
