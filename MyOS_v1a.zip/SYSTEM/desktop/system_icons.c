#include "system_icons.h"
#include "kernio.h"
#include "common.h"

typedef struct {
    const char *path;
    png_image_t image;
    uint8_t load_attempted;
} system_icon_slot_t;

static system_icon_slot_t slots[SYSTEM_ICON_COUNT] = {
    [SYSTEM_ICON_MYPC]        = { "/SYSTEM/res/icons/mypc.png", {0}, 0 },
    [SYSTEM_ICON_RECYCLE_BIN] = { "/SYSTEM/res/icons/recycle.png", {0}, 0 },
    [SYSTEM_ICON_SLEEP]       = { "/SYSTEM/res/icons/sleep.png", {0}, 0 },
    [SYSTEM_ICON_RESTART]     = { "/SYSTEM/res/icons/reset.png", {0}, 0 },
    [SYSTEM_ICON_SHUTDOWN]    = { "/SYSTEM/res/icons/shutdown.png", {0}, 0 },
};

png_image_t *system_icon_get(system_icon_id_t id) {
    if(id < 0 || id >= SYSTEM_ICON_COUNT) return NULL;

    system_icon_slot_t *slot = &slots[id];
    if(!slot->load_attempted) {
        slot->load_attempted = 1;
        if(!png_load_from_file(slot->path, &slot->image)) {
            printf("system_icons: failed to load %s\n", slot->path);
            return NULL;
        }
    }

    return slot->image.pixels ? &slot->image : NULL;
}
