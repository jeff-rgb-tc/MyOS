#include "stdint.h"
#include "stddef.h"
#include "gfx.h"
#include "vesa.h"
#include "kheap.h"
#include "common.h"
#include "kernio.h"
#include "font.h"

static gfx_surface_t backbuffer;

/* Integer square root via binary search -- no libm/floating point
 * available in this freestanding kernel, and this is the only place
 * gfx.c needs one (see rounded_corner_coverage()'s antialiasing below).
 * Correct (returns floor(sqrt(n))) for the full uint32_t range;
 * accuracy/speed tradeoffs of fancier bit-tricks methods aren't needed
 * here since this only ever runs on values from small on-screen
 * distances, not large numbers where iteration count would matter. */
static uint32_t isqrt32(uint32_t n) {
    if(n == 0) return 0;
    uint32_t lo = 0, hi = n < 65536 ? 256 : 65536; /* hi must be >= sqrt(n); this is a safe starting bound for either range */
    while((hi - lo) > 1) {
        uint32_t mid = lo + (hi - lo) / 2;
        /* mid*mid could overflow uint32_t for mid near 65536 -- use
         * uint64_t for the comparison to avoid that, even though the
         * result itself is always returned as a uint32_t. */
        if((uint64_t)mid * mid <= n) lo = mid;
        else hi = mid;
    }
    return lo;
}

int gfx_init() {
    /* Idempotent: kernel.c now calls this once early (right after
     * paging/heap are up, to draw the boot splash screen while the rest
     * of boot -- ATA detection, filesystem mount -- runs) and
     * desktop_run() calls it again before starting the main loop. If
     * the back buffer already exists and still matches the current
     * screen size, reuse it rather than leaking the old allocation and
     * allocating a fresh one for no reason. (Screen size can't actually
     * change between those two calls in practice -- set_vmode() only
     * ever runs once, early in boot -- but checking rather than
     * assuming costs nothing and avoids relying on that.) */
    uint32_t w = get_screen_width();
    uint32_t h = get_screen_height();

    if(w == 0 || h == 0) {
        printf("gfx: refusing to init with zero-sized screen (is VESA up?)\n");
        return 0;
    }

    if(backbuffer.pixels && backbuffer.width == w && backbuffer.height == h) {
        return 1; /* already initialized for this exact size -- nothing to do */
    }

    if(backbuffer.pixels) {
        kfree(backbuffer.pixels);
        backbuffer.pixels = NULL;
    }

    backbuffer.width = w;
    backbuffer.height = h;
    backbuffer.pixels = (uint32_t *)kmalloc(w * h * sizeof(uint32_t));

    if(!backbuffer.pixels) {
        printf("gfx: failed to allocate %dx%d back buffer\n", w, h);
        return 0;
    }

    memset(backbuffer.pixels, 0, w * h * sizeof(uint32_t));
    return 1;
}

gfx_surface_t *gfx_backbuffer() {
    return &backbuffer;
}

uint32_t gfx_width() {
    return backbuffer.width;
}

uint32_t gfx_height() {
    return backbuffer.height;
}

void gfx_clear(uint32_t color) {
    uint32_t count = backbuffer.width * backbuffer.height;
    uint32_t *p = backbuffer.pixels;
    __asm__ volatile("rep stosl" : "+D"(p), "+c"(count) : "a"(color) : "memory");
}

static inline int clampi(int v, int lo, int hi) {
    if(v < lo) return lo;
    if(v > hi) return hi;
    return v;
}

/* Exact-enough /255 without a divide instruction (a divide is very
 * expensive under QEMU's CPU emulation, and blending runs per pixel). */
static inline uint32_t div255(uint32_t v) {
    v += 128;
    return (v + (v >> 8)) >> 8;
}

static inline uint32_t blend_argb_over(uint32_t d, uint32_t argb, uint32_t a) {
    uint32_t ia = 255 - a;
    uint32_t r = div255(((argb >> 16) & 0xFF) * a + ((d >> 16) & 0xFF) * ia);
    uint32_t g = div255(((argb >> 8) & 0xFF) * a + ((d >> 8) & 0xFF) * ia);
    uint32_t b = div255((argb & 0xFF) * a + (d & 0xFF) * ia);
    return (r << 16) | (g << 8) | b;
}

/* Fast row fill: rep stosl writes 4 bytes per step with no per-pixel
 * loop overhead -- by far the hottest primitive in the desktop (window
 * backgrounds, taskbar, buttons, text-area clears all go through it). */
static inline void fill_span(uint32_t *dst, int count, uint32_t color) {
    __asm__ volatile("rep stosl" : "+D"(dst), "+c"(count) : "a"(color) : "memory");
}

void gfx_fill_rect(int x, int y, int w, int h, uint32_t color) {
    int x0 = clampi(x, 0, (int)backbuffer.width);
    int y0 = clampi(y, 0, (int)backbuffer.height);
    int x1 = clampi(x + w, 0, (int)backbuffer.width);
    int y1 = clampi(y + h, 0, (int)backbuffer.height);
    int span = x1 - x0;
    if(span <= 0) return;

    uint32_t *row = backbuffer.pixels + y0 * backbuffer.width + x0;
    for(int yy = y0; yy < y1; yy++) {
        fill_span(row, span, color);
        row += backbuffer.width;
    }
}

void gfx_hline(int x, int y, int w, uint32_t color) {
    gfx_fill_rect(x, y, w, 1, color);
}

void gfx_vline(int x, int y, int h, uint32_t color) {
    gfx_fill_rect(x, y, 1, h, color);
}

void gfx_draw_rect(int x, int y, int w, int h, uint32_t color) {
    gfx_hline(x, y, w, color);
    gfx_hline(x, y + h - 1, w, color);
    gfx_vline(x, y, h, color);
    gfx_vline(x + w - 1, y, h, color);
}

void gfx_draw_bevel(int x, int y, int w, int h, uint32_t light, uint32_t dark) {
    /* Classic "raised button" bevel: light on top/left, dark on bottom/right. */
    gfx_hline(x, y, w, light);
    gfx_vline(x, y, h, light);
    gfx_hline(x, y + h - 1, w, dark);
    gfx_vline(x + w - 1, y, h, dark);
}

/* ---------------------------------------------------------------------
 * Rounded-corner antialiasing
 *
 * Coverage (0-255) of one pixel inside a corner box, as a function of its
 * distance (in whole pixels, 1..r on each axis) from the corner circle's
 * centre. The values only depend on the radius, so each radius gets a
 * small r*r table computed once (with the integer square root) and every
 * later pixel is a plain array lookup. The old code ran a binary-search
 * isqrt for EVERY corner pixel of EVERY window EVERY frame, which is a lot
 * of wasted work under QEMU's software CPU.
 * ------------------------------------------------------------------- */
#define COV_CACHE_SLOTS 8
#define COV_MAX_R 128   /* (2 * 128^2) << 16 still fits in 32 bits */

static struct { int r; uint8_t *t; } cov_cache[COV_CACHE_SLOTS];
static int cov_next_slot = 0;

static const uint8_t *corner_lut(int r) {
    if(r <= 0 || r > COV_MAX_R) return NULL;
    for(int i = 0; i < COV_CACHE_SLOTS; i++) {
        if(cov_cache[i].r == r && cov_cache[i].t) return cov_cache[i].t;
    }

    uint8_t *t = (uint8_t *)kmalloc((uint32_t)(r * r));
    if(!t) return NULL;

    for(int my = 1; my <= r; my++) {
        for(int mx = 1; mx <= r; mx++) {
            /* Distance from the pixel to the corner circle's centre,
             * scaled by 256 so the fractional part survives integer
             * square-rooting (~1/256 px precision). */
            uint32_t d2 = (uint32_t)(mx * mx + my * my) << 16;
            int32_t dist = (int32_t)isqrt32(d2);
            /* Linear falloff across a 1px band centred on the true edge
             * (negative edge_dist = inside the circle). */
            int32_t cov = 128 - (dist - (r << 8));
            if(cov < 0) cov = 0;
            if(cov > 255) cov = 255;
            t[(my - 1) * r + (mx - 1)] = (uint8_t)cov;
        }
    }

    int slot = cov_next_slot;
    cov_next_slot = (cov_next_slot + 1) % COV_CACHE_SLOTS;
    if(cov_cache[slot].t) kfree(cov_cache[slot].t);
    cov_cache[slot].r = r;
    cov_cache[slot].t = t;
    return t;
}

static inline int cov_lookup(const uint8_t *lut, int r, int mx, int my) {
    if(lut) return lut[(my - 1) * r + (mx - 1)];
    /* Radius too large for a table: hard (unantialiased) edge. */
    return (mx * mx + my * my <= r * r) ? 255 : 0;
}

/* Coverage for pixel (px, py) of a w*h rounded rect with all four corners
 * rounded -- kept as a public helper because window.c needs it to mask the
 * client area against the window's own silhouette. */
int gfx_rounded_coverage(int px, int py, int w, int h, int r) {
    if(r <= 0) return 255;
    if(r > w / 2) r = w / 2;
    if(r > h / 2) r = h / 2;
    if(r <= 0) return 255;

    int mx, my;
    if(px < r)            mx = r - px;
    else if(px >= w - r)  mx = px - (w - r - 1);
    else return 255;
    if(py < r)            my = r - py;
    else if(py >= h - r)  my = py - (h - r - 1);
    else return 255;

    return cov_lookup(corner_lut(r), r, mx, my);
}

static inline int rounded_corner_coverage(int px, int py, int w, int h, int r) {
    return gfx_rounded_coverage(px, py, w, h, r);
}

/* Square root through the x87 unit -- the FPU is already initialised for
 * the calculator, and fsqrt is a single instruction. */
static inline double gfx_sqrt(double v) {
    double r;
    __asm__("fsqrt" : "=t"(r) : "0"(v));
    return r;
}

/* ---- temporary render target ----
 * Every gfx_* routine draws into the `backbuffer` global. Pointing that
 * global at another pixel buffer for the duration of a few calls is all it
 * takes to draw into it instead -- that is how the app syscall layer lets
 * a .app use the full set of desktop primitives (rounded rects, AA lines,
 * text, ...) on its own window surface. Not nestable: one level only. */
static gfx_surface_t saved_target;
static int target_pushed = 0;

void gfx_target_push(uint32_t *pixels, int w, int h) {
    if(target_pushed || !pixels || w <= 0 || h <= 0) return;
    saved_target = backbuffer;
    backbuffer.pixels = pixels;
    backbuffer.width = (uint32_t)w;
    backbuffer.height = (uint32_t)h;
    target_pushed = 1;
}

void gfx_target_pop(void) {
    if(!target_pushed) return;
    backbuffer = saved_target;
    target_pushed = 0;
}

/* Opaque rectangular copy (no blending), clipped to the target. `stride`
 * is the source row length in pixels. */
void gfx_copy_pixels(int x, int y, const uint32_t *src, int w, int h, int stride) {
    if(!src || w <= 0 || h <= 0) return;
    int sx0 = 0, sy0 = 0;
    if(x < 0) { sx0 = -x; }
    if(y < 0) { sy0 = -y; }
    int dx0 = x + sx0, dy0 = y + sy0;
    int copy_w = w - sx0;
    if(dx0 + copy_w > (int)backbuffer.width) copy_w = (int)backbuffer.width - dx0;
    int rows = h - sy0;
    if(dy0 + rows > (int)backbuffer.height) rows = (int)backbuffer.height - dy0;
    if(copy_w <= 0 || rows <= 0) return;
    for(int r = 0; r < rows; r++) {
        const uint32_t *from = src + (sy0 + r) * stride + sx0;
        uint32_t *to = backbuffer.pixels + (dy0 + r) * backbuffer.width + dx0;
        for(int c = 0; c < copy_w; c++) to[c] = from[c];
    }
}

/* ---- generic rounded rectangle: per-corner, translucent, gradient ---- */

static inline uint32_t lerp_argb(uint32_t a, uint32_t b, int num, int den) {
    if(den <= 0) return a;
    uint32_t out = 0;
    for(int sh = 0; sh <= 24; sh += 8) {
        int ca = (int)((a >> sh) & 0xFF), cb = (int)((b >> sh) & 0xFF);
        int c = ca + ((cb - ca) * num) / den;
        out |= (uint32_t)c << sh;
    }
    return out;
}

static void blend_span(int yy, int x0, int x1, uint32_t argb, uint32_t a) {
    if(yy < 0 || yy >= (int)backbuffer.height) return;
    if(x0 < 0) x0 = 0;
    if(x1 > (int)backbuffer.width) x1 = (int)backbuffer.width;
    if(x1 <= x0) return;
    uint32_t *row = backbuffer.pixels + yy * backbuffer.width;
    if(a >= 255) {
        fill_span(row + x0, x1 - x0, argb & 0x00FFFFFF);
    }
    else if(a > 0) {
        for(int xx = x0; xx < x1; xx++) row[xx] = blend_argb_over(row[xx], argb, a);
    }
}

static void rrect_core(int x, int y, int w, int h, int r,
                       uint32_t top, uint32_t bottom, int corners) {
    if(w <= 0 || h <= 0) return;
    if(r > w / 2) r = w / 2;
    if(r > h / 2) r = h / 2;
    if(r < 0) r = 0;
    if(r == 0) corners = 0;

    const uint8_t *lut = r > 0 ? corner_lut(r) : NULL;
    int y0 = clampi(y, 0, (int)backbuffer.height);
    int y1 = clampi(y + h, 0, (int)backbuffer.height);
    int graded = (top != bottom);

    for(int yy = y0; yy < y1; yy++) {
        int py = yy - y;
        uint32_t col = graded ? lerp_argb(top, bottom, py, h - 1) : top;
        uint32_t ba = col >> 24;
        if(ba == 0) continue;

        int lc = 0, rc = 0, my = 0;
        if(py < r)           { lc = corners & GFX_CORNER_TL; rc = corners & GFX_CORNER_TR; my = r - py; }
        else if(py >= h - r) { lc = corners & GFX_CORNER_BL; rc = corners & GFX_CORNER_BR; my = py - (h - r - 1); }

        blend_span(yy, x + (lc ? r : 0), x + w - (rc ? r : 0), col, ba);

        if(lc) {
            for(int i = 0; i < r; i++) {
                int cov = cov_lookup(lut, r, r - i, my);
                if(cov <= 0) continue;
                uint32_t a = cov >= 255 ? ba : (ba * (uint32_t)cov) / 255;
                if(a) blend_span(yy, x + i, x + i + 1, col, a);
            }
        }
        if(rc) {
            for(int i = 0; i < r; i++) {
                int cov = cov_lookup(lut, r, i + 1, my);
                if(cov <= 0) continue;
                uint32_t a = cov >= 255 ? ba : (ba * (uint32_t)cov) / 255;
                if(a) blend_span(yy, x + w - r + i, x + w - r + i + 1, col, a);
            }
        }
    }
}

void gfx_blend_rounded_rect_ex(int x, int y, int w, int h, int radius, uint32_t argb, int corners) {
    rrect_core(x, y, w, h, radius, argb, argb, corners);
}

void gfx_fill_rounded_gradient(int x, int y, int w, int h, int radius,
                               uint32_t top_argb, uint32_t bottom_argb, int corners) {
    rrect_core(x, y, w, h, radius, top_argb, bottom_argb, corners);
}

/* 1px antialiased outline hugging a rounded rectangle's edge (what the
 * old code faked with gfx_draw_rect, whose square corners stuck out past
 * the rounded fill underneath it). */
void gfx_draw_rounded_outline(int x, int y, int w, int h, int radius, uint32_t argb) {
    if(w < 2 || h < 2) return;
    int r = radius;
    if(r > w / 2) r = w / 2;
    if(r > h / 2) r = h / 2;
    if(r < 0) r = 0;
    uint32_t ba = argb >> 24;
    if(ba == 0) return;

    /* Straight edges, between the corners. */
    gfx_blend_rounded_rect_ex(x + r, y, w - 2 * r, 1, 0, argb, 0);
    gfx_blend_rounded_rect_ex(x + r, y + h - 1, w - 2 * r, 1, 0, argb, 0);
    gfx_blend_rounded_rect_ex(x, y + r, 1, h - 2 * r, 0, argb, 0);
    gfx_blend_rounded_rect_ex(x + w - 1, y + r, 1, h - 2 * r, 0, argb, 0);
    if(r == 0) {
        gfx_blend_rounded_rect_ex(x, y, 1, 1, 0, argb, 0);
        gfx_blend_rounded_rect_ex(x + w - 1, y, 1, 1, 0, argb, 0);
        gfx_blend_rounded_rect_ex(x, y + h - 1, 1, 1, 0, argb, 0);
        gfx_blend_rounded_rect_ex(x + w - 1, y + h - 1, 1, 1, 0, argb, 0);
        return;
    }

    /* Corners: ring coverage = outer silhouette minus the silhouette of
     * the same rect shrunk by one pixel. */
    for(int j = 0; j < r; j++) {
        for(int i = 0; i < r; i++) {
            int px[2] = { i, w - 1 - i };
            int py[2] = { j, h - 1 - j };
            for(int a = 0; a < 2; a++) {
                for(int b = 0; b < 2; b++) {
                    int outer = gfx_rounded_coverage(px[a], py[b], w, h, r);
                    int inner = gfx_rounded_coverage(px[a] - 1, py[b] - 1, w - 2, h - 2, r > 1 ? r - 1 : 0);
                    if(px[a] < 1 || py[b] < 1 || px[a] > w - 2 || py[b] > h - 2) inner = 0;
                    int ring = outer - inner;
                    if(ring <= 0) continue;
                    uint32_t al = (ba * (uint32_t)ring) / 255;
                    if(al) gfx_blend_pixel(x + px[a], y + py[b], (argb & 0x00FFFFFF) | (al << 24));
                }
            }
        }
    }
}

/* Soft drop shadow around a rounded rectangle. Only the pixels OUTSIDE
 * the window are touched (the window itself is drawn on top afterwards),
 * the falloff is a cubic ease-out so the edge fades out smoothly rather
 * than banding, and the whole thing is separable (one lookup per axis),
 * so it costs a handful of integer ops per shadow pixel -- no blur
 * passes, no extra buffers. `offset_y` pushes the shadow down a bit,
 * which is what makes a window look like it is floating above the
 * desktop instead of glowing. */
void gfx_draw_shadow(int x, int y, int w, int h, int radius, int spread, int offset_y, int max_alpha) {
    if(spread <= 0 || max_alpha <= 0 || w <= 0 || h <= 0) return;
    if(spread > 48) spread = 48;
    if(max_alpha > 255) max_alpha = 255;

    int r = radius;
    if(r > w / 2) r = w / 2;
    if(r > h / 2) r = h / 2;
    if(r < 0) r = 0;

    /* alpha_at[d] = shadow darkness at distance d (px) outside the
     * rounded silhouette, cubic ease-out. */
    uint8_t alpha_at[49];
    int s3 = spread * spread * spread;
    for(int d = 0; d <= spread; d++) {
        int v = spread - d;
        alpha_at[d] = (uint8_t)(((v * v * v * 255) / s3 * max_alpha) / 255);
    }

    /* Distance is measured to the shadow rectangle's "core" -- the rect
     * shrunk by the corner radius -- minus the radius, which yields the
     * exact distance to a rounded rectangle. Along straight edges that is
     * a plain subtraction; only in the corner zones does it need a square
     * root (done by the FPU in one instruction). Without this the corners
     * of the shadow came out as dark squares. */
    int sy = y + offset_y;
    int core_x0 = x + r, core_x1 = x + w - 1 - r;
    int core_y0 = sy + r, core_y1 = sy + h - 1 - r;

    int bx0 = x - spread, bx1 = x + w + spread;
    int by0 = sy - spread, by1 = sy + h + spread;
    int ya = by0 < 0 ? 0 : by0;
    int yb = by1 > (int)backbuffer.height ? (int)backbuffer.height : by1;

    for(int yy = ya; yy < yb; yy++) {
        int ey = yy < core_y0 ? core_y0 - yy : (yy > core_y1 ? yy - core_y1 : 0);

        /* The part hidden under the window itself is skipped entirely. */
        int skip0 = 0, skip1 = 0;
        if(yy >= y && yy < y + h) {
            int py = yy - y;
            int corner = (py < r || py >= h - r);
            skip0 = x + (corner ? r : 0);
            skip1 = x + w - (corner ? r : 0);
        }

        uint32_t *row = backbuffer.pixels + yy * backbuffer.width;
        for(int xx = bx0; xx < bx1; xx++) {
            if(xx >= skip0 && xx < skip1) { xx = skip1 - 1; continue; }
            if(xx < 0) continue;
            if(xx >= (int)backbuffer.width) break;

            int ex = xx < core_x0 ? core_x0 - xx : (xx > core_x1 ? xx - core_x1 : 0);
            int d;
            if(ex == 0 || ey == 0) {
                d = ex + ey - r;
            }
            else {
                double dist = gfx_sqrt((double)(ex * ex + ey * ey));
                d = (int)(dist - (double)r + 0.5);
            }
            if(d < 0) d = 0;
            if(d > spread) continue;
            uint32_t a = alpha_at[d];
            if(a) row[xx] = blend_argb_over(row[xx], 0xFF000000, a);
        }
    }
}

void gfx_fill_circle(int cx, int cy, int r, uint32_t argb) {
    if(r <= 0) return;
    gfx_blend_rounded_rect_ex(cx - r, cy - r, r * 2, r * 2, r, argb, GFX_CORNER_ALL);
}

/* Antialiased line segment with round caps and arbitrary thickness,
 * evaluated as a distance field over the segment's bounding box: for each
 * pixel the coverage is how much of the pixel lies within width/2 of the
 * segment. Used for clock hands, the close "x", chart lines. */
void gfx_draw_line_thick(double x0, double y0, double x1, double y1, double width, uint32_t argb) {
    uint32_t base = argb >> 24;
    if(base == 0 || width <= 0) return;
    double half = width / 2.0;
    double pad = half + 1.0;

    double minx = x0 < x1 ? x0 : x1, maxx = x0 < x1 ? x1 : x0;
    double miny = y0 < y1 ? y0 : y1, maxy = y0 < y1 ? y1 : y0;
    int ix0 = (int)(minx - pad), ix1 = (int)(maxx + pad) + 1;
    int iy0 = (int)(miny - pad), iy1 = (int)(maxy + pad) + 1;
    if(ix0 < 0) ix0 = 0;
    if(iy0 < 0) iy0 = 0;
    if(ix1 > (int)backbuffer.width) ix1 = (int)backbuffer.width;
    if(iy1 > (int)backbuffer.height) iy1 = (int)backbuffer.height;

    double dx = x1 - x0, dy = y1 - y0;
    double len2 = dx * dx + dy * dy;

    for(int py = iy0; py < iy1; py++) {
        uint32_t *row = backbuffer.pixels + py * backbuffer.width;
        for(int px = ix0; px < ix1; px++) {
            double fx = px + 0.5 - x0, fy = py + 0.5 - y0;
            double t = len2 > 0 ? (fx * dx + fy * dy) / len2 : 0;
            if(t < 0) t = 0;
            if(t > 1) t = 1;
            double ex = fx - t * dx, ey = fy - t * dy;
            double d = gfx_sqrt(ex * ex + ey * ey);
            double cov = half + 0.5 - d;
            if(cov <= 0) continue;
            if(cov > 1) cov = 1;
            uint32_t a = (uint32_t)(cov * (double)base);
            if(a) row[px] = blend_argb_over(row[px], argb, a);
        }
    }
}

void gfx_fill_rounded_rect(int x, int y, int w, int h, int radius, uint32_t color) {
    if(radius <= 0) {
        gfx_fill_rect(x, y, w, h, color);
        return;
    }
    /* Opaque by definition (alpha byte of `color` is ignored). */
    rrect_core(x, y, w, h, radius, color | 0xFF000000, color | 0xFF000000, GFX_CORNER_ALL);
}

void gfx_blend_rounded_rect(int x, int y, int w, int h, int radius, uint32_t argb) {
    rrect_core(x, y, w, h, radius, argb, argb, GFX_CORNER_ALL);
}

void gfx_blend_pixel(int x, int y, uint32_t argb) {
    if(x < 0 || y < 0 || x >= (int)backbuffer.width || y >= (int)backbuffer.height) {
        return;
    }

    uint32_t a = (argb >> 24) & 0xFF;
    if(a == 0) return;

    uint32_t *dst = &backbuffer.pixels[y * backbuffer.width + x];
    if(a == 255) {
        *dst = argb & 0x00FFFFFF;
        return;
    }
    *dst = blend_argb_over(*dst, argb, a);
}

void gfx_blit_argb(int screen_x, int screen_y, const uint32_t *pixels,
                    int img_w, int img_h, int hotspot_x, int hotspot_y) {
    int origin_x = screen_x - hotspot_x;
    int origin_y = screen_y - hotspot_y;

    int sx0 = origin_x < 0 ? -origin_x : 0;
    int sy0 = origin_y < 0 ? -origin_y : 0;
    int sx1 = img_w;
    int sy1 = img_h;
    if(origin_x + sx1 > (int)backbuffer.width) sx1 = (int)backbuffer.width - origin_x;
    if(origin_y + sy1 > (int)backbuffer.height) sy1 = (int)backbuffer.height - origin_y;

    for(int y = sy0; y < sy1; y++) {
        uint32_t *dst = backbuffer.pixels + (origin_y + y) * backbuffer.width + origin_x;
        const uint32_t *src = pixels + y * img_w;
        for(int x = sx0; x < sx1; x++) {
            uint32_t p = src[x];
            uint32_t a = p >> 24;
            if(a == 0) continue;
            if(a == 255) dst[x] = p & 0x00FFFFFF;
            else dst[x] = blend_argb_over(dst[x], p, a);
        }
    }
}

/* Per-column source index table, so the scaled blits do one table lookup
 * per pixel instead of a multiply+divide (divides are extremely slow
 * under QEMU's CPU emulation). Sized for the widest supported mode. */
#define GFX_MAX_SCALE_W 4096
static int scale_x_map[GFX_MAX_SCALE_W];

static int build_scale_map(int dst_x, int dst_w, int x0, int x1, int src_w) {
    if(x1 - x0 > GFX_MAX_SCALE_W) return 0;
    for(int dx = x0; dx < x1; dx++) {
        int sx = ((dx - dst_x) * src_w) / dst_w;
        if(sx < 0) sx = 0;
        if(sx >= src_w) sx = src_w - 1;
        scale_x_map[dx - x0] = sx;
    }
    return 1;
}

void gfx_blit_scaled_argb(int dst_x, int dst_y, int dst_w, int dst_h,
                           const uint32_t *pixels, int src_w, int src_h) {
    if(src_w <= 0 || src_h <= 0 || dst_w <= 0 || dst_h <= 0) return;

    int x0 = clampi(dst_x, 0, (int)backbuffer.width);
    int y0 = clampi(dst_y, 0, (int)backbuffer.height);
    int x1 = clampi(dst_x + dst_w, 0, (int)backbuffer.width);
    int y1 = clampi(dst_y + dst_h, 0, (int)backbuffer.height);
    if(x1 <= x0 || !build_scale_map(dst_x, dst_w, x0, x1, src_w)) return;

    for(int dy = y0; dy < y1; dy++) {
        int sy = ((dy - dst_y) * src_h) / dst_h;
        if(sy < 0) sy = 0;
        if(sy >= src_h) sy = src_h - 1;
        const uint32_t *src_row = pixels + sy * src_w;
        uint32_t *dst_row = backbuffer.pixels + dy * backbuffer.width + x0;
        for(int dx = 0; dx < x1 - x0; dx++) {
            dst_row[dx] = src_row[scale_x_map[dx]] & 0x00FFFFFF;
        }
    }
}

/* Straight opaque copy of a pre-scaled, screen-sized (or any-sized)
 * image -- one memcpy per row. The desktop caches its scaled wallpaper
 * once and uses this every frame instead of re-scaling it. */
void gfx_blit_opaque(int dst_x, int dst_y, const uint32_t *pixels, int w, int h) {
    int x0 = clampi(dst_x, 0, (int)backbuffer.width);
    int y0 = clampi(dst_y, 0, (int)backbuffer.height);
    int x1 = clampi(dst_x + w, 0, (int)backbuffer.width);
    int y1 = clampi(dst_y + h, 0, (int)backbuffer.height);
    if(x1 <= x0) return;
    for(int yy = y0; yy < y1; yy++) {
        memcpy(backbuffer.pixels + yy * backbuffer.width + x0,
               pixels + (yy - dst_y) * w + (x0 - dst_x),
               (size_t)(x1 - x0) * 4);
    }
}

void gfx_blit_scaled_argb_alpha(int dst_x, int dst_y, int dst_w, int dst_h,
                                 const uint32_t *pixels, int src_w, int src_h) {
    if(src_w <= 0 || src_h <= 0 || dst_w <= 0 || dst_h <= 0) return;

    int x0 = clampi(dst_x, 0, (int)backbuffer.width);
    int y0 = clampi(dst_y, 0, (int)backbuffer.height);
    int x1 = clampi(dst_x + dst_w, 0, (int)backbuffer.width);
    int y1 = clampi(dst_y + dst_h, 0, (int)backbuffer.height);
    if(x1 <= x0 || !build_scale_map(dst_x, dst_w, x0, x1, src_w)) return;

    for(int dy = y0; dy < y1; dy++) {
        int sy = ((dy - dst_y) * src_h) / dst_h;
        if(sy < 0) sy = 0;
        if(sy >= src_h) sy = src_h - 1;
        const uint32_t *src_row = pixels + sy * src_w;
        uint32_t *dst_row = backbuffer.pixels + dy * backbuffer.width + x0;
        for(int dx = 0; dx < x1 - x0; dx++) {
            uint32_t p = src_row[scale_x_map[dx]];
            uint32_t a = p >> 24;
            if(a == 0) continue;
            if(a == 255) dst_row[dx] = p & 0x00FFFFFF;
            else dst_row[dx] = blend_argb_over(dst_row[dx], p, a);
        }
    }
}

/* --- text rendering ---
 * Mirrors the same simplistic (char - 32) * 16-bytes-per-glyph layout that
 * kernel/vesa.c's populate_chars() assumes for this particular font blob,
 * so glyphs drawn here look identical to the boot console's text.
 * GFX_CHAR_ROWS/COLS are declared in gfx.h (not here) so other files can
 * use them too, e.g. to center text. */

void gfx_draw_string(int x, int y, const char *str, uint32_t fg_color) {
    int cx = x;
    uint32_t color = fg_color & 0x00FFFFFF;
    int W = (int)backbuffer.width, H = (int)backbuffer.height;

    while(*str) {
        char c = *str++;
        if(c == '\n') { cx = x; y += GFX_CHAR_ROWS; continue; }
        if(c < ' ' || (unsigned char)c > '~') { cx += GFX_CHAR_COLS; continue; }

        /* Whole glyph off-screen horizontally/vertically: skip it. */
        if(cx + GFX_CHAR_COLS <= 0 || cx >= W || y + GFX_CHAR_ROWS <= 0 || y >= H) {
            cx += GFX_CHAR_COLS;
            continue;
        }

        unsigned short offset = ((unsigned char)c - 31) * 16;
        int fully_inside = (cx >= 0 && cx + GFX_CHAR_COLS <= W && y >= 0 && y + GFX_CHAR_ROWS <= H);

        for(int row = 0; row < GFX_CHAR_ROWS; row++) {
            uint8_t bits = font.Bitmap[offset + row];
            if(!bits) continue;
            if(fully_inside) {
                uint32_t *dst = backbuffer.pixels + (y + row) * W + cx;
                if(bits & 0x80) dst[0] = color;
                if(bits & 0x40) dst[1] = color;
                if(bits & 0x20) dst[2] = color;
                if(bits & 0x10) dst[3] = color;
                if(bits & 0x08) dst[4] = color;
                if(bits & 0x04) dst[5] = color;
                if(bits & 0x02) dst[6] = color;
                if(bits & 0x01) dst[7] = color;
            }
            else {
                for(int col = 0; col < GFX_CHAR_COLS; col++) {
                    if(bits & (0x80 >> col)) gfx_blend_pixel(cx + col, y + row, 0xFF000000 | color);
                }
            }
        }
        cx += GFX_CHAR_COLS;
    }
}

/* Draws text with every font pixel enlarged to scale x scale squares --
 * used for the calculator's big result display (the font is fixed 8x16). */
void gfx_draw_string_scaled(int x, int y, const char *str, uint32_t fg_color, int scale) {
    if(scale <= 1) { gfx_draw_string(x, y, str, fg_color); return; }
    uint32_t color = fg_color | 0xFF000000;
    int cx = x;
    while(*str) {
        char c = *str++;
        if(c < ' ' || (unsigned char)c > '~') { cx += GFX_CHAR_COLS * scale; continue; }
        unsigned short offset = ((unsigned char)c - 31) * 16;
        for(int row = 0; row < GFX_CHAR_ROWS; row++) {
            uint8_t bits = font.Bitmap[offset + row];
            if(!bits) continue;
            int col = 0;
            while(col < GFX_CHAR_COLS) {
                if(bits & (0x80 >> col)) {
                    int run = 1;
                    while(col + run < GFX_CHAR_COLS && (bits & (0x80 >> (col + run)))) run++;
                    gfx_fill_rect(cx + col * scale, y + row * scale, run * scale, scale, color);
                    col += run;
                }
                else col++;
            }
        }
        cx += GFX_CHAR_COLS * scale;
    }
}

/* ---- mouse cursor without a full redraw ----
 * Moving the pointer used to rebuild and copy the WHOLE screen. Now the
 * scene (everything except the cursor) stays in the back buffer, and the
 * cursor is composited on top of it on its own:
 *   gfx_present_with_cursor  after a full redraw: cursor goes into the back
 *                            buffer, the frame is presented, then the pixels
 *                            under the cursor are put back, so the back
 *                            buffer stays cursor-free;
 *   gfx_move_cursor          for plain movement / animation frames: restores
 *                            the old spot on screen from the back buffer and
 *                            draws the new one -- a few hundred pixels
 *                            instead of ~900,000. */
#define CURSOR_MAX 64
static uint32_t cursor_backing[CURSOR_MAX * CURSOR_MAX];
static int cur_valid = 0, cur_rx = 0, cur_ry = 0, cur_rw = 0, cur_rh = 0;

/* Sprite rectangle clipped to the screen; returns 0 if nothing is visible. */
static int cursor_rect(int x, int y, int w, int h, int hx, int hy, int *rx, int *ry, int *rw, int *rh, int *sx, int *sy) {
    if(w <= 0 || h <= 0 || w > CURSOR_MAX || h > CURSOR_MAX) return 0;
    int x0 = x - hx, y0 = y - hy, x1 = x0 + w, y1 = y0 + h;
    int cx0 = x0 < 0 ? 0 : x0, cy0 = y0 < 0 ? 0 : y0;
    int cx1 = x1 > (int)backbuffer.width ? (int)backbuffer.width : x1;
    int cy1 = y1 > (int)backbuffer.height ? (int)backbuffer.height : y1;
    if(cx1 <= cx0 || cy1 <= cy0) return 0;
    *rx = cx0; *ry = cy0; *rw = cx1 - cx0; *rh = cy1 - cy0;
    *sx = cx0 - x0; *sy = cy0 - y0;
    return 1;
}

static inline uint32_t cursor_pixel(uint32_t base, uint32_t src, uint32_t dim) {
    uint32_t a = src >> 24;
    if(a == 0) return base;
    if(dim) {                     /* software brightness applies to the cursor too */
        uint32_t k = 255 - dim;
        uint32_t r = div255(((src >> 16) & 0xFF) * k), g = div255(((src >> 8) & 0xFF) * k), b = div255((src & 0xFF) * k);
        src = (src & 0xFF000000u) | (r << 16) | (g << 8) | b;
    }
    return a >= 255 ? (src & 0x00FFFFFF) : blend_argb_over(base, src, a);
}

/* Software brightness: scales every pixel toward black by `alpha`/255. Two
 * channels at a time in one multiply (the 0x00FF00FF / 0x0000FF00 split), no
 * per-pixel division -- the previous full-screen alpha blend cost several
 * times as much, every frame, for anyone with brightness below 100%. */
void gfx_darken_screen(uint32_t alpha) {
    if(alpha == 0) return;
    if(alpha > 255) alpha = 255;
    uint32_t k = 255 - alpha;
    uint32_t n = backbuffer.width * backbuffer.height;
    uint32_t *p = backbuffer.pixels;
    for(uint32_t i = 0; i < n; i++) {
        uint32_t v = p[i];
        uint32_t rb = (((v & 0x00FF00FFu) * k) >> 8) & 0x00FF00FFu;
        uint32_t gg = (((v & 0x0000FF00u) * k) >> 8) & 0x0000FF00u;
        p[i] = (v & 0xFF000000u) | rb | gg;
    }
}

static void gfx_present_raw(void);

/* ---- hardware-style software cursor ---------------------------------------------
 * The pointer is drawn straight onto the visible framebuffer and the pixels
 * under it are kept in front_saved, so it can be moved WITHOUT the desktop loop:
 * the mouse interrupt calls gfx_cursor_irq_move(), which is why the pointer
 * keeps following the hand even while a program is stuck in an endless loop.
 * cursor_busy is a tiny lock: the normal (main-thread) drawing code sets it,
 * and the interrupt version simply gives up while it is set. */
static uint32_t front_saved[CURSOR_MAX * CURSOR_MAX];     /* scene (no pointer) under the pointer on screen */
static volatile int cursor_busy = 0;
static struct { const uint32_t *px; int w, h, hx, hy; uint32_t dim; } last_cur = { 0, 0, 0, 0, 0, 0 };

static void cursor_restore_front(void) {
    if(!cur_valid) return;
    uint8_t *fb = (uint8_t *)get_framebuffer_addr();
    uint32_t pitch = get_screen_pitch();
    for(int j = 0; j < cur_rh; j++) {
        uint32_t *dst = (uint32_t *)(fb + (uint32_t)(cur_ry + j) * pitch) + cur_rx;
        for(int i = 0; i < cur_rw; i++) dst[i] = front_saved[j * CURSOR_MAX + i];
    }
    cur_valid = 0;
}

/* Saves the scene under the new rectangle from the screen, then draws the pointer. */
static void cursor_draw_front(int x, int y, const uint32_t *px, int w, int h, int hx, int hy, uint32_t dim) {
    int rx, ry, rw, rh, sx, sy;
    if(!px || !cursor_rect(x, y, w, h, hx, hy, &rx, &ry, &rw, &rh, &sx, &sy)) return;
    uint8_t *fb = (uint8_t *)get_framebuffer_addr();
    uint32_t pitch = get_screen_pitch();
    for(int j = 0; j < rh; j++) {
        uint32_t *dst = (uint32_t *)(fb + (uint32_t)(ry + j) * pitch) + rx;
        for(int i = 0; i < rw; i++) {
            uint32_t base = dst[i];
            front_saved[j * CURSOR_MAX + i] = base;
            dst[i] = cursor_pixel(base, px[(sy + j) * w + sx + i], dim);
        }
    }
    cur_valid = 1; cur_rx = rx; cur_ry = ry; cur_rw = rw; cur_rh = rh;
}

void gfx_present_with_cursor(int x, int y, const uint32_t *px, int w, int h, int hx, int hy, uint32_t dim) {
    cursor_busy = 1;
    last_cur.px = px; last_cur.w = w; last_cur.h = h; last_cur.hx = hx; last_cur.hy = hy; last_cur.dim = dim;
    int rx, ry, rw, rh, sx, sy;
    int ok = px && cursor_rect(x, y, w, h, hx, hy, &rx, &ry, &rw, &rh, &sx, &sy);
    if(ok) {
        for(int j = 0; j < rh; j++) {
            uint32_t *row = backbuffer.pixels + (ry + j) * backbuffer.width + rx;
            for(int i = 0; i < rw; i++) {
                cursor_backing[j * CURSOR_MAX + i] = row[i];
                row[i] = cursor_pixel(row[i], px[(sy + j) * w + sx + i], dim);
            }
        }
    }
    gfx_present_raw();
    if(ok) {
        for(int j = 0; j < rh; j++) {
            uint32_t *row = backbuffer.pixels + (ry + j) * backbuffer.width + rx;
            for(int i = 0; i < rw; i++) { row[i] = cursor_backing[j * CURSOR_MAX + i]; front_saved[j * CURSOR_MAX + i] = cursor_backing[j * CURSOR_MAX + i]; }
        }
        cur_valid = 1; cur_rx = rx; cur_ry = ry; cur_rw = rw; cur_rh = rh;
    }
    else cur_valid = 0;
    cursor_busy = 0;
}

void gfx_move_cursor(int x, int y, const uint32_t *px, int w, int h, int hx, int hy, uint32_t dim) {
    cursor_busy = 1;
    last_cur.px = px; last_cur.w = w; last_cur.h = h; last_cur.hx = hx; last_cur.hy = hy; last_cur.dim = dim;
    cursor_restore_front();                           /* put the scene back where the cursor was */
    cursor_draw_front(x, y, px, w, h, hx, hy, dim);
    cursor_busy = 0;
}

/* Interrupt context: moves the pointer to (x, y) with the image the desktop used last.
 * Does nothing while the main thread is drawing (it will place the pointer itself). */
void gfx_cursor_irq_move(int x, int y) {
    if(cursor_busy || !last_cur.px) return;
    cursor_busy = 1;
    cursor_restore_front();
    cursor_draw_front(x, y, last_cur.px, last_cur.w, last_cur.h, last_cur.hx, last_cur.hy, last_cur.dim);
    cursor_busy = 0;
}

/* Interrupt context: swaps the pointer image (the not-responding spinner) and redraws it at (x, y). */
void gfx_cursor_irq_set(const uint32_t *px, int w, int h, int hx, int hy, int x, int y) {
    if(cursor_busy || !px) return;
    cursor_busy = 1;
    cursor_restore_front();
    last_cur.px = px; last_cur.w = w; last_cur.h = h; last_cur.hx = hx; last_cur.hy = hy;
    cursor_draw_front(x, y, px, w, h, hx, hy, last_cur.dim);
    cursor_busy = 0;
}

/* The plain frame copy; callers that manage the pointer hold cursor_busy around it. */
static void gfx_present_raw(void) {
    uint32_t fb_addr = get_framebuffer_addr();
    uint32_t pitch = get_screen_pitch();
    uint8_t *fb = (uint8_t *)fb_addr;

    uint32_t row_bytes = backbuffer.width * sizeof(uint32_t);

    /* Pitch == row size (the common case): the framebuffer is contiguous,
     * so copy the whole frame as ONE rep movsl instead of a call per row. */
    if(pitch == row_bytes) {
        uint32_t dwords = (row_bytes * backbuffer.height) >> 2;
        void *d = fb; const void *sp = backbuffer.pixels;
        __asm__ volatile("rep movsl" : "+D"(d), "+S"(sp), "+c"(dwords) : : "memory");
        return;
    }

    for(uint32_t y = 0; y < backbuffer.height; y++) {
        fastcp((char *)(fb + y * pitch), (char *)(backbuffer.pixels + y * backbuffer.width), row_bytes);
    }
}

void gfx_present() {
    cursor_busy = 1;
    gfx_present_raw();
    cur_valid = 0;                    /* the frame just overwrote the pointer */
    cursor_busy = 0;
}
