#include "stdint.h"
#include "stddef.h"
#include "shortcut.h"
#include "fileops.h"
#include "ini.h"
#include "common.h"
#include "kheap.h"
#include "apps.h"
#include "app_loader.h"
#include "app_explorer.h"
#include "app_notepad.h"
#include "app_mediaplayer.h"
#include "app_paint.h"

static const char *last_dot_of(const char *name) {
    const char *r = NULL;
    for(const char *p = name; *p; p++) if(*p == '.') r = p;
    return r;
}

static void copy_str(char *dst, int max, const char *src) {
    int i = 0;
    if(src) while(src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

int shortcut_load(const char *lnk_path, shortcut_t *out) {
    static ini_document_t doc;     /* large: keep it off the stack */
    memset(out, 0, sizeof(*out));

    uint32_t size = 0;
    uint8_t *data = fsu_read_file(lnk_path, &size);
    if(!data) return 0;
    int ok = ini_parse((const char *)data, size, &doc);
    kfree(data);
    if(!ok) return 0;

    const char *target = ini_get(&doc, "shortcut", "target");
    if(!target || !target[0]) return 0;
    copy_str(out->target, sizeof(out->target), target);

    const char *name = ini_get(&doc, "shortcut", "name");
    if(name && name[0]) copy_str(out->name, sizeof(out->name), name);
    else {
        char parent[FSU_PATH_MAX], file[48];
        fsu_split(lnk_path, parent, sizeof(parent), file, sizeof(file));
        const char *dot = last_dot_of(file);
        int n = dot ? (int)(dot - file) : (int)strlen(file);
        if(n > (int)sizeof(out->name) - 1) n = (int)sizeof(out->name) - 1;
        for(int i = 0; i < n; i++) out->name[i] = file[i];
        out->name[n] = '\0';
    }
    return 1;
}

int shortcut_create(const char *dir_path, const char *display_name, const char *target,
                    char *out_path, int out_max) {
    if(!dir_path || !display_name || !target || !target[0]) return 0;

    /* A file name can't hold every character a display name might. */
    char base[40]; int b = 0;
    for(const char *c = display_name; *c && b < 36; c++) {
        char ch = *c;
        if(ch == '/' || ch == '\\' || ch == ':' || ch == '*' || ch == '?' || ch == '"' || ch == '<' || ch == '>' || ch == '|') ch = '_';
        base[b++] = ch;
    }
    base[b] = '\0';
    if(!b) copy_str(base, sizeof(base), "Shortcut");

    char file[48];
    int p = 0;
    for(int i = 0; base[i] && p < 40; i++) file[p++] = base[i];
    file[p++] = '.'; file[p++] = 'l'; file[p++] = 'n'; file[p++] = 'k'; file[p] = '\0';

    char unique[64];
    fileops_unique_name(dir_path, file, unique, sizeof(unique));
    char full[FSU_PATH_MAX];
    fileops_join(dir_path, unique, full, sizeof(full));

    char text[SC_TARGET_MAX + 80]; int n = 0;
    const char *h1 = "[shortcut]\ntarget=";
    for(const char *c = h1; *c; c++) text[n++] = *c;
    for(const char *c = target; *c && n < (int)sizeof(text) - 40; c++) text[n++] = *c;
    const char *h2 = "\nname=";
    for(const char *c = h2; *c; c++) text[n++] = *c;
    for(const char *c = display_name; *c && n < (int)sizeof(text) - 3; c++) text[n++] = *c;
    text[n++] = '\n';

    if(!fsu_write_file(full, (const uint8_t *)text, (uint32_t)n)) return 0;
    if(out_path) copy_str(out_path, out_max, full);
    return 1;
}

int shortcut_create_for_path(const char *dir_path, const char *target_path, char *out_path, int out_max) {
    char parent[FSU_PATH_MAX], name[48];
    fsu_split(target_path, parent, sizeof(parent), name, sizeof(name));
    const char *dot = last_dot_of(name);
    int is_dir = 0;
    fsu_stat(target_path, &is_dir, NULL, NULL, NULL);
    char display[48];
    int n = (dot && !is_dir) ? (int)(dot - name) : (int)strlen(name);
    if(n > 46) n = 46;
    for(int i = 0; i < n; i++) display[i] = name[i];
    display[n] = '\0';
    if(!n) copy_str(display, sizeof(display), "Disk");
    return shortcut_create(dir_path, display, target_path, out_path, out_max);
}

app_entry_t *shortcut_target_app(const shortcut_t *sc) {
    if(strncmp(sc->target, "app:", 4) != 0) return NULL;
    const char *want = sc->target + 4;
    for(int i = 0; i < apps_count(); i++) {
        app_entry_t *a = apps_get(i);
        if(a && strcasecmp(a->name, want) == 0) return a;
    }
    return NULL;
}

static int is_text_ext(const char *ext) {
    static const char *list[] = { ".txt", ".log", ".md", ".ini", ".cfg", ".c", ".h", ".nasm", ".asm", ".json", ".xml", ".csv", ".bat", ".cmd", ".html", ".css", ".js", ".py" };
    for(unsigned i = 0; i < sizeof(list) / sizeof(list[0]); i++) if(strcasecmp(ext, list[i]) == 0) return 1;
    return 0;
}

static int open_depth = 0;

void desktop_open_path(const char *path) {
    int is_dir = 0;
    if(!fsu_stat(path, &is_dir, NULL, NULL, NULL)) return;
    if(is_dir) { launch_explorer_at(path); return; }

    const char *ext = last_dot_of(path);
    if(!ext) return;
    if(strcasecmp(ext, ".app") == 0) { app_loader_run(path); return; }
    if(strcasecmp(ext, ".mp3") == 0 || strcasecmp(ext, ".wav") == 0) { launch_mediaplayer_with_file(path); return; }
    if(is_text_ext(ext)) { launch_notepad_with_file(path); return; }
    if(strcasecmp(ext, ".lnk") == 0) {
        shortcut_t sc;
        if(open_depth < 4 && shortcut_load(path, &sc)) { open_depth++; shortcut_open(&sc); open_depth--; }
    }
}

void shortcut_open(const shortcut_t *sc) {
    app_entry_t *app = shortcut_target_app(sc);
    if(app) { apps_launch(app); return; }
    if(strncmp(sc->target, "app:", 4) == 0) return;      /* unknown built-in: nothing to do */
    desktop_open_path(sc->target);
}
