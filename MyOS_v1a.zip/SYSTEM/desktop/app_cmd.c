/*
 * Command Prompt -- modeled on the Windows 11 cmd.exe experience:
 * "C:\Users\User>" prompt, real directory navigation, the classic
 * command set with the same output formats/error messages, command
 * history, Tab completion and scrollback.
 */

#include "stdint.h"
#include "stddef.h"
#include "app_cmd.h"
#include "window.h"
#include "gfx.h"
#include "common.h"
#include "kernio.h"
#include "kheap.h"
#include "fat32.h"
#include "fs_util.h"
#include "clipboard.h"
#include "context_menu.h"
#include "keyboard.h"
#include "settings.h"
#include "rtc.h"
#include "pit.h"
#include "apps.h"
#include "app_loader.h"
#include "app_mediaplayer.h"
#include "app_notepad.h"
#include "app_calculator.h"
#include "cursor_set.h"

#define CMD_MAX_LINES 500
#define CMD_LINE_MAX 200
#define CMD_INPUT_MAX 180
#define CMD_HIST 32
#define CMD_MAX_ARGS 16
#define CMD_ENV_MAX 16
#define CMD_REDIR_MAX 32768
#define CMD_PAD_X 8
#define CMD_PAD_Y 6

extern uint32_t allocations;
extern uint32_t heap_free;

/* Windows "Campbell" console palette. */
static const uint32_t cmd_palette[16] = {
    0x0C0C0C, 0x0037DA, 0x13A10E, 0x3A96DD, 0xC50F1F, 0x881798, 0xC19C00, 0xCCCCCC,
    0x767676, 0x3B78FF, 0x16C60C, 0x61D6D6, 0xE74856, 0xB4009E, 0xF9F1A5, 0xF2F2F2,
};

typedef struct { char name[24]; char value[96]; } cmd_env_t;

typedef struct {
    window_t *win;

    char (*lines)[CMD_LINE_MAX];  /* ring buffer of finished output lines */
    int first, count;

    char cwd[FSU_PATH_MAX];
    char input[CMD_INPUT_MAX];
    int input_len, cursor;

    char hist[CMD_HIST][CMD_INPUT_MAX];
    int hist_count, hist_pos;     /* hist_pos == hist_count -> editing a new line */

    int scroll;                   /* visual rows scrolled up from the bottom */
    uint8_t fg, bg;               /* palette indexes */
    uint8_t echo_on;
    char prompt_fmt[64];
    int errorlevel;

    /* modal states */
    uint8_t pause_wait;           /* "Press any key to continue . . ." */
    uint8_t confirm_wait;         /* "Are you sure (Y/N)?" */
    char confirm_path[FSU_PATH_MAX];
    uint8_t want_exit;

    /* Tab completion cycling */
    int tab_active, tab_idx, tab_word_start;
    char tab_base[CMD_INPUT_MAX];

    cmd_env_t env[CMD_ENV_MAX];

    /* output redirection */
    char *redir_buf;
    uint32_t redir_len;
    uint8_t redir_on;
} cmd_state_t;

/* ---------- small string helpers ---------- */
static void scopy(char *dst, const char *src, int max) {
    int i = 0;
    while(src && src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}
static void sappend(char *dst, const char *src, int max) {
    int n = (int)strlen(dst);
    scopy(dst + n, src, max - n);
}
static char lower(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c; }

static int wild_match(const char *pat, const char *s) {
    while(*pat) {
        if(*pat == '*') {
            while(*pat == '*') pat++;
            if(!*pat) return 1;
            for(; *s; s++) if(wild_match(pat, s)) return 1;
            return 0;
        }
        if(!*s) return 0;
        if(*pat != '?' && lower(*pat) != lower(*s)) return 0;
        pat++; s++;
    }
    return *s == '\0';
}
static int has_wild(const char *s) { for(; *s; s++) if(*s == '*' || *s == '?') return 1; return 0; }

static void u32_to_str(uint32_t v, char *out) {
    char d[12]; int n = 0;
    if(!v) d[n++] = '0';
    while(v) { d[n++] = (char)('0' + v % 10); v /= 10; }
    for(int i = 0; i < n; i++) out[i] = d[n - 1 - i];
    out[n] = '\0';
}
static void pad2(int v, char *out) { out[0] = (char)('0' + (v / 10) % 10); out[1] = (char)('0' + v % 10); out[2] = '\0'; }

static void win_path(const char *cwd, char *out, int max) {
    out[0] = 'C'; out[1] = ':'; out[2] = '\0';
    if(strcmp(cwd, "/") == 0) { sappend(out, "\\", max); return; }
    int p = 2;
    for(const char *c = cwd; *c && p < max - 1; c++) out[p++] = (*c == '/') ? '\\' : *c;
    out[p] = '\0';
}

/* ---------- line storage ---------- */
static char *line_at(cmd_state_t *st, int i) { return st->lines[(st->first + i) % CMD_MAX_LINES]; }

static void push_raw(cmd_state_t *st, const char *text, int len) {
    int slot;
    if(st->count < CMD_MAX_LINES) { slot = (st->first + st->count) % CMD_MAX_LINES; st->count++; }
    else { slot = st->first; st->first = (st->first + 1) % CMD_MAX_LINES; }
    if(len > CMD_LINE_MAX - 1) len = CMD_LINE_MAX - 1;
    for(int i = 0; i < len; i++) st->lines[slot][i] = text[i];
    st->lines[slot][len] = '\0';
}

/* Appends output text (may contain '\n'); honors > redirection. */
static void out(cmd_state_t *st, const char *text) {
    if(st->redir_on) {
        for(const char *p = text; *p && st->redir_len < CMD_REDIR_MAX - 3; p++) {
            if(*p == '\n') { st->redir_buf[st->redir_len++] = '\r'; }
            st->redir_buf[st->redir_len++] = *p;
        }
        if(st->redir_len < CMD_REDIR_MAX - 3) { st->redir_buf[st->redir_len++] = '\r'; st->redir_buf[st->redir_len++] = '\n'; }
        return;
    }
    const char *p = text;
    while(1) {
        const char *e = p;
        while(*e && *e != '\n') e++;
        int len = (int)(e - p);
        while(len > 0 && p[len - 1] == '\r') len--;
        if(len > CMD_LINE_MAX - 1) {
            /* Hard-split absurdly long lines; normal wrapping happens at draw time. */
            push_raw(st, p, CMD_LINE_MAX - 1);
            p += CMD_LINE_MAX - 1;
            continue;
        }
        push_raw(st, p, len);
        if(!*e) break;
        p = e + 1;
    }
    st->scroll = 0;
}

static void err(cmd_state_t *st, const char *msg) { out(st, msg); st->errorlevel = 1; }

/* ---------- prompt ---------- */
static void build_prompt(cmd_state_t *st, char *dst, int max) {
    dst[0] = '\0';
    if(!st->echo_on) return;
    char wp[FSU_PATH_MAX]; win_path(st->cwd, wp, sizeof(wp));
    const char *f = st->prompt_fmt;
    int p = 0;
    while(*f && p < max - 40) {
        if(*f == '$' && f[1]) {
            f++;
            char c = lower(*f++);
            const char *rep = NULL; char tmp[40];
            switch(c) {
                case 'p': rep = wp; break;
                case 'g': rep = ">"; break;
                case 'l': rep = "<"; break;
                case 'b': rep = "|"; break;
                case 's': rep = " "; break;
                case 'q': rep = "="; break;
                case '$': rep = "$"; break;
                case 'v': rep = "MyOS [Version 1.0.0]"; break;
                case 'n': rep = "C"; break;
                case 'd': { rtc_date_t d; rtc_read_date(&d); char a[4], b[4], y[8]; pad2(d.month, a); pad2(d.day, b); u32_to_str(d.year, y);
                            tmp[0] = 0; sappend(tmp, a, 40); sappend(tmp, "/", 40); sappend(tmp, b, 40); sappend(tmp, "/", 40); sappend(tmp, y, 40); rep = tmp; break; }
                case 't': { rtc_time_t t; rtc_read_time(&t); char a[4], b[4], s[4]; pad2(t.hours, a); pad2(t.minutes, b); pad2(t.seconds, s);
                            tmp[0] = 0; sappend(tmp, a, 40); sappend(tmp, ":", 40); sappend(tmp, b, 40); sappend(tmp, ":", 40); sappend(tmp, s, 40); rep = tmp; break; }
                default: rep = ""; break;
            }
            if(c == '_') { /* $_ = newline: not supported inside a single-row prompt */ rep = ""; }
            for(const char *r = rep; r && *r && p < max - 1; r++) dst[p++] = *r;
        }
        else dst[p++] = *f++;
    }
    dst[p] = '\0';
}

/* ---------- environment ---------- */
static const char *env_get(cmd_state_t *st, const char *name) {
    for(int i = 0; i < CMD_ENV_MAX; i++)
        if(st->env[i].name[0] && strcasecmp(st->env[i].name, name) == 0) return st->env[i].value;
    return NULL;
}
static void env_set(cmd_state_t *st, const char *name, const char *value) {
    int free_i = -1;
    for(int i = 0; i < CMD_ENV_MAX; i++) {
        if(st->env[i].name[0] && strcasecmp(st->env[i].name, name) == 0) {
            if(value && value[0]) scopy(st->env[i].value, value, sizeof(st->env[i].value));
            else st->env[i].name[0] = '\0';
            return;
        }
        if(!st->env[i].name[0] && free_i < 0) free_i = i;
    }
    if(free_i >= 0 && value && value[0]) {
        scopy(st->env[free_i].name, name, sizeof(st->env[free_i].name));
        scopy(st->env[free_i].value, value, sizeof(st->env[free_i].value));
    }
}

/* ---------- date/time formatting ---------- */
static const char *weekday_name(int y, int m, int d) {
    static const char *names[] = { "Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri" };
    if(m < 3) { m += 12; y--; }
    int k = y % 100, j = y / 100;
    int h = (d + (13 * (m + 1)) / 5 + k + k / 4 + j / 4 + 5 * j) % 7;
    return names[h];
}
static void fmt_date(char *out, int y, int m, int d) {
    char a[4], b[4], c[8]; pad2(m, a); pad2(d, b); u32_to_str((uint32_t)y, c);
    out[0] = 0; sappend(out, a, 16); sappend(out, "/", 16); sappend(out, b, 16); sappend(out, "/", 16); sappend(out, c, 16);
}
static void fmt_time12(char *out, int h, int mi) {
    int h12 = h % 12; if(h12 == 0) h12 = 12;
    char a[4], b[4]; pad2(h12, a); pad2(mi, b);
    out[0] = 0; sappend(out, a, 16); sappend(out, ":", 16); sappend(out, b, 16); sappend(out, h >= 12 ? " PM" : " AM", 16);
}

/* ---------- expansion of %VAR% ---------- */
static void expand_vars(cmd_state_t *st, const char *in, char *outbuf, int max) {
    int p = 0;
    while(*in && p < max - 1) {
        if(*in == '%') {
            const char *e = in + 1;
            while(*e && *e != '%') e++;
            if(*e == '%' && e > in + 1) {
                char name[32]; int n = 0;
                for(const char *c = in + 1; c < e && n < 31; c++) name[n++] = *c;
                name[n] = '\0';
                char tmp[FSU_PATH_MAX]; const char *val = NULL;
                if(strcasecmp(name, "cd") == 0) { win_path(st->cwd, tmp, sizeof(tmp)); val = tmp; }
                else if(strcasecmp(name, "username") == 0) val = settings_current()->username;
                else if(strcasecmp(name, "computername") == 0) val = "MYOS";
                else if(strcasecmp(name, "errorlevel") == 0) { u32_to_str((uint32_t)st->errorlevel, tmp); val = tmp; }
                else if(strcasecmp(name, "date") == 0) { rtc_date_t d; rtc_read_date(&d); fmt_date(tmp, d.year, d.month, d.day); val = tmp; }
                else if(strcasecmp(name, "time") == 0) { rtc_time_t t; rtc_read_time(&t); fmt_time12(tmp, t.hours, t.minutes); val = tmp; }
                else val = env_get(st, name);
                if(val) {
                    for(const char *c = val; *c && p < max - 1; c++) outbuf[p++] = *c;
                    in = e + 1;
                    continue;
                }
            }
        }
        outbuf[p++] = *in++;
    }
    outbuf[p] = '\0';
}

/* ---------- argument tokenizer (quotes aware) ---------- */
static int tokenize(char *line, char **argv, int max) {
    int argc = 0;
    char *p = line;
    while(*p && argc < max) {
        while(*p == ' ' || *p == '\t') p++;
        if(!*p) break;
        if(*p == '"') {
            p++;
            argv[argc++] = p;
            while(*p && *p != '"') p++;
            if(*p) *p++ = '\0';
        }
        else {
            argv[argc++] = p;
            while(*p && *p != ' ' && *p != '\t') p++;
            if(*p) *p++ = '\0';
        }
    }
    return argc;
}

static int is_switch(const char *a, char c) { return (a[0] == '/' || a[0] == '-') && lower(a[1]) == lower(c) && !a[2]; }

static void resolve(cmd_state_t *st, const char *arg, char *outp) { fsu_normalize(st->cwd, arg, outp, FSU_PATH_MAX); }

/* ---------- sorted directory listing helper ---------- */
static int cmp_entries(struct directory *d, int a, int b) {
    int da = (d->entries[a].dir_attrs & DIRECTORY) != 0, db = (d->entries[b].dir_attrs & DIRECTORY) != 0;
    if(da != db) return db - da; /* directories first */
    return strcasecmp(d->entries[a].name, d->entries[b].name);
}

static int list_sorted(struct directory *d, int *idx, int max) {
    int n = 0;
    for(uint32_t i = 0; i < d->num_entries && n < max; i++) {
        if(!d->entries[i].name || (d->entries[i].dir_attrs & LFN)) continue;
        if(d->entries[i].name[0] == '\0') continue;
        idx[n++] = (int)i;
    }
    for(int i = 1; i < n; i++) {
        int k = idx[i], j = i - 1;
        while(j >= 0 && cmp_entries(d, idx[j], k) > 0) { idx[j + 1] = idx[j]; j--; }
        idx[j + 1] = k;
    }
    return n;
}

static void vol_info(cmd_state_t *st) {
    const struct bios_parameter_block *bpb = getBPB(master_fs);
    char label[16] = "MyOS";
    if(bpb && bpb->volume_label[0] && bpb->volume_label[0] != ' ') {
        int n = 0; while(n < 11 && bpb->volume_label[n] && bpb->volume_label[n] != ' ') { label[n] = bpb->volume_label[n]; n++; } label[n] = '\0';
    }
    uint32_t id = bpb ? bpb->volume_id : 0;
    static const char hx[] = "0123456789ABCDEF";
    char serial[10];
    serial[0] = hx[(id >> 28) & 15]; serial[1] = hx[(id >> 24) & 15]; serial[2] = hx[(id >> 20) & 15]; serial[3] = hx[(id >> 16) & 15];
    serial[4] = '-';
    serial[5] = hx[(id >> 12) & 15]; serial[6] = hx[(id >> 8) & 15]; serial[7] = hx[(id >> 4) & 15]; serial[8] = hx[id & 15]; serial[9] = 0;
    char line[80];
    line[0] = 0; sappend(line, " Volume in drive C is ", 80); sappend(line, label, 80); out(st, line);
    line[0] = 0; sappend(line, " Volume Serial Number is ", 80); sappend(line, serial, 80); out(st, line);
}

/* ---------- commands ---------- */
static void cmd_dir(cmd_state_t *st, int argc, char **argv) {
    int bare = 0; const char *target = NULL;
    for(int i = 1; i < argc; i++) {
        if(is_switch(argv[i], 'b')) bare = 1;
        else if(argv[i][0] == '/') { /* ignore other switches */ }
        else target = argv[i];
    }
    char path[FSU_PATH_MAX]; resolve(st, target ? target : ".", path);

    char dirpath[FSU_PATH_MAX]; char pattern[48]; pattern[0] = '\0';
    scopy(dirpath, path, sizeof(dirpath));
    int is_dir = 0;
    if(!fsu_stat(path, &is_dir, NULL, NULL, NULL) || !is_dir) {
        if(has_wild(path) || fsu_stat(path, &is_dir, NULL, NULL, NULL)) {
            fsu_split(path, dirpath, sizeof(dirpath), pattern, sizeof(pattern));
        }
        else { out(st, " Volume in drive C is MyOS"); out(st, ""); out(st, "File Not Found"); st->errorlevel = 1; return; }
    }

    struct directory d;
    if(!fsu_open_dir(dirpath, &d)) { err(st, "The system cannot find the path specified."); return; }
    int idx[256]; int n = list_sorted(&d, idx, 256);

    if(!bare) {
        vol_info(st);
        out(st, "");
        char wp[FSU_PATH_MAX], line[FSU_PATH_MAX + 20];
        win_path(dirpath, wp, sizeof(wp));
        line[0] = 0; sappend(line, " Directory of ", sizeof(line)); sappend(line, wp, sizeof(line)); out(st, line);
        out(st, "");
    }

    rtc_date_t today; rtc_time_t now; rtc_read_date(&today); rtc_read_time(&now);
    uint32_t files = 0, dirs = 0, total = 0; int shown = 0;

    for(int k = 0; k < n; k++) {
        struct dir_entry *e = &d.entries[idx[k]];
        if(pattern[0] && !wild_match(pattern, e->name)) continue;
        int isd = (e->dir_attrs & DIRECTORY) != 0;
        if(bare) {
            if(strcmp(e->name, ".") == 0 || strcmp(e->name, "..") == 0) continue;
            out(st, e->name); shown++;
            continue;
        }
        int y, mo, da, h, mi;
        if(e->wr_date) { y = 1980 + (e->wr_date >> 9); mo = (e->wr_date >> 5) & 15; da = e->wr_date & 31; h = e->wr_time >> 11; mi = (e->wr_time >> 5) & 63; }
        else { y = today.year; mo = today.month; da = today.day; h = now.hours; mi = now.minutes; }
        char ds[20], ts[20], line[FSU_PATH_MAX + 60];
        fmt_date(ds, y, mo, da); fmt_time12(ts, h, mi);
        line[0] = 0;
        sappend(line, ds, sizeof(line)); sappend(line, "  ", sizeof(line)); sappend(line, ts, sizeof(line)); sappend(line, "    ", sizeof(line));
        if(isd) { sappend(line, "<DIR>          ", sizeof(line)); dirs++; }
        else {
            char num[20], padded[24]; fsu_format_number(e->file_size, num, sizeof(num));
            int pad = 14 - (int)strlen(num); int p = 0; while(pad-- > 0) padded[p++] = ' ';
            for(char *c = num; *c; c++) padded[p++] = *c; padded[p++] = ' '; padded[p] = '\0';
            sappend(line, padded, sizeof(line));
            files++; total += e->file_size;
        }
        sappend(line, e->name, sizeof(line));
        out(st, line); shown++;
    }

    if(!bare) {
        if(!shown && pattern[0]) { out(st, "File Not Found"); st->errorlevel = 1; }
        else {
            char num[20], line[80], pad[24];
            fsu_format_number(files, num, sizeof(num));
            int sp = 15 - (int)strlen(num); int p = 0; while(sp-- > 0) pad[p++] = ' '; pad[p] = 0;
            line[0] = 0; sappend(line, pad, 80); sappend(line, num, 80); sappend(line, " File(s)", 80);
            char tn[20], tp[24]; fsu_format_number(total, tn, sizeof(tn));
            int sp2 = 15 - (int)strlen(tn); p = 0; while(sp2-- > 0) tp[p++] = ' '; tp[p] = 0;
            sappend(line, tp, 80); sappend(line, tn, 80); sappend(line, " bytes", 80); out(st, line);

            fsu_format_number(dirs, num, sizeof(num));
            sp = 15 - (int)strlen(num); p = 0; while(sp-- > 0) pad[p++] = ' '; pad[p] = 0;
            line[0] = 0; sappend(line, pad, 80); sappend(line, num, 80); sappend(line, " Dir(s)", 80);
            uint32_t free_bytes = master_fs ? count_free_clusters(master_fs) * master_fs->cluster_size : 0;
            fsu_format_number(free_bytes, tn, sizeof(tn));
            sp2 = 16 - (int)strlen(tn); p = 0; while(sp2-- > 0) tp[p++] = ' '; tp[p] = 0;
            sappend(line, tp, 80); sappend(line, tn, 80); sappend(line, " bytes free", 80); out(st, line);
        }
    }
    free_directory(master_fs, &d);
}

static void cmd_cd(cmd_state_t *st, int argc, char **argv) {
    int i = 1;
    if(argc > 1 && is_switch(argv[1], 'd')) i = 2;
    if(i >= argc) { char wp[FSU_PATH_MAX]; win_path(st->cwd, wp, sizeof(wp)); out(st, wp); return; }
    /* "cd Program Files" without quotes: join remaining args like Windows does. */
    char arg[FSU_PATH_MAX]; arg[0] = 0;
    for(int k = i; k < argc; k++) { if(k > i) sappend(arg, " ", sizeof(arg)); sappend(arg, argv[k], sizeof(arg)); }
    char path[FSU_PATH_MAX]; resolve(st, arg, path);
    int is_dir = 0;
    if(!fsu_stat(path, &is_dir, NULL, NULL, NULL) || !is_dir) {
        err(st, is_dir ? "The directory name is invalid." : "The system cannot find the path specified.");
        return;
    }
    scopy(st->cwd, path, sizeof(st->cwd));
}

static void cmd_md(cmd_state_t *st, int argc, char **argv) {
    if(argc < 2) { err(st, "The syntax of the command is incorrect."); return; }
    for(int a = 1; a < argc; a++) {
        char path[FSU_PATH_MAX]; resolve(st, argv[a], path);
        int is_dir;
        if(fsu_stat(path, &is_dir, NULL, NULL, NULL)) {
            char m[FSU_PATH_MAX + 50]; m[0] = 0; sappend(m, "A subdirectory or file ", sizeof(m)); sappend(m, argv[a], sizeof(m)); sappend(m, " already exists.", sizeof(m)); err(st, m); continue;
        }
        /* Create intermediate directories as needed (Windows does this). */
        char partial[FSU_PATH_MAX]; int p = 0; partial[0] = '\0';
        for(int i = 0; path[i]; ) {
            partial[p++] = path[i++];
            while(path[i] && path[i] != '/') partial[p++] = path[i++];
            partial[p] = '\0';
            if(p > 1 && !fsu_stat(partial, &is_dir, NULL, NULL, NULL)) {
                if(!fsu_mkdir(partial)) { err(st, "The system cannot find the path specified."); break; }
            }
        }
    }
}

static void cmd_rd(cmd_state_t *st, int argc, char **argv) {
    int recursive = 0, quiet = 0; const char *target = NULL;
    for(int i = 1; i < argc; i++) {
        if(is_switch(argv[i], 's')) recursive = 1;
        else if(is_switch(argv[i], 'q')) quiet = 1;
        else target = argv[i];
    }
    if(!target) { err(st, "The syntax of the command is incorrect."); return; }
    char path[FSU_PATH_MAX]; resolve(st, target, path);
    int is_dir = 0;
    if(!fsu_stat(path, &is_dir, NULL, NULL, NULL)) { err(st, "The system cannot find the file specified."); return; }
    if(!is_dir) { err(st, "The directory name is invalid."); return; }
    if(strcmp(path, "/") == 0 || strcmp(path, st->cwd) == 0) { err(st, "The process cannot access the file because it is being used by another process."); return; }
    if(recursive && !quiet) {
        scopy(st->confirm_path, path, sizeof(st->confirm_path));
        st->confirm_wait = 1;
        return;
    }
    if(!fsu_remove_dir(path, recursive)) err(st, "The directory is not empty.");
}

static void cmd_type(cmd_state_t *st, int argc, char **argv) {
    if(argc < 2) { err(st, "The syntax of the command is incorrect."); return; }
    for(int a = 1; a < argc; a++) {
        char path[FSU_PATH_MAX]; resolve(st, argv[a], path);
        int is_dir = 0; uint32_t size = 0;
        if(!fsu_stat(path, &is_dir, &size, NULL, NULL)) { err(st, "The system cannot find the file specified."); continue; }
        if(is_dir) { char m[FSU_PATH_MAX + 30]; m[0] = 0; sappend(m, argv[a], sizeof(m)); sappend(m, " Access is denied.", sizeof(m)); err(st, m); continue; }
        uint32_t len = 0; uint8_t *data = fsu_read_file(path, &len);
        if(!data) { err(st, "The system cannot find the file specified."); continue; }
        char line[CMD_LINE_MAX]; int lp = 0;
        for(uint32_t i = 0; i < len; i++) {
            char c = (char)data[i];
            if(c == '\n') { line[lp] = 0; out(st, line); lp = 0; }
            else if(c == '\r') { }
            else if(c == '\t') { for(int t = 0; t < 4 && lp < CMD_LINE_MAX - 1; t++) line[lp++] = ' '; }
            else if(c >= ' ' && (unsigned char)c < 127) { if(lp < CMD_LINE_MAX - 1) line[lp++] = c; }
            else { if(lp < CMD_LINE_MAX - 1) line[lp++] = '.'; }
        }
        if(lp) { line[lp] = 0; out(st, line); }
        kfree(data);
    }
}

/* Iterates files in the parent of `spec` that match its final component
 * (wildcards allowed), calling fn for each matching *file*. */
typedef void (*match_fn)(cmd_state_t *st, const char *dir, const char *name, void *ctx);
static int for_each_match(cmd_state_t *st, const char *spec, match_fn fn, void *ctx) {
    char path[FSU_PATH_MAX]; resolve(st, spec, path);
    char dir[FSU_PATH_MAX], pat[48];
    int is_dir = 0;
    if(fsu_stat(path, &is_dir, NULL, NULL, NULL) && !is_dir) { fsu_split(path, dir, sizeof(dir), pat, sizeof(pat)); }
    else { fsu_split(path, dir, sizeof(dir), pat, sizeof(pat)); }

    struct directory d;
    if(!fsu_open_dir(dir, &d)) return -1;
    int n = (int)d.num_entries;
    char (*names)[48] = (char (*)[48])kmalloc((uint32_t)(n ? n : 1) * 48);
    int cnt = 0;
    for(int i = 0; i < n; i++) {
        struct dir_entry *e = &d.entries[i];
        if(!e->name || (e->dir_attrs & (LFN | DIRECTORY))) continue;
        if(wild_match(pat, e->name)) { scopy(names[cnt], e->name, 48); cnt++; }
    }
    free_directory(master_fs, &d);
    for(int i = 0; i < cnt; i++) fn(st, dir, names[i], ctx);
    kfree(names);
    return cnt;
}

static void join(const char *dir, const char *name, char *o) {
    scopy(o, dir, FSU_PATH_MAX);
    int n = (int)strlen(o);
    if(n > 1) sappend(o, "/", FSU_PATH_MAX);
    sappend(o, name, FSU_PATH_MAX);
}

static void del_one(cmd_state_t *st, const char *dir, const char *name, void *ctx) {
    (void)st; (void)ctx; char p[FSU_PATH_MAX]; join(dir, name, p); fsu_delete_file(p);
}
static void cmd_del(cmd_state_t *st, int argc, char **argv) {
    const char *target = NULL;
    for(int i = 1; i < argc; i++) if(argv[i][0] != '/') target = argv[i];
    if(!target) { err(st, "The syntax of the command is incorrect."); return; }
    int n = for_each_match(st, target, del_one, NULL);
    if(n <= 0) {
        char path[FSU_PATH_MAX], m[FSU_PATH_MAX + 30]; resolve(st, target, path); char wp[FSU_PATH_MAX]; win_path(path, wp, sizeof(wp));
        m[0] = 0; sappend(m, "Could Not Find ", sizeof(m)); sappend(m, wp, sizeof(m)); err(st, m);
    }
}

typedef struct { char dst[FSU_PATH_MAX]; int dst_is_dir; int copied; int move; } copy_ctx_t;
static void copy_one(cmd_state_t *st, const char *dir, const char *name, void *vctx) {
    (void)st; copy_ctx_t *c = (copy_ctx_t *)vctx;
    char src[FSU_PATH_MAX], dst[FSU_PATH_MAX]; join(dir, name, src);
    if(c->dst_is_dir) join(c->dst, name, dst); else scopy(dst, c->dst, sizeof(dst));
    if(strcasecmp(src, dst) == 0) return;
    if(c->move ? fsu_move_file(src, dst) : fsu_copy_file(src, dst)) c->copied++;
}
static void cmd_copy_move(cmd_state_t *st, int argc, char **argv, int move) {
    const char *a[2] = { NULL, NULL }; int na = 0;
    for(int i = 1; i < argc; i++) if(argv[i][0] != '/' && na < 2) a[na++] = argv[i];
    if(na < 1) { err(st, "The syntax of the command is incorrect."); return; }
    if(na < 2) { if(move) { err(st, "The syntax of the command is incorrect."); return; } a[1] = "."; }

    copy_ctx_t ctx; ctx.copied = 0; ctx.move = move;
    resolve(st, a[1], ctx.dst);
    int dst_dir = 0; ctx.dst_is_dir = (fsu_stat(ctx.dst, &dst_dir, NULL, NULL, NULL) && dst_dir) ? 1 : 0;

    char src[FSU_PATH_MAX]; resolve(st, a[0], src);
    int src_dir = 0;
    if(fsu_stat(src, &src_dir, NULL, NULL, NULL) && src_dir) {
        if(!move) { err(st, "Access is denied."); return; }
        char target[FSU_PATH_MAX];
        if(ctx.dst_is_dir) { char par[FSU_PATH_MAX], nm[48]; fsu_split(src, par, sizeof(par), nm, sizeof(nm)); join(ctx.dst, nm, target); }
        else scopy(target, ctx.dst, sizeof(target));
        if(fsu_copy_tree(src, target) && fsu_remove_dir(src, 1)) out(st, "        1 dir(s) moved.");
        else err(st, "Access is denied.");
        return;
    }

    if(has_wild(a[0]) && !ctx.dst_is_dir) { err(st, "The syntax of the command is incorrect."); return; }
    int n = for_each_match(st, a[0], copy_one, &ctx);
    if(n <= 0) { err(st, "The system cannot find the file specified."); out(st, move ? "        0 file(s) moved." : "        0 file(s) copied."); return; }
    char num[16], line[48]; u32_to_str((uint32_t)ctx.copied, num);
    line[0] = 0; sappend(line, "        ", sizeof(line)); sappend(line, num, sizeof(line)); sappend(line, move ? " file(s) moved." : " file(s) copied.", sizeof(line));
    out(st, line);
}

static void cmd_ren(cmd_state_t *st, int argc, char **argv) {
    if(argc < 3) { err(st, "The syntax of the command is incorrect."); return; }
    char src[FSU_PATH_MAX], par[FSU_PATH_MAX], nm[48]; resolve(st, argv[1], src);
    int is_dir = 0;
    if(!fsu_stat(src, &is_dir, NULL, NULL, NULL)) { err(st, "The system cannot find the file specified."); return; }
    fsu_split(src, par, sizeof(par), nm, sizeof(nm));
    char dst[FSU_PATH_MAX]; join(par, argv[2], dst);
    if(fsu_stat(dst, NULL, NULL, NULL, NULL)) { err(st, "A duplicate file name exists, or the file cannot be found."); return; }
    int ok = is_dir ? (fsu_copy_tree(src, dst) && fsu_remove_dir(src, 1)) : fsu_move_file(src, dst);
    if(!ok) err(st, "Access is denied.");
}

static void tree_rec(cmd_state_t *st, const char *path, const char *prefix, int show_files, int depth) {
    if(depth > 8) return;
    struct directory d;
    if(!fsu_open_dir(path, &d)) return;
    int idx[256]; int n = list_sorted(&d, idx, 256);
    int shown[256]; int sc = 0;
    for(int k = 0; k < n; k++) {
        struct dir_entry *e = &d.entries[idx[k]];
        if(strcmp(e->name, ".") == 0 || strcmp(e->name, "..") == 0) continue;
        if(!(e->dir_attrs & DIRECTORY) && !show_files) continue;
        shown[sc++] = idx[k];
    }
    char (*names)[48] = (char (*)[48])kmalloc((uint32_t)(sc ? sc : 1) * 48);
    uint8_t *isd = (uint8_t *)kmalloc((uint32_t)(sc ? sc : 1));
    for(int k = 0; k < sc; k++) { scopy(names[k], d.entries[shown[k]].name, 48); isd[k] = (d.entries[shown[k]].dir_attrs & DIRECTORY) ? 1 : 0; }
    free_directory(master_fs, &d);

    for(int k = 0; k < sc; k++) {
        int last = (k == sc - 1);
        char line[CMD_LINE_MAX]; line[0] = 0;
        sappend(line, prefix, sizeof(line)); sappend(line, last ? "\\---" : "+---", sizeof(line)); sappend(line, names[k], sizeof(line));
        out(st, line);
        if(isd[k]) {
            char child[FSU_PATH_MAX], np[CMD_LINE_MAX];
            join(path, names[k], child);
            np[0] = 0; sappend(np, prefix, sizeof(np)); sappend(np, last ? "    " : "|   ", sizeof(np));
            tree_rec(st, child, np, show_files, depth + 1);
        }
    }
    kfree(names); kfree(isd);
}

static void cmd_tree(cmd_state_t *st, int argc, char **argv) {
    int files = 0; const char *t = NULL;
    for(int i = 1; i < argc; i++) { if(is_switch(argv[i], 'f')) files = 1; else if(argv[i][0] != '/') t = argv[i]; }
    char path[FSU_PATH_MAX]; resolve(st, t ? t : ".", path);
    int is_dir = 0;
    if(!fsu_stat(path, &is_dir, NULL, NULL, NULL) || !is_dir) { err(st, "Invalid path - "); return; }
    out(st, "Folder PATH listing"); vol_info(st);
    char wp[FSU_PATH_MAX]; win_path(path, wp, sizeof(wp)); out(st, wp);
    tree_rec(st, path, "", files, 0);
}

static void cmd_set(cmd_state_t *st, int argc, char **argv, const char *raw_args) {
    (void)argv;
    if(argc < 2) {
        for(int i = 0; i < CMD_ENV_MAX; i++) if(st->env[i].name[0]) {
            char l[140]; l[0] = 0; sappend(l, st->env[i].name, sizeof(l)); sappend(l, "=", sizeof(l)); sappend(l, st->env[i].value, sizeof(l)); out(st, l);
        }
        char l[140]; l[0] = 0; sappend(l, "USERNAME=", sizeof(l)); sappend(l, settings_current()->username, sizeof(l)); out(st, l);
        out(st, "COMPUTERNAME=MYOS"); out(st, "OS=MyOS");
        return;
    }
    const char *eq = strchr(raw_args, '=');
    if(!eq) {
        int shown = 0;
        for(int i = 0; i < CMD_ENV_MAX; i++) if(st->env[i].name[0] && strncmp(st->env[i].name, raw_args, strlen(raw_args)) == 0) {
            char l[140]; l[0] = 0; sappend(l, st->env[i].name, sizeof(l)); sappend(l, "=", sizeof(l)); sappend(l, st->env[i].value, sizeof(l)); out(st, l); shown++;
        }
        if(!shown) { char l[100]; l[0] = 0; sappend(l, "Environment variable ", sizeof(l)); sappend(l, raw_args, sizeof(l)); sappend(l, " not defined", sizeof(l)); err(st, l); }
        return;
    }
    char name[24]; int n = 0;
    for(const char *c = raw_args; c < eq && n < 23; c++) name[n++] = *c;
    name[n] = '\0';
    env_set(st, name, eq + 1);
}

typedef struct { const char *name; const char *desc; const char *usage; } help_t;
static const help_t help_table[] = {
    { "CD",      "Displays the name of or changes the current directory.", "CD [/D] [drive:][path]\n\n  CD ..   Move to the parent directory.\n  CD \\    Move to the root directory." },
    { "CLS",     "Clears the screen.", "CLS" },
    { "COLOR",   "Sets the default console foreground and background colors.", "COLOR [attr]\n\n  attr  Two hex digits: first = background, second = foreground.\n        0 Black  1 Blue  2 Green  3 Aqua  4 Red  5 Purple  6 Yellow  7 White\n        8 Gray   9 Lt Blue  A Lt Green  B Lt Aqua  C Lt Red  D Lt Purple  E Lt Yellow  F Bright White" },
    { "COPY",    "Copies one or more files to another location.", "COPY source [destination]\n\n  Wildcards (* and ?) are accepted in the source." },
    { "DATE",    "Displays the date.", "DATE [/T]" },
    { "DEL",     "Deletes one or more files.", "DEL names\n\n  Wildcards (* and ?) are accepted." },
    { "DIR",     "Displays a list of files and subdirectories in a directory.", "DIR [drive:][path][filename] [/B]\n\n  /B  Uses bare format (no heading information or summary)." },
    { "ECHO",    "Displays messages, or turns command-echoing on or off.", "ECHO [message]\nECHO ON | OFF\nECHO.   Prints an empty line." },
    { "EXIT",    "Quits the command prompt.", "EXIT" },
    { "HELP",    "Provides help information for commands.", "HELP [command]" },
    { "HOSTNAME","Prints the name of the computer.", "HOSTNAME" },
    { "MD",      "Creates a directory.", "MD [drive:]path" },
    { "MEM",     "Displays heap memory usage.", "MEM" },
    { "MKDIR",   "Creates a directory.", "MKDIR [drive:]path" },
    { "NOTEPAD", "Opens Notepad (optionally with a file).", "NOTEPAD [file]" },
    { "CALC",    "Opens Calculator.", "CALC" },
    { "MOVE",    "Moves files or directories to another location.", "MOVE source destination" },
    { "PAUSE",   "Suspends processing and displays a message.", "PAUSE" },
    { "PROMPT",  "Changes the command prompt.", "PROMPT [text]\n\n  $P current path  $G >  $L <  $S space  $D date  $T time  $V version  $$ dollar sign" },
    { "RD",      "Removes a directory.", "RD [/S] [/Q] [drive:]path\n\n  /S  Removes all directories and files in the directory.\n  /Q  Quiet mode, do not ask if ok to remove a directory tree with /S." },
    { "REM",     "Records comments.", "REM [comment]" },
    { "REN",     "Renames a file or directory.", "REN [drive:][path]filename1 filename2" },
    { "RMDIR",   "Removes a directory.", "RMDIR [/S] [/Q] [drive:]path" },
    { "SET",     "Displays, sets, or removes environment variables.", "SET [variable=[string]]" },
    { "START",   "Starts a program or opens a file (apps, .mp3/.wav in Media Player).", "START [program | file]" },
    { "TIME",    "Displays the system time.", "TIME [/T]" },
    { "TITLE",   "Sets the window title.", "TITLE [string]" },
    { "TREE",    "Graphically displays the folder structure.", "TREE [drive:][path] [/F]" },
    { "TYPE",    "Displays the contents of a text file.", "TYPE [drive:][path]filename" },
    { "VER",     "Displays the version.", "VER" },
    { "VOL",     "Displays the volume label and serial number.", "VOL" },
    { "WHOAMI",  "Displays the current user.", "WHOAMI" },
};
#define HELP_COUNT ((int)(sizeof(help_table) / sizeof(help_table[0])))

static int show_usage(cmd_state_t *st, const char *name) {
    for(int i = 0; i < HELP_COUNT; i++) if(strcasecmp(help_table[i].name, name) == 0) {
        out(st, help_table[i].desc); out(st, ""); out(st, help_table[i].usage); return 1;
    }
    return 0;
}

static void cmd_help(cmd_state_t *st, int argc, char **argv) {
    if(argc >= 2) {
        if(!show_usage(st, argv[1])) {
            char m[100]; m[0] = 0; sappend(m, "This command is not supported by the help utility.  Try \"", sizeof(m)); sappend(m, argv[1], sizeof(m)); sappend(m, " /?\".", sizeof(m)); err(st, m);
        }
        return;
    }
    out(st, "For more information on a specific command, type HELP command-name");
    for(int i = 0; i < HELP_COUNT; i++) {
        char l[CMD_LINE_MAX]; l[0] = 0; sappend(l, help_table[i].name, sizeof(l));
        int pad = 9 - (int)strlen(help_table[i].name); while(pad-- > 0) sappend(l, " ", sizeof(l));
        sappend(l, help_table[i].desc, sizeof(l)); out(st, l);
    }
}

static int is_audio_file(const char *name) {
    const char *e = fsu_ext(name);
    return strcasecmp(e, ".mp3") == 0 || strcasecmp(e, ".wav") == 0;
}

static int try_launch_target(cmd_state_t *st, const char *name, int argc, char **argv) {
    (void)argc; (void)argv;
    /* 1. Built-in apps by name. */
    char base[32]; scopy(base, name, sizeof(base));
    int bl = (int)strlen(base);
    if(bl > 4 && strcasecmp(base + bl - 4, ".exe") == 0) base[bl - 4] = '\0';
    if(strcasecmp(base, "cmd") == 0) { launch_cmd_at(st->cwd); return 1; }
    if(strcasecmp(base, "calc") == 0 || strcasecmp(base, "calculator") == 0) { launch_calculator(); return 1; }
    if(strcasecmp(base, "notepad") == 0) {
        if(argc >= 2 && strcmp(name, argv[0]) == 0 && argv[1][0] != '/') {
            char p[FSU_PATH_MAX]; resolve(st, argv[1], p); int d = 0;
            if(fsu_stat(p, &d, NULL, NULL, NULL) && !d) { launch_notepad_with_file(p); return 1; }
        }
        launch_notepad(); return 1;
    }
    if(strcasecmp(base, "mediaplayer") == 0 || strcasecmp(base, "wmplayer") == 0 || strcasecmp(base, "media") == 0) { launch_mediaplayer(); return 1; }
    for(int i = 0; i < apps_count(); i++) {
        app_entry_t *a = apps_get(i);
        if(a && a->launch && (strcasecmp(a->name, base) == 0)) { a->launch(); return 1; }
    }
    if(strcasecmp(base, "explorer") == 0 || strcasecmp(base, "paint") == 0 || strcasecmp(base, "settings") == 0) {
        for(int i = 0; i < apps_count(); i++) { app_entry_t *a = apps_get(i); if(a && strcasecmp(a->name, base) == 0) { a->launch(); return 1; } }
    }

    /* 2. A file path. */
    char path[FSU_PATH_MAX]; resolve(st, name, path);
    int is_dir = 0;
    if(!fsu_stat(path, &is_dir, NULL, NULL, NULL)) {
        char with_app[FSU_PATH_MAX]; scopy(with_app, path, sizeof(with_app)); sappend(with_app, ".app", sizeof(with_app));
        if(fsu_stat(with_app, &is_dir, NULL, NULL, NULL)) { app_loader_run(with_app); return 1; }
        return 0;
    }
    if(is_dir) return 0;
    if(strcasecmp(fsu_ext(path), ".app") == 0) { app_loader_run(path); return 1; }
    if(is_audio_file(path)) { launch_mediaplayer_with_file(path); return 1; }
    { const char *e2 = fsu_ext(path);
      if(strcasecmp(e2, ".txt") == 0 || strcasecmp(e2, ".log") == 0 || strcasecmp(e2, ".md") == 0 || strcasecmp(e2, ".ini") == 0 || strcasecmp(e2, ".c") == 0 || strcasecmp(e2, ".h") == 0) { launch_notepad_with_file(path); return 1; } }
    return 0;
}

static void execute_line(cmd_state_t *st, const char *raw_line) {
    char expanded[CMD_INPUT_MAX * 2];
    expand_vars(st, raw_line, expanded, sizeof(expanded));

    /* strip leading '@' and spaces */
    char *line = expanded;
    while(*line == ' ' || *line == '@') line++;
    if(!*line) return;

    /* Redirection: find > or >> outside quotes. */
    char redir_file[FSU_PATH_MAX]; redir_file[0] = '\0'; int append = 0;
    { int inq = 0;
      for(char *c = line; *c; c++) {
          if(*c == '"') inq = !inq;
          if(!inq && *c == '>') {
              append = (c[1] == '>');
              char *f = c + (append ? 2 : 1);
              while(*f == ' ') f++;
              int n = 0; while(*f && n < FSU_PATH_MAX - 1) { if(*f == '"') { f++; continue; } redir_file[n++] = *f++; }
              while(n > 0 && redir_file[n - 1] == ' ') n--;
              redir_file[n] = '\0';
              *c = '\0';
              break;
          }
      } }
    int len = (int)strlen(line); while(len > 0 && line[len - 1] == ' ') line[--len] = '\0';

    /* "cd.." / "cd\" / "dir\" style: split the command name from a leading . or \ */
    char work[CMD_INPUT_MAX * 2]; scopy(work, line, sizeof(work));
    char *args_raw = work; while(*args_raw && *args_raw != ' ' && *args_raw != '\t') {
        if((args_raw == work + 2 || args_raw == work + 5) && (*args_raw == '.' || *args_raw == '\\' || *args_raw == '/') &&
           (lower(work[0]) == 'c' && lower(work[1]) == 'd')) break;
        args_raw++;
    }
    char cmdname[40]; int cn = 0;
    { char *c = work; while(c < args_raw && cn < 39) cmdname[cn++] = *c++; cmdname[cn] = '\0'; }
    while(*args_raw == ' ') args_raw++;
    const char *raw_args = args_raw;

    char tokline[CMD_INPUT_MAX * 2]; tokline[0] = 0;
    sappend(tokline, cmdname, sizeof(tokline)); sappend(tokline, " ", sizeof(tokline)); sappend(tokline, args_raw, sizeof(tokline));
    char *argv[CMD_MAX_ARGS]; int argc = tokenize(tokline, argv, CMD_MAX_ARGS);
    if(argc == 0) return;

    st->errorlevel = 0;
    if(redir_file[0]) {
        st->redir_on = 1; st->redir_len = 0;
    }

    const char *c = argv[0];
    int helpq = (argc >= 2 && strcmp(argv[1], "/?") == 0);

    if(helpq && show_usage(st, c)) { }
    else if(strcasecmp(c, "help") == 0) cmd_help(st, argc, argv);
    else if(strcasecmp(c, "cls") == 0 || strcasecmp(c, "clear") == 0) { st->count = 0; st->first = 0; }
    else if(strcasecmp(c, "dir") == 0 || strcasecmp(c, "ls") == 0) cmd_dir(st, argc, argv);
    else if(strcasecmp(c, "cd") == 0 || strcasecmp(c, "chdir") == 0) cmd_cd(st, argc, argv);
    else if(strcasecmp(c, "md") == 0 || strcasecmp(c, "mkdir") == 0) cmd_md(st, argc, argv);
    else if(strcasecmp(c, "rd") == 0 || strcasecmp(c, "rmdir") == 0) cmd_rd(st, argc, argv);
    else if(strcasecmp(c, "type") == 0 || strcasecmp(c, "cat") == 0) cmd_type(st, argc, argv);
    else if(strcasecmp(c, "del") == 0 || strcasecmp(c, "erase") == 0 || strcasecmp(c, "rm") == 0) cmd_del(st, argc, argv);
    else if(strcasecmp(c, "copy") == 0 || strcasecmp(c, "cp") == 0) cmd_copy_move(st, argc, argv, 0);
    else if(strcasecmp(c, "move") == 0 || strcasecmp(c, "mv") == 0) cmd_copy_move(st, argc, argv, 1);
    else if(strcasecmp(c, "ren") == 0 || strcasecmp(c, "rename") == 0) cmd_ren(st, argc, argv);
    else if(strcasecmp(c, "tree") == 0) cmd_tree(st, argc, argv);
    else if(strcasecmp(c, "set") == 0) cmd_set(st, argc, argv, raw_args);
    else if(strcasecmp(c, "rem") == 0) { }
    else if(strcasecmp(c, "vol") == 0) vol_info(st);
    else if(strcasecmp(c, "ver") == 0) { out(st, ""); out(st, "MyOS [Version 1.0.0]"); }
    else if(strcasecmp(c, "hostname") == 0) out(st, "MyOS");
    else if(strcasecmp(c, "whoami") == 0) {
        char u[80]; u[0] = 0; sappend(u, "myos\\", sizeof(u));
        const char *name = settings_current()->username; int n = (int)strlen(u);
        for(; *name && n < 78; name++) u[n++] = lower(*name); u[n] = 0; out(st, u);
    }
    else if(strcasecmp(c, "echo") == 0) {
        if(argc == 1 && !cmdname[4]) { out(st, st->echo_on ? "ECHO is on." : "ECHO is off."); }
        else if(strcasecmp(raw_args, "on") == 0) st->echo_on = 1;
        else if(strcasecmp(raw_args, "off") == 0) st->echo_on = 0;
        else out(st, raw_args);
    }
    else if(strncmp(c, "echo.", 5) == 0 || strcasecmp(c, "echo.") == 0) { out(st, c + 5); }
    else if(strcasecmp(c, "title") == 0) { if(st->win) scopy(st->win->title, raw_args[0] ? raw_args : "Command Prompt", sizeof(st->win->title)); }
    else if(strcasecmp(c, "color") == 0) {
        if(argc < 2) { st->fg = 7; st->bg = 0; }
        else {
            int bgc = -1, fgc = -1; const char *a = argv[1];
            #define HEXV(ch) (((ch) >= '0' && (ch) <= '9') ? (ch) - '0' : (((ch) | 32) >= 'a' && ((ch) | 32) <= 'f') ? (((ch) | 32) - 'a' + 10) : -1)
            if(a[0] && a[1]) { bgc = HEXV(a[0]); fgc = HEXV(a[1]); } else if(a[0]) { fgc = HEXV(a[0]); bgc = st->bg; }
            if(bgc < 0 || fgc < 0 || bgc == fgc) { st->errorlevel = 1; }
            else { st->bg = (uint8_t)bgc; st->fg = (uint8_t)fgc; }
        }
    }
    else if(strcasecmp(c, "prompt") == 0) { scopy(st->prompt_fmt, raw_args[0] ? raw_args : "$P$G", sizeof(st->prompt_fmt)); }
    else if(strcasecmp(c, "pause") == 0) { out(st, "Press any key to continue . . ."); st->pause_wait = 1; }
    else if(strcasecmp(c, "exit") == 0) st->want_exit = 1;
    else if(strcasecmp(c, "date") == 0) {
        rtc_date_t d; rtc_read_date(&d); char ds[20], l[60]; fmt_date(ds, d.year, d.month, d.day);
        l[0] = 0;
        if(argc >= 2 && is_switch(argv[1], 't')) { sappend(l, weekday_name(d.year, d.month, d.day), sizeof(l)); sappend(l, " ", sizeof(l)); sappend(l, ds, sizeof(l)); }
        else { sappend(l, "The current date is: ", sizeof(l)); sappend(l, weekday_name(d.year, d.month, d.day), sizeof(l)); sappend(l, " ", sizeof(l)); sappend(l, ds, sizeof(l)); }
        out(st, l);
    }
    else if(strcasecmp(c, "time") == 0) {
        rtc_time_t t; rtc_read_time(&t); char l[60];
        l[0] = 0;
        if(argc >= 2 && is_switch(argv[1], 't')) { fmt_time12(l, t.hours, t.minutes); }
        else { char a[4], b[4], s[4]; pad2(t.hours, a); pad2(t.minutes, b); pad2(t.seconds, s);
               sappend(l, "The current time is: ", sizeof(l)); sappend(l, a, sizeof(l)); sappend(l, ":", sizeof(l)); sappend(l, b, sizeof(l)); sappend(l, ":", sizeof(l)); sappend(l, s, sizeof(l)); }
        out(st, l);
    }
    else if(strcasecmp(c, "mem") == 0) {
        char l[80], n[16];
        u32_to_str(heap_free, n); l[0] = 0; sappend(l, "Heap free: ", sizeof(l)); sappend(l, n, sizeof(l)); sappend(l, " bytes", sizeof(l)); out(st, l);
        u32_to_str(allocations, n); l[0] = 0; sappend(l, "Allocations: ", sizeof(l)); sappend(l, n, sizeof(l)); out(st, l);
    }
    else if(strcasecmp(c, "start") == 0) {
        if(argc < 2) launch_cmd_at(st->cwd);
        else if(!try_launch_target(st, argv[1], argc, argv)) {
            char m[CMD_LINE_MAX]; m[0] = 0; sappend(m, "The system cannot find the file ", sizeof(m)); sappend(m, argv[1], sizeof(m)); sappend(m, ".", sizeof(m)); err(st, m);
        }
    }
    else if(strlen(c) == 2 && c[1] == ':') {
        if(lower(c[0]) != 'c') err(st, "The system cannot find the drive specified.");
    }
    else if(!try_launch_target(st, c, argc, argv)) {
        char m[CMD_LINE_MAX]; m[0] = 0;
        sappend(m, "'", sizeof(m)); sappend(m, c, sizeof(m)); sappend(m, "' is not recognized as an internal or external command,", sizeof(m));
        err(st, m); out(st, "operable program or batch file.");
    }

    if(redir_file[0]) {
        st->redir_on = 0;
        char path[FSU_PATH_MAX]; resolve(st, redir_file, path);
        uint8_t *final_buf = (uint8_t *)st->redir_buf; uint32_t final_len = st->redir_len; uint8_t *tmp = NULL;
        if(append) {
            uint32_t old = 0; uint8_t *old_data = fsu_read_file(path, &old);
            if(old_data) {
                tmp = (uint8_t *)kmalloc(old + st->redir_len + 1);
                if(tmp) { memcpy(tmp, old_data, old); memcpy(tmp + old, st->redir_buf, st->redir_len); final_buf = tmp; final_len = old + st->redir_len; }
                kfree(old_data);
            }
        }
        if(!fsu_write_file(path, final_buf, final_len)) err(st, "The system cannot find the path specified.");
        if(tmp) kfree(tmp);
    }
}

/* ---------- input handling ---------- */
static void do_enter(cmd_state_t *st) {
    char prompt[160]; build_prompt(st, prompt, sizeof(prompt));
    char echoed[CMD_LINE_MAX]; echoed[0] = 0;

    if(st->confirm_wait) {
        char l[FSU_PATH_MAX + 40]; char wp[FSU_PATH_MAX]; win_path(st->confirm_path, wp, sizeof(wp));
        l[0] = 0; sappend(l, wp, sizeof(l)); sappend(l, ", Are you sure (Y/N)? ", sizeof(l)); sappend(l, st->input, sizeof(l)); out(st, l);
        if(lower(st->input[0]) == 'y') { if(!fsu_remove_dir(st->confirm_path, 1)) err(st, "The directory is not empty."); }
        st->confirm_wait = 0;
        st->input[0] = 0; st->input_len = st->cursor = 0;
        return;
    }

    sappend(echoed, prompt, sizeof(echoed)); sappend(echoed, st->input, sizeof(echoed));
    out(st, echoed);

    if(st->input_len > 0) {
        /* history (skip consecutive duplicates) */
        if(st->hist_count == 0 || strcmp(st->hist[st->hist_count - 1], st->input) != 0) {
            if(st->hist_count == CMD_HIST) { for(int i = 1; i < CMD_HIST; i++) scopy(st->hist[i - 1], st->hist[i], CMD_INPUT_MAX); st->hist_count--; }
            scopy(st->hist[st->hist_count++], st->input, CMD_INPUT_MAX);
        }
        char line[CMD_INPUT_MAX]; scopy(line, st->input, sizeof(line));
        st->input[0] = 0; st->input_len = st->cursor = 0;
        st->hist_pos = st->hist_count;
        execute_line(st, line);
        out(st, st->echo_on ? "" : "");
        if(st->echo_on && st->count > 0 && !st->confirm_wait && !st->pause_wait) { /* Windows prints a blank line only after some commands; keep output compact */ st->count--; }
    }
    st->hist_pos = st->hist_count;
}

static void tab_complete(cmd_state_t *st) {
    /* Word being completed: from the last space (outside quotes) to cursor. */
    if(!st->tab_active) {
        int s = st->cursor; while(s > 0 && st->input[s - 1] != ' ') s--;
        st->tab_word_start = s;
        int n = 0; for(int i = s; i < st->cursor && n < CMD_INPUT_MAX - 1; i++) st->tab_base[n++] = st->input[i];
        st->tab_base[n] = '\0';
        st->tab_idx = 0; st->tab_active = 1;
    }
    char word[CMD_INPUT_MAX]; scopy(word, st->tab_base, sizeof(word));
    if(word[0] == '"') { /* drop the opening quote */ for(int i = 0; word[i]; i++) word[i] = word[i + 1]; }

    /* split into directory part + prefix */
    int last_sep = -1; for(int i = 0; word[i]; i++) if(word[i] == '/' || word[i] == '\\') last_sep = i;
    char dir_part[FSU_PATH_MAX], prefix[48];
    if(last_sep >= 0) { int n = last_sep + 1; if(n > FSU_PATH_MAX - 1) n = FSU_PATH_MAX - 1; for(int i = 0; i < n; i++) dir_part[i] = word[i]; dir_part[n] = '\0'; scopy(prefix, word + last_sep + 1, sizeof(prefix)); }
    else { dir_part[0] = '\0'; scopy(prefix, word, sizeof(prefix)); }

    char dir_abs[FSU_PATH_MAX]; resolve(st, dir_part[0] ? dir_part : ".", dir_abs);
    struct directory d;
    if(!fsu_open_dir(dir_abs, &d)) { st->tab_active = 0; return; }
    int idx[256]; int n = list_sorted(&d, idx, 256);
    int match = 0; char chosen[48]; chosen[0] = 0; int chosen_dir = 0;
    for(int k = 0; k < n; k++) {
        struct dir_entry *e = &d.entries[idx[k]];
        if(strcmp(e->name, ".") == 0 || strcmp(e->name, "..") == 0) continue;
        int pl = (int)strlen(prefix);
        int ok = 1; for(int i = 0; i < pl; i++) if(lower(e->name[i]) != lower(prefix[i])) { ok = 0; break; }
        if(!ok) continue;
        if(match == st->tab_idx) { scopy(chosen, e->name, sizeof(chosen)); chosen_dir = (e->dir_attrs & DIRECTORY) != 0; }
        match++;
    }
    free_directory(master_fs, &d);
    if(match == 0) { st->tab_active = 0; return; }
    st->tab_idx = (st->tab_idx + 1) % match;

    char repl[CMD_INPUT_MAX]; repl[0] = 0;
    int quote = 0; for(const char *c = chosen; *c; c++) if(*c == ' ') quote = 1;
    if(quote) sappend(repl, "\"", sizeof(repl));
    sappend(repl, dir_part, sizeof(repl)); sappend(repl, chosen, sizeof(repl));
    if(quote) sappend(repl, "\"", sizeof(repl));
    (void)chosen_dir;

    char tail[CMD_INPUT_MAX]; scopy(tail, st->input + st->cursor, sizeof(tail));
    st->input[st->tab_word_start] = '\0';
    sappend(st->input, repl, CMD_INPUT_MAX);
    st->cursor = (int)strlen(st->input);
    sappend(st->input, tail, CMD_INPUT_MAX);
    st->input_len = (int)strlen(st->input);
}

static void insert_char(cmd_state_t *st, char c) {
    if(st->input_len >= CMD_INPUT_MAX - 1) return;
    for(int i = st->input_len; i > st->cursor; i--) st->input[i] = st->input[i - 1];
    st->input[st->cursor++] = c;
    st->input_len++;
    st->input[st->input_len] = '\0';
}

static int visible_rows(window_t *w) { int cx, cy, cw, ch; wm_get_client_rect(w, &cx, &cy, &cw, &ch); int r = (ch - CMD_PAD_Y * 2) / GFX_CHAR_ROWS; return r < 1 ? 1 : r; }

static void cmd_key(window_t *self, char c) {
    cmd_state_t *st = (cmd_state_t *)self->user_data;
    if(!st) return;

    if(st->pause_wait) { st->pause_wait = 0; return; }

    if(c != '\t') st->tab_active = 0;

    if(c == KEY_PGUP) { st->scroll += visible_rows(self) - 1; return; }
    if(c == KEY_PGDN) { st->scroll -= visible_rows(self) - 1; if(st->scroll < 0) st->scroll = 0; return; }

    st->scroll = 0;

    if(c == '\n' || c == '\r') { do_enter(st); }
    else if(c == '\b' || c == 127) {
        if(st->cursor > 0) {
            for(int i = st->cursor - 1; i < st->input_len; i++) st->input[i] = st->input[i + 1];
            st->cursor--; st->input_len--;
        }
    }
    else if(c == KEY_DELETE) {
        if(st->cursor < st->input_len) { for(int i = st->cursor; i < st->input_len; i++) st->input[i] = st->input[i + 1]; st->input_len--; }
    }
    else if(c == KEY_LEFT) { if(st->cursor > 0) st->cursor--; }
    else if(c == KEY_RIGHT) { if(st->cursor < st->input_len) st->cursor++; }
    else if(c == KEY_HOME) st->cursor = 0;
    else if(c == KEY_END) st->cursor = st->input_len;
    else if(c == KEY_UP) {
        if(st->hist_pos > 0) { st->hist_pos--; scopy(st->input, st->hist[st->hist_pos], CMD_INPUT_MAX); st->input_len = st->cursor = (int)strlen(st->input); }
    }
    else if(c == KEY_DOWN) {
        if(st->hist_pos < st->hist_count) {
            st->hist_pos++;
            if(st->hist_pos == st->hist_count) st->input[0] = '\0'; else scopy(st->input, st->hist[st->hist_pos], CMD_INPUT_MAX);
            st->input_len = st->cursor = (int)strlen(st->input);
        }
    }
    else if(c == 27) { st->input[0] = '\0'; st->input_len = st->cursor = 0; }
    else if(c == 3) { /* Ctrl+C */
        char prompt[160]; build_prompt(st, prompt, sizeof(prompt));
        char l[CMD_LINE_MAX]; l[0] = 0; sappend(l, prompt, sizeof(l)); sappend(l, st->input, sizeof(l)); sappend(l, "^C", sizeof(l)); out(st, l);
        st->input[0] = '\0'; st->input_len = st->cursor = 0; st->confirm_wait = 0;
    }
    else if(c == 22) { /* Ctrl+V */
        const char *t = clipboard_get_text();
        for(; *t; t++) if(*t >= ' ' && (unsigned char)*t < 127) insert_char(st, *t);
    }
    else if(c == '\t') { tab_complete(st); }
    else if(c >= ' ' && (unsigned char)c < 127) { insert_char(st, c); }

    if(st->want_exit) wm_destroy_window(self);
}

/* ---------- drawing ---------- */
static int rows_for(int len, int cols) { if(len <= 0) return 1; return (len + cols - 1) / cols; }

static void cmd_paint(window_t *self, int cx, int cy, int cw, int ch) {
    cmd_state_t *st = (cmd_state_t *)self->user_data;
    if(!st) return;

    uint32_t bg = 0xFF000000 | cmd_palette[st->bg & 15];
    uint32_t fg = 0xFF000000 | cmd_palette[st->fg & 15];
    gfx_fill_rect(cx, cy, cw, ch, bg);

    int cols = (cw - CMD_PAD_X * 2 - 10) / GFX_CHAR_COLS; if(cols < 8) cols = 8;
    int rows = (ch - CMD_PAD_Y * 2) / GFX_CHAR_ROWS; if(rows < 1) rows = 1;

    /* Live (prompt + input) line. */
    char prompt[160]; char live[CMD_LINE_MAX + 160];
    if(st->confirm_wait) { char wp[FSU_PATH_MAX]; win_path(st->confirm_path, wp, sizeof(wp)); prompt[0] = 0; sappend(prompt, wp, sizeof(prompt)); sappend(prompt, ", Are you sure (Y/N)? ", sizeof(prompt)); }
    else if(st->pause_wait) prompt[0] = '\0';
    else build_prompt(st, prompt, sizeof(prompt));
    live[0] = 0; sappend(live, prompt, sizeof(live));
    int prompt_len = (int)strlen(prompt);
    if(!st->pause_wait) sappend(live, st->input, sizeof(live));
    int live_len = (int)strlen(live);
    int cursor_pos = prompt_len + st->cursor;

    int total_lines = st->count + 1; /* + live line */
    int total_rows = 0;
    for(int i = 0; i < st->count; i++) total_rows += rows_for((int)strlen(line_at(st, i)), cols);
    total_rows += rows_for(live_len + 1, cols);

    int max_scroll = total_rows - rows; if(max_scroll < 0) max_scroll = 0;
    if(st->scroll > max_scroll) st->scroll = max_scroll;
    int need = rows + st->scroll;

    /* Walk back to find the first logical line to draw. */
    int acc = 0, li = total_lines - 1;
    while(li >= 0 && acc < need) {
        int len = (li == st->count) ? live_len + 1 : (int)strlen(line_at(st, li));
        acc += rows_for(len, cols); li--;
    }
    li++;
    int skip = acc - need; if(skip < 0) skip = 0;

    int row = 0;
    uint8_t blink = ((pit_get_ticks() / 5) & 1) == 0;
    for(int l = li; l < total_lines && row < rows; l++) {
        const char *text = (l == st->count) ? live : line_at(st, l);
        int len = (l == st->count) ? live_len : (int)strlen(text);
        int nrows = rows_for((l == st->count) ? len + 1 : len, cols);
        for(int k = (l == li ? skip : 0); k < nrows && row < rows; k++) {
            char chunk[200]; int cl = len - k * cols; if(cl > cols) cl = cols; if(cl < 0) cl = 0; if(cl > 199) cl = 199;
            for(int i = 0; i < cl; i++) chunk[i] = text[k * cols + i];
            chunk[cl] = '\0';
            int px = cx + CMD_PAD_X, py = cy + CMD_PAD_Y + row * GFX_CHAR_ROWS;
            gfx_draw_string(px, py, chunk, fg);

            if(l == st->count && !st->pause_wait && st->scroll == 0 && cursor_pos >= k * cols && cursor_pos < (k + 1) * cols) {
                int ccol = cursor_pos - k * cols;
                if(blink) {
                    gfx_fill_rect(px + ccol * GFX_CHAR_COLS, py + GFX_CHAR_ROWS - 3, GFX_CHAR_COLS, 2, fg); /* underscore-style caret like conhost */
                }
            }
            row++;
        }
    }

    /* Slim scrollbar like Windows Terminal. */
    if(total_rows > rows) {
        int track_h = ch - 4;
        int thumb_h = (track_h * rows) / total_rows; if(thumb_h < 16) thumb_h = 16;
        int pos_from_top = ((total_rows - rows - st->scroll) * (track_h - thumb_h)) / (total_rows - rows);
        gfx_blend_rounded_rect(cx + cw - 9, cy + 2 + pos_from_top, 6, thumb_h, 3, 0x70FFFFFF);
    }
}

/* ---------- context menu ---------- */
static void act_paste(void *ud) { cmd_state_t *st = (cmd_state_t *)ud; for(const char *t = clipboard_get_text(); *t; t++) if(*t >= ' ' && (unsigned char)*t < 127) insert_char(st, *t); }
static void act_clear(void *ud) { cmd_state_t *st = (cmd_state_t *)ud; st->count = 0; st->first = 0; }
static void act_exit(void *ud) { cmd_state_t *st = (cmd_state_t *)ud; if(st->win) wm_destroy_window(st->win); }
static void act_copy_cwd(void *ud) { cmd_state_t *st = (cmd_state_t *)ud; char wp[FSU_PATH_MAX]; win_path(st->cwd, wp, sizeof(wp)); clipboard_set_text(wp); }
static void act_open_new(void *ud) { cmd_state_t *st = (cmd_state_t *)ud; launch_cmd_at(st->cwd); }

static void cmd_right_click(window_t *self, int rx, int ry) {
    cmd_state_t *st = (cmd_state_t *)self->user_data; if(!st) return;
    int cx, cy, cw, ch; wm_get_client_rect(self, &cx, &cy, &cw, &ch);
    static context_menu_item_t items[] = {
        CM_ITEM("Paste", act_paste, "Ctrl+V"),
        CM_ITEM("Copy current path", act_copy_cwd, ""),
        CM_SEP(),
        CM_ITEM("Clear screen", act_clear, ""),
        CM_ITEM("New Command Prompt here", act_open_new, ""),
        CM_SEP(),
        CM_ITEM("Close", act_exit, ""),
    };
    items[0].enabled = clipboard_get_text()[0] ? 1 : 0;
    context_menu_open(cx + rx, cy + ry, items, 7, st);
}

static int cmd_cursor_at(window_t *self, int rx, int ry) { (void)self; (void)rx; (void)ry; return CURSOR_TEXT; }

static void cmd_destroy(window_t *self) {
    cmd_state_t *st = (cmd_state_t *)self->user_data;
    if(!st) return;
    if(st->lines) kfree(st->lines);
    if(st->redir_buf) kfree(st->redir_buf);
    kfree(st);
    self->user_data = NULL;
}

void launch_cmd_at(const char *path) {
    int sw = (int)gfx_width(), sh = (int)gfx_height();
    int w = 8 * 100 + CMD_PAD_X * 2 + 10 + 2 * WM_BORDER; if(w > sw - 40) w = sw - 40;
    int h = 16 * 26 + CMD_PAD_Y * 2 + WM_TITLEBAR_HEIGHT + WM_BORDER; if(h > sh - 80) h = sh - 80;
    static int cascade = 0;
    int x = 90 + (cascade % 6) * 26, y = 60 + (cascade % 6) * 26; cascade++;

    window_t *win = wm_create_window("Command Prompt", x, y, w, h, 0xFF0C0C0C);
    if(!win) return;

    cmd_state_t *st = (cmd_state_t *)kmalloc(sizeof(cmd_state_t));
    if(!st) { wm_destroy_window(win); return; }
    memset(st, 0, sizeof(cmd_state_t));
    st->lines = (char (*)[CMD_LINE_MAX])kmalloc((uint32_t)CMD_MAX_LINES * CMD_LINE_MAX);
    st->redir_buf = (char *)kmalloc(CMD_REDIR_MAX);
    if(!st->lines || !st->redir_buf) { if(st->lines) kfree(st->lines); if(st->redir_buf) kfree(st->redir_buf); kfree(st); wm_destroy_window(win); return; }

    st->win = win;
    st->fg = 7; st->bg = 0; st->echo_on = 1;
    scopy(st->prompt_fmt, "$P$G", sizeof(st->prompt_fmt));
    int is_dir = 0;
    if(path && fsu_stat(path, &is_dir, NULL, NULL, NULL) && is_dir) scopy(st->cwd, path, sizeof(st->cwd));
    else if(fsu_stat("/Users/User", &is_dir, NULL, NULL, NULL) && is_dir) scopy(st->cwd, "/Users/User", sizeof(st->cwd));
    else scopy(st->cwd, "/", sizeof(st->cwd));

    out(st, "MyOS [Version 1.0.0]");
    out(st, "(c) MyOS. All rights reserved.");
    out(st, "");

    win->user_data = st;
    win->on_paint = cmd_paint;
    win->on_key = cmd_key;
    win->on_destroy = cmd_destroy;
    win->on_right_click = cmd_right_click;
    win->cursor_at = cmd_cursor_at;
}

void launch_cmd(void) { launch_cmd_at(NULL); }
