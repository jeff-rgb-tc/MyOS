#ifndef CURSOR_SET_H
#define CURSOR_SET_H

#include "cursor.h"

/* Named cursor shapes -- which one is shown depends on what's under the
 * mouse each frame (see desktop.c's pick_cursor_for_position(), called
 * once per frame right before drawing the cursor). Files live at
 * /SYSTEM/res/cursors/<name>.cur; CURSOR_DEFAULT falls back to the
 * built-in arrow (cursor_build_default_arrow()) if its file is missing,
 * the same way the single cursor this OS used to have always did --
 * every other shape simply isn't drawn (falls back to CURSOR_DEFAULT)
 * if its own file didn't load, rather than each needing its own
 * fallback shape. */
typedef enum {
    CURSOR_DEFAULT = 0,       /* normal_select.cur -- plain arrow */
    CURSOR_TEXT,              /* text_select.cur -- I-beam, over editable text fields */
    CURSOR_LINK,              /* link_select.cur -- over a hyperlink-style clickable element */
    CURSOR_MOVE,              /* move.cur -- 4-way arrow, dragging a window/icon */
    CURSOR_RESIZE_H,          /* horizontal_resize.cur -- left/right window edges */
    CURSOR_RESIZE_V,          /* vertical_resize.cur -- top/bottom window edges */
    CURSOR_RESIZE_DIAG_1,     /* diagonal_resize_1.cur -- top-left/bottom-right corners ("\" diagonal) */
    CURSOR_RESIZE_DIAG_2,     /* diagonal_resize_2.cur -- top-right/bottom-left corners ("/" diagonal) */
    CURSOR_UNAVAILABLE,       /* unavailable.cur -- over a disabled control */
    CURSOR_BUSY,              /* busy.ani (animated spinner); busy.cur is the still fallback -- blocking operation */
    CURSOR_WORKING,           /* working_in_background.ani (animated arrow + spinner); .cur fallback -- non-blocking background work */
    CURSOR_HELP,              /* help_select.cur -- "what's this" / help mode */
    CURSOR_PRECISION,         /* precision_select.cur -- crosshair, e.g. Paint's drawing tools */
    CURSOR_HANDWRITING,       /* handwriting.cur */
    CURSOR_PERSON,            /* person_select.cur -- over a user/profile element, e.g. the Start menu avatar */
    CURSOR_LOCATION,          /* location_select.cur */
    CURSOR_ALTERNATE,         /* alternate_select.cur */
    CURSOR_COUNT,
} cursor_kind_t;

/* Returns the requested cursor's image, loading it from disk on first
 * use and caching it after that (same lazy-load-and-cache pattern as
 * system_icons.c). Returns NULL if the file is missing/unparseable --
 * callers should fall back to cursor_set_get(CURSOR_DEFAULT) in that
 * case (see desktop.c's draw call, which already does this). */
cursor_image_t *cursor_set_get(cursor_kind_t kind);

/* Animated cursors: CURSOR_BUSY and CURSOR_WORKING play their .ani files
 * (see cursor_ani.h). cursor_set_get() already returns the CURRENT frame
 * for those, so drawing code needs no changes; these two let the main
 * loop know when a repaint is due. */
cursor_image_t *cursor_set_peek(cursor_kind_t kind);   /* interrupt-safe, never loads anything */
void cursor_set_preload(void);
int cursor_set_is_animated(cursor_kind_t kind);
/* Different value whenever the visible frame changes; constant (0) for
 * still cursors. */
int cursor_set_animation_token(cursor_kind_t kind);

#endif
