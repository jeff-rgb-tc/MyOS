#ifndef DESKTOP_UI_H
#define DESKTOP_UI_H

#include "stdint.h"
#include "window.h"

/* Small shared widget layer for the built-in apps (Clock, Calendar, Task
 * Manager). Everything is immediate-mode: an app computes its layout from
 * the client size every frame, draws with these helpers, and hit-tests
 * with ui_in() on click. Keeping the look in one place is what makes the
 * apps feel like one system instead of three separate programs. */

/* Palette (same dark family as the calculator, taskbar and window chrome). */
#define UI_BG          0xFF1E1E22
#define UI_CARD        0xFF2A2A30
#define UI_CARD_HI     0xFF34343B
#define UI_STROKE      0x1CFFFFFF
#define UI_TEXT        0xFFF2F2F5
#define UI_TEXT_DIM    0xFFA0A0AA
#define UI_TEXT_FAINT  0xFF6C6C76
#define UI_ACCENT      0xFF4CC2FF
#define UI_ACCENT_HI   0xFF6FD0FF
#define UI_ACCENT_LO   0xFF3A9FD0
#define UI_ON_ACCENT   0xFF0E1620
#define UI_DANGER      0xFFC42B1C
#define UI_OK          0xFF5FD38D

typedef enum { UI_BTN_NORMAL = 0, UI_BTN_ACCENT, UI_BTN_DANGER, UI_BTN_FLAT } ui_btn_style_t;

/* Rectangle hit test. */
int ui_in(int px, int py, int x, int y, int w, int h);

/* If the mouse is currently over THIS window's client area (and the window
 * is the topmost one there), returns 1 and fills the client-relative mouse
 * position. Used for hover highlights computed at paint time, so a
 * highlight can never get stuck after the cursor leaves the window. */
int ui_hover_pos(window_t *self, int client_x, int client_y, int *rel_x, int *rel_y);

/* 1 while the left mouse button is held. */
int ui_mouse_down(void);

/* Text helpers (the font is fixed 8x16). */
int  ui_text_w(const char *s);
void ui_text_center(int x, int y, int w, int h, const char *s, uint32_t color);
void ui_text_right(int right_x, int y, const char *s, uint32_t color);

/* Rounded push button. hover/pressed come from the caller's hit test. */
void ui_button(int x, int y, int w, int h, const char *label,
               ui_btn_style_t style, int hover, int pressed);

/* Raised rounded panel with a hairline outline. */
void ui_card(int x, int y, int w, int h, int radius);

/* Segmented control: n labelled tabs filling the given rectangle. */
void ui_tabs(int x, int y, int w, int h, const char *const *labels, int n, int selected, int hover);
/* Returns the tab index at (px,py) for the same geometry, or -1. */
int  ui_tabs_hit(int x, int y, int w, int h, int n, int px, int py);

/* Horizontal progress/usage bar. value/max in arbitrary units. */
void ui_bar(int x, int y, int w, int h, uint32_t value, uint32_t max, uint32_t color);

/* Fills the client area with the app background. */
void ui_clear(int cx, int cy, int cw, int ch);

/* Fixed-width helpers that avoid pulling in sprintf for tiny cases. */
void ui_fmt2(char *out, int v);   /* writes "07" style, 2 digits, NUL-terminated */

#endif
