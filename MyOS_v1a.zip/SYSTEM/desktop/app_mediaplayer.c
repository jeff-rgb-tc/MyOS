#include "stdint.h"
#include "stddef.h"
#include "app_mediaplayer.h"
#include "desktop.h"
#include "window.h"
#include "gfx.h"
#include "common.h"
#include "kernio.h"
#include "kheap.h"
#include "fat32.h"
#include "fs_util.h"
#include "audio.h"
#include "mp3.h"
#include "wav.h"
#include "keyboard.h"
#include "pit.h"
#include "context_menu.h"
#include "cursor_set.h"

#define MP_MAX_TRACKS 64
#define MP_NAME_MAX 40
#define MP_LIST_W 210
#define MP_ROW_H 28
#define MP_HEADER_H 40
#define MP_MUSIC_DIR "/Users/User/Music"

#define STAGE_SAMPLES 8192            /* staging buffer (interleaved stereo int16) */
#define AC97_CHUNK 4096               /* matches the driver's buffer size */

/* colors */
#define C_BG        0xFF1B1B1F
#define C_PANEL     0xFF232328
#define C_PANEL_HI  0xFF2E2E35
#define C_ACCENT    0xFF4CC2FF
#define C_TEXT      0xFFFFFFFF
#define C_TEXT_DIM  0xFFA0A0A8
#define C_TRACK     0xFF3C3C44

typedef enum { MP_STOPPED = 0, MP_PLAYING, MP_PAUSED } mp_state_t;
typedef enum { DRAG_NONE = 0, DRAG_SEEK, DRAG_VOLUME } mp_drag_t;

typedef struct {
    window_t *win;
    char dir[FSU_PATH_MAX];
    char names[MP_MAX_TRACKS][MP_NAME_MAX];
    int count, current, list_scroll;

    mp_state_t state;
    int shuffle, repeat;        /* repeat: 0 off, 1 all, 2 one */

    /* decoder */
    mp3_stream_t *mp3;
    wav_audio_t wav; int wav_loaded; uint32_t wav_pos;   /* sample index */
    uint32_t rate; uint8_t channels;
    uint32_t duration_ms;
    uint32_t pos_ms;
    uint32_t wav_total_ms;

    int16_t stage[STAGE_SAMPLES]; int stage_n;
    int eof;
    mp_drag_t drag;
    int muted;
    char status[48];
    long long last_click_tick; int last_click_row;
} mp_state_t_;

typedef mp_state_t_ mp;

/* ---------- helpers ---------- */
static void scopy(char *d, const char *s, int max) { int i = 0; while(s && s[i] && i < max - 1) { d[i] = s[i]; i++; } d[i] = 0; }
static void sappend(char *d, const char *s, int max) { int n = (int)strlen(d); scopy(d + n, s, max - n); }

static void fmt_time(uint32_t ms, char *o) {
    uint32_t s = ms / 1000, m = s / 60; s %= 60;
    char a[12]; int n = 0; uint32_t v = m;
    if(!v) a[n++] = '0';
    while(v) { a[n++] = (char)('0' + v % 10); v /= 10; }
    int p = 0; for(int i = n - 1; i >= 0; i--) o[p++] = a[i];
    o[p++] = ':'; o[p++] = (char)('0' + s / 10); o[p++] = (char)('0' + s % 10); o[p] = 0;
}

static void strip_ext(const char *name, char *out, int max) {
    scopy(out, name, max);
    for(int i = (int)strlen(out) - 1; i > 0; i--) if(out[i] == '.') { out[i] = 0; break; }
    for(int i = 0; out[i]; i++) if(out[i] == '_') out[i] = ' ';
}

static int is_audio(const char *n) { const char *e = fsu_ext(n); return strcasecmp(e, ".mp3") == 0 || strcasecmp(e, ".wav") == 0; }

static void load_playlist(mp *st, const char *dir) {
    st->count = 0; st->current = -1;
    scopy(st->dir, dir, sizeof(st->dir));
    struct directory d;
    if(!fsu_open_dir(dir, &d)) return;
    for(uint32_t i = 0; i < d.num_entries && st->count < MP_MAX_TRACKS; i++) {
        struct dir_entry *e = &d.entries[i];
        if(!e->name || (e->dir_attrs & (LFN | DIRECTORY))) continue;
        if(!is_audio(e->name)) continue;
        scopy(st->names[st->count++], e->name, MP_NAME_MAX);
    }
    free_directory(master_fs, &d);
    /* alphabetical */
    for(int i = 1; i < st->count; i++) {
        char t[MP_NAME_MAX]; scopy(t, st->names[i], MP_NAME_MAX); int j = i - 1;
        while(j >= 0 && strcasecmp(st->names[j], t) > 0) { scopy(st->names[j + 1], st->names[j], MP_NAME_MAX); j--; }
        scopy(st->names[j + 1], t, MP_NAME_MAX);
    }
}

/* ---------- decoding / playback ---------- */
static void close_track(mp *st) {
    if(st->mp3) { mp3_stream_close(st->mp3); st->mp3 = NULL; }
    if(st->wav_loaded) { wav_free(&st->wav); st->wav_loaded = 0; }
    st->stage_n = 0; st->eof = 0; st->pos_ms = 0; st->duration_ms = 0; st->wav_pos = 0;
}

static void stop_playback(mp *st) {
    audio_flush();
    close_track(st);
    st->state = MP_STOPPED;
}

static int open_track(mp *st, int index) {
    if(index < 0 || index >= st->count) return 0;
    audio_flush();
    close_track(st);
    st->current = index;

    char path[FSU_PATH_MAX]; scopy(path, st->dir, sizeof(path));
    if(strlen(path) > 1) sappend(path, "/", sizeof(path));
    sappend(path, st->names[index], sizeof(path));

    st->status[0] = 0;
    if(!audio_is_available()) { scopy(st->status, "No sound device found", sizeof(st->status)); }

    if(strcasecmp(fsu_ext(path), ".mp3") == 0) {
        uint32_t rate = 0, dur = 0; uint8_t ch = 0;
        desktop_busy_begin();        /* reading a big file: show the spinner, keep it turning */
        st->mp3 = mp3_stream_open(path, &rate, &ch, &dur);
        desktop_busy_end();
        if(!st->mp3) { scopy(st->status, "Can't play this MP3 (unsupported format)", sizeof(st->status)); st->state = MP_STOPPED; return 0; }
        st->rate = rate; st->channels = ch; st->duration_ms = dur;
    }
    else {
        desktop_busy_begin();
        int wav_ok = wav_load_from_file(path, &st->wav);
        desktop_busy_end();
        if(!wav_ok) { scopy(st->status, "Can't play this WAV file", sizeof(st->status)); st->state = MP_STOPPED; return 0; }
        st->wav_loaded = 1; st->rate = st->wav.sample_rate; st->channels = st->wav.channels;
        uint32_t frames = st->wav.sample_count / (st->wav.channels ? st->wav.channels : 1);
        st->duration_ms = (uint32_t)(((uint64_t)frames * 1000) / (st->rate ? st->rate : 1));
    }
    audio_set_format(st->rate, 2);
    st->state = MP_PLAYING;
    audio_pause(0);
    return 1;
}

/* Pulls up to ~one frame of decoded audio into the staging buffer
 * (always interleaved stereo). Returns 0 at end of stream. */
static int decode_more(mp *st) {
    if(st->eof) return 0;
    if(st->mp3) {
        int16_t pcm[1152 * 2];
        int frames = mp3_stream_read(st->mp3, pcm);
        if(frames <= 0) { st->eof = 1; return 0; }
        if(st->stage_n + frames * 2 > STAGE_SAMPLES) return 1; /* caller guards, but be safe */
        if(st->channels == 1) {
            for(int i = 0; i < frames; i++) { st->stage[st->stage_n++] = pcm[i]; st->stage[st->stage_n++] = pcm[i]; }
        }
        else {
            for(int i = 0; i < frames * 2; i++) st->stage[st->stage_n++] = pcm[i];
        }
        st->pos_ms = mp3_stream_position_ms(st->mp3);
        return 1;
    }
    if(st->wav_loaded) {
        uint32_t ch = st->wav.channels ? st->wav.channels : 1;
        uint32_t total_frames = st->wav.sample_count / ch;
        uint32_t cur_frame = st->wav_pos;
        if(cur_frame >= total_frames) { st->eof = 1; return 0; }
        uint32_t n = 1024; if(cur_frame + n > total_frames) n = total_frames - cur_frame;
        for(uint32_t i = 0; i < n; i++) {
            if(ch == 1) { int16_t v = st->wav.samples[cur_frame + i]; st->stage[st->stage_n++] = v; st->stage[st->stage_n++] = v; }
            else { st->stage[st->stage_n++] = st->wav.samples[(cur_frame + i) * ch]; st->stage[st->stage_n++] = st->wav.samples[(cur_frame + i) * ch + 1]; }
        }
        st->wav_pos += n;
        st->pos_ms = (uint32_t)(((uint64_t)st->wav_pos * 1000) / (st->rate ? st->rate : 1));
        return 1;
    }
    return 0;
}

static int next_index(mp *st, int dir) {
    if(st->count == 0) return -1;
    if(st->shuffle && st->count > 1) {
        long long t = pit_get_ticks();
        int r = (int)((t * 7 + st->current * 13 + 5) % st->count);
        if(r == st->current) r = (r + 1) % st->count;
        return r;
    }
    int i = st->current + dir;
    if(i >= st->count) i = 0;
    if(i < 0) i = st->count - 1;
    return i;
}

static void play_index(mp *st, int index) { open_track(st, index); }

static void track_finished(mp *st) {
    if(st->repeat == 2) { play_index(st, st->current); return; }
    int at_end = (!st->shuffle && st->current == st->count - 1);
    if(at_end && st->repeat == 0) { stop_playback(st); return; }
    play_index(st, next_index(st, 1));
}

/* Called every desktop iteration (~100Hz while idle). */
static void mp_tick(window_t *self) {
    mp *st = (mp *)self->user_data;
    if(!st || st->state != MP_PLAYING) return;

    int budget = 6; /* limit decode work per tick so the UI stays responsive */
    while(budget-- > 0) {
        /* keep the staging buffer topped up */
        while(st->stage_n < AC97_CHUNK && !st->eof) {
            if(STAGE_SAMPLES - st->stage_n < 2304 + 64) break;
            if(!decode_more(st)) break;
        }
        if(st->stage_n >= AC97_CHUNK || (st->eof && st->stage_n > 0)) {
            if(!audio_ready_for_more()) return;
            int n = st->stage_n >= AC97_CHUNK ? AC97_CHUNK : st->stage_n;
            audio_queue(st->stage, (uint32_t)n);
            int rest = st->stage_n - n;
            for(int i = 0; i < rest; i++) st->stage[i] = st->stage[n + i];
            st->stage_n = rest;
        }
        else if(st->eof && st->stage_n == 0) {
            /* let the last queued buffers drain (~0.7s) before moving on */
            static long long drain_start = 0;
            if(drain_start == 0) drain_start = pit_get_ticks();
            if(pit_get_ticks() - drain_start >= 8) { drain_start = 0; track_finished(st); }
            return;
        }
        else return;
    }
}

static void toggle_play(mp *st) {
    if(st->state == MP_PLAYING) { st->state = MP_PAUSED; audio_pause(1); }
    else if(st->state == MP_PAUSED) { st->state = MP_PLAYING; audio_pause(0); }
    else if(st->count > 0) { play_index(st, st->current >= 0 ? st->current : 0); }
}

static void do_seek(mp *st, uint32_t ms) {
    if(st->state == MP_STOPPED || st->duration_ms == 0) return;
    if(ms > st->duration_ms) ms = st->duration_ms;
    audio_flush();
    st->stage_n = 0; st->eof = 0;
    if(st->mp3) mp3_stream_seek_ms(st->mp3, ms);
    else if(st->wav_loaded) st->wav_pos = (uint32_t)(((uint64_t)ms * st->rate) / 1000);
    st->pos_ms = ms;
    audio_set_format(st->rate, 2);
    if(st->state == MP_PAUSED) { audio_pause(1); }
}

/* ---------- layout ---------- */
typedef struct { int list_x, list_w; int main_x, main_w; int art_size, art_x, art_y; int title_y;
                 int bar_x, bar_y, bar_w; int btn_y; int btn_cx; int vol_x, vol_w, vol_y; } layout_t;

static void get_layout(int cw, int ch, layout_t *L) {
    L->list_x = 0; L->list_w = MP_LIST_W;
    L->main_x = MP_LIST_W; L->main_w = cw - MP_LIST_W;
    int avail_h = ch - 190;
    int art = avail_h < L->main_w - 60 ? avail_h : L->main_w - 60;
    if(art > 220) art = 220; if(art < 64) art = 64;
    L->art_size = art;
    L->art_x = L->main_x + (L->main_w - art) / 2;
    L->art_y = 18;
    L->title_y = L->art_y + art + 14;
    L->bar_x = L->main_x + 28; L->bar_w = L->main_w - 56;
    L->bar_y = ch - 92;
    L->btn_y = ch - 62;
    L->btn_cx = L->main_x + L->main_w / 2;
    L->vol_w = 90; L->vol_x = L->main_x + L->main_w - L->vol_w - 22; L->vol_y = L->btn_y + 14;
}

/* ---------- icon drawing ---------- */
static void icon_play(int x, int y, int s, uint32_t c) { for(int i = 0; i < s; i++) { int w = (i < s / 2 ? i : s - 1 - i) + 1; gfx_fill_rect(x, y + i, w * 2 > s ? s : w * 2 - 0, 1, c); } }
static void icon_pause(int x, int y, int s, uint32_t c) { gfx_fill_rect(x + s / 5, y, s / 3, s, c); gfx_fill_rect(x + s - s / 5 - s / 3, y, s / 3, s, c); }
static void icon_next(int x, int y, int s, uint32_t c) { icon_play(x, y, s, c); gfx_fill_rect(x + s, y, 3, s, c); }
static void icon_prev(int x, int y, int s, uint32_t c) {
    gfx_fill_rect(x, y, 3, s, c);
    for(int i = 0; i < s; i++) { int w = (i < s / 2 ? i : s - 1 - i) + 1; w *= 2; if(w > s) w = s; gfx_fill_rect(x + 3 + s - w, y + i, w, 1, c); }
}
static void icon_speaker(int x, int y, uint32_t c, int muted) {
    gfx_fill_rect(x, y + 5, 5, 6, c);
    for(int i = 0; i < 8; i++) gfx_fill_rect(x + 5 + i / 2, y + 4 - i / 2 + (i > 3 ? 0 : 0), 1, 8 + i / 1 * 0, c);
    if(muted) { for(int i = 0; i < 8; i++) { gfx_fill_rect(x + 13 + i, y + 3 + i, 2, 2, 0xFFFF6B6B); gfx_fill_rect(x + 20 - i, y + 3 + i, 2, 2, 0xFFFF6B6B); } }
    else { gfx_fill_rect(x + 12, y + 4, 2, 8, c); gfx_fill_rect(x + 15, y + 1, 2, 14, c); }
}
static void icon_shuffle(int x, int y, uint32_t c) { for(int i = 0; i < 14; i++) { gfx_fill_rect(x + i, y + 12 - i * 10 / 14, 2, 2, c); gfx_fill_rect(x + i, y + 2 + i * 10 / 14, 2, 2, c); } gfx_fill_rect(x + 14, y, 3, 3, c); gfx_fill_rect(x + 14, y + 11, 3, 3, c); }
static void icon_repeat(int x, int y, uint32_t c, int one) {
    gfx_fill_rect(x + 1, y + 2, 14, 2, c); gfx_fill_rect(x + 1, y + 12, 14, 2, c);
    gfx_fill_rect(x, y + 2, 2, 11, c); gfx_fill_rect(x + 14, y + 2, 2, 11, c);
    gfx_fill_rect(x + 10, y, 2, 6, c);
    if(one) gfx_draw_string(x + 5, y + 1, "1", c);
}

static void draw_note(int x, int y, int s, uint32_t c) {
    int u = s / 8; if(u < 2) u = 2;
    gfx_fill_rect(x + 3 * u, y + 1 * u, u, 5 * u, c);                 /* stem */
    gfx_fill_rect(x + 3 * u, y + 1 * u, 3 * u, u, c);                 /* flag */
    gfx_fill_rounded_rect(x + 1 * u, y + 5 * u, 3 * u, 2 * u, u, c);  /* note head */
}

/* ---------- paint ---------- */
static void mp_paint(window_t *self, int cx, int cy, int cw, int ch) {
    mp *st = (mp *)self->user_data; if(!st) return;
    layout_t L; get_layout(cw, ch, &L);

    gfx_fill_rect(cx, cy, cw, ch, C_BG);
    gfx_fill_rect(cx, cy, MP_LIST_W, ch, C_PANEL);
    gfx_vline(cx + MP_LIST_W - 1, cy, ch, 0xFF303036);

    /* playlist header */
    gfx_draw_string(cx + 16, cy + 12, "Music library", C_TEXT);
    gfx_hline(cx + 12, cy + MP_HEADER_H - 2, MP_LIST_W - 24, 0xFF34343A);

    int rows = (ch - MP_HEADER_H - 8) / MP_ROW_H; if(rows < 1) rows = 1;
    if(st->current >= 0) {
        if(st->current < st->list_scroll) st->list_scroll = st->current;
        if(st->current >= st->list_scroll + rows) st->list_scroll = st->current - rows + 1;
    }
    if(st->list_scroll < 0) st->list_scroll = 0;

    if(st->count == 0) {
        gfx_draw_string(cx + 16, cy + MP_HEADER_H + 14, "No music found.", C_TEXT_DIM);
        gfx_draw_string(cx + 16, cy + MP_HEADER_H + 34, "Put .mp3 / .wav files", C_TEXT_DIM);
        gfx_draw_string(cx + 16, cy + MP_HEADER_H + 52, "in Users\\User\\Music", C_TEXT_DIM);
    }
    for(int r = 0; r < rows; r++) {
        int idx = st->list_scroll + r; if(idx >= st->count) break;
        int ry = cy + MP_HEADER_H + 4 + r * MP_ROW_H;
        int cur = (idx == st->current);
        if(cur) { gfx_fill_rounded_rect(cx + 6, ry, MP_LIST_W - 14, MP_ROW_H - 2, 5, C_PANEL_HI); gfx_fill_rect(cx + 6, ry + 6, 3, MP_ROW_H - 14, C_ACCENT); }
        char label[MP_NAME_MAX]; strip_ext(st->names[idx], label, sizeof(label));
        int maxc = (MP_LIST_W - 50) / GFX_CHAR_COLS; if((int)strlen(label) > maxc) { label[maxc - 2] = '.'; label[maxc - 1] = '.'; label[maxc] = 0; }
        gfx_draw_string(cx + 16, ry + (MP_ROW_H - 2 - GFX_CHAR_ROWS) / 2, label, cur ? C_ACCENT : C_TEXT);
    }

    /* album art placeholder */
    int ax = cx + L.art_x, ay = cy + L.art_y;
    gfx_fill_rounded_rect(ax, ay, L.art_size, L.art_size, 12, 0xFF2B3A55);
    gfx_blend_rounded_rect(ax, ay + L.art_size / 2, L.art_size, L.art_size / 2, 12, 0x30000000);
    draw_note(ax + L.art_size / 2 - L.art_size / 6, ay + L.art_size / 2 - L.art_size / 5, L.art_size / 2, 0xFFBFD7FF);

    /* title */
    char title[MP_NAME_MAX] = "Nothing playing";
    if(st->current >= 0 && st->current < st->count) strip_ext(st->names[st->current], title, sizeof(title));
    int tw = (int)strlen(title) * GFX_CHAR_COLS;
    int max_tw = L.main_w - 30; if(tw > max_tw) { int mc = max_tw / GFX_CHAR_COLS; title[mc - 2] = '.'; title[mc - 1] = '.'; title[mc] = 0; tw = (int)strlen(title) * GFX_CHAR_COLS; }
    gfx_draw_string(cx + L.main_x + (L.main_w - tw) / 2, cy + L.title_y, title, C_TEXT);
    const char *sub = st->status[0] ? st->status : (st->state == MP_PLAYING ? "Now playing" : st->state == MP_PAUSED ? "Paused" : "Ready");
    int sw = (int)strlen(sub) * GFX_CHAR_COLS;
    gfx_draw_string(cx + L.main_x + (L.main_w - sw) / 2, cy + L.title_y + 20, sub, st->status[0] ? 0xFFFF8A8A : C_TEXT_DIM);

    /* progress bar */
    int bx = cx + L.bar_x, by = cy + L.bar_y;
    gfx_fill_rounded_rect(bx, by, L.bar_w, 4, 2, C_TRACK);
    int fill = 0;
    if(st->duration_ms) fill = (int)(((uint64_t)st->pos_ms * L.bar_w) / st->duration_ms);
    if(fill > L.bar_w) fill = L.bar_w;
    if(fill > 0) gfx_fill_rounded_rect(bx, by, fill, 4, 2, C_ACCENT);
    if(st->state != MP_STOPPED) gfx_fill_rounded_rect(bx + fill - 5, by - 4, 12, 12, 6, C_TEXT);
    char t1[16], t2[16]; fmt_time(st->pos_ms, t1); fmt_time(st->duration_ms, t2);
    gfx_draw_string(bx, by + 12, t1, C_TEXT_DIM);
    gfx_draw_string(bx + L.bar_w - (int)strlen(t2) * GFX_CHAR_COLS, by + 12, t2, C_TEXT_DIM);

    /* transport buttons */
    int by2 = cy + L.btn_y, mid = cx + L.btn_cx;
    icon_prev(mid - 78, by2 + 6, 18, C_TEXT);
    gfx_fill_rounded_rect(mid - 22, by2 - 4, 44, 44, 22, C_ACCENT);
    if(st->state == MP_PLAYING) icon_pause(mid - 9, by2 + 8, 18, 0xFF10131A);
    else icon_play(mid - 6, by2 + 8, 20, 0xFF10131A);
    icon_next(mid + 56, by2 + 6, 18, C_TEXT);
    icon_shuffle(cx + L.main_x + 28, by2 + 10, st->shuffle ? C_ACCENT : C_TEXT_DIM);
    icon_repeat(cx + L.main_x + 62, by2 + 10, st->repeat ? C_ACCENT : C_TEXT_DIM, st->repeat == 2);

    /* volume */
    int vx = cx + L.vol_x, vy = cy + L.vol_y;
    icon_speaker(vx - 28, vy - 7, st->muted ? 0xFF777777 : C_TEXT, st->muted);
    gfx_fill_rounded_rect(vx, vy, L.vol_w, 4, 2, C_TRACK);
    int vv = audio_get_volume(); int vf = st->muted ? 0 : (vv * L.vol_w) / 100;
    if(vf > 0) gfx_fill_rounded_rect(vx, vy, vf, 4, 2, C_ACCENT);
    gfx_fill_rounded_rect(vx + vf - 5, vy - 4, 12, 12, 6, C_TEXT);
    char vs[8]; { int v = vv; int n = 0; char d[4]; if(!v) d[n++] = '0'; while(v) { d[n++] = (char)('0' + v % 10); v /= 10; } int p = 0; for(int i = n - 1; i >= 0; i--) vs[p++] = d[i]; vs[p] = 0; }
    gfx_draw_string(vx + L.vol_w / 2 - (int)strlen(vs) * 4, vy + 14, vs, C_TEXT_DIM);
}

/* ---------- input ---------- */
static int in_box(int x, int y, int bx, int by, int bw, int bh) { return x >= bx && x < bx + bw && y >= by && y < by + bh; }

static void apply_volume_from_x(mp *st, layout_t *L, int rx) {
    int v = ((rx - L->vol_x) * 100) / L->vol_w; if(v < 0) v = 0; if(v > 100) v = 100;
    audio_set_volume((uint8_t)v); st->muted = 0; audio_set_muted(0);
}
static void apply_seek_from_x(mp *st, layout_t *L, int rx) {
    int p = rx - L->bar_x; if(p < 0) p = 0; if(p > L->bar_w) p = L->bar_w;
    do_seek(st, (uint32_t)(((uint64_t)p * st->duration_ms) / L->bar_w));
}

static void client_size(window_t *w, int *cw, int *ch) { int x, y; wm_get_client_rect(w, &x, &y, cw, ch); }

static void mp_click(window_t *self, int rx, int ry) {
    mp *st = (mp *)self->user_data; if(!st) return;
    int cw, ch; client_size(self, &cw, &ch);
    layout_t L; get_layout(cw, ch, &L);

    if(rx < MP_LIST_W) {
        int row = (ry - MP_HEADER_H - 4) / MP_ROW_H;
        if(ry >= MP_HEADER_H) { int idx = st->list_scroll + row; if(idx >= 0 && idx < st->count) play_index(st, idx); }
        return;
    }
    if(in_box(rx, ry, L.bar_x - 6, L.bar_y - 10, L.bar_w + 12, 24) && st->state != MP_STOPPED) { st->drag = DRAG_SEEK; apply_seek_from_x(st, &L, rx); return; }
    if(in_box(rx, ry, L.vol_x - 8, L.vol_y - 10, L.vol_w + 16, 24)) { st->drag = DRAG_VOLUME; apply_volume_from_x(st, &L, rx); return; }
    if(in_box(rx, ry, L.vol_x - 32, L.vol_y - 10, 28, 24)) { st->muted = !st->muted; audio_set_muted(st->muted); return; }

    int mid = L.btn_cx, by = L.btn_y;
    if(in_box(rx, ry, mid - 22, by - 4, 44, 44)) { toggle_play(st); return; }
    if(in_box(rx, ry, mid - 84, by, 34, 34)) { if(st->count) play_index(st, next_index(st, -1)); return; }
    if(in_box(rx, ry, mid + 50, by, 34, 34)) { if(st->count) play_index(st, next_index(st, 1)); return; }
    if(in_box(rx, ry, L.main_x + 22, by + 2, 30, 30)) { st->shuffle = !st->shuffle; return; }
    if(in_box(rx, ry, L.main_x + 56, by + 2, 30, 30)) { st->repeat = (st->repeat + 1) % 3; return; }
}

static void mp_drag(window_t *self, int rx, int ry) {
    (void)ry;
    mp *st = (mp *)self->user_data; if(!st) return;
    int cw, ch; client_size(self, &cw, &ch); layout_t L; get_layout(cw, ch, &L);
    if(st->drag == DRAG_VOLUME) apply_volume_from_x(st, &L, rx);
    else if(st->drag == DRAG_SEEK) { int p = rx - L.bar_x; if(p < 0) p = 0; if(p > L.bar_w) p = L.bar_w; st->pos_ms = (uint32_t)(((uint64_t)p * st->duration_ms) / L.bar_w); }
}
static void mp_mouse_up(window_t *self, int rx, int ry) {
    (void)ry; mp *st = (mp *)self->user_data; if(!st) return;
    if(st->drag == DRAG_SEEK) { int cw, ch; client_size(self, &cw, &ch); layout_t L; get_layout(cw, ch, &L); apply_seek_from_x(st, &L, rx); }
    st->drag = DRAG_NONE;
}

static void mp_key(window_t *self, char c) {
    mp *st = (mp *)self->user_data; if(!st) return;
    if(c == ' ') toggle_play(st);
    else if(c == 'n' || c == 'N') { if(st->count) play_index(st, next_index(st, 1)); }
    else if(c == 'p' || c == 'P') { if(st->count) play_index(st, next_index(st, -1)); }
    else if(c == 's' || c == 'S') st->shuffle = !st->shuffle;
    else if(c == 'r' || c == 'R') st->repeat = (st->repeat + 1) % 3;
    else if(c == 'm' || c == 'M') { st->muted = !st->muted; audio_set_muted(st->muted); }
    else if(c == KEY_RIGHT) do_seek(st, st->pos_ms + 5000);
    else if(c == KEY_LEFT) do_seek(st, st->pos_ms > 5000 ? st->pos_ms - 5000 : 0);
    else if(c == KEY_UP) { int v = audio_get_volume() + 5; if(v > 100) v = 100; audio_set_volume((uint8_t)v); st->muted = 0; audio_set_muted(0); }
    else if(c == KEY_DOWN) { int v = (int)audio_get_volume() - 5; if(v < 0) v = 0; audio_set_volume((uint8_t)v); }
    else if(c == KEY_PGDN) { if(st->list_scroll < st->count - 1) st->list_scroll++; }
    else if(c == KEY_PGUP) { if(st->list_scroll > 0) st->list_scroll--; }
}

/* right-click menu */
static void act_play_pause(void *u) { toggle_play((mp *)u); }
static void act_next(void *u) { mp *st = (mp *)u; if(st->count) play_index(st, next_index(st, 1)); }
static void act_prev(void *u) { mp *st = (mp *)u; if(st->count) play_index(st, next_index(st, -1)); }
static void act_stop(void *u) { stop_playback((mp *)u); }
static void act_shuffle(void *u) { mp *st = (mp *)u; st->shuffle = !st->shuffle; }
static void act_repeat(void *u) { mp *st = (mp *)u; st->repeat = (st->repeat + 1) % 3; }
static void act_mute(void *u) { mp *st = (mp *)u; st->muted = !st->muted; audio_set_muted(st->muted); }
static void act_refresh(void *u) { mp *st = (mp *)u; char cur[MP_NAME_MAX]; cur[0] = 0; if(st->current >= 0) scopy(cur, st->names[st->current], MP_NAME_MAX); load_playlist(st, st->dir); st->current = -1; for(int i = 0; i < st->count; i++) if(strcasecmp(st->names[i], cur) == 0) st->current = i; }
static void act_close(void *u) { mp *st = (mp *)u; if(st->win) wm_destroy_window(st->win); }

static void mp_right_click(window_t *self, int rx, int ry) {
    mp *st = (mp *)self->user_data; if(!st) return;
    int cx, cy, cw, ch; wm_get_client_rect(self, &cx, &cy, &cw, &ch);
    static context_menu_item_t items[] = {
        CM_ITEM("Play / Pause", act_play_pause, "Space"),
        CM_ITEM("Next track", act_next, "N"),
        CM_ITEM("Previous track", act_prev, "P"),
        CM_ITEM("Stop", act_stop, ""),
        CM_SEP(),
        CM_ITEM("Shuffle", act_shuffle, "S"),
        CM_ITEM("Repeat", act_repeat, "R"),
        CM_ITEM("Mute", act_mute, "M"),
        CM_SEP(),
        CM_ITEM("Refresh library", act_refresh, ""),
        CM_ITEM("Close", act_close, ""),
    };
    items[5].checked = (uint8_t)st->shuffle;
    items[6].checked = (uint8_t)(st->repeat != 0);
    items[7].checked = (uint8_t)st->muted;
    context_menu_open(cx + rx, cy + ry, items, 11, st);
}

static int mp_cursor_at(window_t *self, int rx, int ry) {
    mp *st = (mp *)self->user_data; if(!st) return CURSOR_DEFAULT;
    int cw, ch; client_size(self, &cw, &ch); layout_t L; get_layout(cw, ch, &L);
    if(rx < MP_LIST_W && ry >= MP_HEADER_H) return CURSOR_LINK;
    if(in_box(rx, ry, L.bar_x - 6, L.bar_y - 10, L.bar_w + 12, 24)) return CURSOR_LINK;
    if(in_box(rx, ry, L.vol_x - 32, L.vol_y - 10, L.vol_w + 40, 24)) return CURSOR_LINK;
    if(ry >= L.btn_y - 4 && ry < L.btn_y + 40) return CURSOR_LINK;
    return CURSOR_DEFAULT;
}

static void mp_destroy(window_t *self) {
    mp *st = (mp *)self->user_data; if(!st) return;
    audio_flush();
    close_track(st);
    kfree(st);
    self->user_data = NULL;
}

static window_t *create_player(void) {
    int sw = (int)gfx_width(), sh = (int)gfx_height();
    int w = 760, h = 480; if(w > sw - 40) w = sw - 40; if(h > sh - 80) h = sh - 80;
    window_t *win = wm_create_window("Media Player", (sw - w) / 2, 50, w, h, C_BG);
    if(!win) return NULL;
    mp *st = (mp *)kmalloc(sizeof(mp));
    if(!st) { wm_destroy_window(win); return NULL; }
    memset(st, 0, sizeof(mp));
    st->win = win; st->current = -1; st->repeat = 1;
    win->user_data = st;
    win->on_paint = mp_paint; win->on_click = mp_click; win->on_drag = mp_drag; win->on_mouse_up = mp_mouse_up;
    win->on_key = mp_key; win->on_tick = mp_tick; win->on_destroy = mp_destroy;
    win->on_right_click = mp_right_click; win->cursor_at = mp_cursor_at;
    return win;
}

void launch_mediaplayer(void) {
    window_t *win = create_player(); if(!win) return;
    mp *st = (mp *)win->user_data;
    load_playlist(st, MP_MUSIC_DIR);
}

void launch_mediaplayer_with_file(const char *path) {
    window_t *win = create_player(); if(!win) return;
    mp *st = (mp *)win->user_data;
    char parent[FSU_PATH_MAX], name[48];
    fsu_split(path, parent, sizeof(parent), name, sizeof(name));
    load_playlist(st, parent);
    for(int i = 0; i < st->count; i++) if(strcasecmp(st->names[i], name) == 0) { play_index(st, i); break; }
}
