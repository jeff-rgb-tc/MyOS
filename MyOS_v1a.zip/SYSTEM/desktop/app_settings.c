/*
 * Settings -- Windows-11-style layout: navigation sidebar on the left,
 * rounded "cards" with controls on the right. Pages: System, Display,
 * Sound, Personalization, Accounts.
 *
 * Every page is written once as an immediate-mode function that is run in
 * four modes (PAINT / CLICK / DRAG / CURSOR) -- widgets are mode-aware, so
 * what is drawn, what responds to a click, and which mouse cursor shows
 * can never drift out of sync.
 */

#include "stdint.h"
#include "stddef.h"
#include "app_settings.h"
#include "window.h"
#include "gfx.h"
#include "common.h"
#include "kernio.h"
#include "kheap.h"
#include "settings.h"
#include "taskbar.h"
#include "pcspeaker.h"
#include "cpuinfo.h"
#include "desktop.h"
#include "vesa.h"
#include "fat32.h"
#include "file_picker.h"
#include "cursor_set.h"
#include "audio.h"
#include "pit.h"
#include "fs_util.h"
#include "keyboard.h"

extern uint32_t allocated_frames;
extern uint32_t total_frames;

#define SETTINGS_WIN_W 800
#define SETTINGS_WIN_H 520
#define NAV_W 200

/* palette (dark, matches the taskbar/menus) */
#define C_BG        0xFF1F1F1F
#define C_NAV       0xFF272727
#define C_NAV_SEL   0xFF3A3A3A
#define C_CARD      0xFF2D2D2D
#define C_CARD_HI   0xFF383838
#define C_TEXT      0xFFFFFFFF
#define C_DIM       0xFFA8A8A8
#define C_ACCENT    0xFF4CC2FF
#define C_TRACK     0xFF5A5A5A
#define C_FIELD     0xFF1B1B1B
#define C_BORDER    0xFF4A4A4A

typedef enum { PG_SYSTEM = 0, PG_DISPLAY, PG_SOUND, PG_PERSONAL, PG_ACCOUNTS, PG_COUNT } page_t;
static const char *page_names[PG_COUNT] = { "System", "Display", "Sound", "Personalization", "Accounts" };

#define FIELD_NAME_MAX 64

typedef enum { FIELD_NONE = 0, FIELD_WALLPAPER_PATH, FIELD_AVATAR_PATH, FIELD_USERNAME } settings_field_t;
typedef enum { SL_NONE = 0, SL_VOLUME, SL_BRIGHT } slider_id_t;
typedef enum { M_PAINT = 0, M_CLICK, M_DRAG, M_CURSOR } ui_mode_t;

typedef struct {
    int current_page;
    settings_field_t editing_field;
    char edit_buffer[FIELD_NAME_MAX];
    int edit_len;
    file_picker_t picker;
    settings_field_t picker_target;
    slider_id_t drag_slider;
    uint8_t dirty_save;   /* settings need writing on mouse-up */
    int test_tone_tick;
} settings_state_t;

typedef struct {
    ui_mode_t mode;
    settings_state_t *st;
    int ox, oy;        /* PAINT: screen position of the content area's top-left */
    int mx, my;        /* CLICK/DRAG/CURSOR: mouse position relative to content area */
    int cw;            /* content width */
    int handled;       /* CLICK: a widget consumed the click */
    int cursor;        /* CURSOR: result */
} ctx_t;

/* ------------------------------------------------------------------ */
static int hit(ctx_t *c, int x, int y, int w, int h) {
    return c->mx >= x && c->mx < x + w && c->my >= y && c->my < y + h;
}

static void begin_edit(settings_state_t *st, settings_field_t field, const char *initial) {
    st->editing_field = field;
    int i = 0;
    while(initial[i] && i < FIELD_NAME_MAX - 1) { st->edit_buffer[i] = initial[i]; i++; }
    st->edit_buffer[i] = '\0';
    st->edit_len = i;
}

static void commit_edit(settings_state_t *st) {
    settings_t *s = settings_current();
    switch(st->editing_field) {
        case FIELD_WALLPAPER_PATH:
            fastcp(s->wallpaper_path, st->edit_buffer, (uint32_t)strlen(st->edit_buffer) + 1);
            settings_save();
            reload_background();
            break;
        case FIELD_AVATAR_PATH:
            fastcp(s->avatar_path, st->edit_buffer, (uint32_t)strlen(st->edit_buffer) + 1);
            settings_save();
            break;
        case FIELD_USERNAME:
            if(st->edit_len > 0) { fastcp(s->username, st->edit_buffer, (uint32_t)strlen(st->edit_buffer) + 1); settings_save(); }
            break;
        default: break;
    }
    st->editing_field = FIELD_NONE;
}

/* ------------------------------ widgets ---------------------------- */
static void ui_text(ctx_t *c, int x, int y, const char *s, uint32_t color) {
    if(c->mode == M_PAINT) gfx_draw_string(c->ox + x, c->oy + y, s, color);
}
static void ui_title(ctx_t *c, int x, int y, const char *s) {
    if(c->mode != M_PAINT) return;
    gfx_draw_string(c->ox + x, c->oy + y, s, C_TEXT);
    gfx_draw_string(c->ox + x + 1, c->oy + y, s, C_TEXT); /* faux bold */
}
static void ui_card(ctx_t *c, int x, int y, int w, int h) {
    if(c->mode == M_PAINT) gfx_fill_rounded_rect(c->ox + x, c->oy + y, w, h, 6, C_CARD);
}

/* Slider: value 0-100. Returns the (possibly new) value. */
static int ui_slider(ctx_t *c, slider_id_t id, int x, int y, int w, int value) {
    int track_y = y + 8;
    if(c->mode == M_PAINT) {
        int fill = (value * w) / 100;
        gfx_fill_rounded_rect(c->ox + x, c->oy + track_y, w, 4, 2, C_TRACK);
        if(fill > 0) gfx_fill_rounded_rect(c->ox + x, c->oy + track_y, fill, 4, 2, C_ACCENT);
        gfx_fill_rounded_rect(c->ox + x + fill - 8, c->oy + track_y - 8, 20, 20, 10, 0xFFE8E8E8);
        gfx_fill_rounded_rect(c->ox + x + fill - 3, c->oy + track_y - 3, 10, 10, 5, C_ACCENT);
        return value;
    }
    int is_target = (c->mode == M_DRAG && c->st->drag_slider == id);
    if(c->mode == M_CLICK && hit(c, x - 10, y - 4, w + 20, 28)) { c->st->drag_slider = id; is_target = 1; c->handled = 1; }
    if(c->mode == M_CURSOR && hit(c, x - 10, y - 4, w + 20, 28)) { c->cursor = CURSOR_LINK; }
    if(is_target) {
        int v = ((c->mx - x) * 100) / w;
        if(v < 0) v = 0; if(v > 100) v = 100;
        return v;
    }
    return value;
}

/* Toggle switch. Returns 1 if clicked (caller flips the state). */
static int ui_toggle(ctx_t *c, int x, int y, int on) {
    if(c->mode == M_PAINT) {
        gfx_fill_rounded_rect(c->ox + x, c->oy + y, 44, 22, 11, on ? C_ACCENT : 0xFF6A6A6A);
        gfx_fill_rounded_rect(c->ox + x + (on ? 24 : 4), c->oy + y + 4, 14, 14, 7, on ? 0xFF101010 : 0xFFE0E0E0);
        return 0;
    }
    if(hit(c, x, y, 44, 22)) {
        if(c->mode == M_CLICK) { c->handled = 1; return 1; }
        if(c->mode == M_CURSOR) c->cursor = CURSOR_LINK;
    }
    return 0;
}

static int ui_button(ctx_t *c, int x, int y, int w, int h, const char *label, int selected) {
    if(c->mode == M_PAINT) {
        gfx_fill_rounded_rect(c->ox + x, c->oy + y, w, h, 5, selected ? C_ACCENT : C_CARD_HI);
        int tw = (int)strlen(label) * GFX_CHAR_COLS;
        gfx_draw_string(c->ox + x + (w - tw) / 2, c->oy + y + (h - GFX_CHAR_ROWS) / 2, label, selected ? 0xFF101010 : C_TEXT);
        return 0;
    }
    if(hit(c, x, y, w, h)) {
        if(c->mode == M_CLICK) { c->handled = 1; return 1; }
        if(c->mode == M_CURSOR) c->cursor = CURSOR_LINK;
    }
    return 0;
}

/* Text field; returns 1 if clicked (caller begins edit). */
static int ui_field(ctx_t *c, int x, int y, int w, const char *value, int editing, const char *edit_buf) {
    if(c->mode == M_PAINT) {
        gfx_fill_rounded_rect(c->ox + x, c->oy + y, w, 28, 5, C_FIELD);
        gfx_draw_rect(c->ox + x, c->oy + y, w, 28, editing ? C_ACCENT : C_BORDER);
        const char *t = editing ? edit_buf : value;
        int maxc = (w - 14) / GFX_CHAR_COLS; char buf[80]; int n = (int)strlen(t);
        const char *src = t; if(n > maxc) { src = t + (n - maxc); n = maxc; }
        for(int i = 0; i < n && i < 78; i++) buf[i] = src[i]; buf[n < 78 ? n : 78] = 0;
        gfx_draw_string(c->ox + x + 8, c->oy + y + 6, buf, C_TEXT);
        if(editing && (((pit_get_ticks() / 5) & 1) == 0)) gfx_vline(c->ox + x + 8 + n * GFX_CHAR_COLS, c->oy + y + 5, 18, C_TEXT);
        return 0;
    }
    if(hit(c, x, y, w, 28)) {
        if(c->mode == M_CLICK) { c->handled = 1; return 1; }
        if(c->mode == M_CURSOR) c->cursor = CURSOR_TEXT;
    }
    return 0;
}

static void ui_bar(ctx_t *c, int x, int y, int w, int pct, uint32_t color) {
    if(c->mode != M_PAINT) return;
    if(pct > 100) pct = 100; if(pct < 0) pct = 0;
    gfx_fill_rounded_rect(c->ox + x, c->oy + y, w, 8, 4, C_TRACK);
    if(pct > 0) gfx_fill_rounded_rect(c->ox + x, c->oy + y, (w * pct) / 100 < 8 ? 8 : (w * pct) / 100, 8, 4, color);
}

static void speaker_icon(int x, int y, uint32_t col, int muted, int level) {
    gfx_fill_rect(x, y + 6, 6, 8, col);
    for(int i = 0; i < 8; i++) gfx_fill_rect(x + 6 + i, y + 10 - i - 1 + 0, 1, 2 + i * 2, col);
    if(muted) { for(int i = 0; i < 10; i++) { gfx_fill_rect(x + 18 + i, y + 5 + i, 2, 2, 0xFFFF6B6B); gfx_fill_rect(x + 27 - i, y + 5 + i, 2, 2, 0xFFFF6B6B); } }
    else {
        if(level > 0) gfx_fill_rect(x + 17, y + 7, 2, 6, col);
        if(level > 35) gfx_fill_rect(x + 21, y + 4, 2, 12, col);
        if(level > 70) gfx_fill_rect(x + 25, y + 1, 2, 18, col);
    }
}

/* ------------------------------ pages ------------------------------ */
static const struct { int w, h; } resolution_choices[] = { {1920,1080}, {1280,720}, {1024,768}, {800,600} };
#define RES_COUNT 4

static void page_system(ctx_t *c) {
    ui_title(c, 24, 20, "System");
    ui_text(c, 24, 46, "About this PC", C_DIM);
    int w = c->cw - 48;

    ui_card(c, 24, 70, w, 180);
    ui_text(c, 44, 86, "Device name", C_DIM);   ui_text(c, 200, 86, "MyOS-PC", C_TEXT);
    ui_text(c, 44, 112, "Operating system", C_DIM); ui_text(c, 200, 112, "MyOS 1.0.0", C_TEXT);
    char line[96];
    sprintf(line, "%dx%d", (int)get_screen_width(), (int)get_screen_height());
    ui_text(c, 44, 138, "Display", C_DIM); ui_text(c, 200, 138, line, C_TEXT);
    ui_text(c, 44, 164, "Sound device", C_DIM);
    ui_text(c, 200, 164, audio_is_available() ? audio_active_driver_name() : "Not found", C_TEXT);
    { char cpu[49]; cpu_brand(cpu); ui_text(c, 44, 190, "Processor", C_DIM); ui_text(c, 200, 190, cpu, C_TEXT); }
    ui_text(c, 44, 216, "CPU type", C_DIM);
    ui_text(c, 200, 216, cpu_has_long_mode() ? "64-bit capable (running the 32-bit x86 system)" : "32-bit", C_TEXT);

    uint32_t used_mb = (allocated_frames * 0x1000) / (1024 * 1024);
    uint32_t total_mb = (total_frames * 0x1000) / (1024 * 1024);
    ui_card(c, 24, 264, w, 62);
    sprintf(line, "Memory   %d MB used of %d MB", (int)used_mb, (int)total_mb);
    ui_text(c, 44, 276, line, C_TEXT);
    ui_bar(c, 44, 300, w - 40, total_mb ? (int)(used_mb * 100 / total_mb) : 0, C_ACCENT);

    if(master_fs) {
        const struct bios_parameter_block *bpb = getBPB(master_fs);
        uint32_t total_sectors = bpb->large_sectors_on_media ? bpb->large_sectors_on_media : bpb->total_sectors;
        uint32_t disk_mb = (uint32_t)(((uint64_t)total_sectors * bpb->bytes_per_sector) >> 20);
        uint32_t free_mb = (uint32_t)(((uint64_t)count_free_clusters(master_fs) * master_fs->cluster_size) >> 20);
        uint32_t used_d = disk_mb > free_mb ? disk_mb - free_mb : 0;
        ui_card(c, 24, 340, w, 62);
        sprintf(line, "Storage (C:)   %d MB used of %d MB (FAT32)", (int)used_d, (int)disk_mb);
        ui_text(c, 44, 352, line, C_TEXT);
        ui_bar(c, 44, 376, w - 40, disk_mb ? (int)(used_d * 100 / disk_mb) : 0, 0xFF6CCB5F);
    }
}

static void page_display(ctx_t *c) {
    settings_t *s = settings_current();
    ui_title(c, 24, 20, "Display");
    int w = c->cw - 48;

    ui_card(c, 24, 60, w, 82);
    ui_text(c, 44, 74, "Brightness", C_TEXT);
    ui_text(c, 44, 94, "Software dimming of the whole desktop", C_DIM);
    int v = ui_slider(c, SL_BRIGHT, 44, 108, w - 120, s->brightness);
    if(v != s->brightness) { s->brightness = v; c->st->dirty_save = 1; }
    char pct[8]; sprintf(pct, "%d%%", s->brightness);
    ui_text(c, 44 + w - 100, 112, pct, C_TEXT);

    ui_card(c, 24, 156, w, 130);
    ui_text(c, 44, 170, "Display resolution", C_TEXT);
    ui_text(c, 44, 190, "Applied the next time MyOS starts", C_DIM);
    for(int i = 0; i < RES_COUNT; i++) {
        char label[16]; sprintf(label, "%dx%d", resolution_choices[i].w, resolution_choices[i].h);
        int sel = (s->resolution_width == resolution_choices[i].w && s->resolution_height == resolution_choices[i].h);
        if(ui_button(c, 44 + i * 112, 216, 104, 32, label, sel)) {
            s->resolution_width = resolution_choices[i].w; s->resolution_height = resolution_choices[i].h; settings_save();
        }
    }
    char cur[48]; sprintf(cur, "Current: %dx%d", (int)get_screen_width(), (int)get_screen_height());
    ui_text(c, 44, 258, cur, C_DIM);
}

/* Short 880/660 Hz two-note chime, ~0.3s, no libm: triangle-ish wave via integer math. */
static void play_test_tone(void) {
    if(!audio_is_available()) return;
    static int16_t buf[4096 * 4];
    const uint32_t rate = 44100;
    audio_flush();
    audio_set_format(rate, 2);
    int n = 0, total_frames_n = 7000;
    for(int i = 0; i < total_frames_n && n + 1 < (int)(sizeof(buf) / sizeof(buf[0])); i++) {
        uint32_t freq = (i < total_frames_n / 2) ? 660 : 880;
        uint32_t period = rate / freq;
        uint32_t ph = (uint32_t)i % period;
        int32_t tri = (int32_t)((ph * 4 * 8000) / period) - 8000; /* 0..period -> -8000..24000 */
        if(tri > 8000) tri = 16000 - tri;                         /* fold into a triangle */
        int env = (i < 500) ? i * 100 / 500 : (i > total_frames_n - 1500 ? (total_frames_n - i) * 100 / 1500 : 100);
        int16_t smp = (int16_t)((tri * env) / 100);
        buf[n++] = smp; buf[n++] = smp;
    }
    audio_queue(buf, (uint32_t)n);
}

static void page_sound(ctx_t *c) {
    settings_t *s = settings_current();
    ui_title(c, 24, 20, "Sound");
    int w = c->cw - 48;

    ui_card(c, 24, 60, w, 62);
    ui_text(c, 44, 74, "Output", C_TEXT);
    ui_text(c, 44, 94, audio_is_available() ? audio_active_driver_name() : "No sound device found", audio_is_available() ? C_DIM : 0xFFFF8A8A);
    if(c->mode == M_PAINT) {
        gfx_fill_rounded_rect(c->ox + w - 70, c->oy + 80, 54, 6, 3, audio_is_available() ? 0xFF6CCB5F : 0xFFFF6B6B);
    }

    ui_card(c, 24, 136, w, 104);
    if(c->mode == M_PAINT) speaker_icon(c->ox + 44, c->oy + 154, s->muted ? 0xFF888888 : C_TEXT, s->muted, s->volume);
    ui_text(c, 92, 156, "Master volume", C_TEXT);
    int v = ui_slider(c, SL_VOLUME, 44, 190, w - 130, s->volume);
    if(v != s->volume) { s->volume = v; s->muted = 0; audio_set_volume((uint8_t)v); audio_set_muted(0); c->st->dirty_save = 1; }
    char pct[8]; sprintf(pct, "%d", s->muted ? 0 : s->volume);
    ui_text(c, 44 + w - 100, 194, pct, C_TEXT);

    ui_card(c, 24, 254, w, 56);
    ui_text(c, 44, 272, "Mute", C_TEXT);
    if(ui_toggle(c, w - 40, 268, s->muted)) { s->muted = !s->muted; audio_set_muted(s->muted); settings_save(); }

    ui_card(c, 24, 324, w, 56);
    ui_text(c, 44, 342, "Test your speakers", C_TEXT);
    if(ui_button(c, w - 130, 336, 110, 32, "Play sound", 0)) play_test_tone();

    ui_card(c, 24, 394, w, 56);
    ui_text(c, 44, 412, "Test the PC speaker", C_TEXT);
    if(ui_button(c, w - 130, 406, 110, 32, "Beep", 0)) speaker_beep(880, 250);
}

static void page_personal(ctx_t *c) {
    settings_t *s = settings_current();
    settings_state_t *st = c->st;
    ui_title(c, 24, 20, "Personalization");
    int w = c->cw - 48;

    ui_card(c, 24, 60, w, 104);
    ui_text(c, 44, 74, "Background", C_TEXT);
    ui_text(c, 44, 94, "Path to a PNG image", C_DIM);
    int fw = w - 40 - 96;
    if(ui_field(c, 44, 118, fw, s->wallpaper_path, st->editing_field == FIELD_WALLPAPER_PATH, st->edit_buffer)) {
        if(st->editing_field != FIELD_NONE) commit_edit(st);
        begin_edit(st, FIELD_WALLPAPER_PATH, s->wallpaper_path);
    }
    if(ui_button(c, 44 + fw + 8, 118, 88, 28, "Browse...", 0)) {
        if(st->editing_field != FIELD_NONE) commit_edit(st);
        st->picker_target = FIELD_WALLPAPER_PATH; file_picker_open(&st->picker, "png");
    }

    ui_card(c, 24, 178, w, 84);
    ui_text(c, 44, 192, "Taskbar position", C_TEXT);
    static const char *dock_names[4] = { "Bottom", "Top", "Left", "Right" };
    int bw = (w - 40 - 3 * 8) / 4;
    for(int i = 0; i < 4; i++) {
        if(ui_button(c, 44 + i * (bw + 8), 218, bw, 30, dock_names[i], taskbar_get_dock() == i)) {
            taskbar_set_dock(i);
            wm_refit_maximized();
        }
    }

    ui_card(c, 24, 276, w, 56);
    ui_text(c, 44, 294, "Animations (windows, Start menu)", C_TEXT);
    if(ui_toggle(c, w - 40, 290, s->animations)) { s->animations = !s->animations; settings_save(); }
}

static void page_accounts(ctx_t *c) {
    settings_t *s = settings_current();
    settings_state_t *st = c->st;
    ui_title(c, 24, 20, "Accounts");
    int w = c->cw - 48;

    ui_card(c, 24, 60, w, 96);
    if(c->mode == M_PAINT) {
        gfx_fill_rounded_rect(c->ox + 44, c->oy + 78, 60, 60, 30, C_ACCENT);
        char init[2] = { s->username[0] ? s->username[0] : 'U', 0 };
        gfx_draw_string(c->ox + 70, c->oy + 100, init, 0xFF101010);
    }
    ui_title(c, 124, 88, s->username);
    ui_text(c, 124, 112, "Local account", C_DIM);

    ui_card(c, 24, 170, w, 78);
    ui_text(c, 44, 182, "User name (shown in the Start menu)", C_TEXT);
    if(ui_field(c, 44, 206, w - 40, s->username, st->editing_field == FIELD_USERNAME, st->edit_buffer)) {
        if(st->editing_field != FIELD_NONE) commit_edit(st);
        begin_edit(st, FIELD_USERNAME, s->username);
    }

    ui_card(c, 24, 262, w, 100);
    ui_text(c, 44, 274, "Profile picture (PNG)", C_TEXT);
    int fw = w - 40 - 96;
    if(ui_field(c, 44, 298, fw, s->avatar_path, st->editing_field == FIELD_AVATAR_PATH, st->edit_buffer)) {
        if(st->editing_field != FIELD_NONE) commit_edit(st);
        begin_edit(st, FIELD_AVATAR_PATH, s->avatar_path);
    }
    if(ui_button(c, 44 + fw + 8, 298, 88, 28, "Browse...", 0)) {
        if(st->editing_field != FIELD_NONE) commit_edit(st);
        st->picker_target = FIELD_AVATAR_PATH; file_picker_open(&st->picker, "png");
    }
}

static void run_page(ctx_t *c) {
    switch(c->st->current_page) {
        case PG_SYSTEM: page_system(c); break;
        case PG_DISPLAY: page_display(c); break;
        case PG_SOUND: page_sound(c); break;
        case PG_PERSONAL: page_personal(c); break;
        case PG_ACCOUNTS: page_accounts(c); break;
    }
}

/* ------------------------------ window ----------------------------- */
static void picker_rect(window_t *self, int *x, int *y, int *w, int *h) {
    int cx, cy, cw, ch; wm_get_client_rect(self, &cx, &cy, &cw, &ch);
    int margin = 30;
    *x = NAV_W + margin; *y = margin; *w = cw - NAV_W - margin * 2; *h = ch - margin * 2;
}

static void settings_paint(window_t *self, int cx, int cy, int cw, int ch) {
    settings_state_t *st = (settings_state_t *)self->user_data;
    if(!st) return;
    settings_t *s = settings_current();

    gfx_fill_rect(cx, cy, cw, ch, C_BG);
    gfx_fill_rect(cx, cy, NAV_W, ch, C_NAV);

    /* profile header */
    gfx_fill_rounded_rect(cx + 16, cy + 16, 44, 44, 22, C_ACCENT);
    char init[2] = { s->username[0] ? s->username[0] : 'U', 0 };
    gfx_draw_string(cx + 34, cy + 31, init, 0xFF101010);
    gfx_draw_string(cx + 70, cy + 22, s->username, C_TEXT);
    gfx_draw_string(cx + 70, cy + 42, "Local account", C_DIM);

    /* navigation */
    for(int i = 0; i < PG_COUNT; i++) {
        int ny = cy + 80 + i * 40;
        int sel = (i == st->current_page);
        if(sel) {
            gfx_fill_rounded_rect(cx + 8, ny, NAV_W - 16, 34, 6, C_NAV_SEL);
            gfx_fill_rounded_rect(cx + 8, ny + 8, 4, 18, 2, C_ACCENT);
        }
        /* little page glyph */
        gfx_fill_rounded_rect(cx + 24, ny + 10, 14, 14, 3, sel ? C_ACCENT : 0xFF8A8A8A);
        gfx_draw_string(cx + 48, ny + 9, page_names[i], sel ? C_TEXT : 0xFFD0D0D0);
    }

    ctx_t c; memset(&c, 0, sizeof(c));
    c.mode = M_PAINT; c.st = st; c.ox = cx + NAV_W; c.oy = cy; c.cw = cw - NAV_W;
    run_page(&c);

    if(st->picker.open) {
        int px, py, pw, ph; picker_rect(self, &px, &py, &pw, &ph);
        file_picker_draw(&st->picker, cx + px, cy + py, pw, ph);
    }
}

static void settings_click(window_t *self, int rel_x, int rel_y) {
    settings_state_t *st = (settings_state_t *)self->user_data;
    if(!st) return;

    if(st->picker.open) {
        int px, py, pw, ph; picker_rect(self, &px, &py, &pw, &ph);
        file_picker_handle_click(&st->picker, rel_x - px, rel_y - py, pw, ph);
        if(st->picker.file_chosen) {
            settings_t *s = settings_current();
            if(st->picker_target == FIELD_WALLPAPER_PATH) {
                fastcp(s->wallpaper_path, st->picker.selected_path, (uint32_t)strlen(st->picker.selected_path) + 1);
                settings_save(); reload_background();
            }
            else if(st->picker_target == FIELD_AVATAR_PATH) {
                fastcp(s->avatar_path, st->picker.selected_path, (uint32_t)strlen(st->picker.selected_path) + 1);
                settings_save();
            }
            file_picker_close(&st->picker);
        }
        return;
    }

    settings_field_t was_editing = st->editing_field;

    if(rel_x < NAV_W) {
        if(was_editing != FIELD_NONE) commit_edit(st);
        int i = (rel_y - 80) / 40;
        if(rel_y >= 80 && i >= 0 && i < PG_COUNT) st->current_page = i;
        return;
    }

    int cx, cy, cw, ch; wm_get_client_rect(self, &cx, &cy, &cw, &ch);
    ctx_t c; memset(&c, 0, sizeof(c));
    c.mode = M_CLICK; c.st = st; c.mx = rel_x - NAV_W; c.my = rel_y; c.cw = cw - NAV_W;
    run_page(&c);

    if(!c.handled && was_editing != FIELD_NONE) commit_edit(st);
}

static void settings_drag(window_t *self, int rel_x, int rel_y) {
    settings_state_t *st = (settings_state_t *)self->user_data;
    if(!st || st->drag_slider == SL_NONE || st->picker.open) return;
    int cx, cy, cw, ch; wm_get_client_rect(self, &cx, &cy, &cw, &ch);
    ctx_t c; memset(&c, 0, sizeof(c));
    c.mode = M_DRAG; c.st = st; c.mx = rel_x - NAV_W; c.my = rel_y; c.cw = cw - NAV_W;
    run_page(&c);
}

static void settings_mouse_up(window_t *self, int rel_x, int rel_y) {
    settings_state_t *st = (settings_state_t *)self->user_data;
    if(!st) return;
    if(st->drag_slider != SL_NONE) {
        settings_drag(self, rel_x, rel_y);
        st->drag_slider = SL_NONE;
    }
    if(st->dirty_save) { st->dirty_save = 0; settings_save(); }
}

static int settings_cursor_at(window_t *self, int rel_x, int rel_y) {
    settings_state_t *st = (settings_state_t *)self->user_data;
    if(!st || st->picker.open) return CURSOR_DEFAULT;
    if(rel_x < NAV_W) return (rel_y >= 80 && rel_y < 80 + PG_COUNT * 40) ? CURSOR_LINK : CURSOR_DEFAULT;
    int cx, cy, cw, ch; wm_get_client_rect(self, &cx, &cy, &cw, &ch);
    ctx_t c; memset(&c, 0, sizeof(c));
    c.mode = M_CURSOR; c.st = st; c.mx = rel_x - NAV_W; c.my = rel_y; c.cw = cw - NAV_W; c.cursor = CURSOR_DEFAULT;
    run_page(&c);
    return c.cursor;
}

static void settings_key(window_t *self, char c) {
    settings_state_t *st = (settings_state_t *)self->user_data;
    if(!st) return;

    if(st->editing_field == FIELD_NONE) {
        /* Volume with the arrow keys while on the Sound page. */
        if(st->current_page == PG_SOUND) {
            settings_t *s = settings_current();
            if(c == KEY_LEFT || c == KEY_DOWN) { s->volume = s->volume >= 5 ? s->volume - 5 : 0; audio_set_volume((uint8_t)s->volume); settings_save(); }
            else if(c == KEY_RIGHT || c == KEY_UP) { s->volume = s->volume <= 95 ? s->volume + 5 : 100; s->muted = 0; audio_set_muted(0); audio_set_volume((uint8_t)s->volume); settings_save(); }
        }
        return;
    }
    if(c == '\n' || c == '\r') commit_edit(st);
    else if(c == 27) st->editing_field = FIELD_NONE;
    else if(c == '\b' || c == 127) { if(st->edit_len > 0) { st->edit_len--; st->edit_buffer[st->edit_len] = '\0'; } }
    else if(c == 22) { /* Ctrl+V pastes the text clipboard */ }
    else if(c >= ' ' && c < 127) { if(st->edit_len < FIELD_NAME_MAX - 1) { st->edit_buffer[st->edit_len++] = c; st->edit_buffer[st->edit_len] = '\0'; } }
}

static void settings_destroy(window_t *self) {
    settings_state_t *st = (settings_state_t *)self->user_data;
    if(st) { if(st->dirty_save) settings_save(); kfree(st); self->user_data = NULL; }
}

void launch_settings(void) {
    int sw = (int)gfx_width(), sh = (int)gfx_height();
    int w = SETTINGS_WIN_W, h = SETTINGS_WIN_H; if(w > sw - 30) w = sw - 30; if(h > sh - 70) h = sh - 70;
    window_t *win = wm_create_window("Settings", (sw - w) / 2, 40, w, h, C_BG);
    if(!win) return;

    settings_state_t *st = (settings_state_t *)kmalloc(sizeof(settings_state_t));
    if(!st) { wm_destroy_window(win); return; }
    memset(st, 0, sizeof(settings_state_t));
    st->current_page = PG_SYSTEM;

    win->user_data = st;
    win->static_content = 1;   /* only changes on input: lets the desktop idle */
    win->on_paint = settings_paint;
    win->on_click = settings_click;
    win->on_drag = settings_drag;
    win->on_mouse_up = settings_mouse_up;
    win->cursor_at = settings_cursor_at;
    win->on_key = settings_key;
    win->on_destroy = settings_destroy;
}
