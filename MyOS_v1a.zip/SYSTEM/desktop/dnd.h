#ifndef DESKTOP_DND_H
#define DESKTOP_DND_H

#include "stdint.h"

/* Drag and drop of files, folders and shortcuts between Explorer windows,
 * the desktop and the Recycle Bin.
 *
 * A window that wants to START a drag (Explorer) calls dnd_begin() once its
 * pointer has moved far enough with the button held. From then on the
 * desktop owns the gesture: it draws the dragged item next to the pointer
 * and, when the button is released, delivers the drop to whatever is under
 * the pointer -- a window's on_drop hook, a desktop icon (Recycle Bin or a
 * folder), or the bare desktop (which moves the item into the Desktop
 * folder). The payload is simply an absolute path. */

#define DND_PATH_MAX 192

void dnd_begin(const char *path, const char *label, int is_dir);
int  dnd_active(void);
const char *dnd_path(void);
const char *dnd_label(void);
int  dnd_is_dir(void);
void dnd_end(void);

#endif
