#include "stdint.h"
#include "stddef.h"
#include "window.h"
#include "taskbar.h"
#include "settings.h"
#include "pit.h"
#include "gfx.h"
#include "common.h"
#include "kernio.h"
#include "mouse.h"

/* Windows are stored in a fixed-size table; the *order of the table* is
 * used directly as Z-order (index 0 = bottom/back, last used slot with
 * in_use = most-recently-focused = drawn last = on top). Focusing a
 * window moves it to the end of the active list by swapping it forward,
 * which keeps this dead simple without needing a linked list. */
static window_t windows[WM_MAX_WINDOWS];
static int window_order[WM_MAX_WINDOWS]; /* indices into windows[], back to front */
static int window_count = 0;

/* Window chrome palette. Everything shares one dark neutral family with
 * the taskbar and menus; focus is shown by a lighter titlebar, brighter
 * text, a crisper outline and a deeper shadow (no hue change needed). */
#define COLOR_FRAME_FOCUSED      0xF2232326
#define COLOR_FRAME_UNFOCUSED    0xEC1C1C1F
#define COLOR_TITLE_TOP_FOCUSED  0xF42E2E33
#define COLOR_TITLE_BOT_FOCUSED  0xF4262629
#define COLOR_TITLE_TOP_UNFOC    0xEC222225
#define COLOR_TITLE_BOT_UNFOC    0xEC1D1D20
#define COLOR_TITLE_TEXT_FOCUSED   0xFFF4F4F6
#define COLOR_TITLE_TEXT_UNFOCUSED 0xFF8E8E96
#define COLOR_OUTLINE_FOCUSED    0x46FFFFFF
#define COLOR_OUTLINE_UNFOCUSED  0x22FFFFFF
#define COLOR_TITLE_SEPARATOR    0x50000000
#define COLOR_BTN_HOVER          0x2EFFFFFF
#define COLOR_BTN_CLOSE_HOVER    0xFFC42B1C
#define COLOR_BTN_GLYPH          0xFFE6E6EA
#define COLOR_BTN_GLYPH_DIM      0xFF8E8E96

void wm_init() {
    memset(windows, 0, sizeof(windows));
    for(int i = 0; i < WM_MAX_WINDOWS; i++) {
        window_order[i] = -1;
    }
    window_count = 0;
}

static int find_free_slot() {
    for(int i = 0; i < WM_MAX_WINDOWS; i++) {
        if(!windows[i].in_use) {
            return i;
        }
    }
    return -1;
}

static int slot_index_of(window_t *win) {
    int idx = (int)(win - windows);
    if(idx < 0 || idx >= WM_MAX_WINDOWS) {
        return -1;
    }
    return idx;
}

static void order_remove(int slot) {
    int found = -1;
    for(int i = 0; i < window_count; i++) {
        if(window_order[i] == slot) {
            found = i;
            break;
        }
    }
    if(found < 0) return;
    for(int i = found; i < window_count - 1; i++) {
        window_order[i] = window_order[i + 1];
    }
    window_count--;
}

static void order_push_top(int slot) {
    order_remove(slot);
    window_order[window_count++] = slot;
}

window_t *wm_create_window(const char *title, int x, int y, int w, int h, uint32_t bg_color) {
    int slot = find_free_slot();
    if(slot < 0) {
        printf("wm: out of window slots\n");
        return NULL;
    }

    window_t *win = &windows[slot];
    memset(win, 0, sizeof(window_t));

    win->x = x;
    win->y = y;
    win->w = w;
    win->h = h;
    win->bg_color = bg_color;
    win->visible = 1;
    win->focused = 0;
    win->in_use = 1;
    win->on_paint = NULL;
    win->user_data = NULL;

    int i = 0;
    while(title[i] && i < (int)sizeof(win->title) - 1) {
        win->title[i] = title[i];
        i++;
    }
    win->title[i] = '\0';

    order_push_top(slot);
    wm_focus(win);

    /* open animation: start 26 px low and glide up (160 ms, ease-out) */
    if(settings_current()->animations) {
        win->anim_target_y = win->y;
        win->y += 26;
        win->anim_t0 = pit_get_ms();
        win->anim_active = 1;
    }

    return win;
}

void wm_destroy_window(window_t *win) {
    if(!win) return;
    int slot = slot_index_of(win);
    if(slot < 0) return;

    if(win->on_destroy) {
        win->on_destroy(win);
    }

    order_remove(slot);
    memset(win, 0, sizeof(window_t));

    /* Whatever is now on top (if anything) becomes focused. */
    if(window_count > 0) {
        wm_focus(&windows[window_order[window_count - 1]]);
    }
}

void wm_focus(window_t *win) {
    if(!win) return;
    int slot = slot_index_of(win);
    if(slot < 0 || !windows[slot].in_use) return;

    for(int i = 0; i < WM_MAX_WINDOWS; i++) {
        windows[i].focused = 0;
    }
    win->focused = 1;

    order_push_top(slot);
}

window_t *wm_focused_window() {
    for(int i = 0; i < WM_MAX_WINDOWS; i++) {
        if(windows[i].in_use && windows[i].focused) {
            return &windows[i];
        }
    }
    return NULL;
}

window_t *wm_window_at(int x, int y) {
    /* Walk front-to-back (end of window_order is topmost). */
    for(int i = window_count - 1; i >= 0; i--) {
        window_t *win = &windows[window_order[i]];
        if(!win->in_use || !win->visible) continue;
        if(x >= win->x && x < win->x + win->w && y >= win->y && y < win->y + win->h) {
            return win;
        }
    }
    return NULL;
}

int wm_point_in_titlebar(window_t *win, int x, int y) {
    if(!win) return 0;
    return x >= win->x && x < win->x + win->w &&
           y >= win->y && y < win->y + WM_TITLEBAR_HEIGHT;
}

/* How many pixels around the window's outer edge count as "the resize
 * border" -- wide enough to actually grab with a mouse (a 1-2px hitbox
 * would be unusably fiddly), narrow enough not to eat into the
 * titlebar's drag region or client area noticeably. */
#define WM_RESIZE_BORDER_WIDTH 6

wm_resize_edge_t wm_resize_edge_at(window_t *win, int x, int y) {
    if(!win || win->maximized) return WM_RESIZE_NONE;

    /* Outside the window's outer rect (plus a small outward margin, so
     * the hitbox isn't only on the inside half of the border) entirely
     * -- definitely not a resize edge. */
    int margin = WM_RESIZE_BORDER_WIDTH;
    if(x < win->x - margin || x >= win->x + win->w + margin) return WM_RESIZE_NONE;
    if(y < win->y - margin || y >= win->y + win->h + margin) return WM_RESIZE_NONE;

    int on_left = (x < win->x + WM_RESIZE_BORDER_WIDTH);
    int on_right = (x >= win->x + win->w - WM_RESIZE_BORDER_WIDTH);
    int on_top = (y < win->y + WM_RESIZE_BORDER_WIDTH);
    int on_bottom = (y >= win->y + win->h - WM_RESIZE_BORDER_WIDTH);

    /* Corners take priority over edges when both would otherwise match
     * (the corner regions are a subset of "on_left && on_top" etc., so
     * checking corners first is enough -- no separate exclusion needed). */
    if(on_top && on_left) return WM_RESIZE_TOP_LEFT;
    if(on_top && on_right) return WM_RESIZE_TOP_RIGHT;
    if(on_bottom && on_left) return WM_RESIZE_BOTTOM_LEFT;
    if(on_bottom && on_right) return WM_RESIZE_BOTTOM_RIGHT;
    if(on_left) return WM_RESIZE_LEFT;
    if(on_right) return WM_RESIZE_RIGHT;
    if(on_top) return WM_RESIZE_TOP;
    if(on_bottom) return WM_RESIZE_BOTTOM;

    return WM_RESIZE_NONE;
}

window_t *wm_window_at_resize_edge(int x, int y, wm_resize_edge_t *out_edge) {
    for(int i = window_count - 1; i >= 0; i--) {
        window_t *win = &windows[window_order[i]];
        if(!win->in_use || !win->visible) continue;
        wm_resize_edge_t edge = wm_resize_edge_at(win, x, y);
        if(edge != WM_RESIZE_NONE) {
            *out_edge = edge;
            return win;
        }
    }
    *out_edge = WM_RESIZE_NONE;
    return NULL;
}

void wm_resize_window(window_t *win, int x, int y, int w, int h) {
    if(!win) return;
    if(w < WM_MIN_WIDTH) w = WM_MIN_WIDTH;
    if(h < WM_MIN_HEIGHT) h = WM_MIN_HEIGHT;
    win->x = x;
    win->y = y;
    win->w = w;
    win->h = h;
}

/* Titlebar button geometry, Windows-style left-to-right order: minimize,
 * maximize/restore, close -- all the same size, right-aligned, packed
 * tightly against each other. `index` 0 = close (rightmost), 1 =
 * maximize (middle), 2 = minimize (leftmost of the three). */
static void titlebar_button_rect(window_t *win, int index_from_right, int *out_x, int *out_y, int *out_size) {
    int box_size = WM_TITLEBAR_HEIGHT - 6;
    *out_size = box_size;
    *out_x = win->x + win->w - (box_size + 4) * (index_from_right + 1);
    *out_y = win->y + 3;
}

int wm_point_in_close_box(window_t *win, int x, int y) {
    if(!win) return 0;
    int bx, by, bsize;
    titlebar_button_rect(win, 0, &bx, &by, &bsize);
    return x >= bx && x < bx + bsize && y >= by && y < by + bsize;
}

int wm_point_in_maximize_box(window_t *win, int x, int y) {
    if(!win) return 0;
    int bx, by, bsize;
    titlebar_button_rect(win, 1, &bx, &by, &bsize);
    return x >= bx && x < bx + bsize && y >= by && y < by + bsize;
}

int wm_point_in_minimize_box(window_t *win, int x, int y) {
    if(!win) return 0;
    int bx, by, bsize;
    titlebar_button_rect(win, 2, &bx, &by, &bsize);
    return x >= bx && x < bx + bsize && y >= by && y < by + bsize;
}

void wm_minimize_window(window_t *win) {
    if(!win || win->minimized) return;
    win->minimized = 1;
    win->visible = 0;
}

void wm_restore_window(window_t *win) {
    if(!win || !win->minimized) return;
    win->minimized = 0;
    win->visible = 1;
    wm_focus(win);
}

void wm_toggle_maximize(window_t *win) {
    if(win) win->anim_active = 0;
    if(!win) return;

    if(win->maximized) {
        win->x = win->restore_x;
        win->y = win->restore_y;
        win->w = win->restore_w;
        win->h = win->restore_h;
        win->maximized = 0;
    }
    else {
        win->restore_x = win->x;
        win->restore_y = win->y;
        win->restore_w = win->w;
        win->restore_h = win->h;

        int wx, wy, ww, wh;
        taskbar_work_area(&wx, &wy, &ww, &wh);
        win->x = wx;
        win->y = wy;
        win->w = ww;
        win->h = wh;
        win->maximized = 1;
    }
}

/* After the taskbar moved: maximized windows follow the new work area. */
void wm_refit_maximized(void) {
    int wx, wy, ww, wh;
    taskbar_work_area(&wx, &wy, &ww, &wh);
    int n = wm_window_count();
    for(int i = 0; i < n; i++) {
        window_t *w = wm_window_at_index(i);
        if(w && w->in_use && w->maximized) { w->x = wx; w->y = wy; w->w = ww; w->h = wh; }
    }
}

void wm_get_client_rect(window_t *win, int *out_x, int *out_y, int *out_w, int *out_h) {
    if(!win) {
        *out_x = *out_y = *out_w = *out_h = 0;
        return;
    }
    *out_x = win->x + WM_BORDER;
    *out_y = win->y + WM_TITLEBAR_HEIGHT;
    *out_w = win->w - WM_BORDER * 2;
    *out_h = win->h - WM_TITLEBAR_HEIGHT - WM_BORDER;
}

int wm_anim_step(void) {
    int any = 0;
    uint32_t now = pit_get_ms();
    for(int i = 0; i < WM_MAX_WINDOWS; i++) {
        window_t *w = &windows[i];
        if(!w->in_use || !w->anim_active) continue;
        uint32_t el = now - w->anim_t0;
        if(el >= 160) { w->y = w->anim_target_y; w->anim_active = 0; continue; }
        int t = (int)(el * 1000 / 160);                 /* 0..1000 */
        int inv = 1000 - t;
        int ease = 1000 - (int)(((uint32_t)inv * (uint32_t)inv * (uint32_t)inv) / 1000000u);   /* ease-out cubic */
        w->y = w->anim_target_y + 26 - (26 * ease) / 1000;
        any = 1;
    }
    return any;
}

void wm_move_window(window_t *win, int x, int y) {
    if(win && win->anim_active) { win->anim_active = 0; }      /* the user grabbed it: stop animating */
    if(!win || win->maximized) return; /* maximized windows aren't draggable, matching Windows */

    int screen_w = (int)gfx_width();
    int screen_h = (int)gfx_height();

    /* Keep at least a sliver of the titlebar on-screen so a window can
     * never become undraggable by being dragged fully off the desktop. */
    int min_visible = 20;
    if(x < min_visible - win->w) x = min_visible - win->w;
    if(x > screen_w - min_visible) x = screen_w - min_visible;
    if(y < 0) y = 0;
    if(y > screen_h - min_visible) y = screen_h - min_visible;

    win->x = x;
    win->y = y;
}

#define WM_CORNER_RADIUS 8
#define WM_CORNER_BOX_MAX 16

/* Titlebar glyphs are drawn from primitives (not ASCII characters) so
 * they are centred exactly and scale with the button. */
static void draw_hline_a(int x, int y, int w, uint32_t argb) {
    gfx_blend_rounded_rect_ex(x, y, w, 1, 0, argb, 0);
}
static void draw_vline_a(int x, int y, int h, uint32_t argb) {
    gfx_blend_rounded_rect_ex(x, y, 1, h, 0, argb, 0);
}
static void draw_box_outline(int x, int y, int w, int h, uint32_t argb) {
    draw_hline_a(x, y, w, argb);
    draw_hline_a(x, y + h - 1, w, argb);
    draw_vline_a(x, y + 1, h - 2, argb);
    draw_vline_a(x + w - 1, y + 1, h - 2, argb);
}

static void draw_titlebar_button(window_t *win, int index_from_right, int hovered) {
    int bx, by, bsize;
    titlebar_button_rect(win, index_from_right, &bx, &by, &bsize);
    int cx = bx + bsize / 2, cy = by + bsize / 2;

    uint32_t glyph = win->focused ? COLOR_BTN_GLYPH : COLOR_BTN_GLYPH_DIM;
    if(hovered) {
        if(index_from_right == 0) {
            gfx_blend_rounded_rect_ex(bx, by, bsize, bsize, 4, COLOR_BTN_CLOSE_HOVER, GFX_CORNER_ALL);
            glyph = 0xFFFFFFFF;
        }
        else {
            gfx_blend_rounded_rect_ex(bx, by, bsize, bsize, 4, COLOR_BTN_HOVER, GFX_CORNER_ALL);
            glyph = 0xFFFFFFFF;
        }
    }

    if(index_from_right == 0) {                 /* close: an X */
        gfx_draw_line_thick(cx - 4.0, cy - 4.0, cx + 4.0, cy + 4.0, 1.3, glyph);
        gfx_draw_line_thick(cx - 4.0, cy + 4.0, cx + 4.0, cy - 4.0, 1.3, glyph);
    }
    else if(index_from_right == 1) {            /* maximize / restore */
        if(win->maximized) {
            draw_box_outline(cx - 4, cy - 2, 7, 7, glyph);           /* front */
            draw_hline_a(cx - 2, cy - 4, 7, glyph);                  /* back, partly hidden */
            draw_hline_a(cx - 2, cy - 4, 1, glyph);
            draw_vline_a(cx - 2, cy - 4, 2, glyph);
            draw_vline_a(cx + 4, cy - 4, 6, glyph);
            draw_hline_a(cx + 3, cy + 1, 2, glyph);
        }
        else {
            draw_box_outline(cx - 4, cy - 4, 9, 9, glyph);
        }
    }
    else {                                      /* minimize: a bar */
        draw_hline_a(cx - 4, cy + 1, 9, glyph);
    }
}

static int point_in_button(window_t *win, int index_from_right, int px, int py) {
    int bx, by, bsize;
    titlebar_button_rect(win, index_from_right, &bx, &by, &bsize);
    return px >= bx && px < bx + bsize && py >= by && py < by + bsize;
}

static void draw_window(window_t *win) {
    if(!win->in_use || !win->visible) return;

    int focused = win->focused;
    int maximized = win->maximized;
    int r = maximized ? 0 : WM_CORNER_RADIUS;

    /* 1. Soft shadow first, so everything below is drawn over it. A
     *    focused window floats a little higher (bigger, darker). */
    if(!maximized) {
        if(focused) gfx_draw_shadow(win->x, win->y, win->w, win->h, r, 22, 7, 96);
        else        gfx_draw_shadow(win->x, win->y, win->w, win->h, r, 14, 4, 58);
    }

    /* 2. Frame silhouette, then the titlebar (rounded on top only, with a
     *    faint vertical gradient so it reads as a surface, not a flat
     *    slab), then a 1px outline following the rounded edge. */
    gfx_blend_rounded_rect_ex(win->x, win->y, win->w, win->h, r,
                              focused ? COLOR_FRAME_FOCUSED : COLOR_FRAME_UNFOCUSED, GFX_CORNER_ALL);
    gfx_fill_rounded_gradient(win->x, win->y, win->w, WM_TITLEBAR_HEIGHT, r,
                              focused ? COLOR_TITLE_TOP_FOCUSED : COLOR_TITLE_TOP_UNFOC,
                              focused ? COLOR_TITLE_BOT_FOCUSED : COLOR_TITLE_BOT_UNFOC,
                              GFX_CORNER_TOP);
    if(maximized) {
        draw_hline_a(win->x, win->y + WM_TITLEBAR_HEIGHT - 1, win->w, COLOR_TITLE_SEPARATOR);
    }
    else {
        draw_hline_a(win->x + WM_BORDER, win->y + WM_TITLEBAR_HEIGHT - 1, win->w - WM_BORDER * 2, COLOR_TITLE_SEPARATOR);
        gfx_draw_rounded_outline(win->x, win->y, win->w, win->h, r,
                                 focused ? COLOR_OUTLINE_FOCUSED : COLOR_OUTLINE_UNFOCUSED);
    }

    /* 3. Title text, clipped with "..." so it can never run under the
     *    buttons. */
    int text_x = win->x + WM_BORDER + 10;
    int avail = win->w - WM_BORDER - 10 - (22 * 3 + 6);
    int max_chars = avail / GFX_CHAR_COLS;
    char title[64];
    int len = 0;
    while(win->title[len] && len < 63) { title[len] = win->title[len]; len++; }
    title[len] = '\0';
    if(max_chars < 3) max_chars = 3;
    if(len > max_chars) {
        title[max_chars - 3] = '.'; title[max_chars - 2] = '.'; title[max_chars - 1] = '.'; title[max_chars] = '\0';
    }
    gfx_draw_string(text_x, win->y + (WM_TITLEBAR_HEIGHT - GFX_CHAR_ROWS) / 2, title,
                    focused ? COLOR_TITLE_TEXT_FOCUSED : COLOR_TITLE_TEXT_UNFOCUSED);

    /* 4. Titlebar buttons with hover feedback. Only the topmost window
     *    under the cursor reacts, so a button hidden behind another
     *    window never lights up. */
    mouse_state_t *m = mouse_get_state();
    int over_this = (wm_window_at(m->x, m->y) == win);
    draw_titlebar_button(win, 2, over_this && point_in_button(win, 2, m->x, m->y));
    draw_titlebar_button(win, 1, over_this && point_in_button(win, 1, m->x, m->y));
    draw_titlebar_button(win, 0, over_this && point_in_button(win, 0, m->x, m->y));

    /* 5. Client area. Its bottom corners are rounded concentrically with
     *    the frame. Apps fill their client rectangle with plain squares
     *    from on_paint, which would poke out of those rounded corners, so
     *    the two tiny corner boxes are saved first and put back after the
     *    app has painted. */
    int client_x = win->x + WM_BORDER;
    int client_y = win->y + WM_TITLEBAR_HEIGHT;
    int client_w = win->w - WM_BORDER * 2;
    int client_h = win->h - WM_TITLEBAR_HEIGHT - WM_BORDER;
    if(client_w <= 0 || client_h <= 0) return;

    int cr = maximized ? 0 : (r > WM_BORDER ? r - WM_BORDER : 0);
    if(cr > WM_CORNER_BOX_MAX) cr = WM_CORNER_BOX_MAX;
    gfx_blend_rounded_rect_ex(client_x, client_y, client_w, client_h, cr,
                              win->bg_color | 0xFF000000, GFX_CORNER_BOTTOM);

    static uint32_t snap[2][WM_CORNER_BOX_MAX * WM_CORNER_BOX_MAX];
    gfx_surface_t *bb = gfx_backbuffer();
    int box_x[2] = { client_x, client_x + client_w - cr };
    int box_y = client_y + client_h - cr;
    if(cr > 0) {
        for(int side = 0; side < 2; side++) {
            for(int j = 0; j < cr; j++) {
                for(int i = 0; i < cr; i++) {
                    int sx = box_x[side] + i, sy = box_y + j;
                    snap[side][j * cr + i] =
                        (sx >= 0 && sy >= 0 && sx < (int)bb->width && sy < (int)bb->height)
                            ? bb->pixels[sy * bb->width + sx] : 0;
                }
            }
        }
    }

    if(win->on_paint) {
        win->on_paint(win, client_x, client_y, client_w, client_h);
    }

    if(cr > 0) {
        for(int side = 0; side < 2; side++) {
            for(int j = 0; j < cr; j++) {
                for(int i = 0; i < cr; i++) {
                    int sx = box_x[side] + i, sy = box_y + j;
                    if(sx < 0 || sy < 0 || sx >= (int)bb->width || sy >= (int)bb->height) continue;
                    int px = (box_x[side] - client_x) + i;
                    int py = (box_y - client_y) + j;
                    if(gfx_rounded_coverage(px, py, client_w, client_h, cr) < 255) {
                        bb->pixels[sy * bb->width + sx] = snap[side][j * cr + i];
                    }
                }
            }
        }
    }
}

void wm_draw_all() {
    for(int i = 0; i < window_count; i++) {
        draw_window(&windows[window_order[i]]);
    }
}

void wm_tick_all() {
    for(int i = 0; i < window_count; i++) {
        window_t *win = &windows[window_order[i]];
        if(win->in_use && win->on_tick) {
            win->on_tick(win);
        }
    }
}

window_t *wm_find_window_by_paint(void (*on_paint)(struct window *, int, int, int, int)) {
    for(int i = 0; i < WM_MAX_WINDOWS; i++) {
        if(windows[i].in_use && windows[i].on_paint == on_paint) return &windows[i];
    }
    return NULL;
}

int wm_all_static(void) {
    for(int i = 0; i < WM_MAX_WINDOWS; i++) {
        if(windows[i].in_use && windows[i].visible && !windows[i].minimized && !windows[i].static_content) return 0;
    }
    return 1;
}

int wm_window_count() {
    return window_count;
}

window_t *wm_window_at_index(int index) {
    if(index < 0 || index >= window_count) return NULL;
    return &windows[window_order[index]];
}
