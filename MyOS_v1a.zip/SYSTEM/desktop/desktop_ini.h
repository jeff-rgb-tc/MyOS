#ifndef DESKTOP_INI_H
#define DESKTOP_INI_H

#include "apps.h"

#define DESKTOP_ICON_ENTRIES_MAX 32

/* What a desktop icon actually does when double-clicked -- desktop
 * icons are NOT the same list as the Start menu's app list (see
 * desktop.c's desktop_icons[]/DEFAULT_DESKTOP_ICON_COUNT): only some
 * apps show up on the desktop by default (Command Prompt), and two
 * icons (My PC, Recycle Bin) aren't apps at all -- they open specific
 * Explorer views the same way clicking those entries in Explorer's own
 * Favorites sidebar does (see app_explorer.c's SIDEBAR_ITEM_MY_PC/
 * SIDEBAR_ITEM_RECYCLE_BIN and explorer_go_to_recycle_bin()). */
typedef enum {
    ICON_KIND_APP = 0,
    ICON_KIND_MYPC,
    ICON_KIND_RECYCLE_BIN,
    ICON_KIND_ITEM,       /* a file, folder or shortcut living in /Users/User/Desktop (not stored in desktop.ini) */
} desktop_icon_kind_t;

/* One entry as stored in desktop.ini: what it represents (an app, by
 * name matched against the apps.c registry, for ICON_KIND_APP -- unused
 * for the two special kinds) and where its icon sits on the desktop.
 * Position is the only thing desktop.ini actually needs to remember for
 * an app icon -- everything else about an app (its icon image, launch
 * behavior) still lives in apps.c's registry; for the special kinds,
 * desktop.ini only needs to remember that this icon exists at all (a
 * user could delete it) plus its position. */
typedef struct {
    desktop_icon_kind_t kind;
    char app_name[32]; /* matches app_entry_t::name from apps.c -- only meaningful when kind == ICON_KIND_APP */
    int x, y;
} desktop_icon_entry_t;

/* Loads SYSTEM/res/../Users/User/Desktop/desktop.ini (see
 * DESKTOP_INI_PATH in the .c file) and returns the icon positions it
 * describes. If the file doesn't exist yet (fresh disk image) or fails
 * to parse, returns 0 entries and desktop.c falls back to a default
 * grid layout -- this is a cache of user-arranged positions, not a
 * required boot dependency. */
int desktop_ini_load(desktop_icon_entry_t *out_entries, int max_entries);

/* Writes the given icon positions back to desktop.ini, overwriting
 * whatever was there before. Called whenever the user finishes dragging
 * an icon to a new position, so layout changes persist across reboots
 * (within the current session -- the ISO itself is read-only, so this
 * only actually persists if MyOS is running against a writable backing
 * store, matching how the rest of the filesystem's write support works). */
void desktop_ini_save(const desktop_icon_entry_t *entries, int count);

#endif
