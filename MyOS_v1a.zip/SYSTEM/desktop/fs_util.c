#include "stdint.h"
#include "stddef.h"
#include "fs_util.h"
#include "common.h"
#include "kheap.h"
#include "fat32.h"

static int is_sep(char c) { return c == '/' || c == '\\'; }

void fsu_normalize(const char *cwd, const char *arg, char *out, int out_max) {
    char tmp[FSU_PATH_MAX * 2];
    int tp = 0;

    /* Skip a leading drive spec like "C:" */
    if(arg[0] && arg[1] == ':') arg += 2;

    if(is_sep(arg[0]) || !cwd) {
        /* absolute */
    }
    else {
        for(const char *p = cwd; *p && tp < (int)sizeof(tmp) - 2; p++) tmp[tp++] = *p;
        tmp[tp++] = '/';
    }
    for(const char *p = arg; *p && tp < (int)sizeof(tmp) - 2; p++) tmp[tp++] = *p;
    tmp[tp] = '\0';

    /* Split into components, resolving . and .. */
    static char comps[24][40];
    int nc = 0;
    int i = 0;
    while(tmp[i]) {
        while(tmp[i] && is_sep(tmp[i])) i++;
        if(!tmp[i]) break;
        char name[40]; int n = 0;
        while(tmp[i] && !is_sep(tmp[i])) { if(n < 39) name[n++] = tmp[i]; i++; }
        name[n] = '\0';
        if(strcmp(name, ".") == 0) continue;
        if(strcmp(name, "..") == 0) { if(nc > 0) nc--; continue; }
        if(nc < 24) { for(int k = 0; k <= n; k++) comps[nc][k] = name[k]; nc++; }
    }

    int op = 0;
    if(nc == 0) { out[op++] = '/'; }
    for(int c = 0; c < nc; c++) {
        if(op < out_max - 1) out[op++] = '/';
        for(int k = 0; comps[c][k] && op < out_max - 1; k++) out[op++] = comps[c][k];
    }
    out[op] = '\0';
}

void fsu_split(const char *path, char *parent_out, int parent_max, char *name_out, int name_max) {
    int len = (int)strlen(path);
    int last = -1;
    for(int i = 0; i < len; i++) if(path[i] == '/') last = i;

    if(len <= 1) { parent_out[0] = '/'; parent_out[1] = '\0'; name_out[0] = '\0'; return; }

    int pn = last <= 0 ? 1 : last;
    if(pn > parent_max - 1) pn = parent_max - 1;
    if(last <= 0) { parent_out[0] = '/'; parent_out[1] = '\0'; }
    else { for(int i = 0; i < pn; i++) parent_out[i] = path[i]; parent_out[pn] = '\0'; }

    int nn = 0;
    for(int i = last + 1; i < len && nn < name_max - 1; i++) name_out[nn++] = path[i];
    name_out[nn] = '\0';
}

int fsu_find(const struct directory *d, const char *name) {
    for(uint32_t i = 0; i < d->num_entries; i++) {
        if(!d->entries[i].name) continue;
        if((d->entries[i].dir_attrs & LFN) == LFN) continue;     /* (a plain & LFN skipped every read-only / hidden / system file) */
        if(strcasecmp(d->entries[i].name, name) == 0) return (int)i;
    }
    return -1;
}

int fsu_open_dir(const char *path, struct directory *out) {
    if(!master_fs) return 0;
    populate_root_dir(master_fs, out);

    int i = 0;
    while(path[i]) {
        while(path[i] == '/') i++;
        if(!path[i]) break;
        char name[40]; int n = 0;
        while(path[i] && path[i] != '/') { if(n < 39) name[n++] = path[i]; i++; }
        name[n] = '\0';

        int idx = fsu_find(out, name);
        if(idx < 0 || !(out->entries[idx].dir_attrs & DIRECTORY)) {
            free_directory(master_fs, out);
            return 0;
        }
        uint32_t cluster = out->entries[idx].first_cluster;
        free_directory(master_fs, out);
        populate_dir(master_fs, out, cluster ? cluster : 2);
    }
    return 1;
}

int fsu_stat(const char *path, int *is_dir, uint32_t *size, uint16_t *wr_date, uint16_t *wr_time) {
    if(strcmp(path, "/") == 0) {
        if(is_dir) *is_dir = 1;
        if(size) *size = 0;
        if(wr_date) *wr_date = 0;
        if(wr_time) *wr_time = 0;
        return 1;
    }
    char parent[FSU_PATH_MAX], name[48];
    fsu_split(path, parent, sizeof(parent), name, sizeof(name));
    struct directory d;
    if(!fsu_open_dir(parent, &d)) return 0;
    int idx = fsu_find(&d, name);
    if(idx < 0) { free_directory(master_fs, &d); return 0; }
    if(is_dir) *is_dir = (d.entries[idx].dir_attrs & DIRECTORY) ? 1 : 0;
    if(size) *size = d.entries[idx].file_size;
    if(wr_date) *wr_date = d.entries[idx].wr_date;
    if(wr_time) *wr_time = d.entries[idx].wr_time;
    free_directory(master_fs, &d);
    return 1;
}

int fsu_mkdir(const char *path) {
    char parent[FSU_PATH_MAX], name[48];
    fsu_split(path, parent, sizeof(parent), name, sizeof(name));
    if(!name[0]) return 0;
    struct directory d;
    if(!fsu_open_dir(parent, &d)) return 0;
    if(fsu_find(&d, name) >= 0) { free_directory(master_fs, &d); return 0; }
    mkdir(master_fs, &d, name);
    free_directory(master_fs, &d);
    return 1;
}

int fsu_delete_file(const char *path) {
    char parent[FSU_PATH_MAX], name[48];
    fsu_split(path, parent, sizeof(parent), name, sizeof(name));
    if(!name[0]) return 0;
    struct directory d;
    if(!fsu_open_dir(parent, &d)) return 0;
    int idx = fsu_find(&d, name);
    if(idx < 0 || (d.entries[idx].dir_attrs & DIRECTORY)) { free_directory(master_fs, &d); return 0; }
    /* delFile() matches by the entry's own stored name. */
    char exact[64];
    int k = 0; while(d.entries[idx].name[k] && k < 63) { exact[k] = d.entries[idx].name[k]; k++; }
    exact[k] = '\0';
    delFile(master_fs, &d, exact);
    free_directory(master_fs, &d);
    return 1;
}

int fsu_dir_is_empty(const char *path) {
    struct directory d;
    if(!fsu_open_dir(path, &d)) return 0;
    int empty = 1;
    for(uint32_t i = 0; i < d.num_entries; i++) {
        if(!d.entries[i].name || (d.entries[i].dir_attrs & LFN)) continue;
        if(strcmp(d.entries[i].name, ".") == 0 || strcmp(d.entries[i].name, "..") == 0) continue;
        empty = 0; break;
    }
    free_directory(master_fs, &d);
    return empty;
}

static void join_path(const char *dir, const char *name, char *out, int max) {
    int p = 0;
    for(const char *c = dir; *c && p < max - 2; c++) out[p++] = *c;
    if(p == 0 || out[p - 1] != '/') out[p++] = '/';
    for(const char *c = name; *c && p < max - 1; c++) out[p++] = *c;
    out[p] = '\0';
}

int fsu_remove_dir(const char *path, int recursive) {
    if(strcmp(path, "/") == 0) return 0;

    if(recursive) {
        struct directory d;
        if(!fsu_open_dir(path, &d)) return 0;
        /* Collect names first (the directory listing is invalidated by deletes). */
        uint32_t n = d.num_entries;
        char (*names)[48] = (char (*)[48])kmalloc(n ? n * 48 : 48);
        uint8_t *isdir = (uint8_t *)kmalloc(n ? n : 1);
        uint32_t cnt = 0;
        for(uint32_t i = 0; i < n; i++) {
            if(!d.entries[i].name || (d.entries[i].dir_attrs & LFN)) continue;
            if(strcmp(d.entries[i].name, ".") == 0 || strcmp(d.entries[i].name, "..") == 0) continue;
            int k = 0; while(d.entries[i].name[k] && k < 47) { names[cnt][k] = d.entries[i].name[k]; k++; }
            names[cnt][k] = '\0';
            isdir[cnt] = (d.entries[i].dir_attrs & DIRECTORY) ? 1 : 0;
            cnt++;
        }
        free_directory(master_fs, &d);
        for(uint32_t i = 0; i < cnt; i++) {
            char child[FSU_PATH_MAX];
            join_path(path, names[i], child, sizeof(child));
            if(isdir[i]) fsu_remove_dir(child, 1);
            else fsu_delete_file(child);
        }
        kfree(names); kfree(isdir);
    }
    else if(!fsu_dir_is_empty(path)) {
        return 0;
    }

    char parent[FSU_PATH_MAX], name[48];
    fsu_split(path, parent, sizeof(parent), name, sizeof(name));
    struct directory pd;
    if(!fsu_open_dir(parent, &pd)) return 0;
    int idx = fsu_find(&pd, name);
    if(idx < 0 || !(pd.entries[idx].dir_attrs & DIRECTORY)) { free_directory(master_fs, &pd); return 0; }
    char exact[64];
    int k = 0; while(pd.entries[idx].name[k] && k < 63) { exact[k] = pd.entries[idx].name[k]; k++; }
    exact[k] = '\0';
    delFile(master_fs, &pd, exact);
    free_directory(master_fs, &pd);
    return 1;
}

uint8_t *fsu_read_file(const char *path, uint32_t *size) {
    char parent[FSU_PATH_MAX], name[48];
    fsu_split(path, parent, sizeof(parent), name, sizeof(name));
    struct directory d;
    if(!fsu_open_dir(parent, &d)) return NULL;
    int idx = fsu_find(&d, name);
    if(idx < 0 || (d.entries[idx].dir_attrs & DIRECTORY)) { free_directory(master_fs, &d); return NULL; }
    uint32_t sz = d.entries[idx].file_size;
    uint8_t *data;
    if(sz == 0) data = (uint8_t *)kmalloc(1);
    else data = readFile(master_fs, &d.entries[idx]);
    free_directory(master_fs, &d);
    if(size) *size = sz;
    return data;
}

int fsu_write_file(const char *path, const uint8_t *data, uint32_t len) {
    char parent[FSU_PATH_MAX], name[48];
    fsu_split(path, parent, sizeof(parent), name, sizeof(name));
    if(!name[0]) return 0;
    struct directory d;
    if(!fsu_open_dir(parent, &d)) return 0;
    writeFile(master_fs, &d, (uint8_t *)data, name, len);
    free_directory(master_fs, &d);
    return 1;
}

int fsu_copy_file(const char *src, const char *dst) {
    uint32_t size = 0;
    uint8_t *data = fsu_read_file(src, &size);
    if(!data) return 0;
    int ok = fsu_write_file(dst, data, size);
    kfree(data);
    return ok;
}

int fsu_move_file(const char *src, const char *dst) {
    if(!fsu_copy_file(src, dst)) return 0;
    return fsu_delete_file(src);
}

int fsu_copy_tree(const char *src, const char *dst) {
    int is_dir = 0;
    if(!fsu_stat(src, &is_dir, NULL, NULL, NULL)) return 0;
    if(!is_dir) return fsu_copy_file(src, dst);

    int dummy;
    if(!fsu_stat(dst, &dummy, NULL, NULL, NULL)) {
        if(!fsu_mkdir(dst)) return 0;
    }

    struct directory d;
    if(!fsu_open_dir(src, &d)) return 0;
    uint32_t n = d.num_entries;
    char (*names)[48] = (char (*)[48])kmalloc(n ? n * 48 : 48);
    uint32_t cnt = 0;
    for(uint32_t i = 0; i < n; i++) {
        if(!d.entries[i].name || (d.entries[i].dir_attrs & LFN)) continue;
        if(strcmp(d.entries[i].name, ".") == 0 || strcmp(d.entries[i].name, "..") == 0) continue;
        int k = 0; while(d.entries[i].name[k] && k < 47) { names[cnt][k] = d.entries[i].name[k]; k++; }
        names[cnt][k] = '\0';
        cnt++;
    }
    free_directory(master_fs, &d);

    int ok = 1;
    for(uint32_t i = 0; i < cnt; i++) {
        char s[FSU_PATH_MAX], t[FSU_PATH_MAX];
        join_path(src, names[i], s, sizeof(s));
        join_path(dst, names[i], t, sizeof(t));
        if(!fsu_copy_tree(s, t)) ok = 0;
    }
    kfree(names);
    return ok;
}

const char *fsu_ext(const char *name) {
    const char *dot = NULL;
    for(const char *p = name; *p; p++) if(*p == '.') dot = p;
    return dot ? dot : "";
}

void fsu_format_number(uint32_t value, char *out, int out_max) {
    char digits[16]; int n = 0;
    if(value == 0) digits[n++] = '0';
    while(value > 0 && n < 15) { digits[n++] = (char)('0' + value % 10); value /= 10; }
    int p = 0;
    for(int i = n - 1; i >= 0 && p < out_max - 1; i--) {
        out[p++] = digits[i];
        if(i > 0 && i % 3 == 0 && p < out_max - 1) out[p++] = ',';
    }
    out[p] = '\0';
}

void fsu_format_size(uint32_t bytes, char *out, int out_max) {
    char num[16]; int p = 0;
    const char *unit;
    uint32_t whole, tenth = 0;
    if(bytes < 1024) { whole = bytes; unit = " B"; }
    else if(bytes < 1024u * 1024u) { whole = bytes / 1024; tenth = ((bytes % 1024) * 10) / 1024; unit = " KB"; }
    else if(bytes < 1024u * 1024u * 1024u) { whole = bytes / (1024u * 1024u); tenth = ((bytes % (1024u * 1024u)) * 10) / (1024u * 1024u); unit = " MB"; }
    else { whole = bytes / (1024u * 1024u * 1024u); tenth = ((bytes % (1024u * 1024u * 1024u)) / (1024u * 1024u) * 10) / 1024; unit = " GB"; }
    int n = 0; uint32_t v = whole;
    if(v == 0) num[n++] = '0';
    while(v > 0 && n < 15) { num[n++] = (char)('0' + v % 10); v /= 10; }
    for(int i = n - 1; i >= 0 && p < out_max - 1; i--) out[p++] = num[i];
    if(tenth && bytes >= 1024 && p < out_max - 3) { out[p++] = '.'; out[p++] = (char)('0' + tenth); }
    for(const char *u = unit; *u && p < out_max - 1; u++) out[p++] = *u;
    out[p] = '\0';
}
