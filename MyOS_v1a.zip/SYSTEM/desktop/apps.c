#include "stdint.h"
#include "stddef.h"
#include "apps.h"
#include "png.h"
#include "app_cmd.h"
#include "app_explorer.h"
#include "app_paint.h"
#include "app_settings.h"
#include "app_mediaplayer.h"
#include "app_calculator.h"
#include "app_notepad.h"
#include "app_calendar.h"
#include "app_clock.h"
#include "app_taskmgr.h"
#include "common.h"
#include "kernio.h"
#include "fs_util.h"
#include "kheap.h"
#include "app_loader.h"
#include "desktop.h"

static app_entry_t apps[APPS_MAX];
static int app_count = 0;

static void register_app(const char *name, const char *icon_path, app_launch_fn launch) {
    if(app_count >= APPS_MAX) return;

    app_entry_t *a = &apps[app_count++];
    memset(a, 0, sizeof(app_entry_t));

    int i = 0;
    while(name[i] && i < (int)sizeof(a->name) - 1) { a->name[i] = name[i]; i++; }
    a->name[i] = '\0';

    i = 0;
    while(icon_path[i] && i < (int)sizeof(a->icon_path) - 1) { a->icon_path[i] = icon_path[i]; i++; }
    a->icon_path[i] = '\0';

    a->launch = launch;
    a->icon_load_attempted = 0;
}

static void scan_installed_apps(void);
static void assign_start_folders(void);

void apps_init() {
    app_count = 0;
    register_app("Command Prompt", "/APPS/cmd/cmd.png", launch_cmd);
    register_app("Explorer", "/APPS/explorer/explorer.png", launch_explorer);
    register_app("Paint", "/APPS/paint/paint.png", launch_paint);
    register_app("Media Player", "/APPS/mediaplayer/mediaplayer.png", launch_mediaplayer);
    register_app("Notepad", "/APPS/notepad/notepad.png", launch_notepad);
    register_app("Calculator", "/APPS/calculator/calculator.png", launch_calculator);
    register_app("Calendar", "/APPS/calendar/calendar.png", launch_calendar);
    register_app("Clock", "/APPS/clock/clock.png", launch_clock);
    register_app("Task Manager", "/APPS/taskmgr/taskmgr.png", launch_taskmgr);
    register_app("Settings", "/APPS/settings/settings.png", launch_settings);
    scan_installed_apps();
    assign_start_folders();
}

/* Finds installed programs: every /APPS/<folder>/<name>.app. Its name and
 * (optional) embedded icon come from the .app's own manifest; if there is
 * no embedded icon, a PNG next to it with the same base name is used, and
 * failing that the generic application icon. Built-in apps are registered
 * first, so a .app can never shadow one by name. */
static void scan_installed_apps(void) {
    struct directory root;
    if(!fsu_open_dir("/APPS", &root)) return;

    for(uint32_t i = 0; i < root.num_entries && app_count < APPS_MAX; i++) {
        struct dir_entry *de = &root.entries[i];
        if(!(de->dir_attrs & DIRECTORY) || !de->name || de->name[0] == '.') continue;

        char dirpath[64] = "/APPS/";
        int n = 6;
        for(const char *p = de->name; *p && n < 60; p++) dirpath[n++] = *p;
        dirpath[n] = '\0';

        struct directory sub;
        if(!fsu_open_dir(dirpath, &sub)) continue;
        for(uint32_t j = 0; j < sub.num_entries && app_count < APPS_MAX; j++) {
            struct dir_entry *fe = &sub.entries[j];
            if((fe->dir_attrs & DIRECTORY) || !fe->name) continue;
            const char *ext = fsu_ext(fe->name);
            if(!ext || strcasecmp(ext, ".app") != 0) continue;

            char path[96]; int pn = 0;
            for(const char *p = dirpath; *p && pn < 60; p++) path[pn++] = *p;
            path[pn++] = '/';
            for(const char *p = fe->name; *p && pn < 95; p++) path[pn++] = *p;
            path[pn] = '\0';

            app_manifest_t m;
            uint8_t *icon = NULL; uint32_t icon_len = 0;
            if(!app_loader_read_manifest(path, &m, &icon, &icon_len)) { if(icon) kfree(icon); continue; }

            int dup = 0;
            for(int k = 0; k < app_count; k++) if(strcasecmp(apps[k].name, m.name) == 0) dup = 1;
            if(dup) { if(icon) kfree(icon); continue; }

            /* sibling icon: same base name with .png */
            char icon_path[64]; int ip = 0;
            for(const char *p = dirpath; *p && ip < 40; p++) icon_path[ip++] = *p;
            icon_path[ip++] = '/';
            for(const char *p = fe->name; *p && p < ext && ip < 58; p++) icon_path[ip++] = *p;
            for(const char *p = ".png"; *p; p++) icon_path[ip++] = *p;
            icon_path[ip] = '\0';

            register_app(m.name, icon_path, NULL);
            app_entry_t *a = &apps[app_count - 1];
            for(int q = 0; path[q] && q < (int)sizeof(a->app_path) - 1; q++) a->app_path[q] = path[q];

            if(icon) {
                png_image_t png;
                if(png_load_from_memory(icon, icon_len, &png)) {
                    a->icon.width = png.width; a->icon.height = png.height; a->icon.pixels = png.pixels;
                    a->icon_load_attempted = 1;
                }
                kfree(icon);
            }
        }
        free_directory(master_fs, &sub);
    }
    free_directory(master_fs, &root);
}

/* Start-menu grouping: related built-ins share a folder, programs installed
 * from .app files go to "My Apps". Everything else stays at the top level. */
static void assign_start_folders(void) {
    static const struct { const char *name; const char *folder; } map[] = {
        { "Calculator", "Accessories" }, { "Calendar", "Accessories" }, { "Clock", "Accessories" },
        { "Notepad", "Accessories" }, { "Paint", "Accessories" },
        { "Command Prompt", "System tools" }, { "Task Manager", "System tools" }, { "Settings", "System tools" },
    };
    for(int i = 0; i < app_count; i++) {
        apps[i].folder[0] = '\0';
        const char *folder = NULL;
        if(apps[i].app_path[0]) folder = "My Apps";
        else for(unsigned k = 0; k < sizeof(map) / sizeof(map[0]); k++) if(strcasecmp(apps[i].name, map[k].name) == 0) folder = map[k].folder;
        for(int c = 0; folder && folder[c] && c < (int)sizeof(apps[i].folder) - 1; c++) { apps[i].folder[c] = folder[c]; apps[i].folder[c + 1] = '\0'; }
    }
}

void apps_launch(app_entry_t *app) {
    if(!app) return;
    if(app->app_path[0]) {
        app_loader_run(app->app_path);          /* sets the working cursor itself */
    }
    else if(app->launch) {
        desktop_working_for_ms(1200);
        app->launch();
    }
}

int apps_count() {
    return app_count;
}

app_entry_t *apps_get(int index) {
    if(index < 0 || index >= app_count) return NULL;
    return &apps[index];
}

app_icon_t *apps_get_icon(app_entry_t *app) {
    if(!app) return NULL;

    if(!app->icon_load_attempted) {
        app->icon_load_attempted = 1;

        png_image_t png;
        if(png_load_from_file(app->icon_path, &png)) {
            app->icon.width = png.width;
            app->icon.height = png.height;
            app->icon.pixels = png.pixels; /* ownership transferred, no separate copy needed */
        }
        else if(png_load_from_file("/SYSTEM/res/icons/app_default.png", &png)) {
            /* No icon of its own: the generic application icon. */
            app->icon.width = png.width;
            app->icon.height = png.height;
            app->icon.pixels = png.pixels;
        }
        else {
            printf("apps: failed to load icon %s for '%s'\n", app->icon_path, app->name);
        }
    }

    return app->icon.pixels ? &app->icon : NULL;
}
