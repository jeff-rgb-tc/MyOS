#ifndef DESKTOP_SHORTCUT_H
#define DESKTOP_SHORTCUT_H

#include "stdint.h"
#include "apps.h"

/* Shortcuts (.lnk files).
 *
 * A .lnk is a small INI file:
 *
 *     [shortcut]
 *     target=/Users/User/Documents          ; any file, folder or .app
 *     name=Documents                         ; optional display name
 *
 * or, for a built-in application:
 *
 *     [shortcut]
 *     target=app:Calculator
 *
 * Opening a shortcut opens its target the way double-clicking the target
 * would. They can live anywhere: on the desktop (which is simply the
 * /Users/User/Desktop folder), in any Explorer folder, or in the Start
 * menu's own folders under /Start Menu/Programs. */

#define SC_TARGET_MAX 120

typedef struct {
    char name[48];              /* display name (without ".lnk") */
    char target[SC_TARGET_MAX]; /* "/absolute/path" or "app:Name" */
} shortcut_t;

/* Reads a .lnk file. The display name defaults to the file's own name. */
int shortcut_load(const char *lnk_path, shortcut_t *out);

/* Creates "<display_name>.lnk" (made unique if needed) in `dir_path`.
 * Optionally returns the new file's path. Returns 1 on success. */
int shortcut_create(const char *dir_path, const char *display_name, const char *target,
                    char *out_path, int out_max);

/* Convenience: a shortcut to `target_path` named after it. */
int shortcut_create_for_path(const char *dir_path, const char *target_path, char *out_path, int out_max);

/* Opens whatever the shortcut points to. */
void shortcut_open(const shortcut_t *sc);

/* For "app:Name" targets: the registered app, or NULL. */
app_entry_t *shortcut_target_app(const shortcut_t *sc);

/* Opens any path the way Explorer's double-click does: a folder opens in
 * Explorer, .app runs, .lnk follows its target, text opens in Notepad,
 * audio in Media Player. */
void desktop_open_path(const char *path);

#endif
