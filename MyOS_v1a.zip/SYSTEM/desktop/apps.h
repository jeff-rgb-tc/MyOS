#ifndef DESKTOP_APPS_H
#define DESKTOP_APPS_H

#include "stdint.h"

#define APPS_MAX 32

/* Called when the user launches an app (double-clicks its desktop icon,
 * or picks it from the Start menu). Should open a window via
 * wm_create_window() and set up whatever on_paint/on_key/on_click hooks
 * it needs. */
typedef void (*app_launch_fn)(void);

/* A loaded app icon, format-agnostic (backed by png.c internally since
 * app icons ship as .png files). Same ARGB8888 layout as every other
 * image type in the desktop so it plugs straight into gfx_blit_argb(). */
typedef struct {
    uint16_t width;
    uint16_t height;
    uint32_t *pixels;
} app_icon_t;

typedef struct {
    char name[32];
    char icon_path[64]; /* path to a .png icon on the FAT32 disk */
    app_icon_t icon;     /* loaded lazily on first draw; icon.pixels == NULL until then */
    app_launch_fn launch;           /* built-in apps; NULL for programs run from a .app */
    char folder[40];                // Start-menu folder ("Accessories", "A/B"); empty = top level
    char app_path[96];              /* non-empty: a .app found under /APPS, started via the app loader */
    uint8_t icon_load_attempted;
} app_entry_t;

/* Registers the built-in apps (cmd, explorer, paint) with their icons and
 * launch callbacks. Safe to call once at desktop startup. */
void apps_init();

int apps_count();
app_entry_t *apps_get(int index);

/* Loads an app's icon from disk on first access (subsequent calls are
 * free). Returns NULL if the icon couldn't be loaded (missing/corrupt
 * file) -- callers should draw a placeholder box in that case rather
 * than skipping the icon draw entirely, so desktop icons never just
 * vanish silently. */
app_icon_t *apps_get_icon(app_entry_t *app);

/* Starts an app the right way for its kind (built-in launch function, or
 * the app loader for a .app) and shows the "working in background" cursor
 * as launch feedback. */
void apps_launch(app_entry_t *app);

#endif
