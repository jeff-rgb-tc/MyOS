#ifndef APP_CALENDAR_H
#define APP_CALENDAR_H

/* Calendar: month grid (weeks start on Monday) with today highlighted,
 * click or arrow-key date selection, month navigation and ISO week / day-
 * of-year info. Opened from the Start menu or by clicking the taskbar
 * clock; only one window exists at a time.
 * Keys: arrows move the selection (left/right = day, up/down = week),
 * PgUp/PgDn = previous/next month, Home or T = jump to today. */
void launch_calendar(void);

#endif
