#ifndef APP_CALCULATOR_H
#define APP_CALCULATOR_H

/* Standard-mode calculator in the style of the Windows 11 Calculator:
 * big right-aligned result, expression line, % CE C <- / 1/x x^2 sqrt /
 * 7 8 9 x / 4 5 6 - / 1 2 3 + / +/- 0 . =  Works with mouse and keyboard
 * (digits, + - * /, Enter/=, Backspace, Esc = C, Delete = CE, % , R = 1/x,
 * N = negate). */
void launch_calculator(void);

#endif
