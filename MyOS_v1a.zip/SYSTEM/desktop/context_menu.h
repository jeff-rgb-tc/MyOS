#ifndef CONTEXT_MENU_H
#define CONTEXT_MENU_H

#include "stdint.h"

#define CONTEXT_MENU_MAX_ITEMS 20

/* Called when the user clicks a context menu item. `user_data` is
 * whatever was passed to context_menu_open() for that item, letting a
 * caller-specific context (e.g. which desktop icon was right-clicked)
 * flow through without global state. */
typedef void (*context_menu_action_fn)(void *user_data);

/* One menu row. The first three fields keep the original positional
 * layout ({ "Label", action, enabled }) so older call sites still compile
 * unchanged; everything after is optional (zero = off). */
typedef struct context_menu_item {
    char label[32];
    context_menu_action_fn action;
    uint8_t enabled;     /* disabled items are shown grayed-out and don't respond to clicks */
    uint8_t separator;   /* 1 = draw a thin divider line instead of a row (label/action ignored) */
    uint8_t checked;     /* 1 = draw a check mark in the left gutter */
    char hint[12];       /* right-aligned shortcut text such as "Ctrl+C" or "Del" */
    /* Optional one-level submenu (e.g. "New >" -> Folder / Text Document).
     * The array must stay valid while the menu is open -- use a static. */
    const struct context_menu_item *submenu;
    int submenu_count;
} context_menu_item_t;

/* Convenience initializers for building static item tables. */
#define CM_ITEM(lbl, fn, hnt)   { lbl, fn, 1, 0, 0, hnt, 0, 0 }
#define CM_ITEM_OFF(lbl, hnt)   { lbl, 0, 0, 0, 0, hnt, 0, 0 }
#define CM_SEP()                { "", 0, 0, 1, 0, "", 0, 0 }
#define CM_SUB(lbl, arr, cnt)   { lbl, 0, 1, 0, 0, "", arr, cnt }

/* Opens a context menu at the given screen position with the given
 * items, replacing any menu that might already be open. `user_data` is
 * passed through to whichever item's action gets clicked. The menu
 * closes itself automatically once an item is clicked or the user
 * clicks anywhere outside it. */
void context_menu_open(int x, int y, const context_menu_item_t *items, int item_count, void *user_data);

void context_menu_close();

/* Row index of the item whose action is being invoked (inside the action
 * callback only). Lets one action serve a whole list of similar rows. */
int context_menu_clicked_index(void);

int context_menu_is_open();

/* Draws the menu (if open) on top of everything else -- call this last,
 * after the desktop/windows/taskbar, so it's never occluded. */
void context_menu_draw();

/* Handles a left-click at (x, y). Returns 1 if the click was consumed
 * (either it hit a menu item, or it was outside the menu and closed it),
 * 0 if there was no menu open at all so the caller should handle the
 * click normally. */
int context_menu_handle_click(int x, int y);

/* Small helpers so callers can fill the char-array fields without
 * hand-copying bytes. */
void context_menu_set_label(context_menu_item_t *it, const char *label);
void context_menu_set_hint(context_menu_item_t *it, const char *hint);

#endif
