#include "clipboard.h"

static char text_buf[CLIPBOARD_TEXT_MAX];
static char file_path[CLIPBOARD_PATH_MAX];
static int file_present = 0;
static int file_cut = 0;

static void copy_str(char *dst, const char *src, int max) {
    int i = 0;
    while(src && src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

void clipboard_set_text(const char *text) { copy_str(text_buf, text, CLIPBOARD_TEXT_MAX); }
const char *clipboard_get_text(void) { return text_buf; }

void clipboard_set_file(const char *path, int cut) {
    copy_str(file_path, path, CLIPBOARD_PATH_MAX);
    file_present = 1;
    file_cut = cut ? 1 : 0;
}
int clipboard_has_file(void) { return file_present; }
const char *clipboard_file_path(void) { return file_path; }
int clipboard_file_is_cut(void) { return file_cut; }
void clipboard_clear_file(void) { file_present = 0; file_cut = 0; file_path[0] = '\0'; }
