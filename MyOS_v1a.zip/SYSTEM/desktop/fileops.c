#include "stdint.h"
#include "stddef.h"
#include "fileops.h"
#include "clipboard.h"
#include "common.h"
#include "desktop.h"

static int str_eq_nocase(const char *a, const char *b) { return strcasecmp(a, b) == 0; }

void fileops_join(const char *dir, const char *name, char *out, int max) {
    int p = 0;
    for(const char *c = dir; *c && p < max - 1; c++) out[p++] = *c;
    if(p == 0 || out[p - 1] != '/') { if(p < max - 1) out[p++] = '/'; }
    for(const char *c = name; *c && p < max - 1; c++) out[p++] = *c;
    out[p] = '\0';
}

void fileops_unique_name(const char *dir, const char *name, char *out, int max) {
    const char *dot = NULL;
    for(const char *c = name; *c; c++) if(*c == '.' && c != name) dot = c;
    int base_len = dot ? (int)(dot - name) : (int)strlen(name);
    if(base_len > 36) base_len = 36;

    for(int n = 1; n < 100; n++) {
        char cand[64]; int p = 0;
        for(int i = 0; i < base_len; i++) cand[p++] = name[i];
        if(n > 1) {
            cand[p++] = ' '; cand[p++] = '(';
            if(n >= 10) cand[p++] = (char)('0' + n / 10);
            cand[p++] = (char)('0' + n % 10); cand[p++] = ')';
        }
        if(dot) for(const char *c = dot; *c && p < 62; c++) cand[p++] = *c;
        cand[p] = '\0';

        char full[FSU_PATH_MAX];
        fileops_join(dir, cand, full, sizeof(full));
        if(!fsu_stat(full, NULL, NULL, NULL, NULL)) {
            int q = 0;
            while(cand[q] && q < max - 1) { out[q] = cand[q]; q++; }
            out[q] = '\0';
            return;
        }
    }
    int q = 0;
    while(name[q] && q < max - 1) { out[q] = name[q]; q++; }
    out[q] = '\0';
}

int fileops_is_inside(const char *path, const char *dir) {
    int n = (int)strlen(dir);
    while(n > 1 && dir[n - 1] == '/') n--;
    for(int i = 0; i < n; i++) {
        char a = path[i], b = dir[i];
        if(a >= 'A' && a <= 'Z') a = (char)(a + 32);
        if(b >= 'A' && b <= 'Z') b = (char)(b + 32);
        if(a != b) return 0;
    }
    return path[n] == '\0' || path[n] == '/' || n == 1;
}

int fileops_parent_is(const char *path, const char *dir) {
    char parent[FSU_PATH_MAX], name[48];
    fsu_split(path, parent, sizeof(parent), name, sizeof(name));
    return str_eq_nocase(parent, dir);
}

int fileops_move_into(const char *src, const char *dest_dir, char *out_new_path, int out_max) {
    int is_dir = 0;
    if(!fsu_stat(src, &is_dir, NULL, NULL, NULL)) return 0;
    int dd = 0;
    if(!fsu_stat(dest_dir, &dd, NULL, NULL, NULL) || !dd) {
        if(!(dest_dir[0] == '/' && dest_dir[1] == '\0')) return 0;
    }

    char parent[FSU_PATH_MAX], name[48];
    fsu_split(src, parent, sizeof(parent), name, sizeof(name));
    if(str_eq_nocase(parent, dest_dir)) {
        if(out_new_path) { int i = 0; while(src[i] && i < out_max - 1) { out_new_path[i] = src[i]; i++; } out_new_path[i] = '\0'; }
        return 1;                                    /* already there */
    }
    if(is_dir && fileops_is_inside(dest_dir, src)) return 0;   /* into itself */

    char unique[64], dst[FSU_PATH_MAX];
    fileops_unique_name(dest_dir, name, unique, sizeof(unique));
    fileops_join(dest_dir, unique, dst, sizeof(dst));

    int ok;
    if(is_dir) { desktop_busy_begin(); ok = fsu_copy_tree(src, dst) && fsu_remove_dir(src, 1); desktop_busy_end(); }
    else ok = fsu_move_file(src, dst);

    if(ok && out_new_path) { int i = 0; while(dst[i] && i < out_max - 1) { out_new_path[i] = dst[i]; i++; } out_new_path[i] = '\0'; }
    return ok;
}

int fileops_trash(const char *path) {
    int d;
    if(!fsu_stat(RECYCLE_BIN_PATH, &d, NULL, NULL, NULL)) fsu_mkdir(RECYCLE_BIN_PATH);
    if(fileops_is_inside(path, RECYCLE_BIN_PATH)) return 0;       /* already in the bin */
    return fileops_move_into(path, RECYCLE_BIN_PATH, NULL, 0);
}

int fileops_paste_clipboard_into(const char *dest_dir) {
    if(!clipboard_has_file()) return 0;
    const char *src = clipboard_file_path();
    int cut = clipboard_file_is_cut();
    int is_dir = 0;
    if(!fsu_stat(src, &is_dir, NULL, NULL, NULL)) { clipboard_clear_file(); return 0; }

    if(cut) {
        int ok = fileops_move_into(src, dest_dir, NULL, 0);
        clipboard_clear_file();
        return ok;
    }
    char parent[FSU_PATH_MAX], name[48], unique[64], dst[FSU_PATH_MAX];
    fsu_split(src, parent, sizeof(parent), name, sizeof(name));
    fileops_unique_name(dest_dir, name, unique, sizeof(unique));
    fileops_join(dest_dir, unique, dst, sizeof(dst));
    if(is_dir) { if(fileops_is_inside(dest_dir, src)) return 0; desktop_busy_begin(); int r = fsu_copy_tree(src, dst); desktop_busy_end(); return r; }
    desktop_busy_begin();
    int r = fsu_copy_file(src, dst);
    desktop_busy_end();
    return r;
}

int fileops_rename(const char *path, const char *new_name) {
    char parent[FSU_PATH_MAX], name[48], dst[FSU_PATH_MAX];
    fsu_split(path, parent, sizeof(parent), name, sizeof(name));
    if(!new_name[0] || strcmp(name, new_name) == 0) return 0;
    for(const char *c = new_name; *c; c++) if(*c == '/' || *c == '\\') return 0;
    fileops_join(parent, new_name, dst, sizeof(dst));
    if(fsu_stat(dst, NULL, NULL, NULL, NULL)) return 0;           /* name taken */
    int is_dir = 0;
    if(!fsu_stat(path, &is_dir, NULL, NULL, NULL)) return 0;
    if(is_dir) return fsu_copy_tree(path, dst) && fsu_remove_dir(path, 1);
    return fsu_move_file(path, dst);
}
