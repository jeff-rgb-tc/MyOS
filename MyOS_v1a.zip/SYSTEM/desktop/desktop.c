#include "app_taskmgr.h"
#include "app_loader.h"
#include "desktop_items.h"
#include "startmenu.h"
#include "dnd.h"
#include "fileops.h"
#include "shortcut.h"
#include "clipboard.h"
#include "stdint.h"
#include "stddef.h"
#include "desktop.h"
#include "gfx.h"
#include "window.h"
#include "taskbar.h"
#include "boot_splash.h"
#include "rtc.h"
#include "mouse.h"
#include "keyboard.h"
#include "cursor.h"
#include "png.h"
#include "apps.h"
#include "context_menu.h"
#include "desktop_ini.h"
#include "fat32.h"
#include "kernio.h"
#include "common.h"
#include "stdio.h"
#include "pit.h"
#include "settings.h"
#include "kheap.h"
#include "app_explorer.h"
#include "system_icons.h"
#include "cursor_set.h"
#include "app_settings.h"
#include "app_cmd.h"
#include "app_mediaplayer.h"
#include "app_notepad.h"
#include "app_calculator.h"
#include "fs_util.h"

/* pause() is a raw assembly helper (the x86 PAUSE instruction, a hint
 * for spin-wait loops) with no header of its own -- keyboard.c declares
 * it the same way for the same reason. Used by desktop_enter_sleep()'s
 * wait loop below. */
extern void pause(void);

#define COLOR_DESKTOP_BG 0xFF2A6F97 /* fallback if the background image can't be loaded */
#define COLOR_ICON_TEXT  0xFFFFFFFF

/* A single background PNG, authored at whatever resolution -- scaled to
 * fill the screen at runtime via gfx_blit_scaled_argb() regardless of
 * which VESA mode actually got negotiated. */
#define BACKGROUND_PATH "/SYSTEM/res/backgrounds/background_1.png"

/* Which cursor shape to show this frame -- recomputed every frame by
 * pick_cursor_for_position() from whatever's under the mouse (resize
 * border, text field, etc.); see cursor_set.h for what each kind is
 * and where its file lives. Replaces the old single hardcoded
 * current_cursor/DEFAULT_CURSOR_PATH: cursor_set.c now owns loading and
 * caching every shape (including the default arrow's own built-in
 * fallback if its file is missing). */
static cursor_kind_t current_cursor_kind = CURSOR_DEFAULT;

static png_image_t desktop_background;
static uint8_t desktop_background_loaded = 0;

#define ICON_SIZE 48
#define ICON_SPACING_Y 84
#define ICON_MARGIN_X 24
#define ICON_MARGIN_Y 24
#define ICON_LABEL_MAX_WIDTH (ICON_SIZE + 16)

/* Desktop icon click/double-click state. Uses real wall-clock time (PIT
 * ticks, 100ms each -- see pit_get_ticks()) rather than a frame count,
 * so the double-click window is the same real duration regardless of
 * how fast the host/emulator renders frames.
 *
 * 5 ticks (~500ms) turned out too tight in practice: real double-clicks
 * measured under QEMU (mouse polling + emulated-PS/2 latency both add
 * delay on top of the human click-to-click gap) were landing at 7-47
 * ticks -- i.e. 700ms-4.7s apart by the time this code saw them -- and
 * so were always read as two separate single clicks. 12 ticks (~1.2s)
 * gives real double-clicks in this environment room to register while
 * still being short enough not to accidentally combine two deliberate,
 * separate single clicks on the same icon. */
#define DOUBLE_CLICK_TICK_WINDOW 12 /* 12 ticks = ~1.2s */
#define DESKTOP_ICONS_MAX 96
#define ITEM_GRID_X 88

/* Desktop icons are their own independent list -- NOT the same thing as
 * the Start menu's full app list (apps.c's registry). Only some apps
 * get a desktop icon by default (Command Prompt), and two icons aren't
 * apps at all (My PC, Recycle Bin -- see desktop_ini.h's
 * desktop_icon_kind_t). This used to be implicitly "one desktop icon
 * per registered app, same index", which meant every new app
 * automatically got a desktop icon whether that made sense or not, and
 * there was no way to have a desktop icon that wasn't an app. */
typedef struct {
    desktop_icon_kind_t kind;
    app_entry_t *app; /* resolved once at load time for ICON_KIND_APP; NULL for the special kinds */
    char label[32];   /* display name -- app->name for ICON_KIND_APP, "My PC"/"Recycle Bin" otherwise */
    char file[48];    /* ICON_KIND_ITEM only: the file name inside /Users/User/Desktop */
} desktop_icon_t;

static desktop_icon_t desktop_icons[DESKTOP_ICONS_MAX];
static int desktop_icon_count = 0;

static uint8_t icon_selected[DESKTOP_ICONS_MAX]; /* multi-select set, indexed into desktop_icons[] */
static int last_click_icon_index = -1;
static long long last_icon_click_tick = -1000;

/* Rubber-band (marquee) selection state: click-and-drag on bare desktop
 * draws a selection rectangle, Windows-style, and every icon whose box
 * intersects it becomes selected once the drag ends. */
static uint8_t rubber_band_active = 0;
static int rubber_band_start_x = 0;
static int rubber_band_start_y = 0;
static int rubber_band_x = 0; /* current corner, i.e. current mouse position while dragging */
static int rubber_band_y = 0;

/* Live icon positions, indexed the same way as apps.c's registry.
 * Loaded from /Users/User/Desktop/desktop.ini at startup (falling back
 * to a default vertical grid for any app desktop.ini doesn't mention --
 * e.g. the very first boot, before any layout has been saved), and
 * written back out whenever the user finishes dragging an icon. */
static int icon_pos_x[DESKTOP_ICONS_MAX];
static int icon_pos_y[DESKTOP_ICONS_MAX];

/* Icon-drag state: which icon (if any) is currently being dragged by the
 * mouse, and the offset from the icon's top-left to where the user
 * originally clicked, so the icon doesn't jump to be centered under the
 * cursor the instant a drag starts. */
static int dragging_icon_index = -1;
static int drag_moved = 0;           /* the pressed icon has actually travelled */
static int drag_origin_x = 0, drag_origin_y = 0;   /* where it was when pressed */
static int drag_press_x = 0, drag_press_y = 0;

/* Keyboard focus can belong to the desktop itself (after clicking an icon
 * or empty desktop), so Delete / F2 / Ctrl+C X V work on desktop items. */
static uint8_t desktop_has_focus = 0;
static window_t *desktop_focus_snapshot = NULL;

/* Inline rename of a desktop item (F2 / context menu / right after New Folder). */
static uint8_t rename_active = 0;
static char rename_file[48];       /* file being renamed */
static char rename_buf[40];
static int rename_len = 0;

static uint32_t last_item_poll_ms = 0;
static int icon_drag_offset_x = 0;
static int icon_drag_offset_y = 0;

/* Drag state for moving windows by their titlebar, kept separate from
 * "dragging inside a window's client area" (which is routed to the
 * focused window's on_drag hook instead -- see handle_mouse_motion). */
static window_t *drag_window = NULL;
static int drag_offset_x = 0;
static int drag_offset_y = 0;

/* Drag state for resizing a window by its border (see
 * wm_resize_edge_t) -- separate from drag_window above (moving) since a
 * single mouse-down can only ever be one or the other, but the two need
 * different per-frame math (resizing has to recompute x/y/w/h together
 * depending on which edge/corner is being dragged, not just offset the
 * window's position). resize_start_* capture the window's geometry at
 * the moment the drag began, so every frame's new size is computed from
 * that fixed starting point plus how far the mouse has moved since --
 * NOT incrementally frame-to-frame (which would drift/compound rounding
 * across a long drag). */
static window_t *resize_window = NULL;
static wm_resize_edge_t resize_edge = WM_RESIZE_NONE;
static int resize_start_mouse_x = 0, resize_start_mouse_y = 0;
static int resize_start_x = 0, resize_start_y = 0, resize_start_w = 0, resize_start_h = 0;

/* Names of the apps (matched against apps.c's registry by name) that
 * get a desktop icon by default -- NOT every registered app. Currently
 * just Command Prompt; Explorer/Paint/Settings are reachable from the
 * Start menu but don't clutter the default desktop. A user who deletes
 * or adds desktop icons has that reflected in desktop.ini from then on
 * (see build_default_desktop_icons(), only used when there's no saved
 * layout at all yet). */
static const char *default_desktop_apps[] = { "Command Prompt" };
#define DEFAULT_DESKTOP_APP_COUNT (int)(sizeof(default_desktop_apps) / sizeof(default_desktop_apps[0]))

static void set_icon_label(desktop_icon_t *icon, const char *label) {
    int j = 0;
    while(label[j] && j < (int)sizeof(icon->label) - 1) { icon->label[j] = label[j]; j++; }
    icon->label[j] = '\0';
}

/* Appends one icon to desktop_icons[] (both the icon list and its
 * default grid position), used by both the "no saved layout yet"
 * default set and load_icon_layout()'s handling of a saved My PC/
 * Recycle Bin entry (neither resolves through the app registry the way
 * ICON_KIND_APP entries do). Returns the new icon's index, or -1 if
 * desktop_icons[] is already full. */
static int add_desktop_icon(desktop_icon_kind_t kind, app_entry_t *app, const char *label) {
    if(desktop_icon_count >= DESKTOP_ICONS_MAX) return -1;
    int i = desktop_icon_count++;
    desktop_icons[i].kind = kind;
    desktop_icons[i].app = app;
    set_icon_label(&desktop_icons[i], label);
    icon_pos_x[i] = ICON_MARGIN_X;
    icon_pos_y[i] = ICON_MARGIN_Y + i * ICON_SPACING_Y;
    return i;
}

/* Builds the out-of-the-box icon set (Command Prompt, My PC, Recycle
 * Bin) -- only called when desktop.ini has no saved layout at all yet
 * (a fresh disk image), so a user's own additions/removals are never
 * overridden by this once any layout has been saved even once. */
static void build_default_desktop_icons(void) {
    desktop_icon_count = 0;

    for(int a = 0; a < DEFAULT_DESKTOP_APP_COUNT; a++) {
        int count = apps_count();
        for(int i = 0; i < count; i++) {
            app_entry_t *app = apps_get(i);
            if(app && strcmp(app->name, default_desktop_apps[a]) == 0) {
                add_desktop_icon(ICON_KIND_APP, app, app->name);
                break;
            }
        }
    }

    add_desktop_icon(ICON_KIND_MYPC, NULL, "My PC");
    add_desktop_icon(ICON_KIND_RECYCLE_BIN, NULL, "Recycle Bin");
}

static void load_icon_layout() {
    desktop_icon_entry_t saved[DESKTOP_ICON_ENTRIES_MAX];
    int saved_count = desktop_ini_load(saved, DESKTOP_ICON_ENTRIES_MAX);

    if(saved_count == 0) {
        /* Nothing saved yet at all (fresh disk, or desktop.ini couldn't
         * be read) -- use the default set rather than leaving the
         * desktop empty. */
        build_default_desktop_icons();
        return;
    }

    desktop_icon_count = 0;
    for(int s = 0; s < saved_count && desktop_icon_count < DESKTOP_ICONS_MAX; s++) {
        int idx = -1;
        if(saved[s].kind == ICON_KIND_APP) {
            int count = apps_count();
            for(int i = 0; i < count; i++) {
                app_entry_t *app = apps_get(i);
                if(app && strcmp(app->name, saved[s].app_name) == 0) {
                    idx = add_desktop_icon(ICON_KIND_APP, app, app->name);
                    break;
                }
            }
            /* If the saved app no longer exists (renamed/removed from
             * apps.c since this layout was saved), the entry is simply
             * dropped -- nothing sensible to show for it. */
        }
        else if(saved[s].kind == ICON_KIND_MYPC) {
            idx = add_desktop_icon(ICON_KIND_MYPC, NULL, "My PC");
        }
        else if(saved[s].kind == ICON_KIND_RECYCLE_BIN) {
            idx = add_desktop_icon(ICON_KIND_RECYCLE_BIN, NULL, "Recycle Bin");
        }

        if(idx >= 0) {
            /* add_desktop_icon() already set a default grid position --
             * overwrite it with the actually-saved one. */
            icon_pos_x[idx] = saved[s].x;
            icon_pos_y[idx] = saved[s].y;
        }
    }
}

/* ---------------------------------------------------------------------
 * Desktop items: files, folders and shortcuts that live in the Desktop
 * folder. They are appended after the persistent system/app icons and
 * rebuilt whenever the folder changes (including changes Explorer makes).
 * ------------------------------------------------------------------- */
static void clear_icon_selection_fwd(void);
static void action_new_app_shortcut(void *u);
static void action_paste_desktop(void *u);

static desktop_item_t *item_of(desktop_icon_t *icon) {
    if(icon->kind != ICON_KIND_ITEM) return NULL;
    int i = ditems_find(icon->file);
    return i >= 0 ? (desktop_item_t *)ditems_get(i) : NULL;
}

static int iabs(int v) { return v < 0 ? -v : v; }

static void place_in_free_slot(int idx) {
    int wax, way, waw, wah;
    taskbar_work_area(&wax, &way, &waw, &wah);
    int usable_h = wah;
    int rows = (usable_h - ICON_MARGIN_Y) / ICON_SPACING_Y;
    if(rows < 1) rows = 1;
    for(int col = 0; col < 40; col++) {
        for(int row = 0; row < rows; row++) {
            int x = wax + ICON_MARGIN_X + col * ITEM_GRID_X, y = way + ICON_MARGIN_Y + row * ICON_SPACING_Y;
            int clash = 0;
            for(int j = 0; j < desktop_icon_count; j++) {
                if(j == idx) continue;
                if(iabs(icon_pos_x[j] - x) < ITEM_GRID_X - 8 && iabs(icon_pos_y[j] - y) < ICON_SPACING_Y - 8) { clash = 1; break; }
            }
            if(!clash) { icon_pos_x[idx] = x; icon_pos_y[idx] = y; return; }
        }
    }
    icon_pos_x[idx] = ICON_MARGIN_X;
    icon_pos_y[idx] = ICON_MARGIN_Y;
}

static void sync_item_icons(void) {
    struct { char file[48]; int x, y; uint8_t sel; } keep[DESKTOP_ICONS_MAX];
    int kn = 0, w = 0;

    for(int i = 0; i < desktop_icon_count; i++) {
        if(desktop_icons[i].kind == ICON_KIND_ITEM) {
            if(kn < DESKTOP_ICONS_MAX) {
                int c = 0;
                while(desktop_icons[i].file[c] && c < 47) { keep[kn].file[c] = desktop_icons[i].file[c]; c++; }
                keep[kn].file[c] = '\0';
                keep[kn].x = icon_pos_x[i]; keep[kn].y = icon_pos_y[i]; keep[kn].sel = icon_selected[i];
                kn++;
            }
            continue;
        }
        if(w != i) {
            desktop_icons[w] = desktop_icons[i];
            icon_pos_x[w] = icon_pos_x[i]; icon_pos_y[w] = icon_pos_y[i]; icon_selected[w] = icon_selected[i];
        }
        w++;
    }
    desktop_icon_count = w;

    for(int k = 0; k < ditems_count() && desktop_icon_count < DESKTOP_ICONS_MAX; k++) {
        const desktop_item_t *it = ditems_get(k);
        int idx = desktop_icon_count++;
        desktop_icons[idx].kind = ICON_KIND_ITEM;
        desktop_icons[idx].app = NULL;
        set_icon_label(&desktop_icons[idx], it->label);
        int c = 0;
        while(it->file[c] && c < 47) { desktop_icons[idx].file[c] = it->file[c]; c++; }
        desktop_icons[idx].file[c] = '\0';
        icon_selected[idx] = 0;

        int x, y;
        if(ditems_pos_get(it->file, &x, &y)) { icon_pos_x[idx] = x; icon_pos_y[idx] = y; }
        else {
            int found = 0;
            for(int q = 0; q < kn; q++) {
                if(strcasecmp(keep[q].file, it->file) == 0) { icon_pos_x[idx] = keep[q].x; icon_pos_y[idx] = keep[q].y; found = 1; break; }
            }
            if(!found) place_in_free_slot(idx);
        }
        for(int q = 0; q < kn; q++) if(strcasecmp(keep[q].file, it->file) == 0) icon_selected[idx] = keep[q].sel;
    }
    for(int i = desktop_icon_count; i < DESKTOP_ICONS_MAX; i++) icon_selected[i] = 0;
    if(dragging_icon_index >= desktop_icon_count) { dragging_icon_index = -1; drag_moved = 0; }
    last_click_icon_index = -1;
}

/* Selects exactly the item with this file name (after New Folder etc.). */
static void select_item_by_file(const char *file) {
    clear_icon_selection_fwd();
    for(int i = 0; i < desktop_icon_count; i++) {
        if(desktop_icons[i].kind == ICON_KIND_ITEM && strcasecmp(desktop_icons[i].file, file) == 0) icon_selected[i] = 1;
    }
}

static void refresh_items_now(void) {
    ditems_invalidate();
    if(ditems_poll()) sync_item_icons();
}

static void save_icon_layout() {
    desktop_icon_entry_t entries[DESKTOP_ICON_ENTRIES_MAX];
    int n = 0;

    for(int i = 0; i < desktop_icon_count && n < DESKTOP_ICON_ENTRIES_MAX; i++) {
        if(desktop_icons[i].kind == ICON_KIND_ITEM) continue;      /* these are remembered in desktop.pos */
        entries[n].kind = desktop_icons[i].kind;
        entries[n].app_name[0] = '\0';
        if(desktop_icons[i].kind == ICON_KIND_APP && desktop_icons[i].app) {
            int j = 0;
            const char *name = desktop_icons[i].app->name;
            while(name[j] && j < (int)sizeof(entries[n].app_name) - 1) {
                entries[n].app_name[j] = name[j];
                j++;
            }
            entries[n].app_name[j] = '\0';
        }
        entries[n].x = icon_pos_x[i];
        entries[n].y = icon_pos_y[i];
        n++;
    }

    desktop_ini_save(entries, n);
}

/* True while the mouse button is held down *and* the press originated
 * inside some window's client area, so on_drag only fires for drags that
 * actually started on that window (matching how real window systems
 * don't route drags to a window just because the cursor passes over it). */
static window_t *client_drag_window = NULL;

/* icon_index_at() is defined further down (next to the rest of the
 * desktop-icon hit-testing code it belongs with), but
 * pick_cursor_for_position() below needs it too -- forward-declared
 * here rather than moving pick_cursor_for_position() itself down,
 * since it also depends on resize/drag state declared up here. */
static int icon_index_at(int x, int y);
static void clear_icon_selection_fwd(void);
static void action_remove_desktop_icon(void *user_data);
static void start_rename_item(const char *file);

/* Maps a resize edge/corner to the matching cursor shape. The two
 * diagonal cursors are named by which diagonal they lie ALONG in the
 * original art: diagonal_resize_1 is the "\" diagonal (top-left to
 * bottom-right), diagonal_resize_2 the "/" diagonal (top-right to
 * bottom-left) -- so TOP_LEFT/BOTTOM_RIGHT both use _1, and
 * TOP_RIGHT/BOTTOM_LEFT both use _2. */
static cursor_kind_t cursor_for_resize_edge(wm_resize_edge_t edge) {
    switch(edge) {
        case WM_RESIZE_LEFT:
        case WM_RESIZE_RIGHT:
            return CURSOR_RESIZE_H;
        case WM_RESIZE_TOP:
        case WM_RESIZE_BOTTOM:
            return CURSOR_RESIZE_V;
        case WM_RESIZE_TOP_LEFT:
        case WM_RESIZE_BOTTOM_RIGHT:
            return CURSOR_RESIZE_DIAG_1;
        case WM_RESIZE_TOP_RIGHT:
        case WM_RESIZE_BOTTOM_LEFT:
            return CURSOR_RESIZE_DIAG_2;
        default:
            return CURSOR_DEFAULT;
    }
}

/* Chooses which cursor shape to draw this frame. Priority order matters:
 * an in-progress resize or move drag decides the cursor on its own
 * (the mouse can drift off the border/titlebar mid-drag without the
 * cursor flickering back to an arrow), before anything about what the
 * mouse is merely hovering over is even considered. */
/* ---- busy / working-in-background indicators ----
 * CURSOR_BUSY (animated spinner) replaces every cursor while something
 * blocking is going on; CURSOR_WORKING (arrow with a spinner) replaces
 * only the plain arrow for a short time after a launch, so the user gets
 * feedback that the click registered while the app is starting. */
static int busy_depth = 0;
static uint32_t working_until_ms = 0;
static int working_active = 0;

void desktop_busy_tick(void);

void desktop_busy_begin(void) {
    busy_depth++;
    if(busy_depth == 1) {
        io_progress_hook = desktop_busy_tick;     /* keep the spinner turning during long file reads */
        desktop_busy_tick();                      /* and show it right now */
    }
}
void desktop_busy_end(void) {
    if(busy_depth > 0) busy_depth--;
    if(busy_depth == 0) io_progress_hook = NULL;
}

void desktop_working_for_ms(uint32_t ms) {
    working_until_ms = pit_get_ms() + ms;
    working_active = 1;
}

static cursor_kind_t pick_cursor_base(mouse_state_t *m);

static cursor_kind_t pick_cursor_for_position(mouse_state_t *m) {
    if(busy_depth > 0) return CURSOR_BUSY;
    cursor_kind_t kind = pick_cursor_base(m);
    if(working_active) {
        /* signed compare so the ms counter wrapping can't strand it on */
        if((int32_t)(working_until_ms - pit_get_ms()) <= 0) working_active = 0;
        else if(kind == CURSOR_DEFAULT) return CURSOR_WORKING;
    }
    return kind;
}

static cursor_kind_t pick_cursor_base(mouse_state_t *m) {
    if(resize_window) {
        return cursor_for_resize_edge(resize_edge);
    }
    if(drag_window) {
        return CURSOR_MOVE;
    }

    int x = m->x, y = m->y;

    /* Anything covering the whole screen while it's showing (the
     * taskbar/Start menu/context menu) owns the cursor -- a resize
     * border "showing through" underneath one of those would be
     * misleading. */
    if(taskbar_contains(x, y) || taskbar_start_menu_open()) {
        int kind = taskbar_cursor_at(x, y);
        if(kind > CURSOR_DEFAULT && kind < CURSOR_COUNT) return (cursor_kind_t)kind;
        return CURSOR_DEFAULT;
    }
    if(context_menu_is_open()) {
        return CURSOR_DEFAULT;
    }

    wm_resize_edge_t edge;
    if(wm_window_at_resize_edge(x, y, &edge)) {
        return cursor_for_resize_edge(edge);
    }

    window_t *win = wm_window_at(x, y);
    if(win && wm_point_in_titlebar(win, x, y)) {
        if(wm_point_in_close_box(win, x, y) || wm_point_in_maximize_box(win, x, y) || wm_point_in_minimize_box(win, x, y)) {
            return CURSOR_LINK;
        }
        return CURSOR_DEFAULT; /* plain titlebar drag area */
    }

    if(win && win->cursor_at) {
        int cx, cy, cw, ch;
        wm_get_client_rect(win, &cx, &cy, &cw, &ch);
        if(x >= cx && y >= cy && x < cx + cw && y < cy + ch) {
            int kind = win->cursor_at(win, x - cx, y - cy);
            if(kind > CURSOR_DEFAULT && kind < CURSOR_COUNT) {
                return (cursor_kind_t)kind;
            }
        }
    }

    /* Bare desktop (no window under the mouse at all): a desktop icon
     * under the pointer shows the pointing-hand cursor, since clicking
     * one launches something -- same convention as a link. */
    if(!win && icon_index_at(x, y) >= 0) {
        return CURSOR_LINK;
    }

    return CURSOR_DEFAULT;
}

/* Frees the previously-loaded background's pixel buffer, if any --
 * called before loading a new one (reload_background(), from
 * Personalization) so switching wallpapers repeatedly doesn't leak the
 * old image every time. load_background() (the boot-time path) never
 * needs this since there's nothing loaded yet to free. */
/* Pre-scaled copy of the wallpaper at exactly screen size, built once.
 * Scaling a PNG to the screen every frame (what this used to do) costs a
 * multiply/divide per pixel and is the single biggest reason the desktop
 * crawled under QEMU's software CPU; now each frame is just a memcpy. */
static uint32_t *bg_cache = NULL;
static int bg_cache_w = 0, bg_cache_h = 0;

static void free_bg_cache(void) {
    if(bg_cache) { kfree(bg_cache); bg_cache = NULL; }
    bg_cache_w = bg_cache_h = 0;
}

static void build_bg_cache(void) {
    free_bg_cache();
    if(!desktop_background_loaded || !desktop_background.pixels) return;
    int w = (int)gfx_width(), h = (int)gfx_height();
    bg_cache = (uint32_t *)kmalloc((uint32_t)w * (uint32_t)h * 4);
    if(!bg_cache) return;
    /* Scale once into the back buffer, then snapshot it. */
    gfx_blit_scaled_argb(0, 0, w, h, desktop_background.pixels,
                         desktop_background.width, desktop_background.height);
    memcpy(bg_cache, gfx_backbuffer()->pixels, (size_t)w * (size_t)h * 4);
    bg_cache_w = w; bg_cache_h = h;
}

static void free_background(void) {
    free_bg_cache();
    if(desktop_background_loaded) {
        png_free(&desktop_background);
    }
    desktop_background_loaded = 0;
}

static void load_background() {
    settings_t *s = settings_current();
    const char *path = (s->wallpaper_path[0]) ? s->wallpaper_path : BACKGROUND_PATH;

    if(png_load_from_file(path, &desktop_background)) {
        desktop_background_loaded = 1;
        printf("desktop: loaded background %s (%dx%d)\n", path,
               desktop_background.width, desktop_background.height);
    }
    else if(strcmp(path, BACKGROUND_PATH) != 0 && png_load_from_file(BACKGROUND_PATH, &desktop_background)) {
        /* The saved wallpaper path is missing/unreadable (e.g. its file
         * was deleted) -- fall back to the built-in default rather than
         * just showing a flat color, since that default is always
         * expected to be present. */
        desktop_background_loaded = 1;
        printf("desktop: could not load saved wallpaper %s, using default\n", path);
    }
    else {
        printf("desktop: no background at %s, using flat color\n", path);
        desktop_background_loaded = 0;
    }
    build_bg_cache();
}

/* Called by the Settings app (via reload_background()'s declaration in
 * desktop.h) right after the user picks a new wallpaper and
 * settings_save()s it, so the change is visible immediately rather than
 * only after a restart -- unlike resolution, wallpaper has no paging/
 * back-buffer dependency, so it's safe to just reload and keep going. */
void reload_background(void) {
    free_background();
    load_background();
}

static void draw_desktop_background() {
    if(bg_cache) {
        gfx_blit_opaque(0, 0, bg_cache, bg_cache_w, bg_cache_h);
    }
    else {
        gfx_clear(COLOR_DESKTOP_BG);
    }
}

static void icon_rect_for_index(int index, int *out_x, int *out_y) {
    if(index >= 0 && index < DESKTOP_ICONS_MAX) {
        *out_x = icon_pos_x[index];
        *out_y = icon_pos_y[index];
    }
    else {
        *out_x = ICON_MARGIN_X;
        *out_y = ICON_MARGIN_Y;
    }
}

/* Returns the image to draw for a given desktop icon, regardless of
 * kind -- app icons come from apps_get_icon() (apps.c's cache), the
 * special kinds from system_icon_get() (system_icons.c's cache). Both
 * return the same png_image_t/app_icon_t-shaped {width,height,pixels}
 * data in practice (app_icon_t and png_image_t have identical layout),
 * so callers just need width/height/pixels regardless of which cache
 * it came from. */
static uint8_t desktop_icon_image(desktop_icon_t *icon, uint32_t *out_w, uint32_t *out_h, uint32_t **out_pixels) {
    if(icon->kind == ICON_KIND_APP) {
        app_icon_t *img = icon->app ? apps_get_icon(icon->app) : NULL;
        if(!img) return 0;
        *out_w = img->width; *out_h = img->height; *out_pixels = img->pixels;
        return 1;
    }

    if(icon->kind == ICON_KIND_ITEM) {
        desktop_item_t *it = item_of(icon);
        if(!it) return 0;
        ditem_image_t im = ditems_icon_for(it);
        if(!im.pixels) return 0;
        *out_w = (uint32_t)im.w; *out_h = (uint32_t)im.h; *out_pixels = (uint32_t *)im.pixels;
        return 1;
    }

    system_icon_id_t sid = (icon->kind == ICON_KIND_MYPC) ? SYSTEM_ICON_MYPC : SYSTEM_ICON_RECYCLE_BIN;
    png_image_t *img = system_icon_get(sid);
    if(!img) return 0;
    *out_w = img->width; *out_h = img->height; *out_pixels = img->pixels;
    return 1;
}

/* Which icon would take a drop at (x, y)? Only the Recycle Bin and folders
 * accept things; `except` is the icon being dragged (never its own target). */
static int drop_target_icon_at(int x, int y, int except) {
    for(int i = 0; i < desktop_icon_count; i++) {
        if(i == except) continue;
        desktop_icon_t *icon = &desktop_icons[i];
        int ix, iy;
        icon_rect_for_index(i, &ix, &iy);
        if(x < ix - 6 || x >= ix + ICON_SIZE + 6 || y < iy - 6 || y >= iy + ICON_SIZE + 18) continue;
        if(icon->kind == ICON_KIND_RECYCLE_BIN) return i;
        if(icon->kind == ICON_KIND_ITEM) {
            desktop_item_t *it = item_of(icon);
            if(it && it->kind == DI_FOLDER) return i;
        }
    }
    return -1;
}

/* Label under an icon: centred, shadowed so it reads on any wallpaper, and
 * shortened with ".." when it would not fit the grid cell. */
static void draw_icon_label(int ix, int iy, const char *label, int max_chars) {
    char text[40];
    int n = 0;
    while(label[n] && n < 39) { text[n] = label[n]; n++; }
    text[n] = '\0';
    if(n > max_chars && max_chars > 3) { text[max_chars - 2] = '.'; text[max_chars - 1] = '.'; text[max_chars] = '\0'; n = max_chars; }
    int w = n * GFX_CHAR_COLS;
    int x = ix + ICON_SIZE / 2 - w / 2;
    int y = iy + ICON_SIZE + 4;
    gfx_draw_string(x + 1, y + 1, text, 0xC0000000);
    gfx_draw_string(x, y, text, COLOR_ICON_TEXT);
}

static void draw_desktop_icons() {
    mouse_state_t *ms = mouse_get_state();
    int drag_active = dnd_active() || (dragging_icon_index >= 0 && drag_moved);
    int hot = drag_active ? drop_target_icon_at(ms->x, ms->y, dnd_active() ? -1 : dragging_icon_index) : -1;

    for(int i = 0; i < desktop_icon_count; i++) {
        desktop_icon_t *icon = &desktop_icons[i];

        int ix, iy;
        icon_rect_for_index(i, &ix, &iy);

        if(icon_selected[i] || i == hot) {
            gfx_blend_rounded_rect(ix - 16, iy - 6, ICON_SIZE + 32, ICON_SIZE + 30, 6, i == hot ? 0x883C8CFF : 0x553C8CFF);
            if(i == hot) gfx_draw_rounded_outline(ix - 16, iy - 6, ICON_SIZE + 32, ICON_SIZE + 30, 6, 0xFF8CC4FF);
        }

        uint32_t iw, ih, *ipixels;
        if(desktop_icon_image(icon, &iw, &ih, &ipixels)) {
            gfx_blit_scaled_argb_alpha(ix, iy, ICON_SIZE, ICON_SIZE, ipixels, iw, ih);
        }
        else {
            /* Icon failed to load -- draw a placeholder box rather than
             * silently having no icon at all, so it's obvious something
             * is missing on the disk image instead of just looking like
             * an empty desktop. */
            gfx_fill_rect(ix, iy, ICON_SIZE, ICON_SIZE, 0xFFDDDDDD);
            gfx_draw_rect(ix, iy, ICON_SIZE, ICON_SIZE, 0xFF000000);
        }

        if(icon->kind == ICON_KIND_ITEM) {
            desktop_item_t *it = item_of(icon);
            if(it && it->kind == DI_SHORTCUT) ditems_draw_shortcut_badge(ix, iy, ICON_SIZE);
        }

        if(rename_active && icon->kind == ICON_KIND_ITEM && strcasecmp(icon->file, rename_file) == 0) {
            int bw = ITEM_GRID_X - 6, bx = ix + ICON_SIZE / 2 - bw / 2, by = iy + ICON_SIZE + 2;
            gfx_fill_rounded_rect(bx, by, bw, 22, 4, 0xFF1E1E22);
            gfx_draw_rounded_outline(bx, by, bw, 22, 4, 0xFF4CC2FF);
            int max_c = (bw - 10) / GFX_CHAR_COLS;
            const char *shown = rename_buf;
            if(rename_len > max_c) shown += rename_len - max_c;
            gfx_draw_string(bx + 5, by + 3, shown, 0xFFF2F2F5);
            int caret = (rename_len > max_c ? max_c : rename_len) * GFX_CHAR_COLS;
            if((pit_get_ms() / 500) % 2 == 0) gfx_fill_rect(bx + 5 + caret, by + 4, 1, 14, 0xFF4CC2FF);
        }
        else {
            draw_icon_label(ix, iy, icon->label, icon->kind == ICON_KIND_ITEM ? 10 : 12);
        }
    }
}

static void draw_rubber_band() {
    if(!rubber_band_active) return;

    int x0 = rubber_band_start_x < rubber_band_x ? rubber_band_start_x : rubber_band_x;
    int y0 = rubber_band_start_y < rubber_band_y ? rubber_band_start_y : rubber_band_y;
    int x1 = rubber_band_start_x > rubber_band_x ? rubber_band_start_x : rubber_band_x;
    int y1 = rubber_band_start_y > rubber_band_y ? rubber_band_start_y : rubber_band_y;

    /* Windows-style marquee: translucent blue fill with a solid border. */
    gfx_blend_rounded_rect(x0, y0, x1 - x0, y1 - y0, 0, 0x403C8CFF);
    gfx_draw_rect(x0, y0, x1 - x0, y1 - y0, 0xFF3C8CFF);
}

static int icon_index_at(int x, int y) {
    for(int i = 0; i < desktop_icon_count; i++) {
        int ix, iy;
        icon_rect_for_index(i, &ix, &iy);
        if(x >= ix && x < ix + ICON_SIZE && y >= iy && y < iy + ICON_SIZE + 16) {
            return i;
        }
    }
    return -1;
}

static void clear_icon_selection() {
    memset(icon_selected, 0, sizeof(icon_selected));
}
static void clear_icon_selection_fwd(void) { clear_icon_selection(); }

/* Selects every icon whose bounding box intersects the given screen
 * rectangle (already normalized so x0<=x1, y0<=y1), matching how a
 * Windows marquee selection picks up any icon it merely overlaps rather
 * than requiring full containment. */
static void select_icons_in_rect(int x0, int y0, int x1, int y1) {
    for(int i = 0; i < desktop_icon_count && i < DESKTOP_ICONS_MAX; i++) {
        int ix, iy;
        icon_rect_for_index(i, &ix, &iy);
        int icon_x1 = ix + ICON_SIZE;
        int icon_y1 = iy + ICON_SIZE + 16; /* include the label strip below the glyph */

        int intersects = (ix < x1 && icon_x1 > x0 && iy < y1 && icon_y1 > y0);
        if(intersects) {
            icon_selected[i] = 1;
        }
    }
}

/* Dispatches by kind -- an app icon launches that app the same way it
 * always did, My PC/Recycle Bin open a new Explorer window straight to
 * that view (see app_explorer.c's launch_explorer_mypc()/
 * launch_explorer_recycle_bin()). */
static void launch_desktop_icon(desktop_icon_t *icon) {
    switch(icon->kind) {
        case ICON_KIND_APP:
            if(icon->app && icon->app->launch) { apps_launch(icon->app); }
            break;
        case ICON_KIND_MYPC:
            launch_explorer_mypc();
            break;
        case ICON_KIND_RECYCLE_BIN:
            launch_explorer_recycle_bin();
            break;
        case ICON_KIND_ITEM: {
            desktop_item_t *it = item_of(icon);
            if(!it) break;
            desktop_working_for_ms(900);
            if(it->kind == DI_FOLDER) launch_explorer_at(it->path);
            else if(it->kind == DI_SHORTCUT) shortcut_open(&it->sc);
            else desktop_open_path(it->path);
            break;
        }
    }
}

static void handle_desktop_icon_click(int x, int y) {
    int idx = icon_index_at(x, y);
    if(idx < 0) {
        clear_icon_selection();
        return;
    }

    if(idx == last_click_icon_index && (pit_get_ticks() - last_icon_click_tick) < DOUBLE_CLICK_TICK_WINDOW) {
        /* Double-click: launch/open whatever this icon represents. */
        launch_desktop_icon(&desktop_icons[idx]);
        last_icon_click_tick = -1000;
        last_click_icon_index = -1;
    }
    else {
        clear_icon_selection();
        if(idx < DESKTOP_ICONS_MAX) icon_selected[idx] = 1;
        last_click_icon_index = idx;
        last_icon_click_tick = pit_get_ticks();

        /* A single click also arms a potential drag -- if the mouse
         * moves before button-up, handle_mouse_motion() will treat this
         * as repositioning the icon rather than just a selection. */
        int ix, iy;
        icon_rect_for_index(idx, &ix, &iy);
        dragging_icon_index = idx;
        icon_drag_offset_x = x - ix;
        icon_drag_offset_y = y - iy;
        drag_moved = 0;
        drag_origin_x = icon_pos_x[idx];
        drag_origin_y = icon_pos_y[idx];
        drag_press_x = x;
        drag_press_y = y;
    }
    desktop_has_focus = 1;
    desktop_focus_snapshot = wm_focused_window();
}

/* --- context menu actions ---
 * Each action_* function matches context_menu_action_fn's signature and
 * receives whatever user_data pointer was passed to context_menu_open()
 * for that particular menu -- e.g. the desktop-icon menu passes the app
 * index, the window menu passes the window_t* that was right-clicked. */

#define DESKTOP_DIR_PATH "/Users/User/Desktop"

/* Picks "<base>", "<base> (2)", ... that doesn't exist yet in the Desktop
 * folder, so repeated "New" clicks never collide. */
static void desktop_unique_path(const char *base, const char *ext, char *out, int max) {
    for(int n = 1; n < 100; n++) {
        char name[64]; int p = 0;
        for(const char *c = base; *c && p < 40; c++) name[p++] = *c;
        if(n > 1) { name[p++] = ' '; name[p++] = '('; if(n >= 10) name[p++] = (char)('0' + n / 10); name[p++] = (char)('0' + n % 10); name[p++] = ')'; }
        for(const char *c = ext; *c && p < 62; c++) name[p++] = *c;
        name[p] = '\0';
        int q = 0;
        for(const char *c = DESKTOP_DIR_PATH "/"; *c && q < max - 1; c++) out[q++] = *c;
        for(int k = 0; name[k] && q < max - 1; k++) out[q++] = name[k];
        out[q] = '\0';
        if(!fsu_stat(out, NULL, NULL, NULL, NULL)) return;
    }
}

static void action_new_folder(void *user_data) {
    (void)user_data;
    if(!master_fs) return;
    char path[FSU_PATH_MAX];
    desktop_unique_path("New Folder", "", path, sizeof(path));
    if(fsu_mkdir(path)) {
        refresh_items_now();
        char parent[FSU_PATH_MAX], name[48];
        fsu_split(path, parent, sizeof(parent), name, sizeof(name));
        select_item_by_file(name);
        start_rename_item(name);
    }
}

static void action_new_text(void *user_data) {
    (void)user_data;
    if(!master_fs) return;
    char path[FSU_PATH_MAX];
    desktop_unique_path("New Text Document", ".txt", path, sizeof(path));
    if(fsu_write_file(path, (const uint8_t *)"", 0)) {
        refresh_items_now();
        char parent[FSU_PATH_MAX], name[48];
        fsu_split(path, parent, sizeof(parent), name, sizeof(name));
        select_item_by_file(name);
        start_rename_item(name);
    }
}

static void action_refresh(void *user_data) {
    (void)user_data;
    /* Re-read the wallpaper too, so a replaced image shows up. */
    reload_background();
    refresh_items_now();
}

static void action_restore_or_maximize(void *user_data) {
    window_t *win = (window_t *)user_data;
    if(win) {
        if(win->minimized) wm_restore_window(win);
        else wm_toggle_maximize(win);
    }
}

static void action_minimize(void *user_data) {
    window_t *win = (window_t *)user_data;
    if(win) wm_minimize_window(win);
}

static void action_close(void *user_data) {
    window_t *win = (window_t *)user_data;
    if(win) wm_destroy_window(win);
}

static void action_open_explorer(void *user_data) { (void)user_data; launch_explorer(); }
static void action_open_cmd(void *user_data) { (void)user_data; launch_cmd(); }
static void action_open_settings(void *user_data) { (void)user_data; launch_settings(); }
static void action_open_media(void *user_data) { (void)user_data; launch_mediaplayer(); }
static void action_open_notepad(void *user_data) { (void)user_data; launch_notepad(); }
static void action_open_calc(void *user_data) { (void)user_data; launch_calculator(); }

/* Resets every icon to the default vertical grid in its current order. */
static void action_arrange_icons(void *user_data) {
    (void)user_data;
    for(int i = 0; i < desktop_icon_count; i++) {
        icon_pos_x[i] = ICON_MARGIN_X;
        icon_pos_y[i] = ICON_MARGIN_Y + i * ICON_SPACING_Y;
    }
    {   /* keep them clear of a taskbar docked at the left */
        int wax, way, waw, wah; taskbar_work_area(&wax, &way, &waw, &wah);
        for(int i = 0; i < desktop_icon_count; i++) { icon_pos_x[i] += wax; icon_pos_y[i] += way; }
    }
    save_icon_layout();
}

static void action_sort_icons_by_name(void *user_data) {
    (void)user_data;
    for(int i = 1; i < desktop_icon_count; i++) {
        for(int j = i; j > 0 && strcasecmp(desktop_icons[j - 1].label, desktop_icons[j].label) > 0; j--) {
            desktop_icon_t tmp = desktop_icons[j]; desktop_icons[j] = desktop_icons[j - 1]; desktop_icons[j - 1] = tmp;
            uint8_t ts = icon_selected[j]; icon_selected[j] = icon_selected[j - 1]; icon_selected[j - 1] = ts;
        }
    }
    action_arrange_icons(NULL);
}

static void action_minimize_all(void *user_data) {
    (void)user_data;
    for(int i = 0; i < wm_window_count(); i++) {
        window_t *w = wm_window_at_index(i);
        if(w && w->in_use && !w->minimized) wm_minimize_window(w);
    }
}

static void action_restore_all(void *user_data) {
    (void)user_data;
    for(int i = 0; i < wm_window_count(); i++) {
        window_t *w = wm_window_at_index(i);
        if(w && w->in_use && w->minimized) wm_restore_window(w);
    }
}

static void action_cascade(void *user_data) {
    (void)user_data;
    int n = 0;
    for(int i = 0; i < wm_window_count(); i++) {
        window_t *w = wm_window_at_index(i);
        if(!w || !w->in_use || w->minimized) continue;
        if(w->maximized) wm_toggle_maximize(w);
        wm_move_window(w, 40 + n * 30, 30 + n * 30);
        n++;
    }
}

static void action_close_all(void *user_data) {
    (void)user_data;
    /* Collect first: destroying shifts the window table under us. */
    window_t *list[WM_MAX_WINDOWS]; int n = 0;
    for(int i = 0; i < wm_window_count() && n < WM_MAX_WINDOWS; i++) {
        window_t *w = wm_window_at_index(i);
        if(w && w->in_use) list[n++] = w;
    }
    for(int i = 0; i < n; i++) wm_destroy_window(list[i]);
}

static void open_desktop_context_menu(int x, int y) {
    static const context_menu_item_t sort_items[] = {
        CM_ITEM("Name", action_sort_icons_by_name, ""),
        CM_ITEM("Reset positions", action_arrange_icons, ""),
    };
    static const context_menu_item_t new_items[] = {
        CM_ITEM("Folder", action_new_folder, ""),
        CM_ITEM("Text Document", action_new_text, ""),
    };
    static context_menu_item_t shortcut_items[CONTEXT_MENU_MAX_ITEMS];
    static context_menu_item_t items[16];

    int sc_n = 0;
    for(int i = 0; i < apps_count() && sc_n < CONTEXT_MENU_MAX_ITEMS; i++) {
        app_entry_t *a = apps_get(i);
        memset(&shortcut_items[sc_n], 0, sizeof(shortcut_items[0]));
        shortcut_items[sc_n].enabled = 1;
        shortcut_items[sc_n].action = action_new_app_shortcut;
        context_menu_set_label(&shortcut_items[sc_n], a ? a->name : "?");
        sc_n++;
    }

    int n = 0;
    context_menu_item_t it;
    #define ADD_STATIC(x_) do { items[n++] = (x_); } while(0)
    ADD_STATIC(((context_menu_item_t)CM_SUB("Sort icons", sort_items, 2)));
    ADD_STATIC(((context_menu_item_t)CM_ITEM("Refresh", action_refresh, "")));
    ADD_STATIC(((context_menu_item_t)CM_SEP()));
    if(clipboard_has_file()) { ADD_STATIC(((context_menu_item_t)CM_ITEM("Paste", action_paste_desktop, "Ctrl+V"))); }
    else { ADD_STATIC(((context_menu_item_t)CM_ITEM_OFF("Paste", "Ctrl+V"))); }
    ADD_STATIC(((context_menu_item_t)CM_SUB("New", new_items, 2)));
    memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "New shortcut");
    it.submenu = shortcut_items; it.submenu_count = sc_n; items[n++] = it;
    ADD_STATIC(((context_menu_item_t)CM_SEP()));
    ADD_STATIC(((context_menu_item_t)CM_ITEM("Open Explorer", action_open_explorer, "")));
    ADD_STATIC(((context_menu_item_t)CM_ITEM("Open Command Prompt", action_open_cmd, "")));
    ADD_STATIC(((context_menu_item_t)CM_ITEM("Open Media Player", action_open_media, "")));
    ADD_STATIC(((context_menu_item_t)CM_ITEM("Open Notepad", action_open_notepad, "")));
    ADD_STATIC(((context_menu_item_t)CM_ITEM("Open Calculator", action_open_calc, "")));
    ADD_STATIC(((context_menu_item_t)CM_SEP()));
    ADD_STATIC(((context_menu_item_t)CM_ITEM("Display settings", action_open_settings, "")));
    ADD_STATIC(((context_menu_item_t)CM_ITEM("Personalize", action_open_settings, "")));
    #undef ADD_STATIC
    context_menu_open(x, y, items, n, NULL);
}

static void open_window_context_menu(int x, int y, window_t *win) {
    context_menu_item_t items[6];
    int i = 0;
    context_menu_item_t it;

    memset(&it, 0, sizeof(it)); context_menu_set_label(&it, "Restore"); it.action = action_restore_or_maximize;
    it.enabled = (win->maximized || win->minimized) ? 1 : 0; items[i++] = it;

    memset(&it, 0, sizeof(it)); context_menu_set_label(&it, "Maximize"); it.action = action_restore_or_maximize;
    it.enabled = win->maximized ? 0 : 1; items[i++] = it;

    memset(&it, 0, sizeof(it)); context_menu_set_label(&it, "Minimize"); it.action = action_minimize;
    it.enabled = win->minimized ? 0 : 1; items[i++] = it;

    memset(&it, 0, sizeof(it)); it.separator = 1; items[i++] = it;

    memset(&it, 0, sizeof(it)); context_menu_set_label(&it, "Close"); it.action = action_close;
    it.enabled = 1; items[i++] = it;

    context_menu_open(x, y, items, i, win);
}

static void action_open_desktop_icon(void *user_data) {
    desktop_icon_t *icon = (desktop_icon_t *)user_data;
    if(icon) launch_desktop_icon(icon);
}

static void action_remove_desktop_icon(void *user_data) {
    desktop_icon_t *icon = (desktop_icon_t *)user_data;
    if(!icon) return;
    int idx = (int)(icon - desktop_icons);
    if(idx < 0 || idx >= desktop_icon_count) return;
    if(icon->kind == ICON_KIND_ITEM) {                    /* a real file: "remove" means into the Recycle Bin */
        desktop_item_t *it = item_of(icon);
        if(it) { char file[48]; int c = 0; while(icon->file[c] && c < 47) { file[c] = icon->file[c]; c++; } file[c] = '\0';
                 if(!fileops_trash(it->path)) desktop_toast("Could not move that to the Recycle Bin");
                 ditems_pos_forget(file); }
        refresh_items_now();
        return;
    }
    for(int i = idx; i < desktop_icon_count - 1; i++) {
        desktop_icons[i] = desktop_icons[i + 1];
        icon_pos_x[i] = icon_pos_x[i + 1];
        icon_pos_y[i] = icon_pos_y[i + 1];
        icon_selected[i] = icon_selected[i + 1];
    }
    desktop_icon_count--;
    icon_selected[desktop_icon_count] = 0;
    last_click_icon_index = -1;
    save_icon_layout();
}

static void action_item_open(void *u) { desktop_icon_t *icon = (desktop_icon_t *)u; if(icon) launch_desktop_icon(icon); }
static void action_item_cut(void *u) { desktop_icon_t *icon = (desktop_icon_t *)u; desktop_item_t *it = icon ? item_of(icon) : NULL; if(it) clipboard_set_file(it->path, 1); }
static void action_item_copy(void *u) { desktop_icon_t *icon = (desktop_icon_t *)u; desktop_item_t *it = icon ? item_of(icon) : NULL; if(it) clipboard_set_file(it->path, 0); }
static void action_item_shortcut(void *u) {
    desktop_icon_t *icon = (desktop_icon_t *)u; desktop_item_t *it = icon ? item_of(icon) : NULL;
    if(!it) return;
    if(shortcut_create_for_path(DESKTOP_FOLDER_PATH, it->path, NULL, 0)) refresh_items_now();
}
static void action_item_rename(void *u) { desktop_icon_t *icon = (desktop_icon_t *)u; if(icon && icon->kind == ICON_KIND_ITEM) start_rename_item(icon->file); }

static void action_paste_desktop(void *u) {
    (void)u;
    if(fileops_paste_clipboard_into(DESKTOP_FOLDER_PATH)) refresh_items_now();
    else desktop_toast("Nothing to paste");
}

/* "New shortcut" lists the registered apps; one action serves every row
 * and picks the app by the row's position. */
static void action_new_app_shortcut(void *u) {
    (void)u;
    int idx = context_menu_clicked_index();
    if(idx < 0 || idx >= apps_count()) return;
    app_entry_t *a = apps_get(idx);
    if(!a) return;
    char target[SC_TARGET_MAX]; int n = 0;
    const char *pre = "app:"; while(*pre) target[n++] = *pre++;
    for(const char *c = a->name; *c && n < SC_TARGET_MAX - 1; c++) target[n++] = *c;
    target[n] = '\0';
    char out[FSU_PATH_MAX];
    if(shortcut_create(DESKTOP_FOLDER_PATH, a->name, target, out, sizeof(out))) {
        refresh_items_now();
        char parent[FSU_PATH_MAX], name[48];
        fsu_split(out, parent, sizeof(parent), name, sizeof(name));
        select_item_by_file(name);
    }
}

static void open_icon_context_menu(int x, int y, desktop_icon_t *icon) {
    if(icon->kind == ICON_KIND_ITEM) {
        static const context_menu_item_t item_items[] = {
            CM_ITEM("Open", action_item_open, ""),
            CM_SEP(),
            CM_ITEM("Cut", action_item_cut, "Ctrl+X"),
            CM_ITEM("Copy", action_item_copy, "Ctrl+C"),
            CM_ITEM("Create shortcut", action_item_shortcut, ""),
            CM_SEP(),
            CM_ITEM("Delete", action_remove_desktop_icon, "Del"),
            CM_ITEM("Rename", action_item_rename, "F2"),
        };
        context_menu_open(x, y, item_items, 8, icon);
        return;
    }
    static const context_menu_item_t items[] = {
        CM_ITEM("Open", action_open_desktop_icon, ""),
        CM_SEP(),
        CM_ITEM("Remove from desktop", action_remove_desktop_icon, ""),
        CM_SEP(),
        CM_ITEM("Refresh", action_refresh, ""),
    };
    context_menu_open(x, y, items, 5, icon);
}

static void set_dock_and_arrange(int dock) {
    taskbar_set_dock(dock);
    action_arrange_icons(NULL);      /* icons that were under the new taskbar position move out from under it */
    wm_refit_maximized();
}
static void action_dock_bottom(void *u) { (void)u; set_dock_and_arrange(TASKBAR_DOCK_BOTTOM); }
static void action_dock_top(void *u)    { (void)u; set_dock_and_arrange(TASKBAR_DOCK_TOP); }
static void action_dock_left(void *u)   { (void)u; set_dock_and_arrange(TASKBAR_DOCK_LEFT); }
static void action_dock_right(void *u)  { (void)u; set_dock_and_arrange(TASKBAR_DOCK_RIGHT); }

static void open_taskbar_context_menu(int x, int y) {
    static const context_menu_item_t items[] = {
        CM_ITEM("Show desktop", action_minimize_all, ""),
        CM_ITEM("Restore all windows", action_restore_all, ""),
        CM_ITEM("Cascade windows", action_cascade, ""),
        CM_SEP(),
        CM_ITEM("Close all windows", action_close_all, ""),
        CM_SEP(),
        CM_ITEM("Dock at bottom", action_dock_bottom, ""),
        CM_ITEM("Dock at top", action_dock_top, ""),
        CM_ITEM("Dock at left", action_dock_left, ""),
        CM_ITEM("Dock at right", action_dock_right, ""),
        CM_SEP(),
        CM_ITEM("Taskbar settings", action_open_settings, ""),
    };
    context_menu_open(x, y, items, 12, NULL);
}

static void handle_mouse_right_click(mouse_state_t *m) {
    int x = m->x, y = m->y;

    if(startmenu_is_open() && startmenu_right_click(x, y)) return;   /* menu row: its own context menu */

    if(taskbar_contains(x, y)) {
        open_taskbar_context_menu(x, y);
        return;
    }

    window_t *win = wm_window_at(x, y);
    if(win && wm_point_in_titlebar(win, x, y)) {
        wm_focus(win);
        open_window_context_menu(x, y, win);
        return;
    }

    if(win) {
        /* Right-click landed inside a window's client area rather than
         * its titlebar -- let the app supply its own context menu (e.g.
         * Explorer's file/folder menu) if it wants one. */
        if(win->on_right_click) {
            int cx, cy, cw, ch;
            wm_get_client_rect(win, &cx, &cy, &cw, &ch);
            (void)cw; (void)ch;
            wm_focus(win);
            win->on_right_click(win, x - cx, y - cy);
        }
        return;
    }

    if(!win) {
        int icon_idx = icon_index_at(x, y);
        if(icon_idx >= 0) {
            open_icon_context_menu(x, y, &desktop_icons[icon_idx]);
        }
        else {
            open_desktop_context_menu(x, y);
        }
    }
}

static void handle_mouse_button_down(mouse_state_t *m) {
    int x = m->x, y = m->y;

    if(context_menu_is_open()) {
        context_menu_handle_click(x, y);
        return;
    }

    if(taskbar_contains(x, y) || taskbar_start_menu_open() || taskbar_volume_open()) {
        taskbar_handle_click(x, y);
        return;
    }

    wm_resize_edge_t edge;
    window_t *resize_target = wm_window_at_resize_edge(x, y, &edge);
    if(resize_target) {
        wm_focus(resize_target);
        resize_window = resize_target;
        resize_edge = edge;
        resize_start_mouse_x = x;
        resize_start_mouse_y = y;
        resize_start_x = resize_target->x;
        resize_start_y = resize_target->y;
        resize_start_w = resize_target->w;
        resize_start_h = resize_target->h;
        return;
    }

    window_t *win = wm_window_at(x, y);
    if(!win) {
        int icon_idx = icon_index_at(x, y);
        if(icon_idx >= 0) {
            handle_desktop_icon_click(x, y);
        }
        else {
            /* Clicked bare desktop: start a rubber-band marquee instead
             * of just clearing selection immediately -- clearing still
             * happens (matching clicking empty space in Windows), but a
             * subsequent drag before mouse-up can still pick up icons. */
            clear_icon_selection();
            rubber_band_active = 1;
            rubber_band_start_x = x;
            rubber_band_start_y = y;
            rubber_band_x = x;
            rubber_band_y = y;
        }
        return;
    }

    wm_focus(win);
    desktop_has_focus = 0;
    if(rename_active) rename_active = 0;

    if(wm_point_in_close_box(win, x, y)) {
        if(win->on_close_request) win->on_close_request(win);
        else wm_destroy_window(win);
        return;
    }

    if(wm_point_in_maximize_box(win, x, y)) {
        wm_toggle_maximize(win);
        return;
    }

    if(wm_point_in_minimize_box(win, x, y)) {
        wm_minimize_window(win);
        return;
    }

    if(wm_point_in_titlebar(win, x, y)) {
        drag_window = win;
        drag_offset_x = x - win->x;
        drag_offset_y = y - win->y;
        return;
    }

    /* Click landed in the window's client area: route to the app's
     * on_click hook (translated to client-relative coordinates), and
     * remember this window so subsequent mouse-move events while the
     * button stays down get routed to its on_drag hook too. */
    int cx, cy, cw, ch;
    wm_get_client_rect(win, &cx, &cy, &cw, &ch);
    if(x >= cx && x < cx + cw && y >= cy && y < cy + ch) {
        if(win->on_click) {
            win->on_click(win, x - cx, y - cy);
        }
        if(win->on_drag) {
            client_drag_window = win;
        }
    }
}

/* ---- drops --------------------------------------------------------- */
static void restore_icon_pos(int idx) {
    icon_pos_x[idx] = drag_origin_x;
    icon_pos_y[idx] = drag_origin_y;
}

static int over_taskbar(int x, int y) { return taskbar_contains(x, y); }

/* A desktop icon was dragged and released at the pointer position. */
static void finish_icon_drag(int idx, mouse_state_t *m) {
    desktop_icon_t *icon = &desktop_icons[idx];

    window_t *win = wm_window_at(m->x, m->y);
    if(win || over_taskbar(m->x, m->y)) {
        /* Dropped on a window (e.g. an Explorer folder): hand over the file. */
        desktop_item_t *it = item_of(icon);
        if(win && win->on_drop && it) {
            char path[FSU_PATH_MAX], file[48];
            int i = 0; while(it->path[i] && i < FSU_PATH_MAX - 1) { path[i] = it->path[i]; i++; } path[i] = '\0';
            i = 0; while(icon->file[i] && i < 47) { file[i] = icon->file[i]; i++; } file[i] = '\0';
            int cx, cy, cw, ch;
            wm_get_client_rect(win, &cx, &cy, &cw, &ch);
            restore_icon_pos(idx);
            if(win->on_drop(win, m->x - cx, m->y - cy, path)) { ditems_pos_forget(file); refresh_items_now(); }
            return;
        }
        restore_icon_pos(idx);
        return;
    }

    int tgt = drop_target_icon_at(m->x, m->y, idx);
    if(tgt >= 0) {
        desktop_icon_t *target = &desktop_icons[tgt];
        desktop_item_t *it = item_of(icon);
        if(target->kind == ICON_KIND_RECYCLE_BIN) {
            if(it) {
                char file[48]; int i = 0; while(icon->file[i] && i < 47) { file[i] = icon->file[i]; i++; } file[i] = '\0';
                if(!fileops_trash(it->path)) desktop_toast("Could not move that to the Recycle Bin");
                ditems_pos_forget(file);
                refresh_items_now();
                return;
            }
            if(icon->kind == ICON_KIND_APP) { action_remove_desktop_icon(icon); return; }
            restore_icon_pos(idx);
            return;
        }
        desktop_item_t *folder = item_of(target);
        if(it && folder && folder->kind == DI_FOLDER) {
            char file[48]; int i = 0; while(icon->file[i] && i < 47) { file[i] = icon->file[i]; i++; } file[i] = '\0';
            if(!fileops_move_into(it->path, folder->path, NULL, 0)) desktop_toast("Could not move that into the folder");
            ditems_pos_forget(file);
            refresh_items_now();
            return;
        }
        restore_icon_pos(idx);
        return;
    }

    /* Plain reposition: keep it on screen and remember where it went. */
    int wax, way, sw, sh;
    taskbar_work_area(&wax, &way, &sw, &sh);
    sw += wax; sh += way;
    int x = icon_pos_x[idx], y = icon_pos_y[idx];
    if(x < wax) x = wax;
    if(y < way) y = way;
    if(x > sw - ICON_SIZE) x = sw - ICON_SIZE;
    if(y > sh - ICON_SIZE - 24) y = sh - ICON_SIZE - 24;
    icon_pos_x[idx] = x; icon_pos_y[idx] = y;
    if(icon->kind == ICON_KIND_ITEM) ditems_pos_set(icon->file, x, y);
    else save_icon_layout();
}

/* Something dragged out of an Explorer window was released at the pointer. */
static void finish_explorer_drop(mouse_state_t *m) {
    char path[FSU_PATH_MAX];
    int i = 0;
    const char *src = dnd_path();
    while(src[i] && i < FSU_PATH_MAX - 1) { path[i] = src[i]; i++; }
    path[i] = '\0';

    window_t *win = wm_window_at(m->x, m->y);
    if(win) {
        if(win->on_drop) {
            int cx, cy, cw, ch;
            wm_get_client_rect(win, &cx, &cy, &cw, &ch);
            win->on_drop(win, m->x - cx, m->y - cy, path);
        }
        return;
    }
    if(over_taskbar(m->x, m->y)) return;

    int tgt = drop_target_icon_at(m->x, m->y, -1);
    if(tgt >= 0 && desktop_icons[tgt].kind == ICON_KIND_RECYCLE_BIN) {
        if(!fileops_trash(path)) desktop_toast("Could not move that to the Recycle Bin");
        refresh_items_now();
        return;
    }

    const char *dest = DESKTOP_FOLDER_PATH;
    int onto_folder = 0;
    if(tgt >= 0) {
        desktop_item_t *folder = item_of(&desktop_icons[tgt]);
        if(folder && folder->kind == DI_FOLDER) { dest = folder->path; onto_folder = 1; }
    }

    char new_path[FSU_PATH_MAX];
    if(fileops_move_into(path, dest, new_path, sizeof(new_path))) {
        if(!onto_folder) {
            /* The icon appears where it was dropped. */
            char parent[FSU_PATH_MAX], name[48];
            fsu_split(new_path, parent, sizeof(parent), name, sizeof(name));
            ditems_pos_set(name, m->x - ICON_SIZE / 2, m->y - ICON_SIZE / 2);
        }
        refresh_items_now();
    }
    else {
        desktop_toast("Could not move that to the desktop");
    }
}

/* The dragged item follows the pointer. */
static void draw_dnd_ghost(mouse_state_t *m) {
    if(!dnd_active()) return;
    ditem_image_t im = ditems_icon_for_path(dnd_path(), dnd_is_dir());
    int x = m->x + 12, y = m->y + 10;
    if(im.pixels) gfx_blit_scaled_argb_alpha(x, y, 32, 32, (uint32_t *)im.pixels, (uint32_t)im.w, (uint32_t)im.h);
    const char *label = dnd_label();
    int n = (int)strlen(label); if(n > 20) n = 20;
    char text[24]; for(int i = 0; i < n; i++) text[i] = label[i]; text[n] = '\0';
    gfx_blend_rounded_rect(x + 36, y + 7, n * GFX_CHAR_COLS + 12, 22, 6, 0xC0202024);
    gfx_draw_string(x + 42, y + 10, text, 0xFFF2F2F5);
}

/* Dragging a window against a screen edge snaps it: left/right edge = that half
 * of the work area, top edge = maximize (the same idea as Windows 10 "Aero Snap"). */
static int snap_zone(const mouse_state_t *m, int *x, int *y, int *w, int *h) {
    if(!drag_window || drag_window->maximized) return 0;
    int wx, wy, ww, wh;
    taskbar_work_area(&wx, &wy, &ww, &wh);
    const int edge = 3;
    if(m->y <= wy + edge)              { *x = wx; *y = wy; *w = ww; *h = wh; return 3; }
    if(m->x <= wx + edge)              { *x = wx; *y = wy; *w = ww / 2; *h = wh; return 1; }
    if(m->x >= wx + ww - 1 - edge)     { *x = wx + ww / 2; *y = wy; *w = ww - ww / 2; *h = wh; return 2; }
    return 0;
}

static void draw_snap_preview(const mouse_state_t *m) {
    int x, y, w, h;
    if(!snap_zone(m, &x, &y, &w, &h)) return;
    gfx_blend_rounded_rect(x + 6, y + 6, w - 12, h - 12, 10, 0x304CC2FF);
    gfx_draw_rounded_outline(x + 6, y + 6, w - 12, h - 12, 10, 0x904CC2FF);
}

static void handle_mouse_button_up(mouse_state_t *m) {
    taskbar_mouse_up();
    if(drag_window) {
        int x, y, w, h;
        int zone = snap_zone(m, &x, &y, &w, &h);
        if(zone == 3) wm_toggle_maximize(drag_window);
        else if(zone) wm_resize_window(drag_window, x, y, w, h);
    }
    if(client_drag_window && client_drag_window->on_mouse_up) {
        int cx, cy, cw, ch;
        wm_get_client_rect(client_drag_window, &cx, &cy, &cw, &ch);
        (void)cw; (void)ch;
        client_drag_window->on_mouse_up(client_drag_window, m->x - cx, m->y - cy);
    }

    drag_window = NULL;
    client_drag_window = NULL;
    resize_window = NULL;
    resize_edge = WM_RESIZE_NONE;

    if(dnd_active()) {
        finish_explorer_drop(m);
        dnd_end();
    }

    if(dragging_icon_index >= 0) {
        int di = dragging_icon_index;
        dragging_icon_index = -1;
        /* Only a real drag does anything: a plain click that merely
         * selected the icon must not touch the disk. */
        if(drag_moved) finish_icon_drag(di, m);
        drag_moved = 0;
    }

    if(rubber_band_active) {
        int x0 = rubber_band_start_x < rubber_band_x ? rubber_band_start_x : rubber_band_x;
        int y0 = rubber_band_start_y < rubber_band_y ? rubber_band_start_y : rubber_band_y;
        int x1 = rubber_band_start_x > rubber_band_x ? rubber_band_start_x : rubber_band_x;
        int y1 = rubber_band_start_y > rubber_band_y ? rubber_band_start_y : rubber_band_y;

        /* A marquee that never actually moved (a plain click that started
         * the rubber-band machinery but was released in place) shouldn't
         * select anything -- it's functionally just a click on empty
         * desktop, which already cleared the selection on mouse-down. */
        if(x1 - x0 > 2 || y1 - y0 > 2) {
            select_icons_in_rect(x0, y0, x1, y1);
        }

        rubber_band_active = 0;
    }
}

static void handle_mouse_motion(mouse_state_t *m) {
    taskbar_mouse_motion(m->x, m->y);
    if(dnd_active()) {            /* an Explorer drag is in flight: the desktop owns the gesture */
        client_drag_window = NULL;
        return;
    }
    if(drag_window) {
        wm_move_window(drag_window, m->x - drag_offset_x, m->y - drag_offset_y);
        return;
    }

    if(resize_window) {
        /* Computed from the drag's FIXED starting geometry plus total
         * mouse movement since, not incrementally each frame -- see
         * resize_start_*'s own comment for why. Left/top edges move the
         * window's origin as they shrink/grow (the opposite edge/corner
         * stays put); right/bottom edges only change w/h. wm_resize_window()
         * itself clamps w/h to WM_MIN_WIDTH/HEIGHT, but that clamp alone
         * would let a left/top drag's ORIGIN keep moving past the point
         * where the size clamp kicks in (the window would appear to
         * "slide" once it hits minimum size) -- computed the clamped
         * size first here so the origin math can account for it. */
        int dx = m->x - resize_start_mouse_x;
        int dy = m->y - resize_start_mouse_y;

        int new_x = resize_start_x, new_y = resize_start_y;
        int new_w = resize_start_w, new_h = resize_start_h;

        int involves_left = (resize_edge == WM_RESIZE_LEFT || resize_edge == WM_RESIZE_TOP_LEFT || resize_edge == WM_RESIZE_BOTTOM_LEFT);
        int involves_right = (resize_edge == WM_RESIZE_RIGHT || resize_edge == WM_RESIZE_TOP_RIGHT || resize_edge == WM_RESIZE_BOTTOM_RIGHT);
        int involves_top = (resize_edge == WM_RESIZE_TOP || resize_edge == WM_RESIZE_TOP_LEFT || resize_edge == WM_RESIZE_TOP_RIGHT);
        int involves_bottom = (resize_edge == WM_RESIZE_BOTTOM || resize_edge == WM_RESIZE_BOTTOM_LEFT || resize_edge == WM_RESIZE_BOTTOM_RIGHT);

        if(involves_right) {
            new_w = resize_start_w + dx;
        }
        if(involves_bottom) {
            new_h = resize_start_h + dy;
        }
        if(involves_left) {
            new_w = resize_start_w - dx;
            if(new_w < WM_MIN_WIDTH) new_w = WM_MIN_WIDTH;
            new_x = resize_start_x + (resize_start_w - new_w);
        }
        if(involves_top) {
            new_h = resize_start_h - dy;
            if(new_h < WM_MIN_HEIGHT) new_h = WM_MIN_HEIGHT;
            new_y = resize_start_y + (resize_start_h - new_h);
        }

        wm_resize_window(resize_window, new_x, new_y, new_w, new_h);
        return;
    }

    if(dragging_icon_index >= 0 && dragging_icon_index < DESKTOP_ICONS_MAX) {
        int screen_w = (int)gfx_width();
        int screen_h = (int)gfx_height();

        int new_x = m->x - icon_drag_offset_x;
        int new_y = m->y - icon_drag_offset_y;

        /* Keep icons fully on-screen and above the taskbar, so a drag
         * can't lose an icon off the visible desktop entirely. */
        int wax, way, waw, wah;
        taskbar_work_area(&wax, &way, &waw, &wah);
        if(new_x < wax) new_x = wax;
        if(new_y < way) new_y = way;
        if(new_x > wax + waw - ICON_SIZE) new_x = wax + waw - ICON_SIZE;
        if(new_y > way + wah - ICON_SIZE - 16) new_y = way + wah - ICON_SIZE - 16;
        (void)screen_w; (void)screen_h;

        if(!drag_moved && (iabs(m->x - drag_press_x) > 4 || iabs(m->y - drag_press_y) > 4)) drag_moved = 1;
        if(drag_moved) {
            icon_pos_x[dragging_icon_index] = new_x;
            icon_pos_y[dragging_icon_index] = new_y;
        }
        return;
    }

    if(rubber_band_active) {
        rubber_band_x = m->x;
        rubber_band_y = m->y;
        return;
    }

    if(client_drag_window && client_drag_window->on_drag) {
        int cx, cy, cw, ch;
        wm_get_client_rect(client_drag_window, &cx, &cy, &cw, &ch);
        /* Clamp into the client rect so a fast drag that overshoots the
         * window edge still reports a sane in-bounds coordinate instead
         * of a wildly out-of-range one -- apps like Paint expect
         * on_drag points to be usable canvas coordinates. */
        int rel_x = m->x - cx;
        int rel_y = m->y - cy;
        if(rel_x < 0) rel_x = 0;
        if(rel_y < 0) rel_y = 0;
        if(rel_x >= cw) rel_x = cw - 1;
        if(rel_y >= ch) rel_y = ch - 1;
        client_drag_window->on_drag(client_drag_window, rel_x, rel_y);
    }
}

/* Centers `message` horizontally using the fixed-width font's known
 * glyph size (GFX_CHAR_COLS, see gfx.h) -- there's no gfx_measure_string
 * helper, but a monospace font makes strlen()*GFX_CHAR_COLS exact, so
 * one isn't needed. */
static int centered_text_x(const char *message) {
    int text_w = (int)strlen(message) * GFX_CHAR_COLS;
    return ((int)gfx_width() - text_w) / 2;
}

void desktop_show_transition_screen(const char *message) {
    gfx_clear(0xFF000000);
    int x = centered_text_x(message);
    int y = ((int)gfx_height() - GFX_CHAR_ROWS) / 2;
    gfx_draw_string(x, y, message, 0xFFFFFFFF);
    gfx_present();
}

void desktop_enter_sleep(void) {
    const char *message = "Sleeping - press any key or click to wake";
    gfx_clear(0xFF000000);
    int x = centered_text_x(message);
    int y = ((int)gfx_height() - GFX_CHAR_ROWS) / 2;
    gfx_draw_string(x, y, message, 0xFFC0C0C0);
    gfx_present();

    /* Drain anything already pending so the very key/click that opened
     * this state (or was buffered right before it) doesn't immediately
     * wake it back up again. */
    while(try_get_ascii_char() != 0) { }
    mouse_state_t *m = mouse_get_state();
    m->updated = 0;

    while(1) {
        if(try_get_ascii_char() != 0) break;
        m = mouse_get_state();
        if(m->updated && mouse_button_down(MOUSE_BUTTON_LEFT)) break;
        pause();
    }

    /* No explicit "redraw everything" call needed on the way out --
     * desktop_run()'s own loop redraws the full frame (background,
     * icons, windows, taskbar, cursor) from scratch every iteration
     * regardless of what was on screen last, so simply returning here
     * and letting that loop continue is enough to restore the desktop. */
}

/* ---- CPU load estimate (for the Task Manager) ----
 * The main loop halts the CPU (sti; hlt) whenever nothing needs
 * redrawing, so "busy" is simply the share of time NOT spent in hlt,
 * measured with the TSC. Sampled twice a second into a 60-entry ring. */
#define CPU_HISTORY_LEN 60
static uint8_t cpu_hist[CPU_HISTORY_LEN];
static int cpu_hist_count = 0;
static int cpu_now = 0;
static uint64_t cpu_idle_acc = 0;
static uint64_t cpu_last_tsc = 0;
static long long cpu_last_tick = 0;

static inline uint64_t read_tsc(void) {
    uint32_t lo, hi;
    __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32) | lo;
}

static void cpu_sample_update(long long now_tick) {
    if(cpu_last_tsc == 0) { cpu_last_tsc = read_tsc(); cpu_last_tick = now_tick; return; }
    if(now_tick - cpu_last_tick < 5) return;
    uint64_t now = read_tsc();
    /* >> 12 keeps everything in 32-bit range: no 64-bit divide needed. */
    uint32_t total = (uint32_t)((now - cpu_last_tsc) >> 12);
    uint32_t idle = (uint32_t)(cpu_idle_acc >> 12);
    int busy = 0;
    if(total > 0) {
        if(idle > total) idle = total;
        busy = 100 - (int)((idle * 100u) / total);
    }
    if(busy < 0) busy = 0;
    if(busy > 100) busy = 100;
    cpu_now = busy;
    if(cpu_hist_count < CPU_HISTORY_LEN) cpu_hist[cpu_hist_count++] = (uint8_t)busy;
    else {
        for(int i = 1; i < CPU_HISTORY_LEN; i++) cpu_hist[i - 1] = cpu_hist[i];
        cpu_hist[CPU_HISTORY_LEN - 1] = (uint8_t)busy;
    }
    cpu_idle_acc = 0;
    cpu_last_tsc = now;
    cpu_last_tick = now_tick;
}

int desktop_cpu_usage(void) { return cpu_now; }

int desktop_cpu_history(uint8_t *out, int max) {
    int n = cpu_hist_count < max ? cpu_hist_count : max;
    for(int i = 0; i < n; i++) out[i] = cpu_hist[cpu_hist_count - n + i];
    return n;
}

/* ---- inline rename ------------------------------------------------- */
static void start_rename_item(const char *file) {
    int i = ditems_find(file);
    if(i < 0) return;
    const desktop_item_t *it = ditems_get(i);
    int c = 0;
    while(file[c] && c < 47) { rename_file[c] = file[c]; c++; }
    rename_file[c] = '\0';
    /* A shortcut's .lnk is an implementation detail: edit just its name. */
    const char *src = it->kind == DI_SHORTCUT ? it->label : it->file;
    c = 0;
    while(src[c] && c < (int)sizeof(rename_buf) - 1) { rename_buf[c] = src[c]; c++; }
    rename_buf[c] = '\0';
    rename_len = c;
    rename_active = 1;
    desktop_has_focus = 1;
    desktop_focus_snapshot = wm_focused_window();
}

static void commit_rename(void) {
    rename_active = 0;
    int i = ditems_find(rename_file);
    if(i < 0 || rename_len == 0) return;
    const desktop_item_t *it = ditems_get(i);
    char new_name[64]; int n = 0;
    for(int k = 0; k < rename_len && n < 50; k++) new_name[n++] = rename_buf[k];
    if(it->kind == DI_SHORTCUT) { new_name[n++] = '.'; new_name[n++] = 'l'; new_name[n++] = 'n'; new_name[n++] = 'k'; }
    new_name[n] = '\0';
    if(strcmp(new_name, it->file) == 0) return;
    char old_file[48]; int c = 0; while(it->file[c] && c < 47) { old_file[c] = it->file[c]; c++; } old_file[c] = '\0';
    if(fileops_rename(it->path, new_name)) {
        ditems_pos_rename(old_file, new_name);
        refresh_items_now();
        select_item_by_file(new_name);
    }
    else desktop_toast("Could not rename (name already used?)");
}

static void rename_key(char c) {
    if(c == '\n') { commit_rename(); return; }
    if(c == 27) { rename_active = 0; return; }
    if((c == 8 || c == 127) && rename_len > 0) { rename_buf[--rename_len] = '\0'; return; }
    if(c >= 32 && c < 127 && c != '/' && c != '\\' && rename_len < (int)sizeof(rename_buf) - 1) {
        rename_buf[rename_len++] = c; rename_buf[rename_len] = '\0';
    }
}

/* Keys while the desktop itself has focus. Returns 1 if consumed. */
static int desktop_key(char c) {
    int sel = -1, nsel = 0;
    for(int i = 0; i < desktop_icon_count; i++) if(icon_selected[i]) { sel = i; nsel++; }

    if(c == 22) { action_paste_desktop(NULL); return 1; }                       /* Ctrl+V */
    if(nsel == 0) return 0;

    if(c == KEY_DELETE) {
        for(int i = desktop_icon_count - 1; i >= 0; i--) {
            if(!icon_selected[i]) continue;
            if(desktop_icons[i].kind == ICON_KIND_ITEM || desktop_icons[i].kind == ICON_KIND_APP) action_remove_desktop_icon(&desktop_icons[i]);
        }
        return 1;
    }
    if(nsel != 1) return 0;
    desktop_icon_t *icon = &desktop_icons[sel];
    if(c == KEY_F2 && icon->kind == ICON_KIND_ITEM) { start_rename_item(icon->file); return 1; }
    if(c == 3 && icon->kind == ICON_KIND_ITEM) { action_item_copy(icon); return 1; }     /* Ctrl+C */
    if(c == 24 && icon->kind == ICON_KIND_ITEM) { action_item_cut(icon); return 1; }     /* Ctrl+X */
    if(c == '\n') { launch_desktop_icon(icon); return 1; }
    return 0;
}

void desktop_refresh_items(void) { refresh_items_now(); }

/* ---- small system shortcuts ------------------------------------------------ */

/* Alt+Tab: bring the next window to the front (restoring it if minimized). */
static void switch_next_window(void) {
    int n = wm_window_count();
    if(n < 2) { if(n == 1) { window_t *w = wm_window_at_index(0); if(w && w->minimized) wm_restore_window(w); } return; }
    window_t *cur = wm_focused_window();
    int start = 0;
    for(int i = 0; i < n; i++) if(wm_window_at_index(i) == cur) { start = i; break; }
    for(int k = 1; k <= n; k++) {
        window_t *w = wm_window_at_index((start + k) % n);
        if(!w || !w->in_use || w == cur) continue;
        if(w->minimized) wm_restore_window(w); else wm_focus(w);
        char msg[64]; int m = 0;
        const char *pre = "Switched to ";
        while(*pre) msg[m++] = *pre++;
        for(int c = 0; w->title[c] && m < 62; c++) msg[m++] = w->title[c];
        msg[m] = 0;
        desktop_toast(msg);
        return;
    }
}

static void put_le32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }

/* Print Screen: writes the current frame as a 24-bit BMP to
 * /Users/User/Pictures/Screenshots/Screenshot_<date>_<time>.bmp */
static void take_screenshot(void) {
    gfx_surface_t *bb = gfx_backbuffer();
    if(!bb || !bb->pixels) { desktop_toast("Screenshot failed"); return; }
    uint32_t w = bb->width, h = bb->height;
    uint32_t row = (w * 3 + 3) & ~3u;
    uint32_t total = 54 + row * h;
    uint8_t *buf = (uint8_t *)kmalloc(total);
    if(!buf) { desktop_toast("Screenshot failed: out of memory"); return; }
    memset(buf, 0, 54);
    buf[0] = 'B'; buf[1] = 'M';
    put_le32(buf + 2, total); put_le32(buf + 10, 54); put_le32(buf + 14, 40);
    put_le32(buf + 18, w); put_le32(buf + 22, h);
    buf[26] = 1; buf[28] = 24; put_le32(buf + 34, row * h);
    for(uint32_t y = 0; y < h; y++) {
        const uint32_t *src = bb->pixels + (h - 1 - y) * w;      /* BMP is stored bottom-up */
        uint8_t *dst = buf + 54 + y * row;
        for(uint32_t x = 0; x < w; x++) { uint32_t px = src[x]; dst[x * 3] = (uint8_t)px; dst[x * 3 + 1] = (uint8_t)(px >> 8); dst[x * 3 + 2] = (uint8_t)(px >> 16); }
    }
    fsu_mkdir("/Users"); fsu_mkdir("/Users/User"); fsu_mkdir("/Users/User/Pictures"); fsu_mkdir("/Users/User/Pictures/Screenshots");
    rtc_time_t t; rtc_date_t d; rtc_read_time(&t); rtc_read_date(&d);
    char path[96];
    sprintf(path, "/Users/User/Pictures/Screenshots/Screenshot_%04d%02d%02d_%02d%02d%02d.bmp", d.year, d.month, d.day, t.hours, t.minutes, t.seconds);
    int ok = fsu_write_file(path, buf, total);
    kfree(buf);
    desktop_toast(ok ? "Screenshot saved to Pictures/Screenshots" : "Could not save the screenshot");
}

static int dispatch_keyboard_input() {
    char c;
    int consumed = 0;
    /* Drain everything the keyboard buffer has accumulated since the
     * last frame, rather than just one character -- otherwise fast
     * typing could get throttled to the desktop's frame rate. */
    while((c = try_get_ascii_char()) != 0) {
        consumed++;
        if(c == KEY_TASKMGR) { launch_taskmgr(); continue; }   /* Ctrl+Shift+Esc */
        if(c == KEY_ALTTAB) { switch_next_window(); continue; }
        if(c == KEY_PRTSCN) { take_screenshot(); continue; }
        if(c == KEY_WIN) { startmenu_toggle(); continue; }
        if(startmenu_is_open()) { startmenu_key(c); continue; }
        if(rename_active) { rename_key(c); continue; }
        if(desktop_has_focus && wm_focused_window() != desktop_focus_snapshot) desktop_has_focus = 0;
        if(desktop_has_focus && desktop_key(c)) continue;
        window_t *focused = wm_focused_window();
        if(focused && focused->on_key) {
            focused->on_key(focused, c);
        }
    }
    return consumed;
}

/* One iteration of the desktop: input, window ticks, and (if anything
 * changed) a full redraw + present; otherwise it halts until the next
 * interrupt. It is a standalone function so that it can be driven from
 * two places: desktop_run()'s endless loop, and -- through
 * desktop_pump() -- from inside a syscall while a .app is running, which
 * is what keeps the whole desktop (window dragging, other windows, the
 * taskbar, cursor animation) alive during an app's own loop. All state it
 * touches is file-static for exactly that reason: a nested call must see
 * and update the same state the outer one does. */
/* ---- toast: short message pill above the taskbar ----
 * Used for things the user must be told but that don't deserve a dialog:
 * "foo.app: file not found", "bar stopped: page fault". */
static char toast_text[120];
static uint32_t toast_until_ms = 0;
static int toast_active = 0;

void desktop_toast(const char *msg) {
    int i = 0;
    while(msg && msg[i] && i < (int)sizeof(toast_text) - 1) { toast_text[i] = msg[i]; i++; }
    toast_text[i] = '\0';
    toast_until_ms = pit_get_ms() + 4500;
    toast_active = 1;
}

static void draw_toast(void) {
    if(!toast_active) return;
    if((int32_t)(toast_until_ms - pit_get_ms()) <= 0) { toast_active = 0; return; }
    int len = (int)strlen(toast_text);
    int w = len * GFX_CHAR_COLS + 44, h = 38;
    int sw = (int)gfx_width(), sh = (int)gfx_height();
    if(w > sw - 20) w = sw - 20;
    int wax, way, waw, wah;
    taskbar_work_area(&wax, &way, &waw, &wah);
    int x = wax + (waw - w) / 2, y = way + wah - h - 18;
    (void)sw; (void)sh;
    gfx_draw_shadow(x, y, w, h, 10, 18, 5, 110);
    gfx_blend_rounded_rect(x, y, w, h, 10, 0xF2262629);
    gfx_draw_rounded_outline(x, y, w, h, 10, 0x30FFFFFF);
    gfx_fill_rounded_rect(x + 10, y + 9, 3, h - 18, 1, 0xFFFFB454);
    gfx_draw_string(x + 24, y + (h - GFX_CHAR_ROWS) / 2, toast_text, 0xFFF2F2F5);
}

static uint8_t prev_left = 0;
static uint8_t prev_right = 0;
static long long last_drawn_tick = -1;
static int force_redraws = 3; /* first few frames always drawn */
static int last_cursor_kind = -1;
static int last_cursor_token = -1;

static int scene_ready = 0;            /* the back buffer holds a finished frame (without cursor) */
static uint32_t last_full_ms = 0;      /* when the last full redraw happened */
static uint8_t hover_pending = 0;      /* the pointer moved since the last full redraw */
static long long last_drawn_sec = -1;

/* Software brightness as an alpha (0 = untouched). */
static uint32_t brightness_dim_alpha(void) {
    settings_t *s = settings_current();
    if(s->brightness >= 100) return 0;
    int dim = 100 - s->brightness;
    if(dim > 100) dim = 100;
    return (uint32_t)(dim * 255 / 100);
}

static cursor_image_t *current_cursor_image(void) {
    cursor_image_t *img = cursor_set_get(current_cursor_kind);
    if(!img) {
        /* The specific shape's file was missing/unparseable -- fall back to
         * the default arrow (which itself always has a built-in fallback,
         * see cursor_set_get()) rather than no cursor at all. */
        img = cursor_set_get(CURSOR_DEFAULT);
    }
    return img;
}

/* ---- "not responding" watchdog -------------------------------------------------
 * desktop_heartbeat_ms is refreshed by every desktop frame and every desktop_pump()
 * an app makes. The timer interrupt checks it every 50 ms: if nothing has beat for
 * 700 ms the program (or the desktop) is stuck in a loop, so the interrupt shows
 * the animated busy pointer at the mouse position -- still following the hand,
 * because the mouse interrupt moves it. */
static volatile uint32_t desktop_heartbeat_ms = 0;
static volatile uint8_t watchdog_shown = 0;

static void desktop_cursor_watchdog(void) {
    uint32_t now = pit_get_ms();
    if(!scene_ready) return;
    if((uint32_t)(now - desktop_heartbeat_ms) < 700) return;
    cursor_image_t *img = cursor_set_peek(CURSOR_BUSY);
    if(!img) img = cursor_set_peek(CURSOR_WORKING);
    if(!img) return;
    mouse_state_t *m = mouse_get_state();
    gfx_cursor_irq_set(img->pixels, (int)img->width, (int)img->height, img->hotspot_x, img->hotspot_y, m->x, m->y);
    watchdog_shown = 1;
}

/* Draws just the pointer on the already-presented scene. */
static void cursor_fast_update(mouse_state_t *m) {
    cursor_image_t *img = current_cursor_image();
    if(img) gfx_move_cursor(m->x, m->y, img->pixels, (int)img->width, (int)img->height,
                            img->hotspot_x, img->hotspot_y, brightness_dim_alpha());
}

/* Called from long blocking operations (file reads) so the busy spinner keeps
 * turning even though the desktop loop cannot run: no redraw, no input --
 * just the cursor sprite. */
void desktop_busy_tick(void) {
    desktop_heartbeat_ms = pit_get_ms();       /* a long operation that still pumps the spinner is alive */
    if(!scene_ready) return;
    static uint32_t last = 0;
    uint32_t now = pit_get_ms();
    if((uint32_t)(now - last) < 16) return;
    last = now;
    mouse_state_t *m = mouse_get_state();
    current_cursor_kind = pick_cursor_for_position(m);
    cursor_fast_update(m);
}

/* While anything is being dragged, or a menu follows the pointer, motion
 * must redraw the scene; plain hovering only needs the cursor moved. */
static int motion_needs_redraw(void) {
    return mouse_button_down(MOUSE_BUTTON_LEFT) || client_drag_window || drag_window || resize_window ||
           rubber_band_active || dragging_icon_index >= 0 || dnd_active() || startmenu_is_open() ||
           context_menu_is_open() || taskbar_volume_open();
}

static void desktop_frame(void) {
    mouse_state_t *m = mouse_get_state();
    int dirty = 0;          /* scene must be rebuilt */
    int cursor_moved = 0;   /* pointer position changed */
    uint32_t now_ms = pit_get_ms();
    desktop_heartbeat_ms = now_ms;
    if(watchdog_shown) { watchdog_shown = 0; dirty = 1; }   /* the stuck program is back: draw a proper frame + pointer */

    /* Pick up files created/renamed/deleted in the Desktop folder (by
     * Explorer, a drop, or a program) -- cheap: it only compares a hash. */
    if(now_ms - last_item_poll_ms > 600) {
        last_item_poll_ms = now_ms;
        if(ditems_poll()) { sync_item_icons(); dirty = 1; }
    }

    if(m->updated) {
        cursor_moved = 1;
        int left_now = mouse_button_down(MOUSE_BUTTON_LEFT);
        int right_now = mouse_button_down(MOUSE_BUTTON_RIGHT);

        /* Commit the new button state BEFORE running the handlers: a
         * handler can launch an app, whose syscalls re-enter this very
         * function, and that nested call must not see stale prev_*. */
        uint8_t was_left = prev_left, was_right = prev_right;
        prev_left = (uint8_t)left_now;
        prev_right = (uint8_t)right_now;
        m->updated = 0;

        handle_mouse_motion(m);

        if(m->wheel) {
            int notches = m->wheel;
            m->wheel = 0;
            dirty = 1;
            if(startmenu_is_open()) startmenu_scroll(notches);
            else {
                window_t *ww = wm_window_at(m->x, m->y);
                if(ww && ww->on_scroll) {
                    int cx, cy, cw, ch;
                    wm_get_client_rect(ww, &cx, &cy, &cw, &ch);
                    ww->on_scroll(ww, m->x - cx, m->y - cy, notches);
                }
            }
        }

        if(left_now && !was_left) {
            handle_mouse_button_down(m);
            dirty = 1;
        }
        else if(!left_now && was_left) {
            handle_mouse_button_up(m);
            dirty = 1;
        }

        if(right_now && !was_right) {
            handle_mouse_right_click(m);
            dirty = 1;
        }

        if(motion_needs_redraw()) dirty = 1;
        else hover_pending = 1;
    }

    if(dispatch_keyboard_input() > 0) dirty = 1;
    wm_tick_all();

    /* On-demand rendering. A full redraw (windows, shadows, taskbar, a 3.6 MB
     * copy to the screen) happens only when something visible changed:
     *   - input that acts (clicks, keys, drags, open menus);
     *   - hover feedback, at most ~14 times a second while the pointer moves,
     *     and once more when it stops;
     *   - the clock: once a second if every window is static, otherwise at
     *     the 10 Hz tick for windows with live content (media progress,
     *     stopwatch, caret blink, apps).
     * A pointer that merely moves or animates does NOT redraw the scene any
     * more: only its own few hundred pixels are updated (gfx_move_cursor).
     * With nothing at all to do the CPU halts until the next interrupt (the
     * PIT fires at 100 Hz, so the halt is at most 10 ms). */
    long long now_tick = pit_get_ticks();
    cpu_sample_update(now_tick);
    int all_static = wm_all_static() && !rename_active && !startmenu_is_open();
    if(all_static) { if(now_tick / 10 != last_drawn_sec) dirty = 1; }
    else if(now_tick != last_drawn_tick) dirty = 1;
    if(wm_anim_step() | startmenu_animating()) dirty = 1;     /* window / Start menu animations: redraw every frame */
    if(force_redraws > 0) { dirty = 1; force_redraws--; }
    if(hover_pending && (uint32_t)(now_ms - last_full_ms) >= 70) dirty = 1;

    current_cursor_kind = pick_cursor_for_position(m);
    int token = cursor_set_animation_token(current_cursor_kind);
    int cursor_changed = ((int)current_cursor_kind != last_cursor_kind || token != last_cursor_token);
    last_cursor_kind = (int)current_cursor_kind;
    last_cursor_token = token;

    if(!dirty) {
        if(scene_ready && (cursor_moved || cursor_changed)) {
            cursor_fast_update(m);
            return;
        }
        uint64_t idle_start = read_tsc();
        __asm__ volatile("sti; hlt");
        cpu_idle_acc += read_tsc() - idle_start;
        return;
    }
    last_drawn_tick = now_tick;
    last_drawn_sec = now_tick / 10;
    last_full_ms = now_ms;
    hover_pending = 0;

    draw_desktop_background();
    draw_desktop_icons();
    draw_rubber_band();
    wm_draw_all();
    draw_snap_preview(m);
    taskbar_draw();
    context_menu_draw();
    draw_dnd_ghost(m);
    draw_toast();

    /* Software brightness: darkens literally everything in the scene
     * (background, windows, taskbar). The cursor is dimmed by the same
     * amount when it is composited below, so it matches a real display's
     * backlight. There is no hardware brightness control this hobby OS can
     * reach (that is ACPI/embedded-controller territory), so this is a
     * deliberate software approximation -- see app_settings.c's
     * Personalization tab for the same point made to the user. */
    uint32_t dim = brightness_dim_alpha();
    if(dim) gfx_darken_screen(dim);

    cursor_image_t *cursor_img = current_cursor_image();
    if(cursor_img) {
        gfx_present_with_cursor(m->x, m->y, cursor_img->pixels, (int)cursor_img->width, (int)cursor_img->height,
                                cursor_img->hotspot_x, cursor_img->hotspot_y, dim);
    }
    else {
        gfx_present();
    }
    scene_ready = 1;
}

void desktop_pump(void) {
    desktop_frame();
}

void desktop_run() {
    if(!gfx_init()) {
        printf("desktop: gfx_init failed, cannot start graphical desktop.\n");
        return;
    }

    pit_set_status_line_enabled(0);

    boot_splash_status("Loading settings");
    settings_load();
    wm_init();
    boot_splash_status("Scanning applications");
    apps_init();
    taskbar_init();
    boot_splash_status("Loading wallpaper");
    load_background();
    boot_splash_status("Loading desktop");
    load_icon_layout();

    /* Folder users can fill with sub-folders and shortcuts to organise the
     * Start menu (see startmenu.h). Created on first boot so it is easy to find. */
    if(!fsu_stat("/Start Menu/Programs", NULL, NULL, NULL, NULL)) {
        fsu_mkdir("/Start Menu");
        fsu_mkdir("/Start Menu/Programs");
        fsu_mkdir("/Start Menu/Pinned");
    }
    refresh_items_now();

    cursor_set_preload();                 /* so the watchdog never has to load a file from an interrupt */
    mouse_set_move_hook(gfx_cursor_irq_move);
    desktop_heartbeat_ms = pit_get_ms();
    pit_set_hook_slot(2, desktop_cursor_watchdog);
    boot_splash_status("Starting desktop");
    boot_splash_stop();      /* start-up is done: the first desktop frame replaces the boot screen */

    while(1) {
        /* A .app waiting to be launched starts here -- at the very top of
         * the loop, never from inside a UI handler -- and this call only
         * returns when that app exits. While it runs, its syscalls keep
         * calling desktop_pump() so the desktop stays live. */
        app_loader_service();
        desktop_frame();
    }
}
