#include "stdint.h"
#include "stddef.h"
#include "app_taskmgr.h"
#include "window.h"
#include "gfx.h"
#include "ui.h"
#include "common.h"
#include "kheap.h"
#include "kernio.h"
#include "keyboard.h"
#include "pit.h"
#include "desktop.h"
#include "fs_util.h"
#include "cursor_set.h"
#include "driver_loader.h"

#define PAD 16
#define TAB_H 32
#define ROW_H 28
#define HEAD_H 26
#define FOOT_H 52
#define LIST_TOP (PAD + TAB_H + 14)

enum { TAB_PROCESSES = 0, TAB_PERFORMANCE, TAB_DRIVERS, TAB_COUNT };

typedef struct {
    int tab;
    window_t *sel;        /* selected window (by identity) */
    int scroll;           /* first visible row */
    int close_self;       /* deferred: destroying our own window mid-click is unsafe */
    int drv_sel;          /* selected row on the Drivers tab (-1 = none) */
    int drv_scroll;
} app_tm_t;

static int imin(int a, int b) { return a < b ? a : b; }

/* Collects all windows in stable (slot-address) order. */
static int collect(window_t **out, int max) {
    int n = 0;
    for(int i = 0; i < wm_window_count() && n < max; i++) {
        window_t *w = wm_window_at_index(i);
        if(w && w->in_use) out[n++] = w;
    }
    for(int i = 1; i < n; i++) {                 /* insertion sort by address */
        window_t *k = out[i]; int j = i - 1;
        while(j >= 0 && out[j] > k) { out[j + 1] = out[j]; j--; }
        out[j + 1] = k;
    }
    return n;
}

static int visible_rows(int ch) {
    int list_h = ch - LIST_TOP - HEAD_H - FOOT_H - PAD;
    int r = list_h / ROW_H;
    return r < 1 ? 1 : r;
}

static int sel_index(window_t **w, int n, window_t *sel) {
    for(int i = 0; i < n; i++) if(w[i] == sel) return i;
    return -1;
}

typedef struct { int x, y, w, h; } rect_t;

static void footer_buttons(int cw, int ch, rect_t *sw, rect_t *end) {
    int y = ch - FOOT_H + 8, bh = 34;
    *end = (rect_t){ cw - PAD - 110, y, 110, bh };
    *sw = (rect_t){ cw - PAD - 110 - 10 - 110, y, 110, bh };
}

static void tabs_rect(int cw, int *x, int *y, int *w, int *h) {
    *w = imin(cw - PAD * 2, 400); *x = PAD; *y = PAD; *h = TAB_H;
}

/* ------------------------- performance tab ------------------------- */
static void fmt_uptime(char *out) {
    int s = (int)(pit_get_ticks() / 10);
    sprintf(out, "%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
}

static void paint_performance(window_t *self, int cx, int cy, int cw, int ch) {
    (void)self;
    int y = LIST_TOP;
    int inner = cw - PAD * 2;

    /* CPU card with history graph */
    int cpu_h = imin(170, (ch - y - PAD) * 45 / 100);
    if(cpu_h < 110) cpu_h = 110;
    ui_card(cx + PAD, cy + y, inner, cpu_h, 10);
    gfx_draw_string(cx + PAD + 16, cy + y + 12, "CPU", UI_TEXT_DIM);
    char pct[8]; sprintf(pct, "%d%%", desktop_cpu_usage());
    gfx_draw_string_scaled(cx + PAD + 16, cy + y + 30, pct, UI_TEXT, 2);

    int gx = cx + PAD + 110, gy = cy + y + 14, gw = inner - 110 - 16, gh = cpu_h - 28;
    gfx_fill_rounded_rect(gx, gy, gw, gh, 6, 0xFF1A1A1E);
    for(int q = 1; q < 4; q++) gfx_blend_rounded_rect_ex(gx, gy + gh * q / 4, gw, 1, 0, 0x14FFFFFF, 0);

    uint8_t hist[60];
    int n = desktop_cpu_history(hist, 60);
    if(n >= 1) {
        double step = (double)gw / 59.0;
        double px = 0, py = 0;
        for(int i = 0; i < n; i++) {
            int slot = 60 - n + i;                       /* newest sample sits at the right edge */
            double x = gx + slot * step;
            double yv = gy + gh - (double)hist[i] * gh / 100.0;
            if(yv > gy + gh - 1) yv = gy + gh - 1;
            int colx = (int)x, colw = (int)step + 1;
            if(colx + colw > gx + gw) colw = gx + gw - colx;
            if(colw > 0 && yv < gy + gh) gfx_blend_rounded_rect_ex(colx, (int)yv, colw, gy + gh - (int)yv, 0, 0x264CC2FF, 0);
            if(i > 0) gfx_draw_line_thick(px, py, x, yv, 1.6, UI_ACCENT);
            px = x; py = yv;
        }
    }
    gfx_draw_rounded_outline(gx, gy, gw, gh, 6, UI_STROKE);
    y += cpu_h + 12;

    /* memory card */
    uint32_t total, freeb, allocs;
    kheap_get_stats(&total, &freeb, &allocs);
    uint32_t used = total > freeb ? total - freeb : 0;
    ui_card(cx + PAD, cy + y, inner, 76, 10);
    gfx_draw_string(cx + PAD + 16, cy + y + 12, "Memory (kernel heap)", UI_TEXT_DIM);
    char a[24], b[24], line[64];
    fsu_format_size(used, a, sizeof(a)); fsu_format_size(total, b, sizeof(b));
    sprintf(line, "%s of %s", a, b);
    ui_text_right(cx + PAD + inner - 16, cy + y + 12, line, UI_TEXT);
    /* KiB keeps the bar's 32-bit math in range */
    ui_bar(cx + PAD + 16, cy + y + 40, inner - 32, 10, used >> 10, total >> 10,
           (total && used * 10 / (total / 10 + 1) > 80) ? 0xFFFFB454 : UI_ACCENT);
    y += 76 + 12;

    /* system card */
    int sys_h = 4 * 22 + 20;
    if(y + sys_h > ch - PAD) return;
    ui_card(cx + PAD, cy + y, inner, sys_h, 10);
    char up[16], v[40];
    fmt_uptime(up);
    int rows_y = cy + y + 12;
    gfx_draw_string(cx + PAD + 16, rows_y, "Uptime", UI_TEXT_DIM);
    ui_text_right(cx + PAD + inner - 16, rows_y, up, UI_TEXT);
    sprintf(v, "%d x %d", (int)gfx_width(), (int)gfx_height());
    gfx_draw_string(cx + PAD + 16, rows_y + 22, "Display", UI_TEXT_DIM);
    ui_text_right(cx + PAD + inner - 16, rows_y + 22, v, UI_TEXT);
    sprintf(v, "%d of %d", wm_window_count(), WM_MAX_WINDOWS);
    gfx_draw_string(cx + PAD + 16, rows_y + 44, "Windows", UI_TEXT_DIM);
    ui_text_right(cx + PAD + inner - 16, rows_y + 44, v, UI_TEXT);
    sprintf(v, "%d", (int)allocs);
    gfx_draw_string(cx + PAD + 16, rows_y + 66, "Heap allocations", UI_TEXT_DIM);
    ui_text_right(cx + PAD + inner - 16, rows_y + 66, v, UI_TEXT);
}

/* -------------------------- processes tab -------------------------- */
static void paint_processes(window_t *self, app_tm_t *t, int cx, int cy, int cw, int ch) {
    window_t *w[WM_MAX_WINDOWS];
    int n = collect(w, WM_MAX_WINDOWS);
    int vis = visible_rows(ch);
    if(t->sel && sel_index(w, n, t->sel) < 0) t->sel = NULL;
    if(t->scroll > n - vis) t->scroll = n - vis;
    if(t->scroll < 0) t->scroll = 0;

    int inner = cw - PAD * 2;
    int list_h = HEAD_H + vis * ROW_H + 8;
    ui_card(cx + PAD, cy + LIST_TOP, inner, list_h, 10);

    int col_status = PAD + inner * 55 / 100, col_size = PAD + inner - 16;
    gfx_draw_string(cx + PAD + 16, cy + LIST_TOP + 6, "Name", UI_TEXT_FAINT);
    gfx_draw_string(cx + col_status, cy + LIST_TOP + 6, "Status", UI_TEXT_FAINT);
    ui_text_right(cx + col_size, cy + LIST_TOP + 6, "Size", UI_TEXT_FAINT);
    gfx_blend_rounded_rect_ex(cx + PAD + 10, cy + LIST_TOP + HEAD_H - 2, inner - 20, 1, 0, UI_STROKE, 0);

    int rx, ry, hov = ui_hover_pos(self, cx, cy, &rx, &ry);
    window_t *focused = wm_focused_window();
    for(int r = 0; r < vis && t->scroll + r < n; r++) {
        window_t *win = w[t->scroll + r];
        int ry0 = LIST_TOP + HEAD_H + r * ROW_H;
        int over = hov && ui_in(rx, ry, PAD + 6, ry0, inner - 12, ROW_H);
        if(win == t->sel) gfx_fill_rounded_rect(cx + PAD + 6, cy + ry0, inner - 12, ROW_H - 2, 6, 0xFF3A3A44);
        else if(over) gfx_blend_rounded_rect(cx + PAD + 6, cy + ry0, inner - 12, ROW_H - 2, 6, 0x1CFFFFFF);

        int ty = cy + ry0 + (ROW_H - 2 - GFX_CHAR_ROWS) / 2;
        char name[40]; int len = 0;
        int maxc = (col_status - 16 - 16) / GFX_CHAR_COLS;
        while(win->title[len] && len < 39) { name[len] = win->title[len]; len++; }
        name[len] = 0;
        if(len > maxc && maxc > 3) { name[maxc - 2] = '.'; name[maxc - 1] = '.'; name[maxc] = 0; }
        gfx_draw_string(cx + PAD + 16, ty, name, UI_TEXT);

        const char *st = win->minimized ? "Minimized" : (win == focused ? "Active" : "Running");
        uint32_t dot = win->minimized ? UI_TEXT_FAINT : (win == focused ? UI_ACCENT : UI_OK);
        gfx_fill_circle(cx + col_status + 4, ty + 8, 4, dot);
        gfx_draw_string(cx + col_status + 16, ty, st, win->minimized ? UI_TEXT_DIM : UI_TEXT);

        char sz[20]; sprintf(sz, "%dx%d", win->w, win->h);
        ui_text_right(cx + col_size, ty, sz, UI_TEXT_DIM);
    }
    if(n > vis) {   /* slim scrollbar */
        int bar_h = (list_h - HEAD_H - 12) * vis / n; if(bar_h < 16) bar_h = 16;
        int track = list_h - HEAD_H - 12 - bar_h;
        int by = LIST_TOP + HEAD_H + 4 + (n - vis > 0 ? track * t->scroll / (n - vis) : 0);
        gfx_fill_rounded_rect(cx + PAD + inner - 8, cy + by, 3, bar_h, 1, 0xFF5A5A66);
    }

    /* footer */
    char summary[40]; sprintf(summary, "%d window%s open", n, n == 1 ? "" : "s");
    gfx_draw_string(cx + PAD, cy + ch - FOOT_H + 8 + 9, summary, UI_TEXT_DIM);
    rect_t sw, en; footer_buttons(cw, ch, &sw, &en);
    int down = ui_mouse_down();
    int has = t->sel != NULL;
    int o1 = hov && has && ui_in(rx, ry, sw.x, sw.y, sw.w, sw.h);
    int o2 = hov && has && ui_in(rx, ry, en.x, en.y, en.w, en.h);
    ui_button(cx + sw.x, cy + sw.y, sw.w, sw.h, "Switch to", has ? UI_BTN_NORMAL : UI_BTN_FLAT, o1, o1 && down);
    ui_button(cx + en.x, cy + en.y, en.w, en.h, "End task", has ? UI_BTN_DANGER : UI_BTN_FLAT, o2, o2 && down);
}

/* -------------------------- drivers tab --------------------------- */
static int driver_rows_visible(int ch) {
    int r = (ch - LIST_TOP - HEAD_H - FOOT_H - PAD) / ROW_H;
    return r < 1 ? 1 : r;
}

static uint32_t driver_status_color(driver_status_t st) {
    switch(st) {
        case DRV_STATUS_ACTIVE: return UI_OK;
        case DRV_STATUS_STANDBY: return UI_ACCENT;
        case DRV_STATUS_NOT_PRESENT: return 0xFFFFB454;
        case DRV_STATUS_DISABLED: return UI_TEXT_FAINT;
        default: return 0xFFFF6B5E;
    }
}

static void paint_drivers(window_t *self, app_tm_t *t, int cx, int cy, int cw, int ch) {
    int n = driver_count(), vis = driver_rows_visible(ch);
    if(t->drv_scroll > n - vis) t->drv_scroll = n - vis;
    if(t->drv_scroll < 0) t->drv_scroll = 0;
    int inner = cw - PAD * 2;
    int list_h = HEAD_H + vis * ROW_H + 8;
    ui_card(cx + PAD, cy + LIST_TOP, inner, list_h, 10);

    int col_cat = PAD + inner * 46 / 100, col_stat = PAD + inner * 66 / 100;
    gfx_draw_string(cx + PAD + 16, cy + LIST_TOP + 6, "Driver", UI_TEXT_FAINT);
    gfx_draw_string(cx + col_cat, cy + LIST_TOP + 6, "Type", UI_TEXT_FAINT);
    gfx_draw_string(cx + col_stat, cy + LIST_TOP + 6, "Status", UI_TEXT_FAINT);
    gfx_blend_rounded_rect_ex(cx + PAD + 10, cy + LIST_TOP + HEAD_H - 2, inner - 20, 1, 0, UI_STROKE, 0);

    int rx, ry, hov = ui_hover_pos(self, cx, cy, &rx, &ry);
    for(int r = 0; r < vis && t->drv_scroll + r < n; r++) {
        int idx = t->drv_scroll + r;
        const driver_info_t *d = driver_get(idx);
        int ry0 = LIST_TOP + HEAD_H + r * ROW_H;
        int over = hov && ui_in(rx, ry, PAD + 6, ry0, inner - 12, ROW_H);
        if(idx == t->drv_sel) gfx_fill_rounded_rect(cx + PAD + 6, cy + ry0, inner - 12, ROW_H - 2, 6, 0xFF3A3A44);
        else if(over) gfx_blend_rounded_rect(cx + PAD + 6, cy + ry0, inner - 12, ROW_H - 2, 6, 0x1CFFFFFF);
        int ty = cy + ry0 + (ROW_H - 2 - GFX_CHAR_ROWS) / 2;

        char name[40]; int len = 0, maxc = (col_cat - 16 - 16) / GFX_CHAR_COLS;
        while(d->name[len] && len < 39) { name[len] = d->name[len]; len++; }
        name[len] = 0;
        if(len > maxc && maxc > 3) { name[maxc - 2] = '.'; name[maxc - 1] = '.'; name[maxc] = 0; }
        gfx_draw_string(cx + PAD + 16, ty, name, UI_TEXT);
        gfx_draw_string(cx + col_cat, ty, d->category, UI_TEXT_DIM);
        gfx_fill_circle(cx + col_stat + 4, ty + 8, 4, driver_status_color(d->status));
        gfx_draw_string(cx + col_stat + 16, ty, driver_status_name(d->status), UI_TEXT);
    }

    /* details line for the selected driver */
    const driver_info_t *sel = driver_get(t->drv_sel);
    int fy = cy + ch - FOOT_H + 6;
    if(sel) {
        char line[80];
        sprintf(line, "%s  v%s  %s", sel->id, sel->version[0] ? sel->version : "-", sel->vendor);
        gfx_draw_string(cx + PAD, fy, line, UI_TEXT_DIM);
        gfx_draw_string(cx + PAD, fy + 20, sel->description, UI_TEXT_FAINT);
    }
    else {
        char line[48]; sprintf(line, "%d driver%s", n, n == 1 ? "" : "s");
        gfx_draw_string(cx + PAD, fy + 10, line, UI_TEXT_DIM);
    }
}

static void tm_paint(window_t *self, int cx, int cy, int cw, int ch) {
    app_tm_t *t = (app_tm_t *)self->user_data;
    if(!t) return;
    ui_clear(cx, cy, cw, ch);

    int x, y, w, h;
    tabs_rect(cw, &x, &y, &w, &h);
    static const char *const labels[TAB_COUNT] = { "Processes", "Performance", "Drivers" };
    int rx, ry, hover = -1;
    if(ui_hover_pos(self, cx, cy, &rx, &ry)) hover = ui_tabs_hit(x, y, w, h, TAB_COUNT, rx, ry);
    ui_tabs(cx + x, cy + y, w, h, labels, TAB_COUNT, t->tab, hover);

    if(t->tab == TAB_PROCESSES) paint_processes(self, t, cx, cy, cw, ch);
    else if(t->tab == TAB_PERFORMANCE) paint_performance(self, cx, cy, cw, ch);
    else paint_drivers(self, t, cx, cy, cw, ch);
}

/* ------------------------------ input ------------------------------ */
static void switch_to(window_t *win) {
    if(!win) return;
    if(win->minimized) wm_restore_window(win); else wm_focus(win);
}

static void end_task(app_tm_t *t, window_t *self) {
    window_t *victim = t->sel;
    if(!victim) return;
    t->sel = NULL;
    if(victim == self) { t->close_self = 1; return; }
    wm_destroy_window(victim);
}

static void tm_tick(window_t *self) {
    app_tm_t *t = (app_tm_t *)self->user_data;
    if(t && t->close_self) { t->close_self = 0; wm_destroy_window(self); }
}

static void tm_click(window_t *self, int rx, int ry) {
    app_tm_t *t = (app_tm_t *)self->user_data;
    if(!t) return;
    int x, y, cw, ch, w, h;
    wm_get_client_rect(self, &x, &y, &cw, &ch);
    tabs_rect(cw, &x, &y, &w, &h);
    int tab = ui_tabs_hit(x, y, w, h, TAB_COUNT, rx, ry);
    if(tab >= 0) { t->tab = tab; return; }
    if(t->tab == TAB_DRIVERS) {
        int row = (ry - (LIST_TOP + HEAD_H)) / ROW_H;
        if(ry >= LIST_TOP + HEAD_H && row >= 0 && row < driver_rows_visible(ch) && t->drv_scroll + row < driver_count())
            t->drv_sel = t->drv_scroll + row;
        return;
    }
    if(t->tab != TAB_PROCESSES) return;

    rect_t sw, en; footer_buttons(cw, ch, &sw, &en);
    if(ui_in(rx, ry, sw.x, sw.y, sw.w, sw.h)) { switch_to(t->sel); return; }
    if(ui_in(rx, ry, en.x, en.y, en.w, en.h)) { end_task(t, self); return; }

    window_t *wl[WM_MAX_WINDOWS];
    int n = collect(wl, WM_MAX_WINDOWS), vis = visible_rows(ch);
    int row = (ry - (LIST_TOP + HEAD_H)) / ROW_H;
    if(ry >= LIST_TOP + HEAD_H && row >= 0 && row < vis && t->scroll + row < n) t->sel = wl[t->scroll + row];
}

static void tm_key(window_t *self, char k) {
    app_tm_t *t = (app_tm_t *)self->user_data;
    if(!t) return;
    if(k == '\t') { t->tab = (t->tab + 1) % TAB_COUNT; return; }
    if(t->tab == TAB_DRIVERS) {
        int n = driver_count(), chh, dummy;
        wm_get_client_rect(self, &dummy, &dummy, &dummy, &chh);
        int vis = driver_rows_visible(chh);
        if(k == KEY_DOWN) t->drv_sel = t->drv_sel < 0 ? 0 : (t->drv_sel + 1 < n ? t->drv_sel + 1 : t->drv_sel);
        else if(k == KEY_UP) t->drv_sel = t->drv_sel < 0 ? 0 : (t->drv_sel > 0 ? t->drv_sel - 1 : 0);
        else return;
        if(t->drv_sel < t->drv_scroll) t->drv_scroll = t->drv_sel;
        if(t->drv_sel >= t->drv_scroll + vis) t->drv_scroll = t->drv_sel - vis + 1;
        return;
    }
    if(t->tab != TAB_PROCESSES) return;

    window_t *wl[WM_MAX_WINDOWS];
    int n = collect(wl, WM_MAX_WINDOWS), ch, dummy;
    wm_get_client_rect(self, &dummy, &dummy, &dummy, &ch);
    int vis = visible_rows(ch), idx = sel_index(wl, n, t->sel);
    if(k == KEY_DOWN) idx = idx < 0 ? 0 : (idx + 1 < n ? idx + 1 : idx);
    else if(k == KEY_UP) idx = idx < 0 ? 0 : (idx > 0 ? idx - 1 : 0);
    else if(k == '\n') { switch_to(t->sel); return; }
    else if(k == KEY_DELETE) { end_task(t, self); return; }
    else return;
    if(n == 0) return;
    t->sel = wl[idx];
    if(idx < t->scroll) t->scroll = idx;
    if(idx >= t->scroll + vis) t->scroll = idx - vis + 1;
}

static int tm_cursor_at(window_t *self, int rx, int ry) {
    app_tm_t *t = (app_tm_t *)self->user_data;
    if(!t) return CURSOR_DEFAULT;
    int x, y, cw, ch, w, h;
    wm_get_client_rect(self, &x, &y, &cw, &ch);
    tabs_rect(cw, &x, &y, &w, &h);
    if(ui_tabs_hit(x, y, w, h, TAB_COUNT, rx, ry) >= 0) return CURSOR_LINK;
    if(t->tab == TAB_DRIVERS) {
        if(ry >= LIST_TOP + HEAD_H && ry < LIST_TOP + HEAD_H + driver_rows_visible(ch) * ROW_H) return CURSOR_LINK;
    }
    if(t->tab == TAB_PROCESSES) {
        rect_t sw, en; footer_buttons(cw, ch, &sw, &en);
        if(ui_in(rx, ry, sw.x, sw.y, sw.w, sw.h) || ui_in(rx, ry, en.x, en.y, en.w, en.h)) return CURSOR_LINK;
        if(ry >= LIST_TOP + HEAD_H && ry < LIST_TOP + HEAD_H + visible_rows(ch) * ROW_H) return CURSOR_LINK;
    }
    return CURSOR_DEFAULT;
}

static void tm_scroll(window_t *self, int rx, int ry, int notches) {
    (void)rx; (void)ry;
    app_tm_t *t = (app_tm_t *)self->user_data;
    if(!t) return;
    if(t->tab == TAB_PROCESSES) { t->scroll += notches * 2; if(t->scroll < 0) t->scroll = 0; }       /* paint clamps the top end */
    else if(t->tab == TAB_DRIVERS) { t->drv_scroll += notches * 2; if(t->drv_scroll < 0) t->drv_scroll = 0; }
}

static void tm_destroy(window_t *self) {
    if(self->user_data) { kfree(self->user_data); self->user_data = NULL; }
}

void launch_taskmgr(void) {
    window_t *existing = wm_find_window_by_paint(tm_paint);
    if(existing) {
        if(existing->minimized) wm_restore_window(existing); else wm_focus(existing);
        return;
    }
    int sw = (int)gfx_width(), sh = (int)gfx_height();
    int w = 520, h = 520;
    if(h > sh - 60) h = sh - 60;
    if(w > sw - 20) w = sw - 20;
    window_t *win = wm_create_window("Task Manager", (sw - w) / 2 + 60, 24 + (sh - 60 - h) / 4, w, h, UI_BG);
    if(!win) return;
    app_tm_t *t = (app_tm_t *)kmalloc(sizeof(app_tm_t));
    if(!t) { wm_destroy_window(win); return; }
    memset(t, 0, sizeof(*t));
    t->drv_sel = -1;
    win->user_data = t;
    win->on_paint = tm_paint;
    win->on_click = tm_click;
    win->on_key = tm_key;
    win->on_tick = tm_tick;
    win->on_scroll = tm_scroll;
    win->cursor_at = tm_cursor_at;
    win->on_destroy = tm_destroy;
}
