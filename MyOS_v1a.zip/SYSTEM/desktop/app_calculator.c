#include "stdint.h"
#include "stddef.h"
#include "app_calculator.h"
#include "window.h"
#include "gfx.h"
#include "common.h"
#include "kheap.h"
#include "keyboard.h"
#include "pit.h"
#include "cursor_set.h"

#define C_BG       0xFF202020
#define C_DIGIT    0xFF3B3B3B
#define C_DIGIT_HI 0xFF4A4A4A
#define C_FUNC     0xFF2E2E2E
#define C_FUNC_HI  0xFF3A3A3A
#define C_EQ       0xFF4CC2FF
#define C_EQ_HI    0xFF6FD0FF
#define C_PRESS    0xFF282828
#define C_TEXT     0xFFFFFFFF
#define C_DIM      0xFFA8A8A8

#define DISPLAY_H 128
#define PAD 4
#define GAP 2

typedef enum {
    B_PCT, B_CE, B_C, B_BACK,
    B_INV, B_SQR, B_SQRT, B_DIV,
    B_7, B_8, B_9, B_MUL,
    B_4, B_5, B_6, B_SUB,
    B_1, B_2, B_3, B_ADD,
    B_NEG, B_0, B_DOT, B_EQ,
    B_COUNT
} button_t;

typedef struct {
    window_t *win;
    double acc;
    char op;               /* 0, '+', '-', '*', '/' */
    char entry[40];        /* what the user is typing / the current result as text */
    int entry_new;         /* next digit starts a fresh entry */
    int just_eval;         /* last action was '=' */
    char expr[96];         /* expression line above the result */
    int error;
    char errmsg[32];
    double last_operand; char last_op;   /* for repeated '=' */
    int hover; int pressed; long long pressed_tick;
} calc_t;

/* ------------------------- number <-> text ------------------------- */
static double dsqrt(double x) { double r; __asm__("fsqrt" : "=t"(r) : "0"(x)); return r; }

static double parse_entry(const char *s) {
    double v = 0, frac = 0, scale = 1; int neg = 0, after_dot = 0, i = 0;
    if(s[i] == '-') { neg = 1; i++; }
    for(; s[i] && s[i] != 'e'; i++) {
        if(s[i] == '.') { after_dot = 1; continue; }
        if(s[i] < '0' || s[i] > '9') continue;
        if(!after_dot) v = v * 10 + (s[i] - '0');
        else { scale /= 10; frac += (s[i] - '0') * scale; }
    }
    v += frac;
    if(s[i] == 'e') {
        i++;
        int eneg = 0, e = 0;
        if(s[i] == '-') { eneg = 1; i++; } else if(s[i] == '+') i++;
        for(; s[i] >= '0' && s[i] <= '9'; i++) e = e * 10 + (s[i] - '0');
        while(e-- > 0) { if(eneg) v /= 10; else v *= 10; }
    }
    return neg ? -v : v;
}

/* Formats a double the way Calculator shows results: up to ~15 significant
 * digits, trailing zeros trimmed, scientific for huge/tiny values. */
static void fmt_double(double v, char *out) {
    int p = 0;
    if(v != v) { out[0] = '0'; out[1] = 0; return; }
    if(v < 0) { out[p++] = '-'; v = -v; }
    if(v == 0) { out[p++] = '0'; out[p] = 0; return; }

    if(v >= 1e16 || v < 1e-6) {
        int e = 0;
        while(v >= 10) { v /= 10; e++; }
        while(v < 1) { v *= 10; e--; }
        long long m = (long long)(v * 1e14 + 0.5);   /* 15 significant digits */
        if(m >= 1000000000000000LL) { m /= 10; e++; }
        char d[20]; long long t = m;
        for(int i = 0; i < 15; i++) { d[i] = (char)('0' + t % 10); t /= 10; }
        out[p++] = d[14];
        int lo = 0; while(lo <= 13 && d[lo] == '0') lo++;
        if(lo <= 13) { out[p++] = '.'; for(int i = 13; i >= lo; i--) out[p++] = d[i]; }
        out[p++] = 'e'; out[p++] = e < 0 ? '-' : '+';
        int ae = e < 0 ? -e : e;
        if(ae >= 100) out[p++] = (char)('0' + ae / 100);
        out[p++] = (char)('0' + (ae / 10) % 10); out[p++] = (char)('0' + ae % 10);
        out[p] = 0; return;
    }

    long long ip = (long long)v;
    double frac = v - (double)ip;
    int int_digits = 1; { long long t = ip; while(t >= 10) { t /= 10; int_digits++; } }
    int fd = (ip == 0 ? 15 : 15 - int_digits); if(fd < 0) fd = 0; if(fd > 15) fd = 15;  /* 15 significant digits hides binary noise: 0.1+0.2 shows 0.3 */
    long long pow10 = 1; for(int i = 0; i < fd; i++) pow10 *= 10;
    long long fr = (long long)(frac * (double)pow10 + 0.5);
    if(fr >= pow10) { ip++; fr = 0; }

    char d[24]; int n = 0; long long t = ip;
    if(t == 0) d[n++] = '0';
    while(t > 0) { d[n++] = (char)('0' + t % 10); t /= 10; }
    for(int i = n - 1; i >= 0; i--) out[p++] = d[i];
    if(fd > 0 && fr > 0) {
        char f[16]; for(int i = fd - 1; i >= 0; i--) { f[i] = (char)('0' + fr % 10); fr /= 10; }
        int last = fd - 1; while(last >= 0 && f[last] == '0') last--;
        out[p++] = '.';
        for(int i = 0; i <= last; i++) out[p++] = f[i];
    }
    out[p] = 0;
}

/* Adds thousands separators to the integer part, for display only. */
static void with_commas(const char *in, char *out, int max) {
    int p = 0, i = 0;
    if(in[i] == '-') out[p++] = in[i++];
    int int_start = i, int_len = 0;
    while(in[i + int_len] >= '0' && in[i + int_len] <= '9') int_len++;
    if(in[int_start + int_len] == 'e' ) { /* scientific: leave alone */
        int_len = 0;
        for(const char *c = in + int_start; *c && p < max - 1; c++) out[p++] = *c;
        out[p] = 0; return;
    }
    for(int k = 0; k < int_len && p < max - 2; k++) {
        out[p++] = in[int_start + k];
        int rem = int_len - 1 - k;
        if(rem > 0 && rem % 3 == 0) out[p++] = ',';
    }
    for(const char *c = in + int_start + int_len; *c && p < max - 1; c++) out[p++] = *c;
    out[p] = 0;
}

static void set_entry_value(calc_t *c, double v) { fmt_double(v, c->entry); }
static double cur(calc_t *c) { return parse_entry(c->entry); }

static void set_error(calc_t *c, const char *msg) {
    c->error = 1; int i = 0; while(msg[i] && i < 31) { c->errmsg[i] = msg[i]; i++; } c->errmsg[i] = 0;
    c->op = 0; c->expr[0] = 0; c->just_eval = 0;
}

static void clear_all(calc_t *c) {
    c->acc = 0; c->op = 0; c->entry[0] = '0'; c->entry[1] = 0; c->entry_new = 1;
    c->just_eval = 0; c->expr[0] = 0; c->error = 0; c->last_op = 0;
}

static int compute(calc_t *c, double a, char op, double b, double *out) {
    switch(op) {
        case '+': *out = a + b; return 1;
        case '-': *out = a - b; return 1;
        case '*': *out = a * b; return 1;
        case '/':
            if(b == 0) { set_error(c, a == 0 ? "Result is undefined" : "Cannot divide by zero"); return 0; }
            *out = a / b; return 1;
    }
    *out = b; return 1;
}

static void expr_set(calc_t *c, const char *a) { int i = 0; while(a[i] && i < 95) { c->expr[i] = a[i]; i++; } c->expr[i] = 0; }
static void expr_cat(calc_t *c, const char *a) { int n = (int)strlen(c->expr); int i = 0; while(a[i] && n + i < 95) { c->expr[n + i] = a[i]; i++; } c->expr[n + i] = 0; }

static void do_digit(calc_t *c, char d) {
    if(c->error) clear_all(c);
    if(c->just_eval) { c->expr[0] = 0; c->just_eval = 0; c->entry_new = 1; c->op = 0; c->last_op = 0; }
    if(c->entry_new) { c->entry[0] = 0; c->entry_new = 0; }
    int len = (int)strlen(c->entry);
    int digits = 0; for(int i = 0; i < len; i++) if(c->entry[i] >= '0' && c->entry[i] <= '9') digits++;
    if(digits >= 16) return;
    if(len == 1 && c->entry[0] == '0') { c->entry[0] = d; return; }
    if(len == 2 && c->entry[0] == '-' && c->entry[1] == '0') { c->entry[1] = d; return; }
    c->entry[len] = d; c->entry[len + 1] = 0;
}

static void do_dot(calc_t *c) {
    if(c->error) clear_all(c);
    if(c->just_eval) { c->expr[0] = 0; c->just_eval = 0; c->entry_new = 1; c->op = 0; c->last_op = 0; }
    if(c->entry_new) { c->entry[0] = '0'; c->entry[1] = 0; c->entry_new = 0; }
    for(int i = 0; c->entry[i]; i++) if(c->entry[i] == '.') return;
    int len = (int)strlen(c->entry); c->entry[len] = '.'; c->entry[len + 1] = 0;
}

static void do_op(calc_t *c, char op) {
    if(c->error) return;
    char buf[40];
    if(c->op && !c->entry_new && !c->just_eval) {
        double r; if(!compute(c, c->acc, c->op, cur(c), &r)) return;
        c->acc = r; set_entry_value(c, r);
    }
    else if(c->just_eval || !c->op) {
        c->acc = cur(c);
    }
    c->op = op; c->just_eval = 0; c->entry_new = 1; c->last_op = 0;
    fmt_double(c->acc, buf);
    expr_set(c, buf);
    char o[4] = { ' ', op == '*' ? 'x' : op, ' ', 0 }; expr_cat(c, o);
}

static void do_equals(calc_t *c) {
    if(c->error) return;
    char a[40], b[40];
    if(c->op) {
        double operand = cur(c);
        double r; fmt_double(c->acc, a); fmt_double(operand, b);
        if(!compute(c, c->acc, c->op, operand, &r)) return;
        char o[6] = { ' ', c->op == '*' ? 'x' : c->op, ' ', 0 };
        expr_set(c, a); expr_cat(c, o); expr_cat(c, b); expr_cat(c, " =");
        c->last_op = c->op; c->last_operand = operand;
        c->acc = r; set_entry_value(c, r); c->op = 0;
    }
    else if(c->last_op) {
        double x = cur(c), r; fmt_double(x, a); fmt_double(c->last_operand, b);
        if(!compute(c, x, c->last_op, c->last_operand, &r)) return;
        char o[6] = { ' ', c->last_op == '*' ? 'x' : c->last_op, ' ', 0 };
        expr_set(c, a); expr_cat(c, o); expr_cat(c, b); expr_cat(c, " =");
        c->acc = r; set_entry_value(c, r);
    }
    else { fmt_double(cur(c), a); expr_set(c, a); expr_cat(c, " ="); }
    c->just_eval = 1; c->entry_new = 1;
}

static void do_unary(calc_t *c, int kind) {
    if(c->error) return;
    double x = cur(c), r; char a[40], t[64];
    fmt_double(x, a);
    if(kind == B_INV) { if(x == 0) { set_error(c, "Cannot divide by zero"); return; } r = 1.0 / x; t[0] = 0; }
    else if(kind == B_SQR) { r = x * x; }
    else { if(x < 0) { set_error(c, "Invalid input"); return; } r = dsqrt(x); }
    const char *pre = kind == B_INV ? "1/(" : kind == B_SQR ? "sqr(" : "sqrt(";
    int p = 0; for(const char *q = pre; *q; q++) t[p++] = *q; for(char *q = a; *q && p < 60; q++) t[p++] = *q; t[p++] = ')'; t[p] = 0;
    if(c->op && !c->just_eval) { char pre_expr[96]; int i = 0; while(c->expr[i]) { pre_expr[i] = c->expr[i]; i++; } pre_expr[i] = 0; expr_set(c, pre_expr); expr_cat(c, t); }
    else { expr_set(c, t); c->just_eval = 0; c->op = 0; }
    set_entry_value(c, r); c->entry_new = 1;
}

static void do_percent(calc_t *c) {
    if(c->error) return;
    double x = cur(c);
    if(c->op) x = c->acc * x / 100.0; else x = 0;
    set_entry_value(c, x); c->entry_new = 1;
    char a[40]; fmt_double(x, a);
    if(c->op) { char pre[96]; fmt_double(c->acc, pre); char o[4] = { ' ', c->op == '*' ? 'x' : c->op, ' ', 0 }; expr_set(c, pre); expr_cat(c, o); expr_cat(c, a); }
}

static void press(calc_t *c, int b) {
    switch(b) {
        case B_0: case B_1: case B_2: case B_3: case B_4: case B_5: case B_6: case B_7: case B_8: case B_9: {
            static const char map[10] = { '0','1','2','3','4','5','6','7','8','9' };
            int d = (b == B_0) ? 0 : (b == B_1 ? 1 : b == B_2 ? 2 : b == B_3 ? 3 : b == B_4 ? 4 : b == B_5 ? 5 : b == B_6 ? 6 : b == B_7 ? 7 : b == B_8 ? 8 : 9);
            do_digit(c, map[d]); break; }
        case B_DOT: do_dot(c); break;
        case B_ADD: do_op(c, '+'); break;
        case B_SUB: do_op(c, '-'); break;
        case B_MUL: do_op(c, '*'); break;
        case B_DIV: do_op(c, '/'); break;
        case B_EQ: do_equals(c); break;
        case B_C: clear_all(c); break;
        case B_CE: if(c->error) clear_all(c); else { c->entry[0] = '0'; c->entry[1] = 0; c->entry_new = 1; if(c->just_eval) { c->expr[0] = 0; c->just_eval = 0; } } break;
        case B_BACK:
            if(c->error) { clear_all(c); break; }
            if(c->just_eval) { c->expr[0] = 0; break; }
            if(c->entry_new) break;
            { int n = (int)strlen(c->entry);
              if(n <= 1 || (n == 2 && c->entry[0] == '-')) { c->entry[0] = '0'; c->entry[1] = 0; }
              else c->entry[n - 1] = 0; }
            break;
        case B_NEG:
            if(c->error) break;
            if(c->entry[0] == '0' && c->entry[1] == 0) break;
            if(c->entry[0] == '-') { int n = (int)strlen(c->entry); for(int i = 0; i < n; i++) c->entry[i] = c->entry[i + 1]; }
            else { int n = (int)strlen(c->entry); if(n < 38) { for(int i = n + 1; i > 0; i--) c->entry[i] = c->entry[i - 1]; c->entry[0] = '-'; } }
            break;
        case B_PCT: do_percent(c); break;
        case B_INV: case B_SQR: case B_SQRT: do_unary(c, b); break;
    }
}

/* ---------------------------- drawing ----------------------------- */
typedef struct { int x, y, w, h; } rect_t;

static void cell_rect(int cw, int ch, int index, rect_t *r) {
    int cols = 4, rows = 6;
    int gw = cw - PAD * 2, gh = ch - DISPLAY_H - PAD;
    int bw = (gw - GAP * (cols - 1)) / cols, bh = (gh - GAP * (rows - 1)) / rows;
    int col = index % cols, row = index / cols;
    r->x = PAD + col * (bw + GAP); r->y = DISPLAY_H + row * (bh + GAP); r->w = bw; r->h = bh;
}

static int is_digit_btn(int b) { return b == B_0 || (b >= B_1 && b <= B_3) || (b >= B_4 && b <= B_6) || (b >= B_7 && b <= B_9); }

static void glyph_div(int cx, int cy, uint32_t col) { gfx_fill_rect(cx - 8, cy - 1, 16, 2, col); gfx_fill_rect(cx - 1, cy - 7, 3, 3, col); gfx_fill_rect(cx - 1, cy + 4, 3, 3, col); }
static void glyph_mul(int cx, int cy, uint32_t col) { for(int i = -6; i <= 6; i++) { gfx_fill_rect(cx + i - 1, cy + i - 1, 2, 2, col); gfx_fill_rect(cx + i - 1, cy - i - 1, 2, 2, col); } }
static void glyph_sub(int cx, int cy, uint32_t col) { gfx_fill_rect(cx - 8, cy - 1, 16, 2, col); }
static void glyph_add(int cx, int cy, uint32_t col) { gfx_fill_rect(cx - 8, cy - 1, 16, 2, col); gfx_fill_rect(cx - 1, cy - 8, 2, 16, col); }
static void glyph_eq(int cx, int cy, uint32_t col) { gfx_fill_rect(cx - 8, cy - 4, 16, 2, col); gfx_fill_rect(cx - 8, cy + 2, 16, 2, col); }
static void glyph_back(int cx, int cy, uint32_t col) {
    gfx_fill_rect(cx - 2, cy - 7, 14, 2, col); gfx_fill_rect(cx - 2, cy + 5, 14, 2, col); gfx_fill_rect(cx + 11, cy - 7, 2, 14, col);
    for(int i = 0; i < 7; i++) { gfx_fill_rect(cx - 2 - i, cy - i, 2, 2, col); gfx_fill_rect(cx - 2 - i, cy + i - 1, 2, 2, col); }
    for(int i = -3; i <= 3; i++) { gfx_fill_rect(cx + 3 + i, cy + i - 1, 2, 2, col); gfx_fill_rect(cx + 3 + i, cy - i - 1, 2, 2, col); }
}
static void glyph_sqrt(int cx, int cy, uint32_t col) { gfx_fill_rect(cx - 9, cy + 1, 3, 2, col); for(int i = 0; i < 9; i++) gfx_fill_rect(cx - 6 + i, cy + 2 + i / 2 - (i > 4 ? (i - 4) * 2 : 0), 2, 2, col); gfx_fill_rect(cx - 2, cy - 7, 12, 2, col); gfx_fill_rect(cx - 2, cy - 7, 2, 12, col); }
static void glyph_neg(int cx, int cy, uint32_t col) { gfx_fill_rect(cx - 8, cy - 2, 6, 2, col); gfx_fill_rect(cx - 6, cy - 4, 2, 6, col); gfx_fill_rect(cx + 0, cy + 2, 8, 2, col); gfx_fill_rect(cx - 8, cy + 5, 16, 2, col); }

static void calc_paint(window_t *self, int cx, int cy, int cw, int ch) {
    calc_t *c = (calc_t *)self->user_data; if(!c) return;
    gfx_fill_rect(cx, cy, cw, ch, C_BG);

    /* expression line */
    int el = (int)strlen(c->expr);
    int maxc = (cw - 20) / GFX_CHAR_COLS;
    const char *es = c->expr; if(el > maxc) { es += el - maxc; el = maxc; }
    gfx_draw_string(cx + cw - 12 - el * GFX_CHAR_COLS, cy + 18, es, C_DIM);

    /* result */
    char shown[80];
    if(c->error) { int i = 0; while(c->errmsg[i]) { shown[i] = c->errmsg[i]; i++; } shown[i] = 0; }
    else with_commas(c->entry, shown, sizeof(shown));
    int len = (int)strlen(shown);
    int scale = 3;
    while(scale > 1 && len * GFX_CHAR_COLS * scale > cw - 24) scale--;
    if(c->error && scale > 2) scale = 2;
    int tw = len * GFX_CHAR_COLS * scale;
    int ty = cy + 50 + (3 - scale) * 6;
    gfx_draw_string_scaled(cx + cw - 12 - tw, ty, shown, C_TEXT, scale);

    for(int b = 0; b < B_COUNT; b++) {
        rect_t r; cell_rect(cw, ch, b, &r);
        int pressed = (c->pressed == b && pit_get_ticks() - c->pressed_tick < 12);
        int hover = (c->hover == b);
        uint32_t fill, tcol = C_TEXT;
        if(b == B_EQ) { fill = pressed ? 0xFF3A9FD0 : hover ? C_EQ_HI : C_EQ; tcol = 0xFF101010; }
        else if(is_digit_btn(b)) fill = pressed ? C_PRESS : hover ? C_DIGIT_HI : C_DIGIT;
        else fill = pressed ? C_PRESS : hover ? C_FUNC_HI : C_FUNC;
        gfx_fill_rounded_rect(cx + r.x, cy + r.y, r.w, r.h, 4, fill);

        int mx = cx + r.x + r.w / 2, my = cy + r.y + r.h / 2;
        switch(b) {
            case B_0: gfx_draw_string(mx - 4, my - 8, "0", tcol); break;
            case B_1: gfx_draw_string(mx - 4, my - 8, "1", tcol); break;
            case B_2: gfx_draw_string(mx - 4, my - 8, "2", tcol); break;
            case B_3: gfx_draw_string(mx - 4, my - 8, "3", tcol); break;
            case B_4: gfx_draw_string(mx - 4, my - 8, "4", tcol); break;
            case B_5: gfx_draw_string(mx - 4, my - 8, "5", tcol); break;
            case B_6: gfx_draw_string(mx - 4, my - 8, "6", tcol); break;
            case B_7: gfx_draw_string(mx - 4, my - 8, "7", tcol); break;
            case B_8: gfx_draw_string(mx - 4, my - 8, "8", tcol); break;
            case B_9: gfx_draw_string(mx - 4, my - 8, "9", tcol); break;
            case B_DOT: gfx_draw_string(mx - 4, my - 8, ".", tcol); break;
            case B_PCT: gfx_draw_string(mx - 4, my - 8, "%", tcol); break;
            case B_CE: gfx_draw_string(mx - 8, my - 8, "CE", tcol); break;
            case B_C: gfx_draw_string(mx - 4, my - 8, "C", tcol); break;
            case B_INV: gfx_draw_string(mx - 12, my - 8, "1/x", tcol); break;
            case B_SQR: gfx_draw_string(mx - 8, my - 6, "x", tcol); gfx_draw_string(mx, my - 12, "2", tcol); break;
            case B_SQRT: glyph_sqrt(mx, my, tcol); break;
            case B_DIV: glyph_div(mx, my, tcol); break;
            case B_MUL: glyph_mul(mx, my, tcol); break;
            case B_SUB: glyph_sub(mx, my, tcol); break;
            case B_ADD: glyph_add(mx, my, tcol); break;
            case B_EQ: glyph_eq(mx, my, tcol); break;
            case B_BACK: glyph_back(mx, my, tcol); break;
            case B_NEG: glyph_neg(mx, my, tcol); break;
        }
    }
}

static int button_at(int cw, int ch, int x, int y) {
    for(int b = 0; b < B_COUNT; b++) { rect_t r; cell_rect(cw, ch, b, &r); if(x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h) return b; }
    return -1;
}

static void client_wh(window_t *w, int *cw, int *ch) { int x, y; wm_get_client_rect(w, &x, &y, cw, ch); }

static void calc_click(window_t *self, int rx, int ry) {
    calc_t *c = (calc_t *)self->user_data; if(!c) return;
    int cw, ch; client_wh(self, &cw, &ch);
    int b = button_at(cw, ch, rx, ry);
    if(b >= 0) { press(c, b); c->pressed = b; c->pressed_tick = pit_get_ticks(); }
}

static int calc_cursor_at(window_t *self, int rx, int ry) {
    calc_t *c = (calc_t *)self->user_data; if(!c) return CURSOR_DEFAULT;
    int cw, ch; client_wh(self, &cw, &ch);
    c->hover = button_at(cw, ch, rx, ry);
    return c->hover >= 0 ? CURSOR_LINK : CURSOR_DEFAULT;
}

static void flash(calc_t *c, int b) { c->pressed = b; c->pressed_tick = pit_get_ticks(); }

static void calc_key(window_t *self, char k) {
    calc_t *c = (calc_t *)self->user_data; if(!c) return;
    int b = -1;
    switch(k) {
        case '0': b = B_0; break; case '1': b = B_1; break; case '2': b = B_2; break; case '3': b = B_3; break;
        case '4': b = B_4; break; case '5': b = B_5; break; case '6': b = B_6; break; case '7': b = B_7; break;
        case '8': b = B_8; break; case '9': b = B_9; break;
        case '.': case ',': b = B_DOT; break;
        case '+': b = B_ADD; break; case '-': b = B_SUB; break; case '*': case 'x': case 'X': b = B_MUL; break; case '/': b = B_DIV; break;
        case '=': case '\n': case '\r': b = B_EQ; break;
        case '\b': case 127: b = B_BACK; break;
        case 27: case 'c': case 'C': b = B_C; break;
        case KEY_DELETE: b = B_CE; break;
        case '%': b = B_PCT; break;
        case 'r': case 'R': b = B_INV; break;
        case 'n': case 'N': b = B_NEG; break;
        case 'q': case 'Q': b = B_SQR; break;
        default: break;
    }
    if(b >= 0) { press(c, b); flash(c, b); }
}

static void calc_destroy(window_t *self) { if(self->user_data) { kfree(self->user_data); self->user_data = NULL; } }

void launch_calculator(void) {
    int sw = (int)gfx_width(), sh = (int)gfx_height();
    int w = 340, h = 530; if(h > sh - 70) h = sh - 70; if(w > sw - 20) w = sw - 20;
    static int cascade = 0;
    window_t *win = wm_create_window("Calculator", (sw - w) / 2 + (cascade % 5) * 24, 30 + (cascade % 5) * 24, w, h, C_BG);
    cascade++;
    if(!win) return;
    calc_t *c = (calc_t *)kmalloc(sizeof(calc_t));
    if(!c) { wm_destroy_window(win); return; }
    memset(c, 0, sizeof(*c));
    c->win = win; c->hover = -1; c->pressed = -1;
    clear_all(c);
    win->user_data = c;
    win->on_paint = calc_paint; win->on_click = calc_click; win->on_key = calc_key;
    win->cursor_at = calc_cursor_at; win->on_destroy = calc_destroy;
}
