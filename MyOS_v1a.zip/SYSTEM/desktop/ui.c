#include "stdint.h"
#include "stddef.h"
#include "ui.h"
#include "gfx.h"
#include "mouse.h"
#include "common.h"

int ui_in(int px, int py, int x, int y, int w, int h) {
    return px >= x && px < x + w && py >= y && py < y + h;
}

int ui_hover_pos(window_t *self, int client_x, int client_y, int *rel_x, int *rel_y) {
    mouse_state_t *m = mouse_get_state();
    if(!self || wm_window_at(m->x, m->y) != self) return 0;
    *rel_x = m->x - client_x;
    *rel_y = m->y - client_y;
    return 1;
}

int ui_mouse_down(void) {
    return mouse_button_down(MOUSE_BUTTON_LEFT);
}

int ui_text_w(const char *s) {
    return (int)strlen(s) * GFX_CHAR_COLS;
}

void ui_text_center(int x, int y, int w, int h, const char *s, uint32_t color) {
    gfx_draw_string(x + (w - ui_text_w(s)) / 2, y + (h - GFX_CHAR_ROWS) / 2, s, color);
}

void ui_text_right(int right_x, int y, const char *s, uint32_t color) {
    gfx_draw_string(right_x - ui_text_w(s), y, s, color);
}

void ui_clear(int cx, int cy, int cw, int ch) {
    gfx_fill_rect(cx, cy, cw, ch, UI_BG);
}

void ui_card(int x, int y, int w, int h, int radius) {
    gfx_fill_rounded_rect(x, y, w, h, radius, UI_CARD);
    gfx_draw_rounded_outline(x, y, w, h, radius, UI_STROKE);
}

void ui_button(int x, int y, int w, int h, const char *label,
               ui_btn_style_t style, int hover, int pressed) {
    uint32_t fill, text = UI_TEXT;
    switch(style) {
        case UI_BTN_ACCENT:
            fill = pressed ? UI_ACCENT_LO : hover ? UI_ACCENT_HI : UI_ACCENT;
            text = UI_ON_ACCENT;
            break;
        case UI_BTN_DANGER:
            fill = pressed ? 0xFFA32316 : hover ? 0xFFD6453A : UI_DANGER;
            text = 0xFFFFFFFF;
            break;
        case UI_BTN_FLAT:
            fill = pressed ? 0xFF2A2A30 : hover ? UI_CARD_HI : UI_BG;
            break;
        default:
            fill = pressed ? 0xFF2C2C32 : hover ? 0xFF47474F : 0xFF3A3A42;
            break;
    }
    gfx_fill_rounded_rect(x, y, w, h, 6, fill);
    if(style == UI_BTN_NORMAL || style == UI_BTN_FLAT) {
        gfx_draw_rounded_outline(x, y, w, h, 6, UI_STROKE);
    }
    /* A pressed button shifts its label down a pixel, like a real key. */
    ui_text_center(x, y + (pressed ? 1 : 0), w, h, label, text);
}

void ui_tabs(int x, int y, int w, int h, const char *const *labels, int n, int selected, int hover) {
    gfx_fill_rounded_rect(x, y, w, h, h / 2, 0xFF2A2A30);
    gfx_draw_rounded_outline(x, y, w, h, h / 2, UI_STROKE);
    if(n <= 0) return;
    int seg = (w - 6) / n;
    for(int i = 0; i < n; i++) {
        int sx = x + 3 + i * seg;
        int sw = (i == n - 1) ? (x + w - 3 - sx) : seg;
        if(i == selected) {
            gfx_fill_rounded_rect(sx, y + 3, sw, h - 6, (h - 6) / 2, UI_ACCENT);
            ui_text_center(sx, y, sw, h, labels[i], UI_ON_ACCENT);
        }
        else {
            if(i == hover) gfx_blend_rounded_rect(sx, y + 3, sw, h - 6, (h - 6) / 2, 0x20FFFFFF);
            ui_text_center(sx, y, sw, h, labels[i], UI_TEXT_DIM);
        }
    }
}

int ui_tabs_hit(int x, int y, int w, int h, int n, int px, int py) {
    if(n <= 0 || !ui_in(px, py, x, y, w, h)) return -1;
    int seg = (w - 6) / n;
    int i = (px - (x + 3)) / (seg > 0 ? seg : 1);
    if(px < x + 3) i = 0;
    if(i < 0) i = 0;
    if(i >= n) i = n - 1;
    return i;
}

void ui_bar(int x, int y, int w, int h, uint32_t value, uint32_t max, uint32_t color) {
    gfx_fill_rounded_rect(x, y, w, h, h / 2, 0xFF3A3A42);
    if(max == 0) return;
    if(value > max) value = max;
    /* 32-bit math on purpose (no libgcc 64-bit divide): value and max stay
     * below 2^22 in every caller (KiB, percent) and w below 1024, so
     * w * value cannot overflow. */
    int fill = (int)(((uint32_t)w * value) / max);
    if(fill < h && value > 0) fill = h;
    if(fill > w) fill = w;
    if(fill > 0) gfx_fill_rounded_rect(x, y, fill, h, h / 2, color);
}

void ui_fmt2(char *out, int v) {
    if(v < 0) v = 0;
    out[0] = (char)('0' + (v / 10) % 10);
    out[1] = (char)('0' + v % 10);
    out[2] = '\0';
}
