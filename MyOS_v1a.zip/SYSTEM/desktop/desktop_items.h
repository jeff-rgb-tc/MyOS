#ifndef DESKTOP_ITEMS_H
#define DESKTOP_ITEMS_H

#include "stdint.h"
#include "shortcut.h"
#include "fileops.h"

/* The desktop is the folder /Users/User/Desktop: every file, folder and
 * shortcut in it appears as an icon on the desktop, and everything you
 * create or drop on the desktop is a real file in that folder (visible in
 * Explorer). This module keeps an up-to-date list of those items, remembers
 * where the user put each icon (/Users/User/Desktop/desktop.pos) and picks
 * an icon image for each. */

#define DITEMS_MAX 64

typedef enum { DI_FILE = 0, DI_FOLDER, DI_SHORTCUT } di_kind_t;

typedef struct {
    di_kind_t kind;
    char file[48];              /* name on disk, e.g. "notes.txt" or "Docs.lnk" */
    char label[32];             /* what the icon says (.lnk extension hidden) */
    char path[FSU_PATH_MAX];    /* absolute path */
    shortcut_t sc;              /* valid when kind == DI_SHORTCUT */
} desktop_item_t;

/* Re-reads the Desktop folder if it changed since the last call (cheap
 * when nothing changed). Returns 1 when the item list was rebuilt. */
int ditems_poll(void);
void ditems_invalidate(void);               /* force the next poll to rebuild */

int ditems_count(void);
const desktop_item_t *ditems_get(int index);
int ditems_find(const char *file_name);     /* index or -1 */

/* Remembered icon positions (by file name). */
int  ditems_pos_get(const char *file, int *x, int *y);
void ditems_pos_set(const char *file, int x, int y);   /* saves immediately */
void ditems_pos_forget(const char *file);
void ditems_pos_rename(const char *old_file, const char *new_file);

/* An icon image (ARGB pixels) for a file/folder/shortcut. */
typedef struct { const uint32_t *pixels; int w, h; } ditem_image_t;
ditem_image_t ditems_icon_for(const desktop_item_t *item);
/* Same for an arbitrary path (used for the drag ghost). */
ditem_image_t ditems_icon_for_path(const char *path, int is_dir);

/* The little arrow-in-a-box drawn over shortcut icons. (x, y) is the icon's
 * top-left, size its edge length. */
void ditems_draw_shortcut_badge(int x, int y, int size);

#endif
