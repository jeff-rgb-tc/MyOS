#ifndef APP_MEDIAPLAYER_H
#define APP_MEDIAPLAYER_H

/* Media Player: plays .mp3 (streamed, decoded frame by frame) and .wav
 * files from /Users/User/Music (or the folder of the file it was asked
 * to open), with playlist, seek bar, volume, shuffle and repeat. */
void launch_mediaplayer(void);

/* Opens the player and starts playing the given absolute path. */
void launch_mediaplayer_with_file(const char *path);

#endif
