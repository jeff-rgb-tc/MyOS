#include "stdint.h"
#include "stddef.h"
#include "context_menu.h"
#include "gfx.h"
#include "mouse.h"
#include "common.h"

#define MENU_ITEM_HEIGHT 30
#define MENU_SEP_HEIGHT 9
#define MENU_MIN_WIDTH 190
#define MENU_PADDING 5
#define MENU_CORNER_RADIUS 8
#define MENU_GUTTER 26      /* room for a check mark on the left */

/* Dark, slightly translucent "acrylic" look to match the taskbar. */
#define COLOR_MENU_BG        0xF0262626
#define COLOR_MENU_BORDER    0xFF4A4A4A
#define COLOR_MENU_TEXT      0xFFFFFFFF
#define COLOR_MENU_HINT      0xFF9A9A9A
#define COLOR_MENU_TEXT_DISABLED 0xFF6E6E6E
#define COLOR_MENU_HOVER     0x38FFFFFF
#define COLOR_MENU_SEP       0xFF444444

typedef struct {
    const context_menu_item_t *items;
    int count;
    int x, y, w, h;
} menu_level_t;

static context_menu_item_t main_items[CONTEXT_MENU_MAX_ITEMS];
static menu_level_t lvl_main;
static menu_level_t lvl_sub;
static int sub_parent = -1; /* index in main menu whose submenu is open, or -1 */
static uint8_t is_open = 0;
static void *action_user_data = NULL;

static void copy_str(char *dst, const char *src, int max) {
    int i = 0;
    while(src && src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

void context_menu_set_label(context_menu_item_t *it, const char *label) { copy_str(it->label, label, sizeof(it->label)); }
void context_menu_set_hint(context_menu_item_t *it, const char *hint) { copy_str(it->hint, hint, sizeof(it->hint)); }

static int slen(const char *s) { int n = 0; while(s[n]) n++; return n; }

static int item_h(const context_menu_item_t *it) { return it->separator ? MENU_SEP_HEIGHT : MENU_ITEM_HEIGHT; }

static void measure(menu_level_t *l) {
    int widest = 0, h = MENU_PADDING * 2;
    for(int i = 0; i < l->count; i++) {
        const context_menu_item_t *it = &l->items[i];
        h += item_h(it);
        if(it->separator) continue;
        int w = slen(it->label) * GFX_CHAR_COLS;
        if(it->hint[0]) w += 24 + slen(it->hint) * GFX_CHAR_COLS;
        else if(it->submenu) w += 24;
        if(w > widest) widest = w;
    }
    l->w = MENU_GUTTER + widest + 30;
    if(l->w < MENU_MIN_WIDTH) l->w = MENU_MIN_WIDTH;
    l->h = h;
}

static void clamp_to_screen(menu_level_t *l) {
    int sw = (int)gfx_width(), sh = (int)gfx_height();
    if(l->x + l->w > sw) l->x = sw - l->w;
    if(l->y + l->h > sh) l->y = sh - l->h;
    if(l->x < 0) l->x = 0;
    if(l->y < 0) l->y = 0;
}

void context_menu_open(int x, int y, const context_menu_item_t *new_items, int count, void *user_data) {
    if(count > CONTEXT_MENU_MAX_ITEMS) count = CONTEXT_MENU_MAX_ITEMS;
    for(int i = 0; i < count; i++) main_items[i] = new_items[i];

    lvl_main.items = main_items;
    lvl_main.count = count;
    lvl_main.x = x; lvl_main.y = y;
    measure(&lvl_main);
    clamp_to_screen(&lvl_main);

    sub_parent = -1;
    action_user_data = user_data;
    is_open = 1;
}

void context_menu_close() {
    is_open = 0;
    lvl_main.count = 0;
    sub_parent = -1;
    action_user_data = NULL;
}

int context_menu_is_open() { return is_open; }

/* Returns the row index under (x,y) in the given level, or -1. */
static int row_at(const menu_level_t *l, int x, int y) {
    if(x < l->x || x >= l->x + l->w) return -1;
    int cy = l->y + MENU_PADDING;
    for(int i = 0; i < l->count; i++) {
        int h = item_h(&l->items[i]);
        if(y >= cy && y < cy + h) return l->items[i].separator ? -1 : i;
        cy += h;
    }
    return -1;
}

static int row_top(const menu_level_t *l, int index) {
    int cy = l->y + MENU_PADDING;
    for(int i = 0; i < index; i++) cy += item_h(&l->items[i]);
    return cy;
}

static int in_rect(const menu_level_t *l, int x, int y) {
    return x >= l->x && x < l->x + l->w && y >= l->y && y < l->y + l->h;
}

/* Opens/closes the submenu based on where the pointer is. */
static void update_hover(int mx, int my) {
    if(sub_parent >= 0 && in_rect(&lvl_sub, mx, my)) return; /* stay in submenu */

    int r = row_at(&lvl_main, mx, my);
    if(r >= 0 && lvl_main.items[r].submenu && lvl_main.items[r].enabled) {
        if(sub_parent != r) {
            sub_parent = r;
            lvl_sub.items = lvl_main.items[r].submenu;
            lvl_sub.count = lvl_main.items[r].submenu_count;
            measure(&lvl_sub);
            lvl_sub.x = lvl_main.x + lvl_main.w - 4;
            lvl_sub.y = row_top(&lvl_main, r) - MENU_PADDING;
            /* Flip to the left side if it would run off the screen. */
            if(lvl_sub.x + lvl_sub.w > (int)gfx_width()) lvl_sub.x = lvl_main.x - lvl_sub.w + 4;
            clamp_to_screen(&lvl_sub);
        }
    }
    else if(r >= 0 || !in_rect(&lvl_main, mx, my)) {
        if(r >= 0) sub_parent = -1; /* hovering a normal row closes the submenu */
        else if(!in_rect(&lvl_sub, mx, my)) sub_parent = -1;
    }
}

static void draw_check(int x, int y) {
    /* Small check mark: two short diagonal strokes. */
    gfx_fill_rect(x,     y + 5, 2, 2, COLOR_MENU_TEXT);
    gfx_fill_rect(x + 2, y + 7, 2, 2, COLOR_MENU_TEXT);
    gfx_fill_rect(x + 4, y + 5, 2, 2, COLOR_MENU_TEXT);
    gfx_fill_rect(x + 6, y + 3, 2, 2, COLOR_MENU_TEXT);
    gfx_fill_rect(x + 8, y + 1, 2, 2, COLOR_MENU_TEXT);
}

static void draw_level(const menu_level_t *l, int hovered, int force_hover) {
    /* Soft drop shadow, then the panel. */
    gfx_draw_shadow(l->x, l->y, l->w, l->h, MENU_CORNER_RADIUS, 16, 5, 100);
    gfx_blend_rounded_rect(l->x, l->y, l->w, l->h, MENU_CORNER_RADIUS, COLOR_MENU_BG);
    gfx_draw_rounded_outline(l->x, l->y, l->w, l->h, MENU_CORNER_RADIUS, 0x30FFFFFF);

    int cy = l->y + MENU_PADDING;
    for(int i = 0; i < l->count; i++) {
        const context_menu_item_t *it = &l->items[i];
        int h = item_h(it);

        if(it->separator) {
            gfx_hline(l->x + 10, cy + h / 2, l->w - 20, COLOR_MENU_SEP);
            cy += h;
            continue;
        }

        if((i == hovered || i == force_hover) && it->enabled) {
            gfx_blend_rounded_rect(l->x + 4, cy + 1, l->w - 8, h - 2, 5, COLOR_MENU_HOVER);
        }

        uint32_t tc = it->enabled ? COLOR_MENU_TEXT : COLOR_MENU_TEXT_DISABLED;
        uint32_t hc = it->enabled ? COLOR_MENU_HINT : COLOR_MENU_TEXT_DISABLED;
        int ty = cy + (h - GFX_CHAR_ROWS) / 2;

        if(it->checked) draw_check(l->x + 11, ty + 2);
        gfx_draw_string(l->x + MENU_GUTTER, ty, it->label, tc);

        if(it->submenu) {
            gfx_draw_string(l->x + l->w - 20, ty, ">", tc);
        }
        else if(it->hint[0]) {
            gfx_draw_string(l->x + l->w - 14 - slen(it->hint) * GFX_CHAR_COLS, ty, it->hint, hc);
        }
        cy += h;
    }
}

void context_menu_draw() {
    if(!is_open) return;

    mouse_state_t *m = mouse_get_state();
    update_hover(m->x, m->y);

    int hover_main = row_at(&lvl_main, m->x, m->y);
    draw_level(&lvl_main, hover_main, sub_parent);

    if(sub_parent >= 0) {
        draw_level(&lvl_sub, row_at(&lvl_sub, m->x, m->y), -1);
    }
}

/* Index (within its menu or submenu) of the row whose action is currently
 * being invoked, for menus whose rows share one action and tell apart by
 * position -- e.g. a list of applications. Valid only during the callback. */
static int last_clicked_index = -1;
int context_menu_clicked_index(void) { return last_clicked_index; }

int context_menu_handle_click(int x, int y) {
    if(!is_open) return 0;

    update_hover(x, y);

    /* Submenu row? */
    if(sub_parent >= 0) {
        int sr = row_at(&lvl_sub, x, y);
        if(sr >= 0) {
            const context_menu_item_t *it = &lvl_sub.items[sr];
            if(it->enabled && it->action) {
                context_menu_action_fn fn = it->action;
                void *ud = action_user_data;
                last_clicked_index = sr;
                context_menu_close();
                fn(ud);
            }
            else if(!it->enabled) { /* keep open */ }
            return 1;
        }
    }

    int idx = row_at(&lvl_main, x, y);
    if(idx < 0) {
        if(in_rect(&lvl_main, x, y) || (sub_parent >= 0 && in_rect(&lvl_sub, x, y))) {
            return 1; /* clicked padding/separator -- keep menu open */
        }
        context_menu_close();
        return 1;
    }

    const context_menu_item_t *it = &lvl_main.items[idx];
    if(it->submenu) return 1; /* parent rows only open their submenu */
    if(it->enabled && it->action) {
        context_menu_action_fn fn = it->action;
        void *ud = action_user_data;
        last_clicked_index = idx;
        /* Close first: an action may open a new menu or destroy the
         * window the menu was opened for. */
        context_menu_close();
        fn(ud);
    }
    else if(!it->enabled) {
        return 1;
    }
    else {
        context_menu_close();
    }
    return 1;
}
