#include "stdint.h"
#include "datetime_util.h"
#include "kernio.h"

static const char *const month_names[12] = {
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
};
static const char *const weekday_names[7] = {
    "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
};

int dt_is_leap(int y) { return (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0); }

int dt_days_in_month(int y, int m) {
    static const int dm[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    if(m < 1 || m > 12) return 30;
    return (m == 2 && dt_is_leap(y)) ? 29 : dm[m - 1];
}

int dt_weekday(int y, int m, int d) {
    static const int t[12] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
    if(m < 3) y -= 1;
    return (y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7;
}

int dt_day_of_year(int y, int m, int d) {
    int n = d;
    for(int i = 1; i < m; i++) n += dt_days_in_month(y, i);
    return n;
}

int dt_iso_week(int y, int m, int d) {
    int wd = dt_weekday(y, m, d);            /* 0 = Sunday */
    int iso_wd = wd == 0 ? 7 : wd;           /* 1 = Monday .. 7 = Sunday */
    int week = (dt_day_of_year(y, m, d) - iso_wd + 10) / 7;
    if(week < 1) {
        /* belongs to the last week of the previous year */
        int py = y - 1;
        int dec31_wd = dt_weekday(py, 12, 31);
        int dec31_iso = dec31_wd == 0 ? 7 : dec31_wd;
        week = (dt_day_of_year(py, 12, 31) - dec31_iso + 10) / 7;
    }
    else if(week == 53) {
        int jan1_next = dt_weekday(y + 1, 1, 1);   /* 0 = Sunday */
        int jan1_iso = jan1_next == 0 ? 7 : jan1_next;
        if(jan1_iso <= 4) week = 1;                /* Jan 1..4 week owns these days */
    }
    return week;
}

const char *dt_month_name(int m) { return (m >= 1 && m <= 12) ? month_names[m - 1] : "?"; }
const char *dt_weekday_name(int w) { return (w >= 0 && w <= 6) ? weekday_names[w] : "?"; }

void dt_format_long_date(char *out, int max, int y, int m, int d) {
    (void)max;
    sprintf(out, "%s, %d %s %d", dt_weekday_name(dt_weekday(y, m, d)), d, dt_month_name(m), y);
}

void dt_add_days(int *y, int *m, int *d, int delta) {
    while(delta > 0) {
        int dim = dt_days_in_month(*y, *m);
        int room = dim - *d;
        if(delta <= room) { *d += delta; return; }
        delta -= room + 1;
        *d = 1;
        if(++(*m) > 12) { *m = 1; (*y)++; }
    }
    while(delta < 0) {
        if(-delta < *d) { *d += delta; return; }
        delta += *d;
        if(--(*m) < 1) { *m = 12; (*y)--; }
        *d = dt_days_in_month(*y, *m);
    }
}
