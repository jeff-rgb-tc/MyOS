#ifndef APP_PAINT_H
#define APP_PAINT_H

/* Launches a functional paint window: draw with the left mouse button
 * (click or drag), pick a color from a small palette strip, and clear
 * the canvas. */
void launch_paint(void);

#endif
