#include "stdint.h"
#include "stddef.h"
#include "app_notepad.h"
#include "window.h"
#include "gfx.h"
#include "common.h"
#include "kernio.h"
#include "kheap.h"
#include "fat32.h"
#include "fs_util.h"
#include "clipboard.h"
#include "context_menu.h"
#include "file_picker.h"
#include "keyboard.h"
#include "pit.h"
#include "rtc.h"
#include "cursor_set.h"

#define NP_CAP (256 * 1024)
#define NP_MAX_LINES 16384
#define MENU_H 26
#define STATUS_H 24
#define PROMPT_H 30
#define TEXT_X 8
#define TAB_W 4
#define SCROLLBAR_W 10
#define DEFAULT_SAVE_PATH "/Users/User/Desktop/Untitled.txt"

#define C_BG      0xFF1F1F1F
#define C_TEXT    0xFFEDEDED
#define C_MENU    0xFF2B2B2B
#define C_MENU_HI 0xFF3C3C3C
#define C_DIM     0xFF9A9A9A
#define C_SEL     0xFF2F5C9E
#define C_ACCENT  0xFF4CC2FF

typedef enum { PR_NONE = 0, PR_SAVE_AS, PR_CONFIRM_NEW, PR_CONFIRM_OPEN } prompt_t;

typedef struct {
    window_t *win;
    char *buf; int len;
    int cursor, anchor;            /* anchor == -1 -> no selection */
    int top_line, left_col;
    int *line_start; int line_count; int lines_dirty;
    int want_col;
    char path[FSU_PATH_MAX]; int has_path;
    int modified, crlf;
    prompt_t prompt; char prompt_text[FSU_PATH_MAX]; int prompt_len;
    file_picker_t picker;
    int dragging, menu_hover;
    char status[48]; long long status_tick;
    int text_rows, text_cols;      /* from last paint */
} np_t;

/* ------------------------------ helpers ------------------------------ */
static void np_status(np_t *n, const char *m) { int i = 0; while(m[i] && i < 47) { n->status[i] = m[i]; i++; } n->status[i] = 0; n->status_tick = pit_get_ticks(); }

static void update_title(np_t *n) {
    char t[64]; int p = 0;
    if(n->modified) t[p++] = '*';
    const char *name = "Untitled";
    if(n->has_path) { const char *s = n->path; name = s; for(const char *c = s; *c; c++) if(*c == '/') name = c + 1; }
    for(const char *c = name; *c && p < 44; c++) t[p++] = *c;
    const char *suf = " - Notepad"; for(const char *c = suf; *c && p < 63; c++) t[p++] = *c;
    t[p] = 0;
    int i = 0; while(t[i]) { n->win->title[i] = t[i]; i++; } n->win->title[i] = 0;
}

static void rebuild_lines(np_t *n) {
    int c = 0; n->line_start[c++] = 0;
    for(int i = 0; i < n->len && c < NP_MAX_LINES; i++) if(n->buf[i] == '\n') n->line_start[c++] = i + 1;
    n->line_count = c; n->lines_dirty = 0;
}
static void ensure_lines(np_t *n) { if(n->lines_dirty) rebuild_lines(n); }

static int line_of(np_t *n, int idx) {
    ensure_lines(n);
    int lo = 0, hi = n->line_count - 1;
    while(lo < hi) { int mid = (lo + hi + 1) / 2; if(n->line_start[mid] <= idx) lo = mid; else hi = mid - 1; }
    return lo;
}
static int line_end(np_t *n, int line) { ensure_lines(n); return (line + 1 < n->line_count) ? n->line_start[line + 1] - 1 : n->len; }

static int vcol_of(np_t *n, int line, int idx) {
    int col = 0; int s = n->line_start[line];
    for(int i = s; i < idx && i < n->len; i++) { if(n->buf[i] == '\t') col += TAB_W - (col % TAB_W); else col++; }
    return col;
}
static int idx_at_vcol(np_t *n, int line, int want) {
    ensure_lines(n);
    int s = n->line_start[line], e = line_end(n, line), col = 0;
    for(int i = s; i < e; i++) {
        int w = (n->buf[i] == '\t') ? TAB_W - (col % TAB_W) : 1;
        if(want < col + w) return ((want - col) * 2 >= w) ? i + 1 : i;
        col += w;
    }
    return e;
}

static int sel_lo(np_t *n) { return n->anchor < n->cursor ? n->anchor : n->cursor; }
static int sel_hi(np_t *n) { return n->anchor < n->cursor ? n->cursor : n->anchor; }
static int has_sel(np_t *n) { return n->anchor >= 0 && n->anchor != n->cursor; }

static void ensure_visible(np_t *n) {
    ensure_lines(n);
    int line = line_of(n, n->cursor);
    int col = vcol_of(n, line, n->cursor);
    int rows = n->text_rows > 0 ? n->text_rows : 10, cols = n->text_cols > 0 ? n->text_cols : 40;
    if(line < n->top_line) n->top_line = line;
    if(line >= n->top_line + rows) n->top_line = line - rows + 1;
    if(col < n->left_col) n->left_col = col;
    if(col >= n->left_col + cols - 1) n->left_col = col - cols + 2;
    if(n->left_col < 0) n->left_col = 0;
    if(n->top_line < 0) n->top_line = 0;
}

static void touch(np_t *n) { n->modified = 1; n->lines_dirty = 1; update_title(n); }

static void delete_range(np_t *n, int a, int b) {
    if(b <= a) return;
    for(int i = b; i < n->len; i++) n->buf[a + (i - b)] = n->buf[i];
    n->len -= (b - a);
    n->cursor = a; n->anchor = -1; touch(n);
}
static void delete_selection(np_t *n) { if(has_sel(n)) delete_range(n, sel_lo(n), sel_hi(n)); n->anchor = -1; }

static void insert_text(np_t *n, const char *t, int count) {
    delete_selection(n);
    if(n->len + count >= NP_CAP) { np_status(n, "File too large"); return; }
    for(int i = n->len - 1; i >= n->cursor; i--) n->buf[i + count] = n->buf[i];
    for(int i = 0; i < count; i++) n->buf[n->cursor + i] = t[i];
    n->len += count; n->cursor += count; touch(n);
}

/* ------------------------------ file ops ------------------------------ */
static void new_doc(np_t *n) {
    n->len = 0; n->cursor = 0; n->anchor = -1; n->top_line = n->left_col = 0;
    n->has_path = 0; n->path[0] = 0; n->modified = 0; n->crlf = 1; n->lines_dirty = 1; update_title(n);
}

static int load_file(np_t *n, const char *path) {
    uint32_t size = 0; uint8_t *data = fsu_read_file(path, &size);
    if(!data) { np_status(n, "Cannot open file"); return 0; }
    int out = 0, crlf = 0;
    for(uint32_t i = 0; i < size && out < NP_CAP - 1; i++) {
        char c = (char)data[i];
        if(c == '\r') { if(i + 1 < size && data[i + 1] == '\n') crlf = 1; continue; }
        n->buf[out++] = c;
    }
    kfree(data);
    n->len = out; n->cursor = 0; n->anchor = -1; n->top_line = n->left_col = 0;
    int i = 0; while(path[i] && i < FSU_PATH_MAX - 1) { n->path[i] = path[i]; i++; } n->path[i] = 0;
    n->has_path = 1; n->modified = 0; n->crlf = crlf; n->lines_dirty = 1; update_title(n);
    np_status(n, size >= NP_CAP ? "File truncated (too large)" : "Opened");
    return 1;
}

static int save_to(np_t *n, const char *path) {
    int extra = 0;
    if(n->crlf) for(int i = 0; i < n->len; i++) if(n->buf[i] == '\n') extra++;
    uint8_t *out = (uint8_t *)kmalloc((uint32_t)(n->len + extra + 1));
    if(!out) { np_status(n, "Out of memory"); return 0; }
    int p = 0;
    for(int i = 0; i < n->len; i++) { if(n->buf[i] == '\n' && n->crlf) out[p++] = '\r'; out[p++] = (uint8_t)n->buf[i]; }
    int ok = fsu_write_file(path, out, (uint32_t)p);
    kfree(out);
    if(!ok) { np_status(n, "Save failed (folder not found?)"); return 0; }
    int i = 0; while(path[i] && i < FSU_PATH_MAX - 1) { n->path[i] = path[i]; i++; } n->path[i] = 0;
    n->has_path = 1; n->modified = 0; update_title(n); np_status(n, "Saved");
    return 1;
}

static void open_prompt(np_t *n, prompt_t kind) {
    n->prompt = kind;
    if(kind == PR_SAVE_AS) {
        const char *init = n->has_path ? n->path : DEFAULT_SAVE_PATH;
        int i = 0; while(init[i] && i < FSU_PATH_MAX - 1) { n->prompt_text[i] = init[i]; i++; } n->prompt_text[i] = 0; n->prompt_len = i;
    }
}

static void do_save(np_t *n) { if(n->has_path) save_to(n, n->path); else open_prompt(n, PR_SAVE_AS); }

static void request_new(np_t *n) { if(n->modified) open_prompt(n, PR_CONFIRM_NEW); else new_doc(n); }
static void request_open(np_t *n) { if(n->modified) open_prompt(n, PR_CONFIRM_OPEN); else file_picker_open(&n->picker, NULL); }

/* ------------------------------ clipboard ----------------------------- */
static void do_copy(np_t *n) {
    if(!has_sel(n)) return;
    int a = sel_lo(n), b = sel_hi(n); char tmp[CLIPBOARD_TEXT_MAX]; int p = 0;
    for(int i = a; i < b && p < CLIPBOARD_TEXT_MAX - 1; i++) tmp[p++] = n->buf[i];
    tmp[p] = 0; clipboard_set_text(tmp);
}
static void do_cut(np_t *n) { if(!has_sel(n)) return; do_copy(n); delete_selection(n); ensure_visible(n); }
static void do_paste(np_t *n) {
    const char *t = clipboard_get_text(); int count = (int)strlen(t);
    if(count) { insert_text(n, t, count); ensure_visible(n); }
}
static void do_select_all(np_t *n) { n->anchor = 0; n->cursor = n->len; }
static void do_time_date(np_t *n) {
    rtc_time_t t; rtc_date_t d; rtc_read_time(&t); rtc_read_date(&d);
    int h12 = t.hours % 12; if(!h12) h12 = 12;
    char s[40]; int p = 0;
    s[p++] = (char)('0' + h12 / 10); s[p++] = (char)('0' + h12 % 10); s[p++] = ':'; s[p++] = (char)('0' + t.minutes / 10); s[p++] = (char)('0' + t.minutes % 10);
    s[p++] = ' '; s[p++] = t.hours >= 12 ? 'P' : 'A'; s[p++] = 'M'; s[p++] = ' ';
    s[p++] = (char)('0' + d.month / 10); s[p++] = (char)('0' + d.month % 10); s[p++] = '/'; s[p++] = (char)('0' + d.day / 10); s[p++] = (char)('0' + d.day % 10); s[p++] = '/';
    s[p++] = (char)('0' + d.year / 1000); s[p++] = (char)('0' + (d.year / 100) % 10); s[p++] = (char)('0' + (d.year / 10) % 10); s[p++] = (char)('0' + d.year % 10);
    insert_text(n, s, p); ensure_visible(n);
}

/* ------------------------------ menus --------------------------------- */
static np_t *g_menu_np;  /* menu actions are plain functions; the menu is modal so one global is safe */
static void m_new(void *u) { (void)u; request_new(g_menu_np); }
static void m_open(void *u) { (void)u; request_open(g_menu_np); }
static void m_save(void *u) { (void)u; do_save(g_menu_np); }
static void m_save_as(void *u) { (void)u; open_prompt(g_menu_np, PR_SAVE_AS); }
static void m_exit(void *u) { (void)u; wm_destroy_window(g_menu_np->win); }
static void m_cut(void *u) { (void)u; do_cut(g_menu_np); }
static void m_copy(void *u) { (void)u; do_copy(g_menu_np); }
static void m_paste(void *u) { (void)u; do_paste(g_menu_np); }
static void m_delete(void *u) { (void)u; if(has_sel(g_menu_np)) { delete_selection(g_menu_np); ensure_visible(g_menu_np); } }
static void m_select_all(void *u) { (void)u; do_select_all(g_menu_np); }
static void m_time(void *u) { (void)u; do_time_date(g_menu_np); }
static void m_goto_start(void *u) { (void)u; g_menu_np->cursor = 0; g_menu_np->anchor = -1; ensure_visible(g_menu_np); }
static void m_goto_end(void *u) { (void)u; g_menu_np->cursor = g_menu_np->len; g_menu_np->anchor = -1; ensure_visible(g_menu_np); }

static void open_file_menu(np_t *n, int x, int y) {
    g_menu_np = n;
    static const context_menu_item_t items[] = {
        CM_ITEM("New", m_new, "Ctrl+N"),
        CM_ITEM("Open...", m_open, "Ctrl+O"),
        CM_ITEM("Save", m_save, "Ctrl+S"),
        CM_ITEM("Save As...", m_save_as, ""),
        CM_SEP(),
        CM_ITEM("Exit", m_exit, ""),
    };
    context_menu_open(x, y, items, 6, n);
}

static void open_edit_menu(np_t *n, int x, int y) {
    g_menu_np = n;
    static context_menu_item_t items[] = {
        CM_ITEM("Cut", m_cut, "Ctrl+X"),
        CM_ITEM("Copy", m_copy, "Ctrl+C"),
        CM_ITEM("Paste", m_paste, "Ctrl+V"),
        CM_ITEM("Delete", m_delete, "Del"),
        CM_SEP(),
        CM_ITEM("Select All", m_select_all, "Ctrl+A"),
        CM_ITEM("Time/Date", m_time, ""),
        CM_SEP(),
        CM_ITEM("Go to start", m_goto_start, ""),
        CM_ITEM("Go to end", m_goto_end, ""),
    };
    items[0].enabled = items[1].enabled = items[3].enabled = has_sel(n) ? 1 : 0;
    items[2].enabled = clipboard_get_text()[0] ? 1 : 0;
    context_menu_open(x, y, items, 10, n);
}

/* ------------------------------ painting ------------------------------ */
static void np_paint(window_t *self, int cx, int cy, int cw, int ch) {
    np_t *n = (np_t *)self->user_data; if(!n) return;
    ensure_lines(n);

    int prompt_h = n->prompt ? PROMPT_H : 0;
    int text_y = cy + MENU_H, text_h = ch - MENU_H - STATUS_H - prompt_h;
    int text_w = cw - SCROLLBAR_W;
    n->text_rows = text_h / GFX_CHAR_ROWS; if(n->text_rows < 1) n->text_rows = 1;
    n->text_cols = (text_w - TEXT_X * 2) / GFX_CHAR_COLS; if(n->text_cols < 4) n->text_cols = 4;

    int max_top = n->line_count - n->text_rows; if(max_top < 0) max_top = 0;
    if(n->top_line > max_top) n->top_line = max_top;

    gfx_fill_rect(cx, cy, cw, ch, C_BG);

    /* menu bar */
    gfx_fill_rect(cx, cy, cw, MENU_H, C_MENU);
    static const char *names[2] = { "File", "Edit" };
    for(int i = 0; i < 2; i++) {
        int mx = cx + 6 + i * 56;
        if(n->menu_hover == i) gfx_fill_rounded_rect(mx, cy + 3, 50, MENU_H - 6, 4, C_MENU_HI);
        gfx_draw_string(mx + 25 - (int)strlen(names[i]) * 4, cy + (MENU_H - GFX_CHAR_ROWS) / 2, names[i], 0xFFFFFFFF);
    }

    /* text */
    int sl = sel_lo(n), sh = sel_hi(n), sel = has_sel(n);
    for(int r = 0; r < n->text_rows; r++) {
        int line = n->top_line + r; if(line >= n->line_count) break;
        int s = n->line_start[line], e = line_end(n, line);
        int py = text_y + r * GFX_CHAR_ROWS;
        int col = 0; char run[256]; int rp = 0; int run_x = 0;
        for(int i = s; i <= e; i++) {
            int w;
            char c = (i < e) ? n->buf[i] : ' ';
            w = (i < e && c == '\t') ? TAB_W - (col % TAB_W) : 1;
            int in_sel = sel && i >= sl && i < sh;
            if(i == e) in_sel = sel && e >= sl && e < sh;   /* selected newline shows as one highlighted cell */
            for(int k = 0; k < w; k++) {
                int vc = col + k - n->left_col;
                if(vc >= 0 && vc < n->text_cols) {
                    int px = cx + TEXT_X + vc * GFX_CHAR_COLS;
                    if(in_sel) gfx_fill_rect(px, py, GFX_CHAR_COLS, GFX_CHAR_ROWS, C_SEL);
                    if(i < e && c != '\t' && c != ' ') {
                        char g = (c >= ' ' && (unsigned char)c < 127) ? c : '?';
                        char one[2] = { g, 0 };
                        gfx_draw_string(px, py, one, C_TEXT);
                    }
                }
            }
            col += w;
            if(col - n->left_col > n->text_cols + 1) break;
        }
        (void)run; (void)rp; (void)run_x;
    }

    /* caret */
    if(!n->picker.open && !n->prompt && ((pit_get_ticks() / 50) & 1) == 0) {
        int line = line_of(n, n->cursor);
        int row = line - n->top_line, vc = vcol_of(n, line, n->cursor) - n->left_col;
        if(row >= 0 && row < n->text_rows && vc >= 0 && vc <= n->text_cols)
            gfx_fill_rect(cx + TEXT_X + vc * GFX_CHAR_COLS, text_y + row * GFX_CHAR_ROWS + 1, 2, GFX_CHAR_ROWS - 2, 0xFFFFFFFF);
    }

    /* scrollbar */
    if(n->line_count > n->text_rows) {
        int track = text_h, thumb = (track * n->text_rows) / n->line_count; if(thumb < 20) thumb = 20;
        int pos = max_top ? (n->top_line * (track - thumb)) / max_top : 0;
        gfx_fill_rect(cx + cw - SCROLLBAR_W, text_y, SCROLLBAR_W, text_h, 0xFF262626);
        gfx_fill_rounded_rect(cx + cw - SCROLLBAR_W + 2, text_y + pos, SCROLLBAR_W - 4, thumb, 3, 0xFF6A6A6A);
    }

    /* prompt bar */
    if(n->prompt) {
        int py = cy + ch - STATUS_H - PROMPT_H;
        gfx_fill_rect(cx, py, cw, PROMPT_H, 0xFF333333);
        gfx_hline(cx, py, cw, C_ACCENT);
        if(n->prompt == PR_SAVE_AS) {
            gfx_draw_string(cx + 8, py + 7, "Save as:", C_DIM);
            int fx = cx + 8 + 9 * GFX_CHAR_COLS;
            gfx_fill_rounded_rect(fx, py + 3, cw - (fx - cx) - 8, PROMPT_H - 6, 4, 0xFF1B1B1B);
            int maxc = (cw - (fx - cx) - 24) / GFX_CHAR_COLS; const char *t = n->prompt_text; int tl = n->prompt_len;
            if(tl > maxc) { t += tl - maxc; tl = maxc; }
            char tmp[FSU_PATH_MAX]; for(int i = 0; i < tl; i++) tmp[i] = t[i]; tmp[tl] = 0;
            gfx_draw_string(fx + 6, py + 7, tmp, 0xFFFFFFFF);
            if(((pit_get_ticks() / 50) & 1) == 0) gfx_fill_rect(fx + 6 + tl * GFX_CHAR_COLS, py + 6, 2, 18, 0xFFFFFFFF);
        }
        else {
            gfx_draw_string(cx + 8, py + 7, "You have unsaved changes. Discard them? (Y / N)", 0xFFFFD27A);
        }
    }

    /* status bar */
    int sy = cy + ch - STATUS_H;
    gfx_fill_rect(cx, sy, cw, STATUS_H, C_MENU);
    char st[96]; int line = line_of(n, n->cursor), col = vcol_of(n, line, n->cursor);
    sprintf(st, "Ln %d, Col %d", line + 1, col + 1);
    gfx_draw_string(cx + 10, sy + 4, st, C_DIM);
    if(n->status[0] && pit_get_ticks() - n->status_tick < 300) gfx_draw_string(cx + cw / 2 - (int)strlen(n->status) * 4, sy + 4, n->status, C_ACCENT);
    char right[48]; sprintf(right, "%d chars   %s   ASCII", n->len, n->crlf ? "Windows (CRLF)" : "Unix (LF)");
    gfx_draw_string(cx + cw - 10 - (int)strlen(right) * GFX_CHAR_COLS, sy + 4, right, C_DIM);

    if(n->picker.open) {
        int m = 24;
        file_picker_draw(&n->picker, cx + m, cy + m, cw - m * 2, ch - m * 2);
    }
}

/* ------------------------------- input -------------------------------- */
static void client_xywh(window_t *w, int *x, int *y, int *cw, int *ch) { wm_get_client_rect(w, x, y, cw, ch); }

static int idx_from_point(np_t *n, window_t *self, int rx, int ry) {
    ensure_lines(n);
    int row = (ry - MENU_H) / GFX_CHAR_ROWS; if(ry < MENU_H) row = 0;
    int line = n->top_line + row; if(line < 0) line = 0; if(line >= n->line_count) line = n->line_count - 1;
    int vc = (rx - TEXT_X + GFX_CHAR_COLS / 2) / GFX_CHAR_COLS + n->left_col; if(rx < TEXT_X) vc = n->left_col;
    (void)self;
    return idx_at_vcol(n, line, vc);
}

static void np_click(window_t *self, int rx, int ry) {
    np_t *n = (np_t *)self->user_data; if(!n) return;
    int cx, cy, cw, ch; client_xywh(self, &cx, &cy, &cw, &ch);

    if(n->picker.open) {
        int m = 24;
        file_picker_handle_click(&n->picker, rx - m, ry - m, cw - m * 2, ch - m * 2);
        if(n->picker.file_chosen) { char p[FILE_PICKER_PATH_MAX]; int i = 0; while(n->picker.selected_path[i] && i < FILE_PICKER_PATH_MAX - 1) { p[i] = n->picker.selected_path[i]; i++; } p[i] = 0; file_picker_close(&n->picker); load_file(n, p); }
        return;
    }
    if(n->prompt) return;

    if(ry < MENU_H) {
        int idx = (rx - 6) / 56;
        if(rx >= 6 && idx >= 0 && idx < 2) {
            int mx = cx + 6 + idx * 56, my = cy + MENU_H;
            if(idx == 0) open_file_menu(n, mx, my); else open_edit_menu(n, mx, my);
        }
        return;
    }
    int text_h = ch - MENU_H - STATUS_H;
    if(ry < MENU_H + text_h) {
        if(rx >= cw - SCROLLBAR_W && n->line_count > n->text_rows) {
            /* click on the scrollbar track: page up/down */
            int mid = MENU_H + text_h / 2;
            n->top_line += (ry < mid) ? -n->text_rows : n->text_rows;
            if(n->top_line < 0) n->top_line = 0;
            return;
        }
        n->cursor = idx_from_point(n, self, rx, ry);
        n->anchor = n->cursor; n->dragging = 1;
        n->want_col = vcol_of(n, line_of(n, n->cursor), n->cursor);
    }
}

static void np_drag(window_t *self, int rx, int ry) {
    np_t *n = (np_t *)self->user_data; if(!n || !n->dragging) return;
    int cx, cy, cw, ch; client_xywh(self, &cx, &cy, &cw, &ch);
    /* autoscroll when dragging above/below the text area */
    if(ry < MENU_H && n->top_line > 0) n->top_line--;
    else if(ry > ch - STATUS_H && n->top_line + n->text_rows < n->line_count) n->top_line++;
    n->cursor = idx_from_point(n, self, rx, ry);
}

static void np_mouse_up(window_t *self, int rx, int ry) { (void)rx; (void)ry; np_t *n = (np_t *)self->user_data; if(n) { n->dragging = 0; if(n->anchor == n->cursor) n->anchor = -1; } }

static void np_right_click(window_t *self, int rx, int ry) {
    np_t *n = (np_t *)self->user_data; if(!n || n->picker.open) return;
    int cx, cy, cw, ch; client_xywh(self, &cx, &cy, &cw, &ch);
    open_edit_menu(n, cx + rx, cy + ry);
}

static int np_cursor_at(window_t *self, int rx, int ry) {
    np_t *n = (np_t *)self->user_data; if(!n) return CURSOR_DEFAULT;
    int cx, cy, cw, ch; client_xywh(self, &cx, &cy, &cw, &ch);
    n->menu_hover = -1;
    if(n->picker.open) return CURSOR_DEFAULT;
    if(ry < MENU_H) { int idx = (rx - 6) / 56; if(rx >= 6 && idx >= 0 && idx < 2) { n->menu_hover = idx; return CURSOR_LINK; } return CURSOR_DEFAULT; }
    if(ry < ch - STATUS_H && rx < cw - SCROLLBAR_W) return CURSOR_TEXT;
    return CURSOR_DEFAULT;
}

static void move_vertical(np_t *n, int dlines) {
    ensure_lines(n);
    int line = line_of(n, n->cursor);
    int col = vcol_of(n, line, n->cursor);
    (void)col;
    int target = line + dlines;
    if(target < 0) { n->cursor = 0; return; }
    if(target >= n->line_count) { n->cursor = n->len; return; }
    n->cursor = idx_at_vcol(n, target, n->want_col);
}

static void np_key(window_t *self, char k) {
    np_t *n = (np_t *)self->user_data; if(!n) return;
    if(n->picker.open) { if(k == 27) file_picker_close(&n->picker); return; }

    if(n->prompt == PR_SAVE_AS) {
        if(k == '\n' || k == '\r') {
            if(n->prompt_len > 0) { char full[FSU_PATH_MAX]; fsu_normalize("/", n->prompt_text, full, sizeof(full)); if(save_to(n, full)) n->prompt = PR_NONE; }
        }
        else if(k == 27) n->prompt = PR_NONE;
        else if(k == '\b' || k == 127) { if(n->prompt_len > 0) n->prompt_text[--n->prompt_len] = 0; }
        else if(k >= ' ' && (unsigned char)k < 127 && n->prompt_len < FSU_PATH_MAX - 2) { n->prompt_text[n->prompt_len++] = k; n->prompt_text[n->prompt_len] = 0; }
        return;
    }
    if(n->prompt == PR_CONFIRM_NEW || n->prompt == PR_CONFIRM_OPEN) {
        if(k == 'y' || k == 'Y') { prompt_t p = n->prompt; n->prompt = PR_NONE; n->modified = 0; if(p == PR_CONFIRM_NEW) new_doc(n); else file_picker_open(&n->picker, NULL); }
        else if(k == 'n' || k == 'N' || k == 27) n->prompt = PR_NONE;
        return;
    }

    int keep_want = 0;
    if(k == 14) request_new(n);              /* Ctrl+N */
    else if(k == 15) request_open(n);        /* Ctrl+O */
    else if(k == 19) do_save(n);             /* Ctrl+S */
    else if(k == 1) do_select_all(n);        /* Ctrl+A */
    else if(k == 3) do_copy(n);              /* Ctrl+C */
    else if(k == 24) do_cut(n);              /* Ctrl+X */
    else if(k == 22) do_paste(n);            /* Ctrl+V */
    else if(k == KEY_LEFT) { if(has_sel(n)) n->cursor = sel_lo(n); else if(n->cursor > 0) n->cursor--; n->anchor = -1; }
    else if(k == KEY_RIGHT) { if(has_sel(n)) n->cursor = sel_hi(n); else if(n->cursor < n->len) n->cursor++; n->anchor = -1; }
    else if(k == KEY_UP) { n->anchor = -1; move_vertical(n, -1); keep_want = 1; }
    else if(k == KEY_DOWN) { n->anchor = -1; move_vertical(n, 1); keep_want = 1; }
    else if(k == KEY_PGUP) { n->anchor = -1; move_vertical(n, -n->text_rows); keep_want = 1; }
    else if(k == KEY_PGDN) { n->anchor = -1; move_vertical(n, n->text_rows); keep_want = 1; }
    else if(k == KEY_HOME) { ensure_lines(n); n->cursor = n->line_start[line_of(n, n->cursor)]; n->anchor = -1; }
    else if(k == KEY_END) { n->cursor = line_end(n, line_of(n, n->cursor)); n->anchor = -1; }
    else if(k == KEY_DELETE) { if(has_sel(n)) delete_selection(n); else if(n->cursor < n->len) delete_range(n, n->cursor, n->cursor + 1); }
    else if(k == '\b' || k == 127) { if(has_sel(n)) delete_selection(n); else if(n->cursor > 0) delete_range(n, n->cursor - 1, n->cursor); }
    else if(k == '\n' || k == '\r') { char c = '\n'; insert_text(n, &c, 1); }
    else if(k == '\t') { char c = '\t'; insert_text(n, &c, 1); }
    else if(k >= ' ' && (unsigned char)k < 127) { insert_text(n, &k, 1); }
    else return;

    ensure_lines(n);
    if(!keep_want) n->want_col = vcol_of(n, line_of(n, n->cursor), n->cursor);
    ensure_visible(n);
}

static void np_scroll(window_t *self, int rx, int ry, int notches) {
    (void)rx; (void)ry;
    np_t *n = (np_t *)self->user_data;
    if(!n) return;
    int max_top = n->line_count - n->text_rows;
    if(max_top < 0) max_top = 0;
    n->top_line += notches * 3;
    if(n->top_line < 0) n->top_line = 0;
    if(n->top_line > max_top) n->top_line = max_top;
}

static void np_destroy(window_t *self) {
    np_t *n = (np_t *)self->user_data; if(!n) return;
    if(n->buf) kfree(n->buf);
    if(n->line_start) kfree(n->line_start);
    kfree(n); self->user_data = NULL;
}

static window_t *create_notepad(void) {
    int sw = (int)gfx_width(), sh = (int)gfx_height();
    int w = 720, h = 500; if(w > sw - 40) w = sw - 40; if(h > sh - 70) h = sh - 70;
    static int cascade = 0;
    window_t *win = wm_create_window("Untitled - Notepad", 80 + (cascade % 6) * 26, 40 + (cascade % 6) * 26, w, h, C_BG);
    cascade++;
    if(!win) return NULL;
    np_t *n = (np_t *)kmalloc(sizeof(np_t));
    if(!n) { wm_destroy_window(win); return NULL; }
    memset(n, 0, sizeof(*n));
    n->buf = (char *)kmalloc(NP_CAP);
    n->line_start = (int *)kmalloc(NP_MAX_LINES * sizeof(int));
    if(!n->buf || !n->line_start) { if(n->buf) kfree(n->buf); if(n->line_start) kfree(n->line_start); kfree(n); wm_destroy_window(win); return NULL; }
    n->win = win; n->anchor = -1; n->menu_hover = -1; n->crlf = 1; n->lines_dirty = 1; n->text_rows = 20; n->text_cols = 80;
    win->user_data = n;
    win->on_paint = np_paint; win->on_click = np_click; win->on_drag = np_drag; win->on_mouse_up = np_mouse_up;
    win->on_right_click = np_right_click; win->cursor_at = np_cursor_at; win->on_key = np_key; win->on_scroll = np_scroll; win->on_destroy = np_destroy;
    update_title(n);
    return win;
}

void launch_notepad(void) { create_notepad(); }

void launch_notepad_with_file(const char *path) {
    window_t *w = create_notepad(); if(!w) return;
    np_t *n = (np_t *)w->user_data;
    load_file(n, path);
}
