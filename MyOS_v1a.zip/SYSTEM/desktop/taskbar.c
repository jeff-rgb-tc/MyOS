#include "stdint.h"
#include "stddef.h"
#include "taskbar.h"
#include "window.h"
#include "gfx.h"
#include "audio.h"
#include "apps.h"
#include "icon.h"
#include "common.h"
#include "kernio.h"
#include "power.h"
#include "rtc.h"
#include "mouse.h"
#include "desktop.h"
#include "settings.h"
#include "png.h"
#include "kheap.h"
#include "system_icons.h"
#include "cursor_set.h"
#include "mouse.h"
#include "app_calendar.h"
#include "startmenu.h"

/* Darker, semi-transparent taskbar -- gfx_blend_rounded_rect (radius 0
 * behaves like a plain blended fill) is used instead of gfx_fill_rect so
 * the alpha byte in COLOR_TASKBAR_BG actually takes effect; a plain
 * gfx_fill_rect would just overwrite with an opaque color regardless of
 * alpha. 0xB0 alpha (~69%) reads as "not fully see-through" while still
 * letting the desktop background show through a bit, per the brief of
 * "translucent but not strongly so". */
#define COLOR_TASKBAR_BG    0xD2202024
#define COLOR_TASKBAR_LIGHT 0xFFE8E8E8
#define COLOR_TASKBAR_DARK  0xFF808080
/* Start button is solid black now (see draw_start_button) rather than
 * green -- COLOR_START_BUTTON/_ACTIVE below are unused for the fill
 * itself but kept for the bevel/active-state distinction. */
#define COLOR_START_BUTTON  0xFF000000
#define COLOR_START_BUTTON_ACTIVE 0xFF1A1A1A
#define COLOR_START_TEXT    0xFFFFFFFF
#define COLOR_TASK_BUTTON       0xFFB0B0B0
#define COLOR_TASK_BUTTON_ACT   0xFF9090D0
#define COLOR_TASK_TEXT         0xFF000000
#define COLOR_MENU_BG           0xF4222226 /* dark, slightly translucent, matching the taskbar/context menu */
#define COLOR_MENU_BORDER       0x30FFFFFF
#define COLOR_MENU_TEXT         0xFFFFFFFF
#define COLOR_MENU_HOVER        0x40FFFFFF /* same soft white wash as context_menu.c's hover */
#define COLOR_CLOCK_TEXT        0xFFFFFFFF

#define START_BUTTON_WIDTH 72
#define TASK_BUTTON_WIDTH 140
#define TASK_BUTTON_GAP 4
#define CLOCK_WIDTH 78

#define START_ICON_PATH "/SYSTEM/res/omys.ico"
/* Bigger Start menu, per the design brief -- both the per-item height
 * and the overall width grew (was 36/200) to give icons and labels more
 * room and make the menu feel proportionate to the rest of the
 * restyled, bolder taskbar UI. */
#define MENU_WIDTH 260
#define MENU_CORNER_RADIUS 10

/* Below the app list, the Start menu always shows three built-in system
 * items -- Sleep, Restart, and Shut Down (in that order, Sleep on top,
 * matching the brief's "sleep above restart") -- separated from the
 * apps by a thin divider line. These aren't regular apps (no icon, no
 * window to launch), so they're handled separately from the
 * apps_get()/app->launch loop rather than being added to the app
 * registry. */
#define MENU_DIVIDER_HEIGHT 6
#define MENU_SYSTEM_ITEM_COUNT 3
#define MENU_ITEM_SLEEP 0
#define MENU_ITEM_RESTART 1
#define MENU_ITEM_SHUTDOWN 2

/* Header row at the top of the Start menu showing the profile avatar +
 * username (see settings.h's username/avatar_path) -- Windows-style.
 * Sits above the app list, which is offset down by this much. */
#define MENU_HEADER_HEIGHT 56
#define PROFILE_AVATAR_SIZE 40

/* The menu grows with the number of registered apps. 48px rows look
 * best, but with ten-odd apps on an 800x600 / 1024x768 screen they would
 * run off the top, so the row height shrinks (never below 28px) until
 * the whole menu fits above the taskbar. */

static icon_image_t start_icon;
static uint8_t start_icon_loaded = 0;

void taskbar_init() {
    if(icon_load_from_file(START_ICON_PATH, &start_icon)) {
        start_icon_loaded = 1;
    }
    else {
        printf("taskbar: failed to load Start icon %s\n", START_ICON_PATH);
        start_icon_loaded = 0;
    }
}

static int vol_open;   /* defined with the volume flyout below */

int taskbar_get_dock(void) {
    int d = settings_current()->taskbar_dock;
    return (d >= 0 && d <= 3) ? d : TASKBAR_DOCK_BOTTOM;
}

void taskbar_set_dock(int dock) {
    if(dock < 0 || dock > 3) return;
    settings_current()->taskbar_dock = dock;
    startmenu_close();
    vol_open = 0;
    settings_save();
}

static int dock_vertical(void) { int d = taskbar_get_dock(); return d == TASKBAR_DOCK_LEFT || d == TASKBAR_DOCK_RIGHT; }

/* The strip the taskbar occupies. */
static void bar_rect(int *x, int *y, int *w, int *h) {
    int sw = (int)gfx_width(), sh = (int)gfx_height();
    switch(taskbar_get_dock()) {
        case TASKBAR_DOCK_TOP:   *x = 0; *y = 0; *w = sw; *h = TASKBAR_HEIGHT; break;
        case TASKBAR_DOCK_LEFT:  *x = 0; *y = 0; *w = TASKBAR_SIDE_WIDTH; *h = sh; break;
        case TASKBAR_DOCK_RIGHT: *x = sw - TASKBAR_SIDE_WIDTH; *y = 0; *w = TASKBAR_SIDE_WIDTH; *h = sh; break;
        default:                 *x = 0; *y = sh - TASKBAR_HEIGHT; *w = sw; *h = TASKBAR_HEIGHT; break;
    }
}

void taskbar_work_area(int *x, int *y, int *w, int *h) {
    int sw = (int)gfx_width(), sh = (int)gfx_height();
    switch(taskbar_get_dock()) {
        case TASKBAR_DOCK_TOP:   *x = 0; *y = TASKBAR_HEIGHT; *w = sw; *h = sh - TASKBAR_HEIGHT; break;
        case TASKBAR_DOCK_LEFT:  *x = TASKBAR_SIDE_WIDTH; *y = 0; *w = sw - TASKBAR_SIDE_WIDTH; *h = sh; break;
        case TASKBAR_DOCK_RIGHT: *x = 0; *y = 0; *w = sw - TASKBAR_SIDE_WIDTH; *h = sh; break;
        default:                 *x = 0; *y = 0; *w = sw; *h = sh - TASKBAR_HEIGHT; break;
    }
}

int taskbar_contains(int x, int y) {
    int bx, by, bw, bh; bar_rect(&bx, &by, &bw, &bh);
    return x >= bx && x < bx + bw && y >= by && y < by + bh;
}

int taskbar_start_menu_open() {
    return startmenu_is_open();
}

void taskbar_close_start_menu() {
    startmenu_close();
}

#define SIDE_BUTTON_H 28

static int start_button_rect(int *out_x, int *out_y, int *out_w, int *out_h) {
    int bx, by, bw, bh; bar_rect(&bx, &by, &bw, &bh);
    if(dock_vertical()) { *out_x = bx + 4; *out_y = 4; *out_w = bw - 8; *out_h = TASKBAR_HEIGHT - 4; }
    else { *out_x = 2; *out_y = by + 2; *out_w = START_BUTTON_WIDTH; *out_h = TASKBAR_HEIGHT - 4; }
    return 1;
}

static int task_button_rect(int index, int *out_x, int *out_y, int *out_w, int *out_h) {
    int bx, by, bw, bh; bar_rect(&bx, &by, &bw, &bh);
    if(dock_vertical()) {
        *out_x = bx + 4; *out_w = bw - 8; *out_h = SIDE_BUTTON_H;
        *out_y = 4 + (TASKBAR_HEIGHT - 4) + 8 + index * (SIDE_BUTTON_H + 4);
    } else {
        *out_x = 2 + START_BUTTON_WIDTH + TASK_BUTTON_GAP + index * (TASK_BUTTON_WIDTH + TASK_BUTTON_GAP);
        *out_y = by + 2; *out_w = TASK_BUTTON_WIDTH; *out_h = TASKBAR_HEIGHT - 4;
    }
    return 1;
}

/* False once a task button no longer fits (it would run under the clock/tray). */
static int task_button_fits(int bx, int by, int bw, int bh) {
    if(dock_vertical()) return by + bh <= (int)gfx_height() - 70;
    return bx + bw <= (int)gfx_width() - CLOCK_WIDTH - 48;
}

static void draw_start_button() {
    int sx, sy, sw, sh;
    start_button_rect(&sx, &sy, &sw, &sh);

    uint32_t color = startmenu_is_open() ? COLOR_START_BUTTON_ACTIVE : COLOR_START_BUTTON;
    /* Fully rounded (all four corners) black pill, per the design brief
     * -- radius = half the button height gives the classic pill/stadium
     * shape rather than just softened corners. */
    int radius = sh / 2;
    gfx_fill_rounded_rect(sx, sy, sw, sh, radius, color);
    /* No border/bevel here: gfx_draw_bevel and gfx_draw_rect both draw
     * straight rectangular edges, which would poke square corners
     * outside this pill's rounded silhouette. A flat fill with no
     * outline reads cleanly as a pill button on its own. */

    if(start_icon_loaded && start_icon.pixels) {
        int icon_display_size = sh - 4; /* leave a small margin within the button */
        int icon_y = sy + (sh - icon_display_size) / 2;
        int icon_x = sx + 4;

        /* omys.ico is itself black, so on a black button it would
         * otherwise be invisible -- lay down a soft white glow behind it
         * first. There's no blur primitive, so the glow is faked with a
         * handful of nested, increasingly-transparent rounded squares
         * (a cheap radial falloff) centered on the icon. Kept small and
         * low-alpha (max 1-3px past the icon edge, alpha maxing out
         * around 0x28) and blended-not-replaced: the inner rings overlap
         * the outer ones, so alpha compounds layer over layer, and it
         * doesn't take much before it reads as a bright blob rather than
         * a subtle halo. */
        int glow_cx = icon_x + icon_display_size / 2;
        int glow_cy = icon_y + icon_display_size / 2;
        static const struct { int extra; uint8_t alpha; } glow_steps[] = {
            { 1, 0x28 },
            { 3, 0x16 },
            { 5, 0x0A },
        };
        for(unsigned i = 0; i < sizeof(glow_steps) / sizeof(glow_steps[0]); i++) {
            int gs = icon_display_size + glow_steps[i].extra * 2;
            int gx = glow_cx - gs / 2;
            int gy = glow_cy - gs / 2;
            uint32_t glow_argb = ((uint32_t)glow_steps[i].alpha << 24) | 0x00FFFFFF;
            gfx_blend_rounded_rect(gx, gy, gs, gs, gs / 3, glow_argb);
        }

        gfx_blit_scaled_argb_alpha(icon_x, icon_y, icon_display_size, icon_display_size,
                                   start_icon.pixels, start_icon.width, start_icon.height);
        gfx_draw_string(icon_x + icon_display_size + 4, sy + (sh - 16) / 2, "MyOS", COLOR_START_TEXT);
    }
    else {
        gfx_draw_string(sx + 8, sy + (sh - 16) / 2, "MyOS", COLOR_START_TEXT);
    }
}

/* Avatar caching: reloading the avatar PNG from disk every single frame
 * the Start menu happens to be open would be wasteful (a file open +
 * decode per frame for something that only changes when the user picks
 * a new one in Settings). Cached by path -- if settings_current()'s
 * avatar_path differs from what's currently cached, reload; empty path
 * means "no avatar", drawn as a plain placeholder circle instead. */

/* Right-aligned HH:MM:SS clock, read from the CMOS RTC each frame. The
 * RTC itself only advances once a second, so re-reading every frame is
 * fine cost-wise -- rtc_read_time() is a handful of port I/O reads, not
 * a filesystem or heap operation. */
static void clock_rect(int *x, int *y, int *w, int *h) {
    int screen_w = (int)gfx_width(), screen_h = (int)gfx_height();
    int bx, by, bw, bh; bar_rect(&bx, &by, &bw, &bh);
    if(dock_vertical()) { *x = bx + 4; *y = screen_h - 30; *w = bw - 8; *h = 26; return; }
    *x = screen_w - CLOCK_WIDTH - 2;
    *y = by + 3;
    *w = CLOCK_WIDTH;
    *h = TASKBAR_HEIGHT - 6;
}

static void draw_clock() {
    rtc_time_t t;
    rtc_read_time(&t);

    char buffer[12];
    sprintf(buffer, "%02d:%02d:%02d", t.hours, t.minutes, t.seconds);

    int rx, ry, rw, rh;
    clock_rect(&rx, &ry, &rw, &rh);

    /* The clock is a button: it opens the Calendar. */
    mouse_state_t *m = mouse_get_state();
    if(m->x >= rx && m->x < rx + rw && m->y >= ry && m->y < ry + rh) {
        gfx_blend_rounded_rect(rx, ry, rw, rh, 6, 0x26FFFFFF);
    }
    gfx_draw_string(rx + (rw - 8 * GFX_CHAR_COLS) / 2, ry + (rh - 16) / 2, buffer, COLOR_CLOCK_TEXT);
}


/* ---------------- volume tray icon + flyout ---------------- */
static int vol_open = 0;
static int vol_dragging = 0;
#define VOL_PANEL_W 250
#define VOL_PANEL_H 64
#define VOL_TRAY_W 30

static void vol_tray_rect(int *x, int *y, int *w, int *h) {
    int screen_w = (int)gfx_width(), screen_h = (int)gfx_height();
    int bx, by, bw, bh; bar_rect(&bx, &by, &bw, &bh);
    if(dock_vertical()) { *x = bx + 4; *y = screen_h - 30 - 34; *w = VOL_TRAY_W; *h = 32; return; }
    *x = screen_w - CLOCK_WIDTH - VOL_TRAY_W - 8; *y = by; *w = VOL_TRAY_W; *h = TASKBAR_HEIGHT;
}
static void vol_panel_rect(int *x, int *y, int *w, int *h) {
    int screen_w = (int)gfx_width(), screen_h = (int)gfx_height();
    *w = VOL_PANEL_W; *h = VOL_PANEL_H;
    switch(taskbar_get_dock()) {
        case TASKBAR_DOCK_TOP:   *x = screen_w - VOL_PANEL_W - 8; *y = TASKBAR_HEIGHT + 8; break;
        case TASKBAR_DOCK_LEFT:  *x = TASKBAR_SIDE_WIDTH + 8; *y = screen_h - VOL_PANEL_H - 8; break;
        case TASKBAR_DOCK_RIGHT: *x = screen_w - TASKBAR_SIDE_WIDTH - VOL_PANEL_W - 8; *y = screen_h - VOL_PANEL_H - 8; break;
        default:                 *x = screen_w - VOL_PANEL_W - 8; *y = screen_h - TASKBAR_HEIGHT - VOL_PANEL_H - 8; break;
    }
}
#define VOL_SLIDER_X_OFF 52
#define VOL_SLIDER_W 150

static void draw_speaker_glyph(int x, int y, uint32_t col, int muted, int level) {
    gfx_fill_rect(x, y + 5, 4, 6, col);
    for(int i = 0; i < 6; i++) gfx_fill_rect(x + 4 + i, y + 7 - i, 1, 2 + i * 2 - (i > 4 ? 0 : 0) + (i ? 0 : 0), col);
    if(muted) { for(int i = 0; i < 8; i++) { gfx_fill_rect(x + 13 + i, y + 4 + i, 2, 2, 0xFFFF6B6B); gfx_fill_rect(x + 20 - i, y + 4 + i, 2, 2, 0xFFFF6B6B); } }
    else {
        if(level > 0)  gfx_fill_rect(x + 12, y + 5, 2, 6, col);
        if(level > 40) gfx_fill_rect(x + 15, y + 3, 2, 10, col);
        if(level > 75) gfx_fill_rect(x + 18, y + 1, 2, 14, col);
    }
}

static void draw_volume_tray(void) {
    int x, y, w, h; vol_tray_rect(&x, &y, &w, &h);
    int muted = audio_is_muted();
    if(vol_open) gfx_blend_rounded_rect(x, y + 3, w, h - 6, 4, 0x30FFFFFF);
    draw_speaker_glyph(x + 4, y + (h - 16) / 2, COLOR_CLOCK_TEXT, muted, audio_get_volume());
}

static void draw_volume_flyout(void) {
    if(!vol_open) return;
    int x, y, w, h; vol_panel_rect(&x, &y, &w, &h);
    gfx_draw_shadow(x, y, w, h, 10, 18, 5, 96);
    gfx_blend_rounded_rect(x, y, w, h, 10, 0xEE262629);
    gfx_draw_rounded_outline(x, y, w, h, 10, 0x30FFFFFF);
    int muted = audio_is_muted(); int vol = audio_get_volume();
    draw_speaker_glyph(x + 16, y + (h - 16) / 2, muted ? 0xFF888888 : COLOR_CLOCK_TEXT, muted, vol);
    int sx = x + VOL_SLIDER_X_OFF, sy = y + h / 2 - 2;
    int fill = muted ? 0 : (vol * VOL_SLIDER_W) / 100;
    gfx_fill_rounded_rect(sx, sy, VOL_SLIDER_W, 4, 2, 0xFF5A5A5A);
    if(fill > 0) gfx_fill_rounded_rect(sx, sy, fill, 4, 2, 0xFF4CC2FF);
    gfx_fill_rounded_rect(sx + fill - 7, sy - 7, 18, 18, 9, 0xFFE8E8E8);
    gfx_fill_rounded_rect(sx + fill - 3, sy - 3, 10, 10, 5, 0xFF4CC2FF);
    char t[8]; sprintf(t, "%d", muted ? 0 : vol);
    gfx_draw_string(x + w - 34, y + h / 2 - 8, t, COLOR_CLOCK_TEXT);
}

static void vol_set_from_x(int mx) {
    int sx; { int x, y, w, h; vol_panel_rect(&x, &y, &w, &h); sx = x + VOL_SLIDER_X_OFF; }
    int v = ((mx - sx) * 100) / VOL_SLIDER_W;
    if(v < 0) v = 0; if(v > 100) v = 100;
    audio_set_volume((uint8_t)v); audio_set_muted(0);
    settings_t *s = settings_current(); s->volume = v; s->muted = 0;
}

int taskbar_volume_open() { return vol_open; }

void taskbar_mouse_motion(int x, int y) {
    if(vol_dragging) vol_set_from_x(x);
    startmenu_motion(x, y);
}

void taskbar_mouse_up() {
    if(vol_dragging) { vol_dragging = 0; settings_save(); }
    startmenu_mouse_up();
}

/* Returns 1 if the click was consumed by the flyout. */
static int handle_volume_click(int x, int y) {
    int tx, ty, tw, th; vol_tray_rect(&tx, &ty, &tw, &th);
    if(x >= tx && x < tx + tw && y >= ty && y < ty + th) { vol_open = !vol_open; return 1; }
    if(!vol_open) return 0;

    int px, py, pw, ph; vol_panel_rect(&px, &py, &pw, &ph);
    if(x >= px && x < px + pw && y >= py && y < py + ph) {
        if(x < px + 44) { /* speaker glyph: mute toggle */
            int m = !audio_is_muted(); audio_set_muted(m); settings_current()->muted = m; settings_save();
        }
        else if(x >= px + VOL_SLIDER_X_OFF - 10 && x <= px + VOL_SLIDER_X_OFF + VOL_SLIDER_W + 10) {
            vol_dragging = 1; vol_set_from_x(x);
        }
        return 1;
    }
    vol_open = 0; /* click elsewhere closes the flyout and continues normally */
    return 0;
}

void taskbar_draw() {
    int bar_x, bar_y, bar_w, bar_h; bar_rect(&bar_x, &bar_y, &bar_w, &bar_h);

    /* gfx_blend_rounded_rect with radius 0 is a plain alpha-blended
     * fill -- gfx_fill_rect would ignore COLOR_TASKBAR_BG's alpha byte
     * and just paint it fully opaque, which is why this isn't a
     * gfx_fill_rect call. */
    int dk = taskbar_get_dock();
    gfx_draw_shadow(bar_x, bar_y, bar_w, bar_h, 0, 10, dk == TASKBAR_DOCK_BOTTOM ? -2 : (dk == TASKBAR_DOCK_TOP ? 2 : 0), 70);
    gfx_blend_rounded_rect(bar_x, bar_y, bar_w, bar_h, 0, COLOR_TASKBAR_BG);
    /* light edge on the side that faces the desktop */
    if(dk == TASKBAR_DOCK_BOTTOM)     gfx_blend_rounded_rect(bar_x, bar_y, bar_w, 1, 0, 0x2AFFFFFF);
    else if(dk == TASKBAR_DOCK_TOP)   gfx_blend_rounded_rect(bar_x, bar_y + bar_h - 1, bar_w, 1, 0, 0x2AFFFFFF);
    else if(dk == TASKBAR_DOCK_LEFT)  gfx_blend_rounded_rect(bar_x + bar_w - 1, bar_y, 1, bar_h, 0, 0x2AFFFFFF);
    else                              gfx_blend_rounded_rect(bar_x, bar_y, 1, bar_h, 0, 0x2AFFFFFF);

    draw_start_button();
    draw_clock();
    draw_volume_tray();

    /* One button per open window */
    int count = wm_window_count();
    window_t *focused = wm_focused_window();
    for(int i = 0; i < count; i++) {
        window_t *win = wm_window_at_index(i);
        if(!win || !win->in_use) continue;

        int bx, by, bw, bh;
        task_button_rect(i, &bx, &by, &bw, &bh);
        /* Leave room for the clock on the right -- CLOCK_WIDTH plus a
         * small gap, not just the bare screen edge, so a long row of
         * task buttons can't be drawn underneath the time. */
        if(!task_button_fits(bx, by, bw, bh)) break; /* ran out of taskbar space */

        int active = (win == focused) && !win->minimized;
        int hover = (mouse_get_state()->x >= bx && mouse_get_state()->x < bx + bw &&
                     mouse_get_state()->y >= by && mouse_get_state()->y < by + bh);
        uint32_t wash = active ? 0x3AFFFFFF : (hover ? 0x26FFFFFF : 0x14FFFFFF);
        gfx_blend_rounded_rect(bx, by, bw, bh, 6, wash);

        /* Little state indicator under the button: accent bar for the
         * focused window, short dim bar for open ones, nothing for
         * minimized ones. */
        if(active) {
            gfx_blend_rounded_rect(bx + bw / 2 - 9, by + bh - 3, 18, 2, 1, 0xFF4CC2FF);
        }
        else if(!win->minimized) {
            gfx_blend_rounded_rect(bx + bw / 2 - 3, by + bh - 3, 6, 2, 1, 0xA0FFFFFF);
        }

        /* App icon when the window title starts with a registered app's
         * name ("Calculator", "Notepad - foo.txt", ...). */
        int text_x = bx + 10;
        int icon_px = 20;
        for(int ai = 0; ai < apps_count(); ai++) {
            app_entry_t *app = apps_get(ai);
            if(!app) continue;
            int n = 0;
            while(app->name[n] && win->title[n] == app->name[n]) n++;
            if(app->name[n] != '\0') continue;
            app_icon_t *ic = apps_get_icon(app);
            if(ic) {
                gfx_blit_scaled_argb_alpha(bx + 8, by + (bh - icon_px) / 2 - 1, icon_px, icon_px,
                                           ic->pixels, ic->width, ic->height);
                text_x = bx + 8 + icon_px + 6;
            }
            break;
        }

        /* Truncate long titles so they don't spill past the button. */
        int max_chars = (bx + bw - 6 - text_x) / GFX_CHAR_COLS;
        char label[24];
        int j = 0;
        while(win->title[j] && j < (int)sizeof(label) - 1) {
            label[j] = win->title[j];
            j++;
        }
        label[j] = '\0';
        if(max_chars < 1) max_chars = 1;
        if(j > max_chars) {
            if(max_chars >= 3) { label[max_chars - 2] = '.'; label[max_chars - 1] = '.'; }
            label[max_chars] = '\0';
        }

        gfx_draw_string(text_x, by + (bh - 16) / 2 - 1, label,
                        win->minimized ? 0xFF9A9AA2 : 0xFFF2F2F5);
    }

    /* The Start menu floats above the taskbar strip, so it's drawn last
     * (on top of everything else this frame, including any windows that
     * might visually overlap that screen region). */
    startmenu_draw();
    draw_volume_flyout();
}

int taskbar_cursor_at(int x, int y) {
    if(startmenu_is_open()) {
        int c = startmenu_cursor_at(x, y);
        if(c >= 0) return c;
    }

    if(!taskbar_contains(x, y)) {
        return CURSOR_DEFAULT;
    }

    int sx, sy, sw, sh;
    start_button_rect(&sx, &sy, &sw, &sh);
    if(x >= sx && x < sx + sw && y >= sy && y < sy + sh) {
        return CURSOR_LINK;
    }

    int kx, ky, kw, kh;
    clock_rect(&kx, &ky, &kw, &kh);
    if(x >= kx && x < kx + kw && y >= ky && y < ky + kh) {
        return CURSOR_LINK;
    }

    int count = wm_window_count();
    for(int i = 0; i < count; i++) {
        window_t *win = wm_window_at_index(i);
        if(!win || !win->in_use) continue;

        int bx, by, bw, bh;
        task_button_rect(i, &bx, &by, &bw, &bh);
        if(!task_button_fits(bx, by, bw, bh)) break;

        if(x >= bx && x < bx + bw && y >= by && y < by + bh) {
            return CURSOR_LINK;
        }
    }

    return CURSOR_DEFAULT;
}

int taskbar_handle_click(int x, int y) {
    if(handle_volume_click(x, y)) { startmenu_close(); return 1; }

    if(startmenu_is_open()) {
        int consumed = startmenu_click(x, y);
        if(consumed) {
            return 1;
        }
        /* Menu was closed by an outside click; fall through so a click
         * that also happens to land on the taskbar/Start button below
         * still gets handled normally in the same click. */
    }

    if(!taskbar_contains(x, y)) {
        return 0;
    }

    int sx, sy, sw, sh;
    start_button_rect(&sx, &sy, &sw, &sh);
    if(x >= sx && x < sx + sw && y >= sy && y < sy + sh) {
        vol_open = 0;
        startmenu_toggle();
        return 1;
    }

    int kx, ky, kw, kh;
    clock_rect(&kx, &ky, &kw, &kh);
    if(x >= kx && x < kx + kw && y >= ky && y < ky + kh) {
        startmenu_close();
        vol_open = 0;
        launch_calendar();
        return 1;
    }

    int count = wm_window_count();
    for(int i = 0; i < count; i++) {
        window_t *win = wm_window_at_index(i);
        if(!win || !win->in_use) continue;

        int bx, by, bw, bh;
        task_button_rect(i, &bx, &by, &bw, &bh);
        if(!task_button_fits(bx, by, bw, bh)) break;

        if(x >= bx && x < bx + bw && y >= by && y < by + bh) {
            if(win->minimized) {
                wm_restore_window(win);
            }
            else {
                wm_focus(win);
            }
            return 1;
        }
    }

    /* The thin sliver at the far end of a horizontal taskbar: "show desktop". */
    if(!dock_vertical() && x >= (int)gfx_width() - 6) {
        startmenu_close();
        for(int i = 0; i < wm_window_count(); i++) {
            window_t *w = wm_window_at_index(i);
            if(w && w->in_use && !w->minimized) wm_minimize_window(w);
        }
        return 1;
    }

    /* Click landed on empty taskbar space; still consume it so it doesn't
     * fall through to the desktop underneath. */
    return 1;
}
