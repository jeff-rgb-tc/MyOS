#include "file_picker.h"
#include "fat32.h"
#include "common.h"
#include "gfx.h"
#include "pit.h"

#define ROW_HEIGHT 20
#define TOOLBAR_HEIGHT 28
/* Same real wall-clock double-click window as everywhere else in this
 * desktop (desktop.c/app_explorer.c/app_paint.c all settled on this
 * exact value after measuring real double-clicks under QEMU -- see
 * desktop.c's DOUBLE_CLICK_TICK_WINDOW comment for the full story). */
#define DOUBLE_CLICK_TICK_WINDOW 12

static const char *last_dot(const char *name) {
    const char *result = NULL;
    for(const char *p = name; *p; p++) {
        if(*p == '.') result = p;
    }
    return result;
}

static void load_current_dir(file_picker_t *fp) {
    struct directory dir;
    if(!master_fs) {
        fp->entry_count = 0;
        return;
    }

    if(fp->depth == 0) {
        populate_root_dir(master_fs, &dir);
    }
    else {
        populate_dir(master_fs, &dir, fp->path_stack[fp->depth - 1]);
    }

    fp->entry_count = 0;
    for(uint32_t i = 0; i < dir.num_entries && fp->entry_count < FILE_PICKER_MAX_ENTRIES; i++) {
        struct dir_entry *e = &dir.entries[i];
        if(!e->name || (e->dir_attrs & LFN)) continue;

        int is_dir = (e->dir_attrs & DIRECTORY) != 0;
        if(!is_dir && fp->extension_filter[0]) {
            const char *ext = last_dot(e->name);
            if(!ext || strcasecmp(ext + 1, fp->extension_filter) != 0) {
                continue; /* filtered out -- not the extension this picker wants */
            }
        }

        file_picker_entry_t *fe = &fp->entries[fp->entry_count];
        int j = 0;
        while(e->name[j] && j < FILE_PICKER_NAME_MAX - 1) { fe->name[j] = e->name[j]; j++; }
        fe->name[j] = '\0';
        fe->is_dir = (uint8_t)is_dir;
        fp->entry_count++;
    }

    free_directory(master_fs, &dir);
    fp->scroll = 0;
    fp->last_click_index = -1;
}

void file_picker_open(file_picker_t *fp, const char *extension_filter) {
    memset(fp, 0, sizeof(file_picker_t));
    fp->open = 1;
    fp->depth = 0;
    fp->last_click_index = -1;
    fp->last_click_tick = -1000;

    if(extension_filter) {
        int i = 0;
        while(extension_filter[i] && i < (int)sizeof(fp->extension_filter) - 1) {
            fp->extension_filter[i] = extension_filter[i];
            i++;
        }
        fp->extension_filter[i] = '\0';
    }

    load_current_dir(fp);
}

void file_picker_close(file_picker_t *fp) {
    fp->open = 0;
}

static void enter_dir(file_picker_t *fp, const char *name, uint32_t cluster) {
    if(fp->depth >= FILE_PICKER_MAX_DEPTH) return;
    fp->path_stack[fp->depth] = cluster;
    int j = 0;
    while(name[j] && j < FILE_PICKER_NAME_MAX - 1) { fp->path_names[fp->depth][j] = name[j]; j++; }
    fp->path_names[fp->depth][j] = '\0';
    fp->depth++;
    load_current_dir(fp);
}

static void go_up(file_picker_t *fp) {
    if(fp->depth == 0) return;
    fp->depth--;
    load_current_dir(fp);
}

void file_picker_draw(file_picker_t *fp, int x, int y, int w, int h) {
    gfx_fill_rect(x, y, w, h, 0xFFF0F0F0);
    gfx_draw_rect(x, y, w, h, 0xFF808080);

    /* Toolbar: Up button + current path breadcrumb */
    gfx_fill_rect(x, y, w, TOOLBAR_HEIGHT, 0xFFD4D0C8);
    gfx_draw_bevel(x, y, w, TOOLBAR_HEIGHT, 0xFFFFFFFF, 0xFF808080);
    gfx_fill_rect(x + 4, y + 4, 40, TOOLBAR_HEIGHT - 8, fp->depth > 0 ? 0xFFB0B0B0 : 0xFFD8D8D8);
    gfx_draw_bevel(x + 4, y + 4, 40, TOOLBAR_HEIGHT - 8, 0xFFFFFFFF, 0xFF808080);
    gfx_draw_string(x + 10, y + 6, "Up", 0xFF000000);

    char path[FILE_PICKER_PATH_MAX];
    int pos = 0;
    path[pos++] = '/';
    for(int i = 0; i < fp->depth && pos < (int)sizeof(path) - 2; i++) {
        int j = 0;
        while(fp->path_names[i][j] && pos < (int)sizeof(path) - 2) path[pos++] = fp->path_names[i][j++];
        path[pos++] = '/';
    }
    path[pos] = '\0';
    gfx_draw_string(x + 52, y + 6, path, 0xFF404040);

    int list_y = y + TOOLBAR_HEIGHT;
    int list_h = h - TOOLBAR_HEIGHT;
    int visible_rows = list_h / ROW_HEIGHT;

    if(fp->entry_count == 0) {
        gfx_draw_string(x + 8, list_y + 4, "(no matching files)", 0xFF888888);
        return;
    }

    for(int row = 0; row < visible_rows; row++) {
        int i = fp->scroll + row;
        if(i >= fp->entry_count) break;

        int row_y = list_y + row * ROW_HEIGHT;
        file_picker_entry_t *fe = &fp->entries[i];

        if(i == fp->last_click_index) {
            gfx_fill_rect(x + 2, row_y, w - 4, ROW_HEIGHT, 0xFFCFE0FF);
        }

        const char *glyph = fe->is_dir ? "[D]" : "[F]";
        gfx_draw_string(x + 6, row_y + 2, glyph, fe->is_dir ? 0xFF9C7A00 : 0xFF404040);
        gfx_draw_string(x + 34, row_y + 2, fe->name, 0xFF000000);
    }
}

void file_picker_handle_click(file_picker_t *fp, int x, int y, int w, int h) {
    (void)h;
    fp->file_chosen = 0;

    /* Up button */
    if(y >= 4 && y < TOOLBAR_HEIGHT - 4 && x >= 4 && x < 44) {
        go_up(fp);
        return;
    }

    int list_y = TOOLBAR_HEIGHT;
    if(y < list_y) return;

    int row = (y - list_y) / ROW_HEIGHT;
    int i = fp->scroll + row;
    if(i < 0 || i >= fp->entry_count) return;
    (void)w;

    file_picker_entry_t *fe = &fp->entries[i];

    if(i == fp->last_click_index && (pit_get_ticks() - fp->last_click_tick) < DOUBLE_CLICK_TICK_WINDOW) {
        /* Double-click */
        if(fe->is_dir) {
            /* Need this entry's cluster to descend into it -- re-fetch
             * from the real directory listing by name rather than
             * storing a cluster number in file_picker_entry_t (keeps
             * that struct small; this lookup only happens on an actual
             * double-click, not per-frame). */
            struct directory dir;
            if(fp->depth == 0) populate_root_dir(master_fs, &dir);
            else populate_dir(master_fs, &dir, fp->path_stack[fp->depth - 1]);

            for(uint32_t k = 0; k < dir.num_entries; k++) {
                if(dir.entries[k].name && strcmp(dir.entries[k].name, fe->name) == 0) {
                    enter_dir(fp, fe->name, dir.entries[k].first_cluster);
                    break;
                }
            }
            free_directory(master_fs, &dir);
        }
        else {
            /* File chosen -- build its full path and hand control back
             * to the caller (see file_picker.h's comment on
             * file_chosen: this picker never closes itself). */
            int pos = 0;
            fp->selected_path[pos++] = '/';
            for(int d = 0; d < fp->depth && pos < FILE_PICKER_PATH_MAX - 2; d++) {
                int j = 0;
                while(fp->path_names[d][j] && pos < FILE_PICKER_PATH_MAX - 2) {
                    fp->selected_path[pos++] = fp->path_names[d][j++];
                }
                fp->selected_path[pos++] = '/';
            }
            int j = 0;
            while(fe->name[j] && pos < FILE_PICKER_PATH_MAX - 1) fp->selected_path[pos++] = fe->name[j++];
            fp->selected_path[pos] = '\0';
            fp->file_chosen = 1;
        }
        fp->last_click_index = -1;
        fp->last_click_tick = -1000;
    }
    else {
        fp->last_click_index = i;
        fp->last_click_tick = pit_get_ticks();
    }
}
