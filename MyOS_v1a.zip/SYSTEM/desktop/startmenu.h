#ifndef DESKTOP_STARTMENU_H
#define DESKTOP_STARTMENU_H

#include "stdint.h"

/* The Start menu.
 *
 * A Windows-10-style all-apps list: apps grouped in expandable folders and
 * sub-folders, alphabetical letter headers, a scroll bar, a narrow rail with
 * Documents / Settings / Power, and type-to-search. Folders come from two
 * places: the app registry (built-ins are grouped, installed .app programs
 * go to "My Apps") and the real folder /Start Menu/Programs -- anything you
 * put there (sub-folders and .lnk shortcuts, made in Explorer) shows up here.
 *
 * Mouse: click rows, drag the scroll bar, right-click for "Create desktop
 * shortcut". Keyboard: just type to search, Up/Down/PgUp/PgDn/Home/End to
 * move, Left/Right to collapse/expand a folder, Enter to open, Esc to
 * clear/close. */

int  startmenu_is_open(void);
int  startmenu_animating(void);      /* the open animation is still running */

/* Pins `target` (a path, or "app:Name" for a built-in app) to the \"Pinned\" block at
 * the top of the Start menu. Returns 1 on success (or if it was already pinned). */
int  startmenu_pin(const char *name, const char *target);
void startmenu_toggle(void);
void startmenu_close(void);

void startmenu_draw(void);

/* Return 1 if the event was consumed. A click outside the menu closes it and
 * returns 0 so the click can also act on whatever is underneath. */
int  startmenu_click(int x, int y);
int  startmenu_right_click(int x, int y);
void startmenu_motion(int x, int y);
void startmenu_mouse_up(void);
void startmenu_key(char c);
void startmenu_scroll(int rows);         /* mouse wheel: positive = down */

/* Cursor kind (CURSOR_*) for the point, or -1 if the menu has no opinion. */
int  startmenu_cursor_at(int x, int y);

#endif
