#ifndef CLIPBOARD_H
#define CLIPBOARD_H

/* System-wide clipboard shared by Command Prompt (text) and Explorer
 * (file copy/cut/paste). */

#define CLIPBOARD_TEXT_MAX 16384
#define CLIPBOARD_MAX_FILES 8
#define CLIPBOARD_PATH_MAX 192

void clipboard_set_text(const char *text);
const char *clipboard_get_text(void);   /* "" if empty */

/* File clipboard: absolute paths. `cut` = 1 means Paste should move. */
void clipboard_set_file(const char *path, int cut);
int clipboard_has_file(void);
const char *clipboard_file_path(void);
int clipboard_file_is_cut(void);
void clipboard_clear_file(void);

#endif
