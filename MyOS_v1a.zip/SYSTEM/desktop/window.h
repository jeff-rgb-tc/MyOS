#ifndef DESKTOP_WINDOW_H
#define DESKTOP_WINDOW_H

#include "stdint.h"

#define WM_MAX_WINDOWS 16
#define WM_TITLEBAR_HEIGHT 24
#define WM_BORDER 2

/* Reserved space at the bottom of the screen a maximized window should
 * not cover, matching taskbar.h's TASKBAR_HEIGHT. Duplicated as a
 * constant (rather than #include "taskbar.h") to keep the dependency
 * direction the right way around -- taskbar.c already depends on
 * window.h to list/focus windows, so window.h depending back on
 * taskbar.h would create a cycle. */
#define WM_TASKBAR_RESERVED_HEIGHT 32   /* legacy: use taskbar_work_area() */
void wm_refit_maximized(void);

/* Advances open animations. Returns 1 while any is still running (the desktop
 * then redraws every frame so the motion is smooth). */
int wm_anim_step(void);

typedef struct window {
    int x, y;             /* top-left of the whole window, including chrome */
    int w, h;              /* total size, including titlebar + border       */
    char title[64];
    uint32_t bg_color;      /* client area fill color                        */
    uint8_t visible;
    uint8_t focused;
    uint8_t in_use;         /* slot is occupied */

    uint8_t minimized;      /* hidden from the desktop, still listed in the taskbar */
    uint8_t maximized;      /* filling the whole desktop (below the taskbar)        */

    /* Saved geometry to restore when un-maximizing. Only meaningful
     * while maximized == 1. */
    int restore_x, restore_y, restore_w, restore_h;

    /* App-provided render hook. Called with the client-area rectangle in
     * screen coordinates every frame the window is visible. May be NULL
     * for a plain color-filled window. */
    void (*on_paint)(struct window *self, int client_x, int client_y, int client_w, int client_h);

    /* App-provided keyboard hook. Called once per newly-available
     * character (from try_get_ascii_char()) while this window is
     * focused. May be NULL for windows that don't accept input. */
    void (*on_key)(struct window *self, char c);

    /* App-provided mouse-click hook. Called with a point already
     * translated into client-area-relative coordinates (0,0 = top-left
     * of the client area) when the left mouse button is pressed inside
     * this window's client area. May be NULL. */
    void (*on_click)(struct window *self, int client_rel_x, int client_rel_y);

    /* App-provided right-click hook, same client-relative coordinates as
     * on_click. Called instead of any titlebar/close-box handling when
     * the right button is pressed inside this window's client area --
     * apps that want a context menu (e.g. Explorer's "Open"/"New
     * Folder"/"Delete") implement this and call context_menu_open()
     * themselves with whatever items make sense for what was clicked.
     * May be NULL, in which case a right-click inside the client area is
     * simply ignored (no default menu). */
    void (*on_right_click)(struct window *self, int client_rel_x, int client_rel_y);

    /* App-provided mouse-drag hook, called continuously while the left
     * button is held and the mouse moves inside this window's client
     * area, again in client-relative coordinates. May be NULL. Used by
     * apps like Paint that need continuous drawing while dragging. */
    void (*on_drag)(struct window *self, int client_rel_x, int client_rel_y);

    /* Optional hover query: given a client-relative point, returns which
     * cursor shape the mouse should show there, as a cursor_kind_t
     * value (see cursor_set.h -- returned as a plain int here so
     * window.h doesn't need to include cursor_set.h just for the enum;
     * 0 is CURSOR_DEFAULT, i.e. "no preference, plain arrow"). Lets each
     * app opt into the I-beam over its own text fields, the pointing
     * hand over its own buttons, a crosshair over Paint's canvas, etc.,
     * without the desktop needing to know anything about what's
     * clickable or editable in each app's custom-drawn UI. May be NULL
     * (plain arrow everywhere over this window's client area). Called
     * every frame the mouse is over this window's client area (see
     * desktop.c's pick_cursor_for_position()), so it must be cheap -- a
     * few rectangle comparisons, nothing that touches the filesystem
     * or allocates. */
    int (*cursor_at)(struct window *self, int client_rel_x, int client_rel_y);

    /* App-provided mouse-release hook: called once when the left button
     * is released, if this window was the one receiving on_click/on_drag
     * for the click that's now ending (i.e. it only fires for a window
     * that actually had the drag, not for whatever's under the cursor at
     * release time -- same client-relative coordinates as on_click/
     * on_drag). Used by tools that need a "commit" moment distinct from
     * "while dragging", e.g. Paint's shape tools drawing a live preview
     * outline while dragging and only stamping the final shape into the
     * canvas on release. May be NULL. */
    void (*on_mouse_up)(struct window *self, int client_rel_x, int client_rel_y);

    /* Called once when the window is destroyed (close box clicked),
     * before its slot is cleared -- gives apps a chance to free anything
     * they stashed in user_data. May be NULL. */
    void (*on_destroy)(struct window *self);

    /* App-provided per-frame tick hook, called once per desktop frame
     * regardless of input, while this window exists (visible or not).
     * Used for things like double-click timing windows and animations
     * that need to advance even without new mouse/keyboard events. May
     * be NULL. */
    void (*on_tick)(struct window *self);

    /* Optional: called instead of destroying the window when its close box
     * is clicked. The hook decides what happens (an app may want to ask
     * about unsaved work); to really close it, call wm_destroy_window().
     * NULL = the window is destroyed immediately, as before. */
    void (*on_close_request)(struct window *self);

    /* Optional: something was dropped on this window (see dnd.h). The point
     * is in client coordinates and `path` is the dragged file/folder's
     * absolute path. Return 1 if the drop was accepted. */
    int (*on_drop)(struct window *self, int rel_x, int rel_y, const char *path);

    /* Optional: the mouse wheel turned over this window. `notches` is
     * positive for "scroll down". */
    void (*on_scroll)(struct window *self, int rel_x, int rel_y, int notches);

    /* Redraw hint: 1 = this window only changes in response to input, so the
     * desktop need not repaint it 10 times a second while idle. Windows with
     * clocks, caret blinks, animation or progress leave it 0 (the default). */
    uint8_t static_content;

    void *user_data; /* free for app use, e.g. app-specific state */

    /* open animation: the window slides up into place (see wm_anim_step) */
    uint8_t anim_active;
    int anim_target_y;
    uint32_t anim_t0;
} window_t;

void wm_init();

/* Creates a new window and returns a handle, or NULL if the window table
 * is full. The window starts visible and unfocused; call wm_focus() to
 * bring it to the front and give it input focus. */
window_t *wm_create_window(const char *title, int x, int y, int w, int h, uint32_t bg_color);

void wm_destroy_window(window_t *win);

/* Brings a window to the top of the Z-order and marks it focused; all
 * other windows lose focus. */
void wm_focus(window_t *win);

/* Returns the currently focused window, or NULL if none. */
window_t *wm_focused_window();

/* Hit-tests a screen point against all windows front-to-back and returns
 * the topmost window under the point, or NULL if the point is over bare
 * desktop. */
window_t *wm_window_at(int x, int y);

/* Returns 1 if (x,y) lands within the titlebar drag region of a window
 * (as opposed to its client area or resize border). */
int wm_point_in_titlebar(window_t *win, int x, int y);

/* Returns 1 if (x,y) lands on the little close-box in the titlebar. */
int wm_point_in_close_box(window_t *win, int x, int y);

/* Returns 1 if (x,y) lands on the maximize/restore box in the titlebar
 * (the middle button of the three, Windows-style: minimize, maximize,
 * close from left to right). */
int wm_point_in_maximize_box(window_t *win, int x, int y);

/* Returns 1 if (x,y) lands on the minimize box in the titlebar (the
 * leftmost of the three buttons). */
int wm_point_in_minimize_box(window_t *win, int x, int y);

/* Which edge/corner of a window's resize border (x,y) falls on, if any
 * -- used both to pick the right resize cursor (see desktop.c's
 * pick_cursor_for_position()) and to know which dimensions a drag
 * should actually resize (see wm_resize_edge_t's own comment). A
 * maximized window has no resize border (matching how real window
 * managers disable resizing while maximized) -- always returns
 * WM_RESIZE_NONE for one. */
typedef enum {
    WM_RESIZE_NONE = 0,
    WM_RESIZE_LEFT,
    WM_RESIZE_RIGHT,
    WM_RESIZE_TOP,
    WM_RESIZE_BOTTOM,
    WM_RESIZE_TOP_LEFT,
    WM_RESIZE_TOP_RIGHT,
    WM_RESIZE_BOTTOM_LEFT,
    WM_RESIZE_BOTTOM_RIGHT,
} wm_resize_edge_t;

wm_resize_edge_t wm_resize_edge_at(window_t *win, int x, int y);

/* Like wm_window_at(), but tests every window's OUTWARD-extending
 * resize border too (wm_window_at() only tests strictly inside a
 * window's own rect, so a click a few pixels outside it -- exactly
 * where the resize border lives -- would otherwise never find the
 * window at all). Walks front-to-back same as wm_window_at(); fills
 * *out_edge with which edge/corner matched. Returns NULL (and
 * WM_RESIZE_NONE) if no window's resize border contains the point. */
window_t *wm_window_at_resize_edge(int x, int y, wm_resize_edge_t *out_edge);

/* Minimum window size -- resizing never shrinks a window below this,
 * so the titlebar (with its three buttons) and at least a sliver of
 * client area always stay usable. */
#define WM_MIN_WIDTH 120
#define WM_MIN_HEIGHT 80

/* Resizes/repositions a window in one call -- used while dragging a
 * resize edge/corner, since resizing from the left or top edge also
 * moves the window's origin (the opposite edge/corner stays fixed in
 * place, matching how every real window manager's edge-resize works).
 * w/h are clamped to WM_MIN_WIDTH/WM_MIN_HEIGHT; x/y are NOT
 * separately clamped to keep on-screen (matching wm_move_window()'s own
 * looser behavior) since the drag that calls this already tracks the
 * mouse, which the desktop itself keeps on-screen. */
void wm_resize_window(window_t *win, int x, int y, int w, int h);

/* Minimizes a window: it stops being drawn on the desktop and drops out
 * of click hit-testing, but stays listed in the taskbar so it can be
 * restored. Safe to call on an already-minimized window (no-op). */
void wm_minimize_window(window_t *win);

/* Restores a minimized window to normal visibility and gives it focus.
 * Safe to call on a window that isn't minimized (no-op). */
void wm_restore_window(window_t *win);

/* Toggles a window between maximized (fills the desktop area above the
 * taskbar) and its previous size/position. */
void wm_toggle_maximize(window_t *win);

/* Fills in the client area's screen-space rectangle for a window (the
 * area inside the border/titlebar where on_paint/on_click/on_drag
 * operate). Useful for callers that need to translate a screen point
 * into client-relative coordinates themselves. */
void wm_get_client_rect(window_t *win, int *out_x, int *out_y, int *out_w, int *out_h);

/* Moves a window so its top-left corner is at (x, y), clamped so the
 * titlebar always stays reachable on-screen. */
void wm_move_window(window_t *win, int x, int y);

/* Draws every visible window (back to front) plus their chrome into the
 * gfx backbuffer. Does not present -- caller should call gfx_present()
 * once after also drawing the desktop background/taskbar/cursor. */
void wm_draw_all();

/* Calls on_tick() for every active window (visible or not), once per
 * desktop frame. Should be called exactly once per iteration of the
 * desktop's main loop, alongside wm_draw_all(). */
void wm_tick_all();

/* Returns the first live window whose on_paint hook is `on_paint`, or
 * NULL. Apps that should only ever have one window (Clock, Calendar, Task
 * Manager) use their own paint function as an identity to find and
 * re-focus the existing window instead of opening a second one. */
window_t *wm_find_window_by_paint(void (*on_paint)(struct window *, int, int, int, int));

/* Iteration helpers for callers (e.g. the taskbar) that want to list
 * windows without reaching into the internal table directly. */
/* 1 if every visible window has static_content set (or there are none). */
int wm_all_static(void);

int wm_window_count();
window_t *wm_window_at_index(int index);

#endif
