#include "stdint.h"
#include "stddef.h"
#include "app_calendar.h"
#include "window.h"
#include "gfx.h"
#include "ui.h"
#include "common.h"
#include "kheap.h"
#include "kernio.h"
#include "keyboard.h"
#include "rtc.h"
#include "cursor_set.h"
#include "datetime_util.h"

#define PAD 16
#define HEADER_H 36
#define WEEKDAY_H 28
#define FOOTER_H 66

typedef struct {
    int view_y, view_m;          /* month being displayed */
    int sel_y, sel_m, sel_d;     /* selected date */
} app_cal_t;

static int imin(int a, int b) { return a < b ? a : b; }

typedef struct { int x, y, w, h; } rect_t;

typedef struct {
    rect_t today_btn, prev_btn, next_btn;
    int grid_x, grid_y, cell_w, cell_h;
    rect_t footer;
} cal_layout_t;

static void layout(int cw, int ch, cal_layout_t *L) {
    int inner = cw - PAD * 2;
    L->cell_w = inner / 7;
    int grid_total_w = L->cell_w * 7;
    L->grid_x = (cw - grid_total_w) / 2;

    L->prev_btn = (rect_t){ cw - PAD - 32 * 2 - 6, PAD + 2, 32, 32 };
    L->next_btn = (rect_t){ cw - PAD - 32, PAD + 2, 32, 32 };
    L->today_btn = (rect_t){ L->prev_btn.x - 10 - 70, PAD + 2, 70, 32 };

    L->grid_y = PAD + HEADER_H + 14 + WEEKDAY_H;
    int avail = ch - L->grid_y - FOOTER_H - PAD - 10;
    L->cell_h = avail / 6;
    if(L->cell_h > 54) L->cell_h = 54;
    if(L->cell_h < 26) L->cell_h = 26;
    L->footer = (rect_t){ PAD, L->grid_y + L->cell_h * 6 + 10, cw - PAD * 2, FOOTER_H };
}

static void add_months(int *y, int *m, int delta) {
    int idx = (*y) * 12 + (*m - 1) + delta;
    *y = idx / 12;
    *m = idx % 12 + 1;
}

static void today_date(int *y, int *m, int *d) {
    rtc_date_t t; rtc_read_date(&t);
    *y = t.year; *m = t.month; *d = t.day;
}

/* First date shown in the grid (a Monday on or before the 1st). */
static void grid_start(app_cal_t *a, int *y, int *m, int *d) {
    *y = a->view_y; *m = a->view_m; *d = 1;
    int offset = (dt_weekday(*y, *m, 1) + 6) % 7;   /* Monday = 0 */
    dt_add_days(y, m, d, -offset);
}

static void select_date(app_cal_t *a, int y, int m, int d) {
    int dim = dt_days_in_month(y, m);
    if(d > dim) d = dim;
    a->sel_y = y; a->sel_m = m; a->sel_d = d;
    a->view_y = y; a->view_m = m;
}

static void goto_today(app_cal_t *a) {
    int y, m, d; today_date(&y, &m, &d);
    select_date(a, y, m, d);
}

static void chevron(int cx, int cy, int dir, uint32_t col) {
    gfx_draw_line_thick(cx - dir * 2.5, cy - 5.0, cx + dir * 2.5, cy, 1.8, col);
    gfx_draw_line_thick(cx + dir * 2.5, cy, cx - dir * 2.5, cy + 5.0, 1.8, col);
}

static void cal_paint(window_t *self, int cx, int cy, int cw, int ch) {
    app_cal_t *a = (app_cal_t *)self->user_data;
    if(!a) return;
    ui_clear(cx, cy, cw, ch);

    cal_layout_t L; layout(cw, ch, &L);
    int rx = -1, ry = -1;
    int hov = ui_hover_pos(self, cx, cy, &rx, &ry);
    int down = ui_mouse_down();
    int ty, tm, td; today_date(&ty, &tm, &td);

    /* header: "October 2026" + Today / < / > */
    char title[40];
    sprintf(title, "%s %d", dt_month_name(a->view_m), a->view_y);
    gfx_draw_string_scaled(cx + PAD, cy + PAD + 2, title, UI_TEXT, 2);

    int over;
    over = hov && ui_in(rx, ry, L.today_btn.x, L.today_btn.y, L.today_btn.w, L.today_btn.h);
    ui_button(cx + L.today_btn.x, cy + L.today_btn.y, L.today_btn.w, L.today_btn.h, "Today", UI_BTN_NORMAL, over, over && down);
    over = hov && ui_in(rx, ry, L.prev_btn.x, L.prev_btn.y, L.prev_btn.w, L.prev_btn.h);
    ui_button(cx + L.prev_btn.x, cy + L.prev_btn.y, L.prev_btn.w, L.prev_btn.h, "", UI_BTN_NORMAL, over, over && down);
    chevron(cx + L.prev_btn.x + 16, cy + L.prev_btn.y + 16, -1, UI_TEXT);
    over = hov && ui_in(rx, ry, L.next_btn.x, L.next_btn.y, L.next_btn.w, L.next_btn.h);
    ui_button(cx + L.next_btn.x, cy + L.next_btn.y, L.next_btn.w, L.next_btn.h, "", UI_BTN_NORMAL, over, over && down);
    chevron(cx + L.next_btn.x + 16, cy + L.next_btn.y + 16, 1, UI_TEXT);

    /* grid card */
    int card_y = PAD + HEADER_H + 14;
    ui_card(cx + PAD, cy + card_y, cw - PAD * 2, WEEKDAY_H + L.cell_h * 6 + 6, 10);

    static const char *const wd[7] = { "Mo", "Tu", "We", "Th", "Fr", "Sa", "Su" };
    for(int c = 0; c < 7; c++) {
        ui_text_center(cx + L.grid_x + c * L.cell_w, cy + card_y + 4, L.cell_w, WEEKDAY_H - 4, wd[c],
                       c >= 5 ? UI_TEXT_FAINT : UI_TEXT_DIM);
    }

    int y, m, d;
    grid_start(a, &y, &m, &d);
    int radius = imin(L.cell_w, L.cell_h) / 2 - 3;
    for(int i = 0; i < 42; i++) {
        int col = i % 7, row = i / 7;
        int x0 = cx + L.grid_x + col * L.cell_w;
        int y0 = cy + L.grid_y + row * L.cell_h;
        int in_month = (m == a->view_m);
        int is_today = (y == ty && m == tm && d == td);
        int is_sel = (y == a->sel_y && m == a->sel_m && d == a->sel_d);
        int is_hover = hov && ui_in(rx, ry, L.grid_x + col * L.cell_w, L.grid_y + row * L.cell_h, L.cell_w, L.cell_h);

        int ccx = x0 + L.cell_w / 2, ccy = y0 + L.cell_h / 2;
        uint32_t tcol = in_month ? (col >= 5 ? 0xFFC8C8D2 : UI_TEXT) : UI_TEXT_FAINT;

        if(is_today) {
            gfx_fill_circle(ccx, ccy, radius, is_hover ? UI_ACCENT_HI : UI_ACCENT);
            tcol = UI_ON_ACCENT;
            if(is_sel) gfx_draw_rounded_outline(ccx - radius - 2, ccy - radius - 2, radius * 2 + 4, radius * 2 + 4, radius + 2, 0xFFFFFFFF);
        }
        else if(is_sel) {
            gfx_fill_circle(ccx, ccy, radius, 0xFF3C3C46);
            gfx_draw_rounded_outline(ccx - radius, ccy - radius, radius * 2, radius * 2, radius, 0x80FFFFFF);
        }
        else if(is_hover) {
            gfx_fill_circle(ccx, ccy, radius, 0x22FFFFFF);
        }

        char num[4]; sprintf(num, "%d", d);
        gfx_draw_string(ccx - ui_text_w(num) / 2, ccy - 8, num, tcol);
        dt_add_days(&y, &m, &d, 1);
    }

    /* footer: selected date details */
    ui_card(cx + L.footer.x, cy + L.footer.y, L.footer.w, L.footer.h, 10);
    char line1[48], line2[56];
    dt_format_long_date(line1, sizeof(line1), a->sel_y, a->sel_m, a->sel_d);
    sprintf(line2, "Day %d of %d  |  Week %d", dt_day_of_year(a->sel_y, a->sel_m, a->sel_d),
            dt_is_leap(a->sel_y) ? 366 : 365, dt_iso_week(a->sel_y, a->sel_m, a->sel_d));
    gfx_draw_string(cx + L.footer.x + 16, cy + L.footer.y + 12, line1, UI_TEXT);
    gfx_draw_string(cx + L.footer.x + 16, cy + L.footer.y + 34, line2, UI_TEXT_DIM);
    if(a->sel_y == ty && a->sel_m == tm && a->sel_d == td) {
        ui_text_right(cx + L.footer.x + L.footer.w - 16, cy + L.footer.y + 12, "Today", UI_ACCENT);
    }
}

static void cal_click(window_t *self, int rx, int ry) {
    app_cal_t *a = (app_cal_t *)self->user_data;
    if(!a) return;
    int x, y, cw, ch;
    wm_get_client_rect(self, &x, &y, &cw, &ch);
    cal_layout_t L; layout(cw, ch, &L);

    if(ui_in(rx, ry, L.today_btn.x, L.today_btn.y, L.today_btn.w, L.today_btn.h)) { goto_today(a); return; }
    if(ui_in(rx, ry, L.prev_btn.x, L.prev_btn.y, L.prev_btn.w, L.prev_btn.h)) { add_months(&a->view_y, &a->view_m, -1); return; }
    if(ui_in(rx, ry, L.next_btn.x, L.next_btn.y, L.next_btn.w, L.next_btn.h)) { add_months(&a->view_y, &a->view_m, 1); return; }

    if(rx >= L.grid_x && rx < L.grid_x + L.cell_w * 7 && ry >= L.grid_y && ry < L.grid_y + L.cell_h * 6) {
        int col = (rx - L.grid_x) / L.cell_w, row = (ry - L.grid_y) / L.cell_h;
        int yy, mm, dd;
        grid_start(a, &yy, &mm, &dd);
        dt_add_days(&yy, &mm, &dd, row * 7 + col);
        select_date(a, yy, mm, dd);
    }
}

static void cal_key(window_t *self, char k) {
    app_cal_t *a = (app_cal_t *)self->user_data;
    if(!a) return;
    int y = a->sel_y, m = a->sel_m, d = a->sel_d;
    if(k == KEY_LEFT) dt_add_days(&y, &m, &d, -1);
    else if(k == KEY_RIGHT) dt_add_days(&y, &m, &d, 1);
    else if(k == KEY_UP) dt_add_days(&y, &m, &d, -7);
    else if(k == KEY_DOWN) dt_add_days(&y, &m, &d, 7);
    else if(k == KEY_PGUP || k == KEY_PGDN || k == '<' || k == '>' || k == ',' || k == '.') {
        int delta = (k == KEY_PGUP || k == '<' || k == ',') ? -1 : 1;
        add_months(&y, &m, delta);
    }
    else if(k == KEY_HOME || k == 't' || k == 'T') { today_date(&y, &m, &d); }
    else return;
    if(y < 1970) return;
    select_date(a, y, m, d);
}

static int cal_cursor_at(window_t *self, int rx, int ry) {
    app_cal_t *a = (app_cal_t *)self->user_data;
    if(!a) return CURSOR_DEFAULT;
    int x, y, cw, ch;
    wm_get_client_rect(self, &x, &y, &cw, &ch);
    cal_layout_t L; layout(cw, ch, &L);
    if(ui_in(rx, ry, L.today_btn.x, L.today_btn.y, L.today_btn.w, L.today_btn.h)) return CURSOR_LINK;
    if(ui_in(rx, ry, L.prev_btn.x, L.prev_btn.y, L.prev_btn.w, L.prev_btn.h)) return CURSOR_LINK;
    if(ui_in(rx, ry, L.next_btn.x, L.next_btn.y, L.next_btn.w, L.next_btn.h)) return CURSOR_LINK;
    if(rx >= L.grid_x && rx < L.grid_x + L.cell_w * 7 && ry >= L.grid_y && ry < L.grid_y + L.cell_h * 6) return CURSOR_LINK;
    return CURSOR_DEFAULT;
}

static void cal_destroy(window_t *self) {
    if(self->user_data) { kfree(self->user_data); self->user_data = NULL; }
}

void launch_calendar(void) {
    window_t *existing = wm_find_window_by_paint(cal_paint);
    if(existing) {
        if(existing->minimized) wm_restore_window(existing); else wm_focus(existing);
        return;
    }

    int sw = (int)gfx_width(), sh = (int)gfx_height();
    int w = 460, h = 540;
    if(h > sh - 60) h = sh - 60;
    if(w > sw - 20) w = sw - 20;
    window_t *win = wm_create_window("Calendar", (sw - w) / 2 - 30, 20 + (sh - 60 - h) / 4, w, h, UI_BG);
    if(!win) return;
    app_cal_t *a = (app_cal_t *)kmalloc(sizeof(app_cal_t));
    if(!a) { wm_destroy_window(win); return; }
    memset(a, 0, sizeof(*a));
    goto_today(a);
    win->user_data = a;
    win->on_paint = cal_paint;
    win->static_content = 1;      /* changes only on input, so the desktop can idle */
    win->on_click = cal_click;
    win->on_key = cal_key;
    win->cursor_at = cal_cursor_at;
    win->on_destroy = cal_destroy;
}
