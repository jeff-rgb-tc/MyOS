#include "stdint.h"
#include "stddef.h"
#include "desktop_items.h"
#include "apps.h"
#include "png.h"
#include "gfx.h"
#include "kheap.h"
#include "common.h"
#include "kernio.h"
#include "fat32.h"

extern f32 *master_fs;

/* ------------------------------------------------------------------ */
/* positions: /Users/User/Desktop/desktop.pos, one "name|x|y" per line  */
/* ------------------------------------------------------------------ */
#define POS_MAX 128
static struct { char file[48]; int x, y; } pos_table[POS_MAX];
static int pos_count = 0;
static int pos_loaded = 0;

static void pos_path(char *out, int max) { fileops_join(DESKTOP_FOLDER_PATH, "desktop.pos", out, max); }

static void pos_save(void) {
    char text[POS_MAX * 64];
    int n = 0;
    for(int i = 0; i < pos_count && n < (int)sizeof(text) - 80; i++) {
        for(const char *c = pos_table[i].file; *c; c++) text[n++] = *c;
        text[n++] = '|';
        int v = pos_table[i].x; char tmp[12]; int t = 0;
        if(v < 0) { text[n++] = '-'; v = -v; }
        if(!v) tmp[t++] = '0';
        while(v) { tmp[t++] = (char)('0' + v % 10); v /= 10; }
        while(t) text[n++] = tmp[--t];
        text[n++] = '|';
        v = pos_table[i].y; t = 0;
        if(v < 0) { text[n++] = '-'; v = -v; }
        if(!v) tmp[t++] = '0';
        while(v) { tmp[t++] = (char)('0' + v % 10); v /= 10; }
        while(t) text[n++] = tmp[--t];
        text[n++] = '\n';
    }
    char path[FSU_PATH_MAX];
    pos_path(path, sizeof(path));
    fsu_write_file(path, (const uint8_t *)text, (uint32_t)n);
}

static void pos_load(void) {
    if(pos_loaded) return;
    pos_loaded = 1;
    pos_count = 0;
    char path[FSU_PATH_MAX];
    pos_path(path, sizeof(path));
    uint32_t size = 0;
    uint8_t *data = fsu_read_file(path, &size);
    if(!data) return;
    uint32_t i = 0;
    while(i < size && pos_count < POS_MAX) {
        char name[48]; int n = 0;
        while(i < size && data[i] != '|' && data[i] != '\n' && n < 47) name[n++] = (char)data[i++];
        name[n] = '\0';
        int vals[2] = { 0, 0 }, ok = 0;
        if(i < size && data[i] == '|') {
            i++;
            for(int k = 0; k < 2; k++) {
                int neg = 0, v = 0;
                if(i < size && data[i] == '-') { neg = 1; i++; }
                while(i < size && data[i] >= '0' && data[i] <= '9') { v = v * 10 + (data[i] - '0'); i++; }
                vals[k] = neg ? -v : v;
                if(k == 0 && i < size && data[i] == '|') i++;
                else if(k == 0) break;
                if(k == 1) ok = 1;
            }
        }
        while(i < size && data[i] != '\n') i++;
        if(i < size) i++;
        if(ok && n > 0) {
            for(int c = 0; c <= n; c++) pos_table[pos_count].file[c] = name[c];
            pos_table[pos_count].x = vals[0]; pos_table[pos_count].y = vals[1];
            pos_count++;
        }
    }
    kfree(data);
}

int ditems_pos_get(const char *file, int *x, int *y) {
    pos_load();
    for(int i = 0; i < pos_count; i++) {
        if(strcasecmp(pos_table[i].file, file) == 0) { *x = pos_table[i].x; *y = pos_table[i].y; return 1; }
    }
    return 0;
}

void ditems_pos_set(const char *file, int x, int y) {
    pos_load();
    for(int i = 0; i < pos_count; i++) {
        if(strcasecmp(pos_table[i].file, file) == 0) {
            if(pos_table[i].x == x && pos_table[i].y == y) return;
            pos_table[i].x = x; pos_table[i].y = y; pos_save(); return;
        }
    }
    if(pos_count >= POS_MAX) return;
    int n = 0;
    while(file[n] && n < 47) { pos_table[pos_count].file[n] = file[n]; n++; }
    pos_table[pos_count].file[n] = '\0';
    pos_table[pos_count].x = x; pos_table[pos_count].y = y;
    pos_count++;
    pos_save();
}

void ditems_pos_forget(const char *file) {
    pos_load();
    for(int i = 0; i < pos_count; i++) {
        if(strcasecmp(pos_table[i].file, file) == 0) {
            pos_table[i] = pos_table[--pos_count];
            pos_save();
            return;
        }
    }
}

void ditems_pos_rename(const char *old_file, const char *new_file) {
    pos_load();
    for(int i = 0; i < pos_count; i++) {
        if(strcasecmp(pos_table[i].file, old_file) == 0) {
            int n = 0;
            while(new_file[n] && n < 47) { pos_table[i].file[n] = new_file[n]; n++; }
            pos_table[i].file[n] = '\0';
            pos_save();
            return;
        }
    }
}

/* ------------------------------------------------------------------ */
/* scanning                                                            */
/* ------------------------------------------------------------------ */
static desktop_item_t items[DITEMS_MAX];
static int item_count = 0;
static uint32_t last_signature = 0;
static int have_signature = 0;

static const char *last_dot(const char *name) {
    const char *r = NULL;
    for(const char *p = name; *p; p++) if(*p == '.') r = p;
    return r;
}

static int hidden_name(const char *name) {
    if(!name[0] || name[0] == '.') return 1;
    return strcasecmp(name, "desktop.ini") == 0 || strcasecmp(name, "desktop.pos") == 0;
}

static void fill_item(desktop_item_t *it, const char *file, int is_dir) {
    memset(it, 0, sizeof(*it));
    int n = 0;
    while(file[n] && n < (int)sizeof(it->file) - 1) { it->file[n] = file[n]; n++; }
    it->file[n] = '\0';
    fileops_join(DESKTOP_FOLDER_PATH, it->file, it->path, sizeof(it->path));

    const char *dot = last_dot(it->file);
    if(!is_dir && dot && strcasecmp(dot, ".lnk") == 0 && shortcut_load(it->path, &it->sc)) {
        it->kind = DI_SHORTCUT;
        int k = 0;
        while(it->sc.name[k] && k < (int)sizeof(it->label) - 1) { it->label[k] = it->sc.name[k]; k++; }
        it->label[k] = '\0';
        return;
    }
    it->kind = is_dir ? DI_FOLDER : DI_FILE;
    int k = 0;
    while(it->file[k] && k < (int)sizeof(it->label) - 1) { it->label[k] = it->file[k]; k++; }
    it->label[k] = '\0';
}

void ditems_invalidate(void) { have_signature = 0; }

int ditems_poll(void) {
    struct directory d;
    if(!fsu_open_dir(DESKTOP_FOLDER_PATH, &d)) {
        if(item_count == 0) return 0;
        item_count = 0; have_signature = 0;
        return 1;
    }

    /* Signature of the listing: names, sizes and kinds. */
    uint32_t sig = 2166136261u;
    int cnt = 0;
    for(uint32_t i = 0; i < d.num_entries; i++) {
        struct dir_entry *e = &d.entries[i];
        if(!e->name || (e->dir_attrs & LFN) || hidden_name(e->name)) continue;
        for(const char *c = e->name; *c; c++) { sig ^= (uint8_t)*c; sig *= 16777619u; }
        sig ^= e->file_size; sig *= 16777619u;
        sig ^= (e->dir_attrs & DIRECTORY) ? 7u : 3u; sig *= 16777619u;
        cnt++;
    }
    sig ^= (uint32_t)cnt;

    if(have_signature && sig == last_signature) { free_directory(master_fs, &d); return 0; }
    have_signature = 1;
    last_signature = sig;

    item_count = 0;
    for(uint32_t i = 0; i < d.num_entries && item_count < DITEMS_MAX; i++) {
        struct dir_entry *e = &d.entries[i];
        if(!e->name || (e->dir_attrs & LFN) || hidden_name(e->name)) continue;
        if(e->dir_attrs & 0x08) continue;                      /* volume label */
        fill_item(&items[item_count], e->name, (e->dir_attrs & DIRECTORY) != 0);
        item_count++;
    }
    free_directory(master_fs, &d);

    /* Folders first, then by name -- the order newly dropped icons are placed in. */
    for(int i = 1; i < item_count; i++) {
        desktop_item_t key = items[i];
        int j = i - 1;
        while(j >= 0) {
            int kf = key.kind == DI_FOLDER, jf = items[j].kind == DI_FOLDER;
            int greater = (jf != kf) ? (kf > jf) : (strcasecmp(items[j].file, key.file) > 0);
            if(!greater) break;
            items[j + 1] = items[j];
            j--;
        }
        items[j + 1] = key;
    }
    return 1;
}

int ditems_count(void) { return item_count; }
const desktop_item_t *ditems_get(int i) { return (i >= 0 && i < item_count) ? &items[i] : NULL; }

int ditems_find(const char *file_name) {
    for(int i = 0; i < item_count; i++) if(strcasecmp(items[i].file, file_name) == 0) return i;
    return -1;
}

/* ------------------------------------------------------------------ */
/* icons                                                               */
/* ------------------------------------------------------------------ */
static png_image_t img_folder, img_file, img_app, img_text, img_music, img_picture;
static uint8_t folder_tried = 0, file_tried = 0, app_tried = 0, text_tried = 0, music_tried = 0, picture_tried = 0;

static ditem_image_t make_image(const png_image_t *p) {
    ditem_image_t r = { p ? p->pixels : NULL, p ? (int)p->width : 0, p ? (int)p->height : 0 };
    return r;
}

static ditem_image_t from_app(app_entry_t *a) {
    ditem_image_t r = { NULL, 0, 0 };
    if(!a) return r;
    app_icon_t *ic = apps_get_icon(a);
    if(ic && ic->pixels) { r.pixels = ic->pixels; r.w = ic->width; r.h = ic->height; }
    return r;
}

static ditem_image_t icon_folder(void) {
    if(!folder_tried) { folder_tried = 1; png_load_from_file("/SYSTEM/res/icons/folder.png", &img_folder); }
    return make_image(img_folder.pixels ? &img_folder : NULL);
}
static ditem_image_t icon_file(void) {
    if(!file_tried) { file_tried = 1; png_load_from_file("/SYSTEM/res/icons/file.png", &img_file); }
    return make_image(img_file.pixels ? &img_file : NULL);
}
/* File-type icons: text, music, picture. Fall back to the plain file icon. */
static ditem_image_t icon_text(void) {
    if(!text_tried) { text_tried = 1; png_load_from_file("/SYSTEM/res/icons/file_text.png", &img_text); }
    return img_text.pixels ? make_image(&img_text) : icon_file();
}
static ditem_image_t icon_music(void) {
    if(!music_tried) { music_tried = 1; png_load_from_file("/SYSTEM/res/icons/file_music.png", &img_music); }
    return img_music.pixels ? make_image(&img_music) : icon_file();
}
static ditem_image_t icon_picture(void) {
    if(!picture_tried) { picture_tried = 1; png_load_from_file("/SYSTEM/res/icons/file_image.png", &img_picture); }
    return img_picture.pixels ? make_image(&img_picture) : icon_file();
}

static ditem_image_t icon_generic_app(void) {
    if(!app_tried) { app_tried = 1; png_load_from_file("/SYSTEM/res/icons/app_default.png", &img_app); }
    return make_image(img_app.pixels ? &img_app : NULL);
}

static int ext_in(const char *ext, const char *list) {
    /* list is a space-separated, lower-case set like ".txt .md" */
    char want[12]; int n = 0;
    for(const char *c = ext; *c && n < 10; c++) want[n++] = (*c >= 'A' && *c <= 'Z') ? (char)(*c + 32) : *c;
    want[n] = '\0';
    const char *p = list;
    while(*p) {
        const char *q = p; int len = 0;
        while(*q && *q != ' ') { q++; len++; }
        if(len == n && strncmp(p, want, (size_t)n) == 0) return 1;
        p = *q ? q + 1 : q;
    }
    return 0;
}

ditem_image_t ditems_icon_for_path(const char *path, int is_dir) {
    if(is_dir) return icon_folder();
    const char *dot = last_dot(path);
    if(dot) {
        if(strcasecmp(dot, ".app") == 0) {
            for(int i = 0; i < apps_count(); i++) {
                app_entry_t *a = apps_get(i);
                if(a && a->app_path[0] && strcasecmp(a->app_path, path) == 0) return from_app(a);
            }
            return icon_generic_app();
        }
        if(ext_in(dot, ".txt .log .md .ini .cfg .c .h .asm .nasm .json .xml .csv .bat .cmd .html .css .js .py .cpp .rtf"))
            return icon_text();
        if(ext_in(dot, ".mp3 .wav .ogg .mid .midi .flac .wma .aac .m4a"))
            return icon_music();
        if(ext_in(dot, ".bmp .png .jpg .jpeg .gif .ico .cur .webp"))
            return icon_picture();
    }
    return icon_file();
}

ditem_image_t ditems_icon_for(const desktop_item_t *it) {
    if(it->kind == DI_FOLDER) return icon_folder();
    if(it->kind == DI_SHORTCUT) {
        app_entry_t *a = shortcut_target_app(&it->sc);
        if(a) return from_app(a);
        if(strncmp(it->sc.target, "app:", 4) == 0) return icon_generic_app();
        int is_dir = 0;
        fsu_stat(it->sc.target, &is_dir, NULL, NULL, NULL);
        return ditems_icon_for_path(it->sc.target, is_dir);
    }
    return ditems_icon_for_path(it->path, 0);
}

void ditems_draw_shortcut_badge(int x, int y, int size) {
    int b = size / 3 + 2;
    int bx = x + 1, by = y + size - b - 1;
    gfx_fill_rounded_rect(bx, by, b, b, 4, 0xFFFFFFFF);
    gfx_draw_rounded_outline(bx, by, b, b, 4, 0x60000000);
    /* arrow pointing up-right */
    double cx = bx + b * 0.5, cy = by + b * 0.5, r = b * 0.22;
    gfx_draw_line_thick(cx - r, cy + r, cx + r, cy - r, 1.8, 0xFF2D6CDF);
    gfx_draw_line_thick(cx - r * 0.1, cy - r, cx + r, cy - r, 1.6, 0xFF2D6CDF);
    gfx_draw_line_thick(cx + r, cy - r, cx + r, cy + r * 0.1, 1.6, 0xFF2D6CDF);
}
