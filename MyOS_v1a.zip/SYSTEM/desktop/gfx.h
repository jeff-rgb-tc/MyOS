#ifndef DESKTOP_GFX_H
#define DESKTOP_GFX_H

#include "stdint.h"

/* Thin drawing layer on top of the kernel's VESA framebuffer, backed by an
 * off-screen buffer of the same size so the desktop can build a full frame
 * before presenting it. This avoids the flicker/tearing you'd get if
 * windows, the taskbar, and the cursor were each drawn directly onto the
 * visible framebuffer one at a time. */

typedef struct {
    uint32_t width;
    uint32_t height;
    uint32_t *pixels; /* width * height, top-down, ARGB8888 (alpha ignored on presentation) */
} gfx_surface_t;

/* Fixed-width bitmap font glyph size used by gfx_draw_string() -- exposed
 * here (rather than staying private to gfx.c) so callers that need to
 * center or otherwise measure text (e.g. desktop.c's shutdown/restart/
 * sleep screens, the boot splash) can compute a string's pixel width as
 * strlen(s) * GFX_CHAR_COLS without duplicating this constant. */
#define GFX_CHAR_COLS 8
#define GFX_CHAR_ROWS 16

/* Sets up the back buffer sized to the current VESA mode. Must be called
 * after set_vmode(). Returns 1 on success, 0 if allocation failed. */
int gfx_init();

/* The back buffer that all drawing happens into. */
gfx_surface_t *gfx_backbuffer();

uint32_t gfx_width();
uint32_t gfx_height();

void gfx_clear(uint32_t color);
void gfx_fill_rect(int x, int y, int w, int h, uint32_t color);
void gfx_draw_rect(int x, int y, int w, int h, uint32_t color); /* outline only */
void gfx_hline(int x, int y, int w, uint32_t color);
void gfx_vline(int x, int y, int h, uint32_t color);
void gfx_draw_bevel(int x, int y, int w, int h, uint32_t light, uint32_t dark);

/* Same as gfx_fill_rect, but with the four corners rounded off by
 * `radius` pixels (quarter-circle corners, computed via a simple
 * midpoint-circle-style distance test). radius <= 0 behaves exactly like
 * gfx_fill_rect. Used for window chrome so windows don't look like harsh
 * rectangles. */
void gfx_fill_rounded_rect(int x, int y, int w, int h, int radius, uint32_t color);

/* Alpha-blending version of the above: draws a rounded rectangle where
 * corner pixels outside the rounded silhouette are left untouched
 * (instead of being skipped as fully transparent), which is what you
 * want when compositing a window's rounded chrome on top of whatever the
 * desktop already drew underneath it. */
void gfx_blend_rounded_rect(int x, int y, int w, int h, int radius, uint32_t argb);

/* Which corners of a rounded rectangle are actually rounded -- lets a
 * titlebar round only its top and a client area only its bottom. */
#define GFX_CORNER_TL 1
#define GFX_CORNER_TR 2
#define GFX_CORNER_BL 4
#define GFX_CORNER_BR 8
#define GFX_CORNER_TOP    (GFX_CORNER_TL | GFX_CORNER_TR)
#define GFX_CORNER_BOTTOM (GFX_CORNER_BL | GFX_CORNER_BR)
#define GFX_CORNER_ALL    15

/* Translucent rounded rectangle with a choice of which corners are round. */
void gfx_blend_rounded_rect_ex(int x, int y, int w, int h, int radius, uint32_t argb, int corners);

/* Same, but filled with a top-to-bottom colour gradient (both colours
 * ARGB, interpolated per row). */
void gfx_fill_rounded_gradient(int x, int y, int w, int h, int radius,
                               uint32_t top_argb, uint32_t bottom_argb, int corners);

/* Antialiased 1px outline that follows the rounded silhouette exactly. */
void gfx_draw_rounded_outline(int x, int y, int w, int h, int radius, uint32_t argb);

/* Soft drop shadow around a (rounded) rectangle; only the area outside
 * it is drawn, so call it BEFORE drawing the rectangle itself.
 * spread = fade distance in px (max 48), offset_y pushes it downward,
 * max_alpha = 0..255 darkness at the rectangle's edge. */
void gfx_draw_shadow(int x, int y, int w, int h, int radius, int spread, int offset_y, int max_alpha);

/* Antialiased filled circle. */
void gfx_fill_circle(int cx, int cy, int r, uint32_t argb);

/* Antialiased line with round caps and any thickness (sub-pixel
 * coordinates). */
void gfx_draw_line_thick(double x0, double y0, double x1, double y1, double width, uint32_t argb);

/* Coverage (0..255) of pixel (px,py) inside a w*h rect whose four corners
 * are rounded by r -- 255 anywhere not in a corner box. */
int gfx_rounded_coverage(int px, int py, int w, int h, int r);

/* Redirects all gfx_* drawing into another pixel buffer (w*h ARGB, top-down)
 * until gfx_target_pop(). One level deep -- do not nest. */
void gfx_target_push(uint32_t *pixels, int w, int h);
void gfx_target_pop(void);

/* Opaque, clipped copy of a w*h block of pixels (source row length
 * `stride`, in pixels) to (x, y) of the current target. */
void gfx_copy_pixels(int x, int y, const uint32_t *src, int w, int h, int stride);

/* Cursor compositing (see gfx.c). `dim` is the software-brightness overlay
 * alpha (0 = none) so the pointer is dimmed along with the scene. The
 * back buffer must hold the finished scene WITHOUT the cursor. */
/* Darkens the whole back buffer (software brightness); alpha 0..255. */
void gfx_darken_screen(uint32_t alpha);
void gfx_present_with_cursor(int x, int y, const uint32_t *pixels, int w, int h, int hot_x, int hot_y, uint32_t dim);
/* Interrupt-safe pointer updates (see gfx.c): the pointer follows the mouse even if the desktop loop is stuck. */
void gfx_cursor_irq_move(int x, int y);
void gfx_cursor_irq_set(const uint32_t *px, int w, int h, int hx, int hy, int x, int y);
void gfx_move_cursor(int x, int y, const uint32_t *pixels, int w, int h, int hot_x, int hot_y, uint32_t dim);

/* Draws a solid 8x16 bitmap-font string using the kernel's built-in font,
 * without disturbing terminal cursor state. Background is transparent
 * unless bg_color's alpha byte is nonzero. */
void gfx_draw_string(int x, int y, const char *str, uint32_t fg_color);

/* Alpha-blends a single ARGB8888 pixel onto the back buffer at (x, y).
 * alpha==0 in the source is a no-op, alpha==255 is a plain overwrite,
 * anything in between blends proportionally. Out-of-bounds is a no-op. */
void gfx_blend_pixel(int x, int y, uint32_t argb);

/* Blits a full ARGB8888 image (e.g. a decoded cursor) with per-pixel alpha
 * blending, anchored so that (hotspot_x, hotspot_y) within the image lands
 * at screen position (screen_x, screen_y). */
void gfx_blit_argb(int screen_x, int screen_y, const uint32_t *pixels,
                    int img_w, int img_h, int hotspot_x, int hotspot_y);

/* Draws an ARGB8888 image scaled (nearest-neighbor) to fill a
 * dst_w x dst_h rectangle at (dst_x, dst_y), regardless of the image's
 * native src_w x src_h size. Used for the desktop background, since
 * background art is authored at a fixed resolution but the screen can be
 * running at any of MyOS's supported VESA modes. Alpha is ignored (drawn
 * fully opaque) since backgrounds are the bottom-most layer. */
void gfx_blit_scaled_argb(int dst_x, int dst_y, int dst_w, int dst_h,
                           const uint32_t *pixels, int src_w, int src_h);

/* Same scaling approach as gfx_blit_scaled_argb, but alpha-blended
 * per-pixel instead of drawn fully opaque -- for scaling icons (which
 * usually have transparent backgrounds) rather than backgrounds. */
void gfx_blit_scaled_argb_alpha(int dst_x, int dst_y, int dst_w, int dst_h,
                                 const uint32_t *pixels, int src_w, int src_h);

/* Text with each font pixel drawn as a scale x scale block (scale >= 1). */
void gfx_draw_string_scaled(int x, int y, const char *str, uint32_t fg_color, int scale);

/* Opaque row-by-row copy of a w*h ARGB image at (dst_x, dst_y) -- used for
 * the cached, pre-scaled wallpaper. */
void gfx_blit_opaque(int dst_x, int dst_y, const uint32_t *pixels, int w, int h);

/* Copies the back buffer to the real framebuffer. Call once per frame
 * after all drawing is done. */
void gfx_present();

#endif
