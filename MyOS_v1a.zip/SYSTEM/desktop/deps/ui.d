ui.o: ui.c ../kernel/stdint.h ../kernel/stddef.h ui.h window.h gfx.h \
 ../kernel/mouse.h ../kernel/stdint.h ../kernel/common.h \
 ../kernel/stddef.h
