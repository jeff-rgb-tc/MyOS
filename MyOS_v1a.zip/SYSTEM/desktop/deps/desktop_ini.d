desktop_ini.o: desktop_ini.c ../kernel/stdint.h ../kernel/stddef.h \
 desktop_ini.h apps.h ../kernel/ini.h ../kernel/stdint.h \
 ../kernel/fat32.h ../kernel/common.h ../kernel/stddef.h \
 ../kernel/kernio.h ../kernel/kheap.h ../kernel/stdio.h
