cursor_set.o: cursor_set.c cursor_set.h ../kernel/cursor.h \
 ../kernel/stdint.h ../kernel/stdio.h ../kernel/stddef.h \
 ../kernel/kernio.h ../kernel/common.h ../kernel/cursor_ani.h \
 ../kernel/cursor.h fs_util.h ../kernel/stdint.h ../kernel/fat32.h \
 ../kernel/kheap.h ../kernel/pit.h ../kernel/driver_loader.h desktop.h
