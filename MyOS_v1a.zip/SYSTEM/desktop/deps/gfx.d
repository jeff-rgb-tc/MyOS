gfx.o: gfx.c ../kernel/stdint.h ../kernel/stddef.h gfx.h ../kernel/vesa.h \
 ../kernel/kheap.h ../kernel/common.h ../kernel/stddef.h \
 ../kernel/stdint.h ../kernel/kernio.h ../kernel/font.h
