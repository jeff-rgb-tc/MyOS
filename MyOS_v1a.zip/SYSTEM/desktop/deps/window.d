window.o: window.c ../kernel/stdint.h ../kernel/stddef.h window.h gfx.h \
 ../kernel/common.h ../kernel/stddef.h ../kernel/stdint.h \
 ../kernel/kernio.h ../kernel/mouse.h
