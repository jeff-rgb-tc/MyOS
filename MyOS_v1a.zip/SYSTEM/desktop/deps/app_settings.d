app_settings.o: app_settings.c ../kernel/stdint.h ../kernel/stddef.h \
 app_settings.h window.h gfx.h ../kernel/common.h ../kernel/stddef.h \
 ../kernel/stdint.h ../kernel/kernio.h ../kernel/kheap.h settings.h \
 desktop.h ../kernel/vesa.h ../kernel/fat32.h file_picker.h cursor_set.h \
 ../kernel/cursor.h ../kernel/audio.h ../kernel/pit.h fs_util.h \
 ../kernel/keyboard.h
