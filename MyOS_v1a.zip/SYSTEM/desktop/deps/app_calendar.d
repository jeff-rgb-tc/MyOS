app_calendar.o: app_calendar.c ../kernel/stdint.h ../kernel/stddef.h \
 app_calendar.h window.h gfx.h ui.h ../kernel/common.h ../kernel/stddef.h \
 ../kernel/stdint.h ../kernel/kheap.h ../kernel/kernio.h \
 ../kernel/keyboard.h ../kernel/rtc.h cursor_set.h ../kernel/cursor.h \
 datetime_util.h
