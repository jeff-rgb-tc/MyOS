desktop_items.o: desktop_items.c ../kernel/stdint.h ../kernel/stddef.h \
 desktop_items.h shortcut.h apps.h fileops.h fs_util.h ../kernel/fat32.h \
 ../kernel/stdint.h ../kernel/png.h gfx.h ../kernel/kheap.h \
 ../kernel/common.h ../kernel/stddef.h ../kernel/kernio.h
