app_paint.o: app_paint.c ../kernel/stdint.h ../kernel/stddef.h \
 app_paint.h window.h gfx.h ../kernel/common.h ../kernel/stddef.h \
 ../kernel/stdint.h ../kernel/kernio.h ../kernel/kheap.h \
 ../kernel/fat32.h ../kernel/bmp.h ../kernel/fat32.h \
 ../kernel/png_encode.h ../kernel/pit.h cursor_set.h ../kernel/cursor.h
