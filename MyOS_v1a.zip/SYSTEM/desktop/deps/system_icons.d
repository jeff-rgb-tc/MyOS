system_icons.o: system_icons.c system_icons.h ../kernel/png.h \
 ../kernel/stdint.h ../kernel/kernio.h ../kernel/common.h \
 ../kernel/stddef.h
