apps.o: apps.c ../kernel/stdint.h ../kernel/stddef.h apps.h \
 ../kernel/png.h ../kernel/stdint.h app_cmd.h app_explorer.h app_paint.h \
 app_settings.h app_mediaplayer.h app_calculator.h app_notepad.h \
 app_calendar.h app_clock.h app_taskmgr.h ../kernel/common.h \
 ../kernel/stddef.h ../kernel/kernio.h fs_util.h ../kernel/fat32.h \
 ../kernel/kheap.h ../kernel/app_loader.h ../apps-sdk/include/myos/abi.h \
 ../kernel/app_format.h desktop.h
