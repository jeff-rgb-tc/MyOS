context_menu.o: context_menu.c ../kernel/stdint.h ../kernel/stddef.h \
 context_menu.h gfx.h ../kernel/mouse.h ../kernel/stdint.h \
 ../kernel/common.h ../kernel/stddef.h
