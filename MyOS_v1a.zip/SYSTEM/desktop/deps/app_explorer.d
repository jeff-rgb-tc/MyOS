app_explorer.o: app_explorer.c ../kernel/stdint.h ../kernel/stddef.h \
 app_explorer.h window.h gfx.h ../kernel/common.h ../kernel/stddef.h \
 ../kernel/stdint.h ../kernel/kernio.h ../kernel/kheap.h \
 ../kernel/fat32.h ../kernel/pit.h context_menu.h ../kernel/app_loader.h \
 ../apps-sdk/include/myos/abi.h ../kernel/app_format.h ../kernel/ini.h \
 ../kernel/stdio.h ../kernel/png.h system_icons.h cursor_set.h \
 ../kernel/cursor.h fs_util.h clipboard.h ../kernel/keyboard.h app_cmd.h \
 app_mediaplayer.h app_notepad.h fileops.h desktop.h dnd.h shortcut.h \
 apps.h ../kernel/rtc.h
