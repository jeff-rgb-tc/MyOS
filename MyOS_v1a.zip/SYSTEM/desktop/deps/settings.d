settings.o: settings.c ../kernel/stdint.h ../kernel/stddef.h settings.h \
 ../kernel/audio.h ../kernel/stdint.h ../kernel/ini.h ../kernel/fat32.h \
 ../kernel/common.h ../kernel/stddef.h ../kernel/kernio.h \
 ../kernel/kheap.h ../kernel/stdio.h
