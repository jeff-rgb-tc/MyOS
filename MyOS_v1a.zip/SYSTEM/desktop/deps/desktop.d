desktop.o: desktop.c app_taskmgr.h ../kernel/app_loader.h \
 ../kernel/stdint.h ../apps-sdk/include/myos/abi.h ../kernel/stdint.h \
 ../kernel/app_format.h desktop_items.h shortcut.h apps.h fileops.h \
 fs_util.h ../kernel/fat32.h startmenu.h dnd.h clipboard.h \
 ../kernel/stddef.h desktop.h gfx.h window.h taskbar.h ../kernel/mouse.h \
 ../kernel/keyboard.h ../kernel/cursor.h ../kernel/png.h context_menu.h \
 desktop_ini.h ../kernel/kernio.h ../kernel/common.h ../kernel/stddef.h \
 ../kernel/stdio.h ../kernel/pit.h settings.h ../kernel/kheap.h \
 app_explorer.h system_icons.h cursor_set.h app_settings.h app_cmd.h \
 app_mediaplayer.h app_notepad.h app_calculator.h
