app_cmd.o: app_cmd.c ../kernel/stdint.h ../kernel/stddef.h app_cmd.h \
 window.h gfx.h ../kernel/common.h ../kernel/stddef.h ../kernel/stdint.h \
 ../kernel/kernio.h ../kernel/kheap.h ../kernel/fat32.h fs_util.h \
 clipboard.h context_menu.h ../kernel/keyboard.h settings.h \
 ../kernel/rtc.h ../kernel/pit.h apps.h ../kernel/app_loader.h \
 ../apps-sdk/include/myos/abi.h ../kernel/app_format.h app_mediaplayer.h \
 app_notepad.h app_calculator.h cursor_set.h ../kernel/cursor.h
