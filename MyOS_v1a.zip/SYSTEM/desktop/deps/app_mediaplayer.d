app_mediaplayer.o: app_mediaplayer.c ../kernel/stdint.h \
 ../kernel/stddef.h app_mediaplayer.h desktop.h window.h gfx.h \
 ../kernel/common.h ../kernel/stddef.h ../kernel/stdint.h \
 ../kernel/kernio.h ../kernel/kheap.h ../kernel/fat32.h fs_util.h \
 ../kernel/audio.h ../kernel/mp3.h ../kernel/wav.h ../kernel/keyboard.h \
 ../kernel/pit.h context_menu.h cursor_set.h ../kernel/cursor.h
