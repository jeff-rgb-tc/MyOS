fs_util.o: fs_util.c ../kernel/stdint.h ../kernel/stddef.h fs_util.h \
 ../kernel/fat32.h ../kernel/stdint.h ../kernel/common.h \
 ../kernel/stddef.h ../kernel/kheap.h
