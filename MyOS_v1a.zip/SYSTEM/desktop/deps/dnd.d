dnd.o: dnd.c ../kernel/stdint.h ../kernel/stddef.h dnd.h
