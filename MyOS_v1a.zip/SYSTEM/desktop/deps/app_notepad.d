app_notepad.o: app_notepad.c ../kernel/stdint.h ../kernel/stddef.h \
 app_notepad.h window.h gfx.h ../kernel/common.h ../kernel/stddef.h \
 ../kernel/stdint.h ../kernel/kernio.h ../kernel/kheap.h \
 ../kernel/fat32.h fs_util.h clipboard.h context_menu.h file_picker.h \
 ../kernel/keyboard.h ../kernel/pit.h ../kernel/rtc.h cursor_set.h \
 ../kernel/cursor.h
