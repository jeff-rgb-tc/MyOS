startmenu.o: startmenu.c ../kernel/stdint.h ../kernel/stddef.h \
 startmenu.h taskbar.h window.h gfx.h apps.h ../kernel/common.h \
 ../kernel/stddef.h ../kernel/stdint.h ../kernel/kernio.h \
 ../kernel/power.h ../kernel/mouse.h desktop.h settings.h ../kernel/png.h \
 ../kernel/kheap.h ../kernel/pit.h system_icons.h cursor_set.h \
 ../kernel/cursor.h context_menu.h shortcut.h fileops.h fs_util.h \
 ../kernel/fat32.h desktop_items.h ../kernel/keyboard.h app_explorer.h
