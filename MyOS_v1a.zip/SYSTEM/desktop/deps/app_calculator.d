app_calculator.o: app_calculator.c ../kernel/stdint.h ../kernel/stddef.h \
 app_calculator.h window.h gfx.h ../kernel/common.h ../kernel/stddef.h \
 ../kernel/stdint.h ../kernel/kheap.h ../kernel/keyboard.h \
 ../kernel/pit.h cursor_set.h ../kernel/cursor.h
