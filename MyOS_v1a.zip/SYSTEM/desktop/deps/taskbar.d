taskbar.o: taskbar.c ../kernel/stdint.h ../kernel/stddef.h taskbar.h \
 window.h gfx.h ../kernel/audio.h ../kernel/stdint.h apps.h \
 ../kernel/icon.h ../kernel/common.h ../kernel/stddef.h \
 ../kernel/kernio.h ../kernel/power.h ../kernel/rtc.h ../kernel/mouse.h \
 desktop.h settings.h ../kernel/png.h ../kernel/kheap.h system_icons.h \
 cursor_set.h ../kernel/cursor.h app_calendar.h startmenu.h
