datetime_util.o: datetime_util.c ../kernel/stdint.h datetime_util.h \
 ../kernel/kernio.h
