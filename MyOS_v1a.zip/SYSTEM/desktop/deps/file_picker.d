file_picker.o: file_picker.c file_picker.h ../kernel/stdint.h \
 ../kernel/fat32.h ../kernel/stdint.h ../kernel/common.h \
 ../kernel/stddef.h gfx.h ../kernel/pit.h
