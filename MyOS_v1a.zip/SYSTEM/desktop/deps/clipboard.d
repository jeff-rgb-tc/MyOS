clipboard.o: clipboard.c clipboard.h
