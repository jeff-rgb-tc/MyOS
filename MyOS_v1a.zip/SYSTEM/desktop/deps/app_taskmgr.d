app_taskmgr.o: app_taskmgr.c ../kernel/stdint.h ../kernel/stddef.h \
 app_taskmgr.h window.h gfx.h ui.h ../kernel/common.h ../kernel/stddef.h \
 ../kernel/stdint.h ../kernel/kheap.h ../kernel/kernio.h \
 ../kernel/keyboard.h ../kernel/pit.h desktop.h fs_util.h \
 ../kernel/fat32.h cursor_set.h ../kernel/cursor.h \
 ../kernel/driver_loader.h
