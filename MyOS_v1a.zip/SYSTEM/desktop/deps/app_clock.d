app_clock.o: app_clock.c ../kernel/stdint.h ../kernel/stddef.h \
 app_clock.h window.h gfx.h ui.h ../kernel/common.h ../kernel/stddef.h \
 ../kernel/stdint.h ../kernel/kheap.h ../kernel/kernio.h \
 ../kernel/keyboard.h ../kernel/pit.h ../kernel/rtc.h cursor_set.h \
 ../kernel/cursor.h datetime_util.h
