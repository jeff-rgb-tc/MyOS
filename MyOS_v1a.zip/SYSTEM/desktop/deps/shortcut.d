shortcut.o: shortcut.c ../kernel/stdint.h ../kernel/stddef.h shortcut.h \
 apps.h fileops.h fs_util.h ../kernel/fat32.h ../kernel/stdint.h \
 ../kernel/ini.h ../kernel/common.h ../kernel/stddef.h ../kernel/kheap.h \
 ../kernel/app_loader.h ../apps-sdk/include/myos/abi.h \
 ../kernel/app_format.h app_explorer.h app_notepad.h app_mediaplayer.h \
 app_paint.h
