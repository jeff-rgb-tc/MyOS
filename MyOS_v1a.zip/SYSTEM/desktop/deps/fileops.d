fileops.o: fileops.c ../kernel/stdint.h ../kernel/stddef.h fileops.h \
 fs_util.h ../kernel/fat32.h ../kernel/stdint.h clipboard.h \
 ../kernel/common.h ../kernel/stddef.h desktop.h
