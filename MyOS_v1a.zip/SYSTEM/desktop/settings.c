/*
 * Reads/writes settings.ini, which lives at /Users/User/settings.ini on
 * the FAT32 disk -- same directory as desktop.ini (see desktop_ini.c),
 * same INI format, same hand-rolled writer approach (this kernel's
 * ini.h only parses, it has no formatter of its own).
 */

#include "stdint.h"
#include "stddef.h"
#include "settings.h"
#include "audio.h"
#include "ini.h"
#include "fat32.h"
#include "common.h"
#include "kernio.h"
#include "kheap.h"
#include "stdio.h"

#define SETTINGS_PATH "/Users/User/settings.ini"
#define SETTINGS_DEFAULT_WALLPAPER "/SYSTEM/res/backgrounds/background_1.png"

static settings_t g_settings;
static uint8_t g_loaded = 0;

/* Same find/create-directory-level helper as desktop_ini.c's
 * step_into_or_create() -- duplicated rather than shared, since it's a
 * small, self-contained ~15 lines and pulling it into a shared header
 * for two call sites isn't worth the extra indirection. */
static struct dir_entry *find_subdir(struct directory *dir, const char *name) {
    for(uint32_t i = 0; i < dir->num_entries; i++) {
        struct dir_entry *e = &dir->entries[i];
        if(e->name && (e->dir_attrs & DIRECTORY) && strcmp(e->name, name) == 0) {
            return e;
        }
    }
    return NULL;
}

static void step_into_or_create(struct directory *dir, const char *name) {
    struct dir_entry *existing = find_subdir(dir, name);

    uint32_t cluster;
    if(existing) {
        cluster = existing->first_cluster;
    }
    else {
        mkdir(master_fs, dir, (char *)name);
        existing = find_subdir(dir, name);
        if(!existing) {
            printf("settings: failed to create directory '%s'\n", name);
            cluster = 0;
        }
        else {
            cluster = existing->first_cluster;
        }
    }

    free_directory(master_fs, dir);
    if(cluster) {
        populate_dir(master_fs, dir, cluster);
    }
    else {
        memset(dir, 0, sizeof(struct directory));
    }
}

static int ensure_user_path(struct directory *out_user_dir) {
    if(!master_fs) return 0;

    struct directory current;
    populate_root_dir(master_fs, &current);

    step_into_or_create(&current, "Users");
    step_into_or_create(&current, "User");

    *out_user_dir = current;
    return 1;
}

static void set_default_settings(void) {
    memset(&g_settings, 0, sizeof(g_settings));
    fastcp(g_settings.wallpaper_path, SETTINGS_DEFAULT_WALLPAPER, sizeof(SETTINGS_DEFAULT_WALLPAPER));
    g_settings.brightness = 100;
    g_settings.resolution_width = 0;  /* 0 = automatic, see settings.h */
    g_settings.resolution_height = 0;
    g_settings.volume = 70;
    g_settings.muted = 0;
    g_settings.taskbar_dock = 0;
    g_settings.animations = 1;
    fastcp(g_settings.username, "User", 5);
    /* avatar_path stays empty -- no avatar set by default. */
}

/* Copies src into a SETTINGS_STRING_MAX-sized field, truncating (with a
 * null terminator still guaranteed) rather than overflowing if the INI
 * file somehow has a longer value than this build's limit allows --
 * defensive against a hand-edited or corrupted settings.ini, not just
 * ones this module wrote itself. */
static void copy_setting_string(char *dest, const char *src) {
    int i = 0;
    while(src[i] && i < SETTINGS_STRING_MAX - 1) {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
}

void settings_load(void) {
    set_default_settings();
    g_loaded = 1;

    FILE *f = fopen(SETTINGS_PATH, NULL);
    if(!f) {
        audio_set_volume((uint8_t)g_settings.volume);
        return; /* no saved settings yet -- defaults stand, not an error */
    }

    uint32_t capacity = 8192;
    uint8_t *buffer = (uint8_t *)kmalloc(capacity);
    uint32_t total = 0;

    size_t chunk;
    while((chunk = fread(buffer + total, 1, capacity - total, f)) > 0) {
        total += chunk;
        if(total >= capacity) break; /* settings.ini should never realistically be this large */
    }
    fclose(f);

    ini_document_t doc;
    ini_parse((const char *)buffer, total, &doc);
    kfree(buffer);

    const char *wallpaper = ini_get(&doc, "personalization", "wallpaper");
    if(wallpaper) copy_setting_string(g_settings.wallpaper_path, wallpaper);

    int brightness;
    if(ini_get_int(&doc, "personalization", "brightness", &brightness)) {
        if(brightness < 0) brightness = 0;
        if(brightness > 100) brightness = 100;
        g_settings.brightness = brightness;
    }

    int res_w, res_h;
    if(ini_get_int(&doc, "personalization", "resolution_width", &res_w)
       && ini_get_int(&doc, "personalization", "resolution_height", &res_h)) {
        g_settings.resolution_width = res_w;
        g_settings.resolution_height = res_h;
    }

    const char *username = ini_get(&doc, "profile", "username");
    if(username && username[0]) copy_setting_string(g_settings.username, username);

    const char *avatar = ini_get(&doc, "profile", "avatar");
    if(avatar) copy_setting_string(g_settings.avatar_path, avatar);

    int vol;
    if(ini_get_int(&doc, "sound", "volume", &vol)) {
        if(vol < 0) vol = 0;
        if(vol > 100) vol = 100;
        g_settings.volume = vol;
    }
    int muted;
    if(ini_get_int(&doc, "sound", "muted", &muted)) g_settings.muted = muted ? 1 : 0;

    int anim;
    if(ini_get_int(&doc, "ui", "animations", &anim)) g_settings.animations = anim ? 1 : 0;
    int dock;
    if(ini_get_int(&doc, "taskbar", "dock", &dock) && dock >= 0 && dock <= 3) g_settings.taskbar_dock = dock;

    audio_set_volume((uint8_t)g_settings.volume);
    audio_set_muted(g_settings.muted);
}

/* Same append_str/append_int text-building approach as
 * desktop_ini.c's writer -- see that file's comment on why (this
 * kernel's sprintf() doesn't report the formatted length, so a
 * strlen()-based running position is used instead of trusting a return
 * value). */
static void append_str(char *buf, uint32_t *pos, const char *text) {
    uint32_t len = strlen(text);
    for(uint32_t i = 0; i < len; i++) {
        buf[*pos + i] = text[i];
    }
    *pos += len;
}

static void append_int(char *buf, uint32_t *pos, int value) {
    char digits[12];
    char *s = itos((uint32_t)value, digits, sizeof(digits));
    append_str(buf, pos, s);
}

void settings_save(void) {
    if(!g_loaded) return;

    struct directory user_dir;
    if(!ensure_user_path(&user_dir)) {
        return;
    }

    /* Generous fixed size -- every field here is capped at
     * SETTINGS_STRING_MAX (64) or a small int, so the whole file is
     * always well under 1KB; 2KB leaves comfortable headroom without
     * needing a growable buffer for something this small. */
    uint32_t capacity = 2048;
    char *text = (char *)kmalloc(capacity);
    uint32_t pos = 0;

    append_str(text, &pos, "[personalization]\n");
    append_str(text, &pos, "wallpaper=");
    append_str(text, &pos, g_settings.wallpaper_path);
    append_str(text, &pos, "\n");
    append_str(text, &pos, "brightness=");
    append_int(text, &pos, g_settings.brightness);
    append_str(text, &pos, "\n");
    append_str(text, &pos, "resolution_width=");
    append_int(text, &pos, g_settings.resolution_width);
    append_str(text, &pos, "\n");
    append_str(text, &pos, "resolution_height=");
    append_int(text, &pos, g_settings.resolution_height);
    append_str(text, &pos, "\n\n");

    append_str(text, &pos, "[profile]\n");
    append_str(text, &pos, "username=");
    append_str(text, &pos, g_settings.username);
    append_str(text, &pos, "\n");
    append_str(text, &pos, "avatar=");
    append_str(text, &pos, g_settings.avatar_path);
    append_str(text, &pos, "\n\n");

    append_str(text, &pos, "[sound]\n");
    append_str(text, &pos, "volume=");
    append_int(text, &pos, g_settings.volume);
    append_str(text, &pos, "\n");
    append_str(text, &pos, "muted=");
    append_int(text, &pos, g_settings.muted);
    append_str(text, &pos, "\n\n");

    append_str(text, &pos, "[ui]\n");
    append_str(text, &pos, "animations=");
    append_int(text, &pos, g_settings.animations);
    append_str(text, &pos, "\n\n");

    append_str(text, &pos, "[taskbar]\n");
    append_str(text, &pos, "dock=");
    append_int(text, &pos, g_settings.taskbar_dock);
    append_str(text, &pos, "\n");

    writeFile(master_fs, &user_dir, (uint8_t *)text, "settings.ini", pos);

    kfree(text);
    free_directory(master_fs, &user_dir);
}

settings_t *settings_current(void) {
    if(!g_loaded) {
        set_default_settings();
        g_loaded = 1;
    }
    return &g_settings;
}
