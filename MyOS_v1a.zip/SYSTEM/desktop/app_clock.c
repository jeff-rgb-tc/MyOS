#include "stdint.h"
#include "stddef.h"
#include "app_clock.h"
#include "window.h"
#include "gfx.h"
#include "ui.h"
#include "common.h"
#include "kheap.h"
#include "kernio.h"
#include "keyboard.h"
#include "pit.h"
#include "rtc.h"
#include "cursor_set.h"
#include "datetime_util.h"

#define PAD 16
#define TAB_H 32
#define CONTENT_TOP (PAD + TAB_H + 18)
#define MAX_LAPS 8
#define TIMER_MAX_SECONDS (99 * 60)

enum { TAB_CLOCK = 0, TAB_STOPWATCH, TAB_TIMER, TAB_COUNT };

typedef enum {
    B_SW_START, B_SW_LAP, B_SW_RESET,
    B_TM_START, B_TM_RESET,
    B_TM_P1, B_TM_P5, B_TM_P10, B_TM_P15,
    B_TM_SUB60, B_TM_ADD60, B_TM_SUB10, B_TM_ADD10,
    B_COUNT
} btn_id_t;

typedef struct { int x, y, w, h; int id; const char *label; ui_btn_style_t style; } btn_t;

typedef struct {
    window_t *win;
    int tab;

    /* stopwatch -- all in PIT ticks (100 ms each) */
    int sw_running;
    long long sw_start;
    int sw_acc;
    int lap_total[MAX_LAPS];
    int lap_count;

    /* timer */
    int tm_total;          /* configured length, seconds            */
    int tm_running;
    long long tm_end;      /* tick at which a running timer expires */
    int tm_rem;            /* remaining ticks while stopped/paused  */
    int tm_done;
} app_clock_t;

/* ----------------------------- math ------------------------------ */
static void sincos_deg(double deg, double *s, double *c) {
    double rad = deg * 0.017453292519943295, sn, cs;
    __asm__("fsincos" : "=t"(cs), "=u"(sn) : "0"(rad));
    *s = sn; *c = cs;
}

static int imin(int a, int b) { return a < b ? a : b; }

/* --------------------------- stopwatch --------------------------- */
static int sw_elapsed(app_clock_t *a) {
    int e = a->sw_acc;
    if(a->sw_running) e += (int)(pit_get_ticks() - a->sw_start);
    return e;
}

static void fmt_sw(char *out, int ticks) {
    if(ticks < 0) ticks = 0;
    int tenths = ticks % 10;
    int secs = (ticks / 10) % 60;
    int mins = (ticks / 600) % 100;
    char m[3], s[3];
    ui_fmt2(m, mins); ui_fmt2(s, secs);
    out[0] = m[0]; out[1] = m[1]; out[2] = ':'; out[3] = s[0]; out[4] = s[1]; out[5] = '.';
    out[6] = (char)('0' + tenths); out[7] = '\0';
}

static void sw_toggle(app_clock_t *a) {
    if(a->sw_running) { a->sw_acc += (int)(pit_get_ticks() - a->sw_start); a->sw_running = 0; }
    else { a->sw_start = pit_get_ticks(); a->sw_running = 1; }
}

static void sw_lap(app_clock_t *a) {
    int e = sw_elapsed(a);
    if(e <= 0) return;
    if(a->lap_count == MAX_LAPS) {
        for(int i = 1; i < MAX_LAPS; i++) a->lap_total[i - 1] = a->lap_total[i];
        a->lap_count--;
    }
    a->lap_total[a->lap_count++] = e;
}

static void sw_reset(app_clock_t *a) {
    a->sw_running = 0; a->sw_acc = 0; a->lap_count = 0;
}

/* ----------------------------- timer ----------------------------- */
static int tm_remaining(app_clock_t *a) {
    if(a->tm_running) {
        long long left = a->tm_end - pit_get_ticks();
        return left > 0 ? (int)left : 0;
    }
    return a->tm_rem;
}

static void tm_set_total(app_clock_t *a, int secs) {
    if(a->tm_running) return;
    if(secs < 10) secs = 10;
    if(secs > TIMER_MAX_SECONDS) secs = TIMER_MAX_SECONDS;
    a->tm_total = secs;
    a->tm_rem = secs * 10;
    a->tm_done = 0;
}

static void tm_toggle(app_clock_t *a) {
    if(a->tm_running) {
        a->tm_rem = tm_remaining(a);
        a->tm_running = 0;
        return;
    }
    if(a->tm_done || a->tm_rem <= 0) { a->tm_rem = a->tm_total * 10; a->tm_done = 0; }
    a->tm_end = pit_get_ticks() + a->tm_rem;
    a->tm_running = 1;
}

static void tm_reset(app_clock_t *a) {
    a->tm_running = 0; a->tm_done = 0; a->tm_rem = a->tm_total * 10;
}

static void clock_tick(window_t *self) {
    app_clock_t *a = (app_clock_t *)self->user_data;
    if(!a) return;
    if(a->tm_running && pit_get_ticks() >= a->tm_end) {
        a->tm_running = 0; a->tm_rem = 0; a->tm_done = 1;
    }
    /* Only the stopwatch/timer need the 10 Hz redraw; the clock face is
     * fine once a second. */
    self->static_content = !(a->sw_running || a->tm_running || a->tm_done) || a->tab == TAB_CLOCK;
}

/* ---------------------------- layout ----------------------------- */
static void tabs_rect(int cw, int *x, int *y, int *w, int *h) {
    *w = imin(cw - PAD * 2, 340);
    *x = (cw - *w) / 2; *y = PAD; *h = TAB_H;
}

/* Builds this frame's button list for the current tab; paint and click
 * both call it so what is drawn and what is clickable always agree. */
static int build_buttons(app_clock_t *a, int cw, int ch, btn_t *b) {
    (void)ch;
    int n = 0;
    int bw = 92, bh = 36, gap = 10;
    int total = bw * 3 + gap * 2;
    int x0 = (cw - total) / 2;

    if(a->tab == TAB_STOPWATCH) {
        int y = CONTENT_TOP + 96;
        int running = a->sw_running;
        b[n++] = (btn_t){ x0, y, bw, bh, B_SW_RESET, "Reset", UI_BTN_NORMAL };
        b[n++] = (btn_t){ x0 + bw + gap, y, bw, bh, B_SW_START, running ? "Stop" : "Start",
                          running ? UI_BTN_DANGER : UI_BTN_ACCENT };
        b[n++] = (btn_t){ x0 + (bw + gap) * 2, y, bw, bh, B_SW_LAP, "Lap", UI_BTN_NORMAL };
    }
    else if(a->tab == TAB_TIMER) {
        int pw = (cw - PAD * 2 - gap * 3) / 4; if(pw > 78) pw = 78;
        int px = (cw - (pw * 4 + gap * 3)) / 2;
        int y = CONTENT_TOP + 108;
        b[n++] = (btn_t){ px, y, pw, 30, B_TM_P1, "1 min", UI_BTN_NORMAL };
        b[n++] = (btn_t){ px + (pw + gap), y, pw, 30, B_TM_P5, "5 min", UI_BTN_NORMAL };
        b[n++] = (btn_t){ px + (pw + gap) * 2, y, pw, 30, B_TM_P10, "10 min", UI_BTN_NORMAL };
        b[n++] = (btn_t){ px + (pw + gap) * 3, y, pw, 30, B_TM_P15, "15 min", UI_BTN_NORMAL };
        y += 40;
        b[n++] = (btn_t){ px, y, pw, 30, B_TM_SUB60, "-1m", UI_BTN_FLAT };
        b[n++] = (btn_t){ px + (pw + gap), y, pw, 30, B_TM_SUB10, "-10s", UI_BTN_FLAT };
        b[n++] = (btn_t){ px + (pw + gap) * 2, y, pw, 30, B_TM_ADD10, "+10s", UI_BTN_FLAT };
        b[n++] = (btn_t){ px + (pw + gap) * 3, y, pw, 30, B_TM_ADD60, "+1m", UI_BTN_FLAT };
        y += 50;
        int tw = bw * 2 + gap;
        int tx = (cw - tw) / 2;
        b[n++] = (btn_t){ tx, y, bw, bh, B_TM_RESET, "Reset", UI_BTN_NORMAL };
        b[n++] = (btn_t){ tx + bw + gap, y, bw, bh, B_TM_START, a->tm_running ? "Pause" : "Start",
                          a->tm_running ? UI_BTN_NORMAL : UI_BTN_ACCENT };
    }
    return n;
}

/* ---------------------------- painting --------------------------- */
static void paint_analog(app_clock_t *a, int cx, int cy, int cw, int ch) {
    (void)a;
    rtc_time_t t; rtc_date_t d;
    rtc_read_time(&t); rtc_read_date(&d);

    int top = cy + CONTENT_TOP;
    int avail = ch - CONTENT_TOP - PAD;
    int R = imin((cw - 40) / 2, (avail - 92) / 2);
    if(R > 150) R = 150;
    if(R < 44) R = 44;
    int mx = cx + cw / 2, my = top + R + 2;

    gfx_draw_shadow(mx - R, my - R, R * 2, R * 2, R, 16, 5, 110);
    gfx_fill_circle(mx, my, R, 0xFF3E3E48);          /* bezel */
    gfx_fill_circle(mx, my, R - 3, 0xFF18181C);      /* face  */

    for(int i = 0; i < 60; i++) {
        double s, c;
        sincos_deg(i * 6.0, &s, &c);
        int hour_tick = (i % 5) == 0;
        double r0 = R - 9, r1 = hour_tick ? R - 21 : R - 14;
        gfx_draw_line_thick(mx + s * r0, my - c * r0, mx + s * r1, my - c * r1,
                            hour_tick ? 2.2 : 1.0, hour_tick ? 0xFFEDEDF2 : 0xFF6A6A76);
    }

    if(R >= 84) {
        for(int h = 1; h <= 12; h++) {
            double s, c;
            sincos_deg(h * 30.0, &s, &c);
            char num[4]; sprintf(num, "%d", h);
            double rn = R - 38;
            gfx_draw_string((int)(mx + s * rn) - ui_text_w(num) / 2, (int)(my - c * rn) - 8, num, 0xFFC9C9D2);
        }
    }

    double hs, hc, ms, mc, ss, sc;
    sincos_deg((t.hours % 12) * 30.0 + t.minutes * 0.5, &hs, &hc);
    sincos_deg(t.minutes * 6.0 + t.seconds * 0.1, &ms, &mc);
    sincos_deg(t.seconds * 6.0, &ss, &sc);

    double lh = R * 0.50, lm = R * 0.76, ls = R * 0.86;
    gfx_draw_line_thick(mx, my, mx + hs * lh, my - hc * lh, 5.0, 0xFFF2F2F6);
    gfx_draw_line_thick(mx, my, mx + ms * lm, my - mc * lm, 3.4, 0xFFF2F2F6);
    gfx_draw_line_thick(mx - ss * 16, my + sc * 16, mx + ss * ls, my - sc * ls, 1.5, 0xFFFF7043);
    gfx_fill_circle(mx, my, 6, 0xFFFF7043);
    gfx_fill_circle(mx, my, 2, 0xFF18181C);

    /* digital readout + date */
    char buf[16];
    sprintf(buf, "%02d:%02d:%02d", t.hours, t.minutes, t.seconds);
    int ty = my + R + 16;
    int scale = (cw >= 8 * 8 * 3 + 20) ? 3 : 2;
    gfx_draw_string_scaled(cx + (cw - ui_text_w(buf) * scale) / 2, ty, buf, UI_TEXT, scale);

    char date[40];
    dt_format_long_date(date, sizeof(date), d.year, d.month, d.day);
    ui_text_center(cx, ty + 16 * scale + 4, cw, 18, date, UI_TEXT_DIM);
}

static void paint_stopwatch(app_clock_t *a, int cx, int cy, int cw, int ch, window_t *self) {
    char buf[16];
    fmt_sw(buf, sw_elapsed(a));
    int scale = (cw >= 7 * 8 * 4 + 20) ? 4 : 3;
    int tw = ui_text_w(buf) * scale;
    gfx_draw_string_scaled(cx + (cw - tw) / 2, cy + CONTENT_TOP + 14, buf, UI_TEXT, scale);

    btn_t b[B_COUNT];
    int n = build_buttons(a, cw, ch, b);
    int rx, ry, hov = ui_hover_pos(self, cx, cy, &rx, &ry), down = ui_mouse_down();
    for(int i = 0; i < n; i++) {
        int over = hov && ui_in(rx, ry, b[i].x, b[i].y, b[i].w, b[i].h);
        ui_button(cx + b[i].x, cy + b[i].y, b[i].w, b[i].h, b[i].label, b[i].style, over, over && down);
    }

    /* laps, newest first */
    int ly = CONTENT_TOP + 96 + 36 + 16;
    int cwid = imin(cw - PAD * 2, 340), lx = (cw - cwid) / 2;
    int rows = imin(a->lap_count, (ch - ly - PAD - 8) / 22);
    if(a->lap_count == 0) {
        ui_text_center(cx, cy + ly + 6, cw, 18, "Press Lap to record split times", UI_TEXT_FAINT);
        return;
    }
    if(rows < 1) return;
    ui_card(cx + lx, cy + ly, cwid, rows * 22 + 12, 8);
    for(int i = 0; i < rows; i++) {
        int idx = a->lap_count - 1 - i;
        int delta = a->lap_total[idx] - (idx > 0 ? a->lap_total[idx - 1] : 0);
        char l1[16], l2[16], name[12];
        fmt_sw(l1, delta); fmt_sw(l2, a->lap_total[idx]);
        sprintf(name, "Lap %d", idx + 1);
        int yy = cy + ly + 6 + i * 22 + 3;
        gfx_draw_string(cx + lx + 14, yy, name, UI_TEXT_DIM);
        gfx_draw_string(cx + lx + cwid / 2 - 28, yy, l1, UI_TEXT);
        ui_text_right(cx + lx + cwid - 14, yy, l2, UI_TEXT_DIM);
    }
}

static void paint_timer(app_clock_t *a, int cx, int cy, int cw, int ch, window_t *self) {
    int rem = tm_remaining(a);
    int secs = (rem + 9) / 10;
    char m[3], s[3], buf[8];
    ui_fmt2(m, secs / 60); ui_fmt2(s, secs % 60);
    buf[0] = m[0]; buf[1] = m[1]; buf[2] = ':'; buf[3] = s[0]; buf[4] = s[1]; buf[5] = '\0';

    uint32_t col = UI_TEXT;
    if(a->tm_done) col = (pit_get_ticks() % 6 < 3) ? 0xFFFF6B5E : UI_TEXT_DIM;
    else if(a->tm_running && secs <= 10) col = 0xFFFFB454;
    int scale = (cw >= 5 * 8 * 5 + 20) ? 5 : 3;
    gfx_draw_string_scaled(cx + (cw - ui_text_w(buf) * scale) / 2, cy + CONTENT_TOP + 6, buf, col, scale);
    if(a->tm_done) ui_text_center(cx, cy + CONTENT_TOP + 6 + 16 * scale + 4, cw, 18, "Time's up!", 0xFFFF6B5E);
    else {
        /* progress ring replaced by a slim bar: remaining / configured */
        int bw = imin(cw - PAD * 4, 300);
        ui_bar(cx + (cw - bw) / 2, cy + CONTENT_TOP + 6 + 16 * scale + 10, bw, 6,
               (uint32_t)rem, (uint32_t)(a->tm_total * 10), a->tm_running ? UI_ACCENT : 0xFF6C6C76);
    }

    btn_t b[B_COUNT];
    int n = build_buttons(a, cw, ch, b);
    int rx, ry, hov = ui_hover_pos(self, cx, cy, &rx, &ry), down = ui_mouse_down();
    for(int i = 0; i < n; i++) {
        int over = hov && ui_in(rx, ry, b[i].x, b[i].y, b[i].w, b[i].h);
        ui_button(cx + b[i].x, cy + b[i].y, b[i].w, b[i].h, b[i].label, b[i].style, over, over && down);
    }
}

static void clock_paint(window_t *self, int cx, int cy, int cw, int ch) {
    app_clock_t *a = (app_clock_t *)self->user_data;
    if(!a) return;
    ui_clear(cx, cy, cw, ch);

    int tx, ty, tw, th;
    tabs_rect(cw, &tx, &ty, &tw, &th);
    static const char *const labels[TAB_COUNT] = { "Clock", "Stopwatch", "Timer" };
    int rx, ry, hover = -1;
    if(ui_hover_pos(self, cx, cy, &rx, &ry)) hover = ui_tabs_hit(tx, ty, tw, th, TAB_COUNT, rx, ry);
    ui_tabs(cx + tx, cy + ty, tw, th, labels, TAB_COUNT, a->tab, hover);

    if(a->tab == TAB_CLOCK) paint_analog(a, cx, cy, cw, ch);
    else if(a->tab == TAB_STOPWATCH) paint_stopwatch(a, cx, cy, cw, ch, self);
    else paint_timer(a, cx, cy, cw, ch, self);
}

/* ---------------------------- input ------------------------------ */
static void do_action(app_clock_t *a, int id) {
    switch(id) {
        case B_SW_START: sw_toggle(a); break;
        case B_SW_LAP: sw_lap(a); break;
        case B_SW_RESET: sw_reset(a); break;
        case B_TM_START: tm_toggle(a); break;
        case B_TM_RESET: tm_reset(a); break;
        case B_TM_P1: tm_set_total(a, 60); break;
        case B_TM_P5: tm_set_total(a, 300); break;
        case B_TM_P10: tm_set_total(a, 600); break;
        case B_TM_P15: tm_set_total(a, 900); break;
        case B_TM_SUB60: tm_set_total(a, a->tm_total - 60); break;
        case B_TM_ADD60: tm_set_total(a, a->tm_total + 60); break;
        case B_TM_SUB10: tm_set_total(a, a->tm_total - 10); break;
        case B_TM_ADD10: tm_set_total(a, a->tm_total + 10); break;
    }
}

static void clock_click(window_t *self, int rx, int ry) {
    app_clock_t *a = (app_clock_t *)self->user_data;
    if(!a) return;
    int x, y, w, h, cw, ch;
    wm_get_client_rect(self, &x, &y, &cw, &ch);
    tabs_rect(cw, &x, &y, &w, &h);
    int t = ui_tabs_hit(x, y, w, h, TAB_COUNT, rx, ry);
    if(t >= 0) { a->tab = t; return; }

    btn_t b[B_COUNT];
    int n = build_buttons(a, cw, ch, b);
    for(int i = 0; i < n; i++) {
        if(ui_in(rx, ry, b[i].x, b[i].y, b[i].w, b[i].h)) { do_action(a, b[i].id); return; }
    }
}

static void clock_key(window_t *self, char k) {
    app_clock_t *a = (app_clock_t *)self->user_data;
    if(!a) return;
    if(k == '1') a->tab = TAB_CLOCK;
    else if(k == '2') a->tab = TAB_STOPWATCH;
    else if(k == '3') a->tab = TAB_TIMER;
    else if(k == '\t') a->tab = (a->tab + 1) % TAB_COUNT;
    else if(a->tab == TAB_STOPWATCH) {
        if(k == ' ' || k == '\n') sw_toggle(a);
        else if(k == 'l' || k == 'L') sw_lap(a);
        else if(k == 'r' || k == 'R') sw_reset(a);
    }
    else if(a->tab == TAB_TIMER) {
        if(k == ' ' || k == '\n') tm_toggle(a);
        else if(k == 'r' || k == 'R') tm_reset(a);
        else if(k == '+' || k == '=') tm_set_total(a, a->tm_total + 60);
        else if(k == '-') tm_set_total(a, a->tm_total - 60);
    }
}

static int clock_cursor_at(window_t *self, int rx, int ry) {
    app_clock_t *a = (app_clock_t *)self->user_data;
    if(!a) return CURSOR_DEFAULT;
    int x, y, w, h, cw, ch;
    wm_get_client_rect(self, &x, &y, &cw, &ch);
    tabs_rect(cw, &x, &y, &w, &h);
    if(ui_tabs_hit(x, y, w, h, TAB_COUNT, rx, ry) >= 0) return CURSOR_LINK;
    btn_t b[B_COUNT];
    int n = build_buttons(a, cw, ch, b);
    for(int i = 0; i < n; i++) if(ui_in(rx, ry, b[i].x, b[i].y, b[i].w, b[i].h)) return CURSOR_LINK;
    return CURSOR_DEFAULT;
}

static void clock_destroy(window_t *self) {
    if(self->user_data) { kfree(self->user_data); self->user_data = NULL; }
}

void launch_clock(void) {
    window_t *existing = wm_find_window_by_paint(clock_paint);
    if(existing) {
        if(existing->minimized) wm_restore_window(existing); else wm_focus(existing);
        return;
    }

    int sw = (int)gfx_width(), sh = (int)gfx_height();
    int w = 420, h = 560;
    if(h > sh - 60) h = sh - 60;
    if(w > sw - 20) w = sw - 20;
    window_t *win = wm_create_window("Clock", (sw - w) / 2 + 40, 20 + (sh - 60 - h) / 4, w, h, UI_BG);
    if(!win) return;
    app_clock_t *a = (app_clock_t *)kmalloc(sizeof(app_clock_t));
    if(!a) { wm_destroy_window(win); return; }
    memset(a, 0, sizeof(*a));
    a->win = win;
    a->tm_total = 300;
    a->tm_rem = 3000;
    win->user_data = a;
    win->on_paint = clock_paint;
    win->on_click = clock_click;
    win->on_key = clock_key;
    win->on_tick = clock_tick;
    win->cursor_at = clock_cursor_at;
    win->on_destroy = clock_destroy;
}
