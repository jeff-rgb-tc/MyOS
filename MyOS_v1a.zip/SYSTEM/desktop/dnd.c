#include "stdint.h"
#include "stddef.h"
#include "dnd.h"

static int active = 0;
static int is_dir_flag = 0;
static char path_buf[DND_PATH_MAX];
static char label_buf[48];

static void copy_str(char *dst, int max, const char *src) {
    int i = 0;
    while(src && src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

void dnd_begin(const char *path, const char *label, int is_dir) {
    if(!path || !path[0]) return;
    copy_str(path_buf, sizeof(path_buf), path);
    copy_str(label_buf, sizeof(label_buf), label ? label : path);
    is_dir_flag = is_dir;
    active = 1;
}

int dnd_active(void) { return active; }
const char *dnd_path(void) { return path_buf; }
const char *dnd_label(void) { return label_buf; }
int dnd_is_dir(void) { return is_dir_flag; }
void dnd_end(void) { active = 0; }
