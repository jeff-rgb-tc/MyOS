#ifndef DESKTOP_DATETIME_UTIL_H
#define DESKTOP_DATETIME_UTIL_H

#include "stdint.h"

/* Calendar arithmetic shared by the Clock, Calendar and Task Manager
 * (no libc time.h in this kernel). All dates are proleptic Gregorian. */

int dt_is_leap(int year);
int dt_days_in_month(int year, int month);          /* month 1..12 */
int dt_weekday(int year, int month, int day);        /* 0 = Sunday .. 6 = Saturday */
int dt_day_of_year(int year, int month, int day);    /* 1..366 */
int dt_iso_week(int year, int month, int day);       /* 1..53 */

const char *dt_month_name(int month);                /* "January".. (1..12) */
const char *dt_weekday_name(int weekday);            /* "Sunday".. (0..6)   */

/* "Tuesday, 13 October 2026" */
void dt_format_long_date(char *out, int max, int year, int month, int day);

/* Shifts a date by `delta` days (negative allowed). */
void dt_add_days(int *year, int *month, int *day, int delta);

#endif
