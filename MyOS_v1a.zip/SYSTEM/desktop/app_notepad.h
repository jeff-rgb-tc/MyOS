#ifndef APP_NOTEPAD_H
#define APP_NOTEPAD_H

/* Notepad: plain-text editor. Menu bar (File / Edit), caret + mouse
 * selection, scrolling, Ctrl+N/O/S/A/C/X/V, F5-style Time/Date insert,
 * Save As path bar, status bar with Ln/Col. Opens any file as text. */
void launch_notepad(void);

/* Opens the player with the file loaded (absolute path). */
void launch_notepad_with_file(const char *path);

#endif
