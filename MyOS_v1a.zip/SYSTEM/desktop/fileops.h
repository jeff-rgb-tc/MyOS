#ifndef DESKTOP_FILEOPS_H
#define DESKTOP_FILEOPS_H

#include "stdint.h"
#include "fs_util.h"

/* Small filesystem operations shared by the desktop, Explorer's drag and
 * drop, the Start menu and shortcuts: unique names, moving into a folder,
 * and "delete" = move to the Recycle Bin. All paths are absolute. */

#define RECYCLE_BIN_PATH "/RecycleBin"
#define DESKTOP_FOLDER_PATH "/Users/User/Desktop"

/* "dir" + "/" + "name" (no doubled slash for the root). */
void fileops_join(const char *dir, const char *name, char *out, int max);

/* Picks a name that does not exist in `dir` yet: "name.ext", then
 * "name (2).ext", "name (3).ext"... (the extension is preserved). */
void fileops_unique_name(const char *dir, const char *name, char *out, int max);

/* Moves a file or folder into `dest_dir` (keeping its name, or a unique
 * variant if that name is taken). Returns 1 on success. Moving something
 * into the folder it already lives in succeeds without doing anything;
 * moving a folder into itself or one of its own subfolders fails. */
int fileops_move_into(const char *src, const char *dest_dir, char *out_new_path, int out_max);

/* "Delete": moves into /RecycleBin (created if missing). Returns 1 on success. */
int fileops_trash(const char *path);

/* 1 if `path` is exactly `dir` or lies somewhere inside it. */
int fileops_is_inside(const char *path, const char *dir);

/* 1 if path's parent directory is exactly `dir`. */
int fileops_parent_is(const char *path, const char *dir);

/* Pastes the file/folder on the shared clipboard (copy or cut, as set by
 * Explorer or the desktop) into `dest_dir`. Returns 1 if something was pasted. */
int fileops_paste_clipboard_into(const char *dest_dir);

/* Renames the file/folder at `path` to `new_name` in the same folder.
 * Fails (0) if that name is taken or contains a slash. */
int fileops_rename(const char *path, const char *new_name);

#endif
