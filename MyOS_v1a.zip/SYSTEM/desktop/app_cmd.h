#ifndef APP_CMD_H
#define APP_CMD_H

/* Windows-11-style Command Prompt: real current directory, cd/md/rd/
 * del/copy/move/ren/type/dir/tree, command history (Up/Down), Tab
 * completion, scrollback (PgUp/PgDn), %VAR% expansion, > and >>
 * redirection, color/title/prompt, and launching apps by name. */
void launch_cmd(void);

/* Same, but starting in the given absolute path ("/Users/User/Music").
 * Used by Explorer's "Open in Command Prompt". */
void launch_cmd_at(const char *path);

#endif
