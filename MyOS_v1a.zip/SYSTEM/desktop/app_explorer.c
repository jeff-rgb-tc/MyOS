#include "stdint.h"
#include "stddef.h"
#include "app_explorer.h"
#include "window.h"
#include "gfx.h"
#include "common.h"
#include "kernio.h"
#include "kheap.h"
#include "fat32.h"
#include "pit.h"
#include "context_menu.h"
#include "app_loader.h"
#include "ini.h"
#include "stdio.h"
#include "png.h"
#include "system_icons.h"
#include "cursor_set.h"
#include "fs_util.h"
#include "clipboard.h"
#include "keyboard.h"
#include "app_cmd.h"
#include "app_mediaplayer.h"
#include "app_notepad.h"
#include "fileops.h"
#include "desktop.h"
#include "dnd.h"
#include "shortcut.h"
#include "startmenu.h"
#include "volumes.h"
#include "fsx.h"
#include "desktop_items.h"

/* Same palette as the Start menu and the other system apps. */
#define EX_BG      0xFF1E1E22
#define EX_PANEL   0xFF18181B
#define EX_CARD    0xFF2A2A30
#define EX_BTN     0xFF34343B
#define EX_TEXT    0xFFF2F2F5
#define EX_DIM     0xFFA0A0AA
#define EX_ACCENT  0xFF4CC2FF
#define EX_SEL     0x404CC2FF
#define EX_HOVER   0x1CFFFFFF
#include "rtc.h"

#define EXPLORER_MAX_DEPTH 16
#define EXPLORER_ROW_HEIGHT 24
#define EXPLORER_TOOLBAR_HEIGHT 32
#define EXPLORER_NAME_MAX 32
/* Real wall-clock double-click window -- see pit_get_ticks() in pit.h
 * for why this must be tick-based (100ms/tick) rather than a frame
 * count: a frame count is a different amount of real time on every
 * host/emulator, which made double-click flaky depending on how fast
 * the desktop's render loop happened to spin. */
#define EXPLORER_DOUBLE_CLICK_TICK_WINDOW 12 /* ~1.2s -- see desktop.c's DOUBLE_CLICK_TICK_WINDOW comment */

/* Left-hand Favorites sidebar, Windows-Explorer-style: fixed shortcuts
 * to well-known folders plus a "My PC" entry that shows disk info
 * instead of a folder listing. The on-disk folder names avoid spaces
 * (write_8_3_filename() in fat32.c copies short-name bytes verbatim
 * without sanitizing embedded spaces into '_' the way real FAT32
 * implementations do, so a literal space in a created folder's name
 * risks a malformed short-name entry) -- "Recycle Bin" is a display
 * label only, backed by an on-disk folder literally named RecycleBin.
 */
#define SIDEBAR_WIDTH 120
#define SIDEBAR_ROW_HEIGHT 22
#define SIDEBAR_ITEM_COUNT 5 /* Music, Pictures, Documents, Recycle Bin, My PC */
#define SIDEBAR_ITEM_MUSIC 0
#define SIDEBAR_ITEM_PICTURES 1
#define SIDEBAR_ITEM_DOCUMENTS 2
#define SIDEBAR_ITEM_RECYCLE_BIN 3
#define SIDEBAR_ITEM_MY_PC 4

static const char *sidebar_labels[SIDEBAR_ITEM_COUNT] = {
    "Music", "Pictures", "Documents", "Recycle Bin", "My PC"
};

/* Matches the existing /Users/User/Desktop convention desktop_ini.c
 * already established (see its DESKTOP_INI_PATH) -- Favorites' Music/
 * Pictures/Documents live alongside Desktop under that same /Users/User
 * tree rather than introducing a second, differently-named user folder. */
#define USERS_FOLDER_NAME "Users"
#define USER_FOLDER_NAME "User"
#define RECYCLE_BIN_FOLDER_NAME "RecycleBin"

typedef struct {
    struct directory dir;
    uint8_t dir_loaded;
    uint32_t path_stack[EXPLORER_MAX_DEPTH];
    char path_names[EXPLORER_MAX_DEPTH][32];
    int depth;
    int selected_index;
    int last_click_index;
    long long last_click_tick;
    uint8_t new_folder_prompt_open;
    char new_folder_name[EXPLORER_NAME_MAX];
    int new_folder_name_len;

    /* "My PC" is a distinct view, not a folder -- when set, the normal
     * dir listing is replaced by a disk-info panel (see draw_mypc_view)
     * and folder-list-only actions (Up, New Folder, double-click-to-
     * enter) are suppressed. Leaving My PC (clicking any other sidebar
     * item, or Up) clears it and resumes normal folder browsing. */
    uint8_t mypc_view;

    /* Generalized name prompt (New Folder / New Text Document / Rename):
     * the toolbar's text field is reused for all three. */
    uint8_t prompt_mode;       /* PROMPT_* below */
    char rename_old[48];       /* original name while renaming */
    uint8_t sort_mode;         /* SORT_* below */

    /* Drag and drop: set when the button goes down on a row; once the pointer
     * has moved far enough, the drag is handed to the desktop (dnd.h). */
    int drag_idx;
    int drag_x, drag_y;

    /* Change detection: other windows, the desktop and drag-and-drop all
     * modify folders, so a cheap hash of the listing is re-checked now and
     * then and the view reloads itself when it differs. */
    uint32_t dir_sig;
    uint32_t last_sig_check_ms;

    /* Another drive opened from My PC (ext2/3/4, ISO 9660, FAT12/16/32 -- see fsx.c). NULL = the system disk.
     * While one of this window's callbacks runs, master_fs is pointed at it (ex_enter / ex_leave), so all the
     * usual fsu_* / populate_dir calls just work on that drive. Such drives are read-only here. */
    f32 *fs;
} explorer_state_t;

#define PROMPT_NEW_FOLDER 1
#define PROMPT_NEW_TEXT   2
#define PROMPT_RENAME     3
#define SORT_NAME 0
#define SORT_SIZE 1
#define SORT_TYPE 2

static int explorer_entry_cmp(const struct dir_entry *a, const struct dir_entry *b, int mode) {
    int da = (a->dir_attrs & DIRECTORY) != 0, db = (b->dir_attrs & DIRECTORY) != 0;
    if(da != db) return db - da; /* folders always first */
    if(mode == SORT_SIZE && !da) {
        if(a->file_size != b->file_size) return a->file_size < b->file_size ? 1 : -1; /* largest first */
    }
    else if(mode == SORT_TYPE && !da) {
        const char *ea = fsu_ext(a->name), *eb = fsu_ext(b->name);
        int c = strcasecmp(ea, eb);
        if(c) return c;
    }
    return strcasecmp(a->name, b->name);
}

static void explorer_sort_entries(explorer_state_t *st) {
    struct directory *d = &st->dir;
    /* ".." / "." sink to the top naturally (folders, names sort before letters). */
    for(uint32_t i = 1; i < d->num_entries; i++) {
        struct dir_entry key = d->entries[i];
        if(!key.name) continue;
        int j = (int)i - 1;
        while(j >= 0 && d->entries[j].name && explorer_entry_cmp(&d->entries[j], &key, st->sort_mode) > 0) {
            d->entries[j + 1] = d->entries[j];
            j--;
        }
        d->entries[j + 1] = key;
    }
}

static uint32_t explorer_listing_signature(struct directory *d) {
    uint32_t sig = 2166136261u;
    for(uint32_t i = 0; i < d->num_entries; i++) {
        struct dir_entry *e = &d->entries[i];
        if(!e->name || (e->dir_attrs & LFN)) continue;
        for(const char *c = e->name; *c; c++) { sig ^= (uint8_t)*c; sig *= 16777619u; }
        sig ^= e->file_size; sig *= 16777619u;
        sig ^= (e->dir_attrs & DIRECTORY) ? 7u : 3u; sig *= 16777619u;
    }
    return sig;
}

static void mypc_refresh(void);

/* ---- other drives: master_fs is swapped for the duration of a window callback ---- */
static f32 *scope_saved = NULL;
static int scope_active = 0;

static void ex_enter(window_t *w) {
    explorer_state_t *st = w ? (explorer_state_t *)w->user_data : NULL;
    if(st && st->fs && !scope_active) { scope_saved = master_fs; master_fs = st->fs; scope_active = 1; }
}
static void ex_leave(void) {
    if(scope_active) { master_fs = scope_saved; scope_active = 0; }
}

/* Back to the system disk: drops the other drive (must be called with the scope active or not). */
static void explorer_leave_volume(explorer_state_t *st) {
    if(!st->fs) return;
    if(scope_active) { master_fs = scope_saved; scope_active = 0; }
    if(st->dir_loaded) { free_directory(st->fs, &st->dir); st->dir_loaded = 0; }
    destroyFilesystem(st->fs);
    st->fs = NULL;
    st->depth = 0;
}

static void explorer_load_current(explorer_state_t *st) {
    if(st->dir_loaded) {
        free_directory(master_fs, &st->dir);
        st->dir_loaded = 0;
    }
    if(!master_fs) return;
    if(st->depth == 0) {
        populate_root_dir(master_fs, &st->dir);
    }
    else {
        populate_dir(master_fs, &st->dir, st->path_stack[st->depth - 1]);
    }
    st->dir_loaded = 1;
    st->selected_index = -1;
    st->dir_sig = explorer_listing_signature(&st->dir);
    explorer_sort_entries(st);
}

/* Per-frame: reload the listing if someone changed the folder. The user's
 * selection survives when the selected name is still there. */
static void explorer_tick_impl(window_t *self);
static void explorer_tick(window_t *self) { ex_enter(self); explorer_tick_impl(self); ex_leave(); }
static void explorer_tick_impl(window_t *self) {
    explorer_state_t *st = (explorer_state_t *)self->user_data;
    if(st) self->static_content = !st->prompt_mode;       /* a text prompt has a blinking caret */
    if(!st || !st->dir_loaded || st->mypc_view || st->prompt_mode || !master_fs) return;
    uint32_t now = pit_get_ms();
    if(now - st->last_sig_check_ms < 700) return;
    st->last_sig_check_ms = now;

    struct directory fresh;
    if(st->depth == 0) populate_root_dir(master_fs, &fresh);
    else populate_dir(master_fs, &fresh, st->path_stack[st->depth - 1]);
    uint32_t sig = explorer_listing_signature(&fresh);
    free_directory(master_fs, &fresh);
    if(sig == st->dir_sig) return;

    char keep[48]; keep[0] = '\0';
    if(st->selected_index >= 0 && st->selected_index < (int)st->dir.num_entries) {
        int n = 0; const char *nm = st->dir.entries[st->selected_index].name;
        while(nm && nm[n] && n < 47) { keep[n] = nm[n]; n++; }
        keep[n] = '\0';
    }
    explorer_load_current(st);
    if(keep[0]) {
        for(uint32_t i = 0; i < st->dir.num_entries; i++) {
            if(st->dir.entries[i].name && strcmp(st->dir.entries[i].name, keep) == 0) { st->selected_index = (int)i; break; }
        }
    }
}

/* Builds the "/" or "/Users/User/Desktop"-style absolute path string
 * for the given entry (which must belong to the currently-displayed
 * directory, st->dir) -- same approach as app_paint.c's
 * save_dir_build_path(), extended with the entry's own name as the
 * final component. Used only where an actual filesystem path string is
 * needed (running a .app, resolving a .lnk's target) -- normal
 * navigation still works off path_stack's cluster numbers, not this. */
static void explorer_build_entry_path(explorer_state_t *st, struct dir_entry *e, char *out, int out_max) {
    int pos = 0;
    out[pos++] = '/';
    for(int i = 0; i < st->depth && pos < out_max - 2; i++) {
        int j = 0;
        while(st->path_names[i][j] && pos < out_max - 2) out[pos++] = st->path_names[i][j++];
        out[pos++] = '/';
    }
    int j = 0;
    while(e->name[j] && pos < out_max - 1) out[pos++] = e->name[j++];
    out[pos] = '\0';
}

/* Returns a pointer to the last '.' in name, or NULL if there isn't one
 * -- common.h only provides strchr() (first occurrence), not strrchr(),
 * so this is a small local equivalent rather than pulling in a new
 * general-purpose libc-style function for the one place that needs it. */
static const char *last_dot(const char *name) {
    const char *result = NULL;
    for(const char *p = name; *p; p++) {
        if(*p == '.') result = p;
    }
    return result;
}

/* Handles double-clicking a non-directory entry: runs it directly if
 * it's a .app, or resolves and runs/opens its target if it's a .lnk
 * shortcut (see write_shortcut()/SHORTCUT_INI_SECTION below for the
 * .lnk format) -- anything else currently does nothing (no other file
 * type has an associated action; there's no generic "open with" concept
 * yet). */
/* Extensions opened in Notepad on double-click. */
static int is_text_ext(const char *ext) {
    static const char *list[] = { ".txt", ".log", ".md", ".ini", ".cfg", ".c", ".h", ".nasm", ".asm", ".json", ".xml", ".csv", ".bat", ".cmd", ".html", ".css", ".js", ".py" };
    for(unsigned i = 0; i < sizeof(list) / sizeof(list[0]); i++) if(strcasecmp(ext, list[i]) == 0) return 1;
    return 0;
}

/* Files on another drive are copied to /Users/User/Downloads first (programs only see the system disk). */
static int foreign_copy_to_downloads(explorer_state_t *st, struct dir_entry *e, char *dst, int dst_max) {
    uint8_t *data = readFile(st->fs, e);
    if(!data && e->file_size) { desktop_toast("Could not read that file"); return 0; }
    f32 *vol = master_fs;
    master_fs = scope_saved;                                  /* write to the system disk */
    fsu_mkdir("/Users"); fsu_mkdir("/Users/User"); fsu_mkdir("/Users/User/Downloads");
    int n = 0; const char *pre = "/Users/User/Downloads/";
    while(*pre && n < dst_max - 2) dst[n++] = *pre++;
    for(int i = 0; e->name[i] && n < dst_max - 1; i++) dst[n++] = e->name[i];
    dst[n] = 0;
    int ok = fsu_write_file(dst, data ? data : (uint8_t *)"", e->file_size);
    master_fs = vol;
    if(data) kfree(data);
    if(!ok) desktop_toast("Could not copy it to Downloads");
    return ok;
}

static void explorer_open_file_path(explorer_state_t *st, struct dir_entry *e, const char *path_in);

static void explorer_open_file(explorer_state_t *st, struct dir_entry *e) {
    char path[192];
    if(st->fs && scope_active) {
        if(!foreign_copy_to_downloads(st, e, path, sizeof(path))) return;
        desktop_toast("Copied to Downloads");
        f32 *vol = master_fs; master_fs = scope_saved;       /* the opened program reads the copy from the system disk */
        explorer_open_file_path(st, e, path);
        master_fs = vol;
        return;
    }
    explorer_build_entry_path(st, e, path, sizeof(path));
    explorer_open_file_path(st, e, path);
}

static void explorer_open_file_path(explorer_state_t *st, struct dir_entry *e, const char *path_in) {
    (void)st;
    const char *ext = last_dot(e->name);
    if(!ext) return;

    char path[192];
    int pi = 0; while(path_in[pi] && pi < 191) { path[pi] = path_in[pi]; pi++; } path[pi] = 0;

    if(strcasecmp(ext, ".app") == 0) {
        app_loader_run(path);
        return;
    }

    if(strcasecmp(ext, ".lnk") == 0) {
        shortcut_t sc;
        if(shortcut_load(path, &sc)) shortcut_open(&sc);
        return;
    }

    if(strcasecmp(ext, ".mp3") == 0 || strcasecmp(ext, ".wav") == 0) {
        launch_mediaplayer_with_file(path);
        return;
    }

    if(is_text_ext(ext)) {
        launch_notepad_with_file(path);
        return;
    }

    if(strcasecmp(ext, ".lnk") == 0) {
        FILE *f = fopen(path, NULL);
        if(!f) return;

        uint32_t capacity = 4096;
        uint8_t *buffer = (uint8_t *)kmalloc(capacity);
        uint32_t total = 0;
        size_t chunk;
        while((chunk = fread(buffer + total, 1, capacity - total, f)) > 0) {
            total += chunk;
            if(total >= capacity) break; /* a .lnk is always tiny -- this should never trip */
        }
        fclose(f);

        ini_document_t doc;
        ini_parse((const char *)buffer, total, &doc);
        kfree(buffer);

        const char *target = ini_get(&doc, "shortcut", "target");
        if(target) {
            /* Shortcuts to a .app run it; a shortcut to anything else
             * (a folder, a document) has no defined action yet -- there's
             * no "open with" dispatch beyond .app execution currently. */
            const char *target_ext = last_dot(target);
            if(target_ext && strcasecmp(target_ext, ".app") == 0) {
                app_loader_run(target);
            }
        }
        return;
    }
}

/* Writes a .lnk shortcut file at shortcut_dir (already-populated
 * directory listing) pointing at target_path. Mirrors desktop_ini.c's
 * INI-writing approach (see its append_str/append_int) rather than
 * pulling in a general sprintf-based INI writer for this one small use.
 */
#define SHORTCUT_INI_SECTION "shortcut"
__attribute__((unused)) static void write_shortcut(struct directory *shortcut_dir, const char *shortcut_name, const char *target_path) {
    char text[256];
    uint32_t pos = 0;

    const char *section_hdr = "[" SHORTCUT_INI_SECTION "]\ntarget=";
    for(const char *p = section_hdr; *p; p++) text[pos++] = *p;
    for(const char *p = target_path; *p && pos < sizeof(text) - 2; p++) text[pos++] = *p;
    text[pos++] = '\n';
    text[pos] = '\0';

    writeFile(master_fs, shortcut_dir, (uint8_t *)text, (char *)shortcut_name, pos);
}

static void explorer_enter(explorer_state_t *st, struct dir_entry *e) {
    if(st->depth >= EXPLORER_MAX_DEPTH) return;
    st->path_stack[st->depth] = e->first_cluster;
    int i = 0;
    while(e->name[i] && i < 31) { st->path_names[st->depth][i] = e->name[i]; i++; }
    st->path_names[st->depth][i] = '\0';
    st->depth++;
    explorer_load_current(st);
}

static void explorer_go_up(explorer_state_t *st) {
    if(st->fs && st->depth == 0) {              /* top of another drive: back to My PC */
        explorer_leave_volume(st);
        st->mypc_view = 1;
        mypc_refresh();
        return;
    }
    st->mypc_view = 0;
    if(st->depth == 0) return;
    st->depth--;
    explorer_load_current(st);
}

/* Finds a subdirectory named `name` (case-insensitive, matching how
 * FAT32 short names actually compare -- see strcasecmp()'s comment in
 * common.c) directly inside `dir`. Returns 1 and fills *out_cluster if
 * found, 0 otherwise. Does not recurse or create anything. */
static int find_subdir(struct directory *dir, const char *name, uint32_t *out_cluster) {
    for(uint32_t i = 0; i < dir->num_entries; i++) {
        struct dir_entry *e = &dir->entries[i];
        if(e->dir_attrs & LFN) continue;
        if(!(e->dir_attrs & DIRECTORY)) continue;
        if(strcasecmp(e->name, name) == 0) {
            *out_cluster = e->first_cluster;
            return 1;
        }
    }
    return 0;
}

/* Finds a subdirectory named `name` inside `dir`, creating it first if
 * it doesn't already exist. `dir` is re-populated by its own
 * dir->cluster afterward (populate_root_dir() is just
 * populate_dir(fs, dir, 2) under the hood -- see fat32.c -- so this
 * works identically for the root dir or any subdirectory) so the
 * returned cluster reflects the freshly-written entry. Idempotent --
 * safe to call on every Explorer launch. */
static uint32_t ensure_subdir(f32 *fs, struct directory *dir, const char *name) {
    uint32_t cluster;
    if(find_subdir(dir, name, &cluster)) {
        return cluster;
    }
    uint32_t parent_cluster = dir->cluster;
    mkdir(fs, dir, (char *)name);
    free_directory(fs, dir);
    populate_dir(fs, dir, parent_cluster);
    find_subdir(dir, name, &cluster);
    return cluster;
}

/* Idempotently creates (if missing) the well-known folders the
 * Favorites sidebar links to: /Users/User/Music, /Users/User/Pictures,
 * /Users/User/Documents (alongside /Users/User/Desktop, which
 * desktop_ini.c's ensure_desktop_path() already creates independently),
 * and /RecycleBin. Safe to call every time Explorer launches --
 * ensure_subdir() only creates what's actually missing. */
static void favorites_ensure_folders(f32 *fs) {
    if(!fs) return;

    struct directory root;
    populate_root_dir(fs, &root);
    uint32_t users_cluster = ensure_subdir(fs, &root, USERS_FOLDER_NAME);
    free_directory(fs, &root);

    struct directory users_dir;
    populate_dir(fs, &users_dir, users_cluster);
    uint32_t user_cluster = ensure_subdir(fs, &users_dir, USER_FOLDER_NAME);
    free_directory(fs, &users_dir);

    struct directory user_dir;
    populate_dir(fs, &user_dir, user_cluster);
    ensure_subdir(fs, &user_dir, "Music");
    free_directory(fs, &user_dir);

    populate_dir(fs, &user_dir, user_cluster);
    ensure_subdir(fs, &user_dir, "Pictures");
    free_directory(fs, &user_dir);

    populate_dir(fs, &user_dir, user_cluster);
    ensure_subdir(fs, &user_dir, "Documents");
    free_directory(fs, &user_dir);

    populate_root_dir(fs, &root);
    ensure_subdir(fs, &root, RECYCLE_BIN_FOLDER_NAME);
    free_directory(fs, &root);
}

/* Navigates directly to /Users/User/<subname> from anywhere, rebuilding
 * the path_stack/path_names/depth from the root rather than assuming
 * anything about where the view currently is -- Favorites clicks can
 * happen from any depth, unlike Up/double-click which only ever move
 * one level at a time from wherever the user already is. */
static void explorer_go_to_user_subfolder(explorer_state_t *st, const char *subname) {
    if(!master_fs) return;
    st->mypc_view = 0;

    struct directory root;
    populate_root_dir(master_fs, &root);
    uint32_t users_cluster;
    if(!find_subdir(&root, USERS_FOLDER_NAME, &users_cluster)) {
        /* Shouldn't happen (favorites_ensure_folders runs at launch),
         * but fail safe to the root rather than crash on a bad index. */
        free_directory(master_fs, &root);
        st->depth = 0;
        explorer_load_current(st);
        return;
    }

    struct directory users_dir;
    populate_dir(master_fs, &users_dir, users_cluster);
    uint32_t user_cluster;
    int found_user = find_subdir(&users_dir, USER_FOLDER_NAME, &user_cluster);
    free_directory(master_fs, &users_dir);
    free_directory(master_fs, &root);
    if(!found_user) {
        st->depth = 0;
        explorer_load_current(st);
        return;
    }

    struct directory user_dir;
    populate_dir(master_fs, &user_dir, user_cluster);
    uint32_t sub_cluster;
    int found = find_subdir(&user_dir, subname, &sub_cluster);
    free_directory(master_fs, &user_dir);
    if(!found) return;

    st->depth = 0;
    st->path_stack[st->depth] = users_cluster;
    fastcp(st->path_names[st->depth], USERS_FOLDER_NAME, sizeof(USERS_FOLDER_NAME));
    st->depth++;
    st->path_stack[st->depth] = user_cluster;
    fastcp(st->path_names[st->depth], USER_FOLDER_NAME, sizeof(USER_FOLDER_NAME));
    st->depth++;
    st->path_stack[st->depth] = sub_cluster;
    /* path_names[] cells are char[32] -- copy strlen(subname)+1 bytes
     * (capped to that size) rather than a fixed count, since fastcp()
     * is a raw byte copy with no bounds-checking or null-termination of
     * its own (see its definition in common_asm.s) and subname here is
     * always one of the short "Music"/"Pictures"/"Documents" literals,
     * not a fixed-size buffer. */
    uint32_t sub_len = (uint32_t)strlen(subname) + 1;
    if(sub_len > 32) sub_len = 32;
    fastcp(st->path_names[st->depth], (char *)subname, sub_len);
    st->depth++;
    explorer_load_current(st);
}

static void explorer_go_to_recycle_bin(explorer_state_t *st) {
    if(!master_fs) return;
    st->mypc_view = 0;

    struct directory root;
    populate_root_dir(master_fs, &root);
    uint32_t cluster;
    int found = find_subdir(&root, RECYCLE_BIN_FOLDER_NAME, &cluster);
    free_directory(master_fs, &root);
    if(!found) return;

    st->depth = 0;
    st->path_stack[st->depth] = cluster;
    /* Display label differs from the on-disk name -- see the sidebar
     * comment above SIDEBAR_WIDTH for why RecycleBin has no space
     * on-disk. */
    fastcp(st->path_names[st->depth], "Recycle Bin", 12);
    st->depth++;
    explorer_load_current(st);
}

/* ---- path helpers ---- */
static void explorer_current_path(explorer_state_t *st, char *out, int max) {
    int pos = 0;
    out[pos++] = '/';
    for(int i = 0; i < st->depth && pos < max - 2; i++) {
        const char *n = st->path_names[i];
        /* "Recycle Bin" is only a display label -- the folder on disk is "RecycleBin". */
        if(i == 0 && strcasecmp(n, "Recycle Bin") == 0) n = RECYCLE_BIN_FOLDER_NAME;
        int j = 0;
        while(n[j] && pos < max - 2) out[pos++] = n[j++];
        if(i < st->depth - 1) out[pos++] = '/';
    }
    out[pos] = '\0';
}

static void explorer_entry_path(explorer_state_t *st, struct dir_entry *e, char *out, int max) {
    explorer_current_path(st, out, max);
    int n = (int)strlen(out);
    if(n > 1 && n < max - 1) out[n++] = '/';
    for(int j = 0; e->name[j] && n < max - 1; j++) out[n++] = e->name[j];
    out[n] = '\0';
}

static int explorer_in_recycle_bin(explorer_state_t *st) {
    return st->depth >= 1 && strcasecmp(st->path_names[0], "Recycle Bin") == 0;
}

static int entry_is_real(struct dir_entry *e) {
    return e->name && !(e->dir_attrs & LFN) && strcmp(e->name, ".") != 0 && strcmp(e->name, "..") != 0;
}

/* Builds "<base> - Copy<ext>" style unique name inside dir_path. */
static void make_unique_name(const char *dir_path, const char *name, char *out, int max) {
    char path[FSU_PATH_MAX];
    int n = 0;
    for(const char *c = dir_path; *c && n < FSU_PATH_MAX - 2; c++) path[n++] = *c;
    if(n > 1) path[n++] = '/';
    path[n] = '\0';
    char full[FSU_PATH_MAX];
    int k = 0; for(const char *c = path; *c; c++) full[k++] = *c;
    for(const char *c = name; *c && k < FSU_PATH_MAX - 1; c++) full[k++] = *c;
    full[k] = '\0';

    int is_dir;
    if(!fsu_stat(full, &is_dir, NULL, NULL, NULL)) { int i = 0; while(name[i] && i < max - 1) { out[i] = name[i]; i++; } out[i] = '\0'; return; }

    const char *ext = fsu_ext(name);
    int base_len = (int)(ext - name); if(*ext == '\0') base_len = (int)strlen(name);
    for(int attempt = 1; attempt < 50; attempt++) {
        char cand[64]; int p = 0;
        for(int i = 0; i < base_len && p < 40; i++) cand[p++] = name[i];
        const char *suffix = " - Copy"; for(const char *c = suffix; *c; c++) cand[p++] = *c;
        if(attempt > 1) { cand[p++] = ' '; if(attempt >= 10) cand[p++] = (char)('0' + attempt / 10); cand[p++] = (char)('0' + attempt % 10); }
        for(const char *c = ext; *c && p < 62; c++) cand[p++] = *c;
        cand[p] = '\0';
        k = (int)strlen(path); for(int i = 0; i <= k; i++) full[i] = path[i];
        for(const char *c = cand; *c && k < FSU_PATH_MAX - 1; c++) full[k++] = *c;
        full[k] = '\0';
        if(!fsu_stat(full, &is_dir, NULL, NULL, NULL)) { int i = 0; while(cand[i] && i < max - 1) { out[i] = cand[i]; i++; } out[i] = '\0'; return; }
    }
    int i = 0; while(name[i] && i < max - 1) { out[i] = name[i]; i++; } out[i] = '\0';
}

static void start_prompt(explorer_state_t *st, int mode, const char *initial) {
    st->new_folder_prompt_open = 1;
    st->prompt_mode = (uint8_t)mode;
    int n = 0;
    while(initial && initial[n] && n < EXPLORER_NAME_MAX - 1) { st->new_folder_name[n] = initial[n]; n++; }
    st->new_folder_name[n] = '\0';
    st->new_folder_name_len = n;
}

static void start_new_folder_prompt(explorer_state_t *st) {
    char dir[FSU_PATH_MAX]; explorer_current_path(st, dir, sizeof(dir));
    char name[48]; make_unique_name(dir, "New Folder", name, sizeof(name));
    start_prompt(st, PROMPT_NEW_FOLDER, name);
}

static void start_new_text_prompt(explorer_state_t *st) {
    char dir[FSU_PATH_MAX]; explorer_current_path(st, dir, sizeof(dir));
    char name[48]; make_unique_name(dir, "New Text Document.txt", name, sizeof(name));
    start_prompt(st, PROMPT_NEW_TEXT, name);
}

static void commit_new_folder(explorer_state_t *st) {
    /* Name of the prompt kept for compatibility with older call sites --
     * handles all three prompt modes now. */
    st->new_folder_prompt_open = 0;
    if(st->new_folder_name_len <= 0 || !st->dir_loaded) return;

    char dir[FSU_PATH_MAX]; explorer_current_path(st, dir, sizeof(dir));
    char path[FSU_PATH_MAX]; int n = (int)strlen(dir);
    for(int i = 0; i < n; i++) path[i] = dir[i];
    if(n > 1) path[n++] = '/';
    for(int i = 0; st->new_folder_name[i] && n < FSU_PATH_MAX - 1; i++) path[n++] = st->new_folder_name[i];
    path[n] = '\0';

    if(st->prompt_mode == PROMPT_NEW_FOLDER) {
        fsu_mkdir(path);
    }
    else if(st->prompt_mode == PROMPT_NEW_TEXT) {
        if(!fsu_stat(path, NULL, NULL, NULL, NULL)) fsu_write_file(path, (const uint8_t *)"", 0);
    }
    else if(st->prompt_mode == PROMPT_RENAME) {
        char old[FSU_PATH_MAX]; n = (int)strlen(dir);
        for(int i = 0; i < n; i++) old[i] = dir[i];
        if(n > 1) old[n++] = '/';
        for(int i = 0; st->rename_old[i] && n < FSU_PATH_MAX - 1; i++) old[n++] = st->rename_old[i];
        old[n] = '\0';
        if(strcmp(st->rename_old, st->new_folder_name) != 0 && !fsu_stat(path, NULL, NULL, NULL, NULL)) {
            int is_dir = 0;
            fsu_stat(old, &is_dir, NULL, NULL, NULL);
            if(is_dir) { if(fsu_copy_tree(old, path)) fsu_remove_dir(old, 1); }
            else fsu_move_file(old, path);
        }
    }
    st->prompt_mode = 0;
    explorer_load_current(st);
}

static void draw_toolbar(explorer_state_t *st, int cx, int cy, int cw) {
    gfx_fill_rect(cx, cy, cw, EXPLORER_TOOLBAR_HEIGHT, EX_PANEL);
    gfx_hline(cx, cy + EXPLORER_TOOLBAR_HEIGHT - 1, cw, 0xFF303036);

    int by = cy + 4, bh = EXPLORER_TOOLBAR_HEIGHT - 8;
    gfx_fill_rounded_rect(cx + 4, by, 40, bh, 6, st->depth > 0 ? EX_BTN : 0xFF26262B);
    gfx_draw_string(cx + 4 + (40 - 2 * GFX_CHAR_COLS) / 2, by + (bh - GFX_CHAR_ROWS) / 2, "Up", st->depth > 0 ? EX_TEXT : 0xFF6C6C76);

    int nf_x = cx + 48;
    gfx_fill_rounded_rect(nf_x, by, 88, bh, 6, EX_ACCENT);
    gfx_draw_string(nf_x + (88 - 10 * GFX_CHAR_COLS) / 2, by + (bh - GFX_CHAR_ROWS) / 2, "New Folder", 0xFF0E1620);

    int path_x = nf_x + 88 + 8;

    if(st->new_folder_prompt_open) {
        char field_text[EXPLORER_NAME_MAX + 2];
        int fp = 0;
        for(int i = 0; i < st->new_folder_name_len; i++) field_text[fp++] = st->new_folder_name[i];
        field_text[fp++] = '_';
        field_text[fp] = '\0';

        gfx_fill_rounded_rect(path_x, cy + 4, cw - (path_x - cx) - 4, EXPLORER_TOOLBAR_HEIGHT - 8, 6, EX_CARD);
        const char *label = st->prompt_mode == PROMPT_RENAME ? "Rename: " : st->prompt_mode == PROMPT_NEW_TEXT ? "New file: " : "New folder: ";
        gfx_draw_string(path_x + 8, cy + 8, label, EX_DIM);
        gfx_draw_string(path_x + 8 + (int)strlen(label) * GFX_CHAR_COLS, cy + 8, field_text, EX_TEXT);
        return;
    }

    char path[160];
    int pos = 0;
    path[pos++] = '/';
    for(int i = 0; i < st->depth; i++) {
        int j = 0;
        while(st->path_names[i][j] && pos < (int)sizeof(path) - 2) {
            path[pos++] = st->path_names[i][j++];
        }
        if(i < st->depth - 1) path[pos++] = '/';
    }
    path[pos] = '\0';

    gfx_fill_rounded_rect(path_x, cy + 4, cw - (path_x - cx) - 4, EXPLORER_TOOLBAR_HEIGHT - 8, 6, EX_CARD);
    gfx_draw_string(path_x + 8, cy + 8, path, EX_TEXT);
}

/* Which sidebar item (if any) is highlighted as "current" -- Music/
 * Pictures/Documents highlight when the view's path exactly matches
 * /User/<that folder>, Recycle Bin when it's exactly /RecycleBin (by
 * display name, since that's what path_names[] holds for it -- see
 * explorer_go_to_recycle_bin), My PC when mypc_view is set. Anything
 * else (root, a folder reached by manual navigation rather than via
 * Favorites, subfolders of Music/etc.) highlights nothing, same as
 * Windows Explorer only highlighting an exact Favorites match. */
static int sidebar_current_item(explorer_state_t *st) {
    if(st->mypc_view) return SIDEBAR_ITEM_MY_PC;
    if(st->depth == 1 && strcasecmp(st->path_names[0], "Recycle Bin") == 0) return SIDEBAR_ITEM_RECYCLE_BIN;
    if(st->depth == 3 && strcasecmp(st->path_names[0], USERS_FOLDER_NAME) == 0
       && strcasecmp(st->path_names[1], USER_FOLDER_NAME) == 0) {
        if(strcasecmp(st->path_names[2], "Music") == 0) return SIDEBAR_ITEM_MUSIC;
        if(strcasecmp(st->path_names[2], "Pictures") == 0) return SIDEBAR_ITEM_PICTURES;
        if(strcasecmp(st->path_names[2], "Documents") == 0) return SIDEBAR_ITEM_DOCUMENTS;
    }
    return -1;
}

static void draw_sidebar(explorer_state_t *st, int cx, int cy, int ch) {
    gfx_fill_rect(cx, cy, SIDEBAR_WIDTH, ch, EX_PANEL);
    gfx_draw_string(cx + 12, cy + 6, "Favorites", EX_DIM);

    int current = sidebar_current_item(st);
    int list_y = cy + 22;
    const int icon_size = 16;
    for(int i = 0; i < SIDEBAR_ITEM_COUNT; i++) {
        int row_y = list_y + i * SIDEBAR_ROW_HEIGHT;
        if(i == current) gfx_blend_rounded_rect(cx + 4, row_y, SIDEBAR_WIDTH - 8, SIDEBAR_ROW_HEIGHT - 2, 6, EX_SEL);

        const uint32_t *px = NULL; int iw = 0, ih = 0;
        if(i == SIDEBAR_ITEM_MY_PC || i == SIDEBAR_ITEM_RECYCLE_BIN) {
            png_image_t *icon = system_icon_get(i == SIDEBAR_ITEM_MY_PC ? SYSTEM_ICON_MYPC : SYSTEM_ICON_RECYCLE_BIN);
            if(icon) { px = icon->pixels; iw = icon->width; ih = icon->height; }
        }
        else {
            const char *probe = i == SIDEBAR_ITEM_MUSIC ? "x.mp3" : i == SIDEBAR_ITEM_PICTURES ? "x.png" : "x.txt";
            ditem_image_t im = ditems_icon_for_path(probe, 0);
            px = im.pixels; iw = im.w; ih = im.h;
        }
        if(px) gfx_blit_scaled_argb_alpha(cx + 12, row_y + (SIDEBAR_ROW_HEIGHT - icon_size) / 2 - 1, icon_size, icon_size, px, iw, ih);
        gfx_draw_string(cx + 12 + icon_size + 6, row_y + (SIDEBAR_ROW_HEIGHT - GFX_CHAR_ROWS) / 2 - 1, sidebar_labels[i], EX_TEXT);
    }
}

/* ---- My PC: every volume the machine has ------------------------------ */
#define MYPC_CARD_W 280
#define MYPC_CARD_H 76
#define MYPC_GAP    10
#define MYPC_TOP    36

static uint32_t mypc_free_mb = 0, mypc_total_mb = 0;

/* Called whenever My PC is entered: rescans the disks and measures the system volume once. */
static void mypc_refresh(void) {
    volumes_scan();
    mypc_total_mb = mypc_free_mb = 0;
    if(!master_fs) return;
    const struct bios_parameter_block *bpb = getBPB(master_fs);
    uint32_t total_sectors = bpb->large_sectors_on_media ? bpb->large_sectors_on_media : bpb->total_sectors;
    uint64_t total_bytes = (uint64_t)total_sectors * bpb->bytes_per_sector;
    uint64_t cluster_bytes = (uint64_t)bpb->sectors_per_cluster * bpb->bytes_per_sector;
    uint64_t free_bytes = (uint64_t)count_free_clusters(master_fs) * cluster_bytes;
    mypc_total_mb = (uint32_t)(total_bytes >> 20);     /* shifts: no libgcc 64-bit division in this build */
    mypc_free_mb = (uint32_t)(free_bytes >> 20);
}

static int mypc_cols(int cw) { int c = (cw - MYPC_GAP) / (MYPC_CARD_W + MYPC_GAP); return c < 1 ? 1 : c; }

static void mypc_card_pos(int i, int cw, int *x, int *y) {
    int cols = mypc_cols(cw);
    *x = MYPC_GAP + (i % cols) * (MYPC_CARD_W + MYPC_GAP);
    *y = MYPC_TOP + (i / cols) * (MYPC_CARD_H + MYPC_GAP);
}

static void fmt_size_mb(uint32_t mb, char *out) {
    if(mb >= 1024) sprintf(out, "%d.%d GB", mb >> 10, ((mb & 1023) * 10) >> 10);
    else sprintf(out, "%d MB", mb);
}

static void draw_mypc_view(int cx, int cy, int cw, int ch) {
    (void)ch;
    gfx_fill_rect(cx, cy, cw, ch, EX_BG);
    gfx_draw_string(cx + 12, cy + 10, "My PC", EX_TEXT);

    int n = volumes_count();
    if(n == 0) { gfx_draw_string(cx + 12, cy + MYPC_TOP, "No drives found.", EX_DIM); return; }

    int disk_no = 0, letter = 'C';
    for(int i = 0; i < n; i++) {
        const volume_t *v = volumes_get(i);
        int x, y; mypc_card_pos(i, cw, &x, &y);
        x += cx; y += cy;
        gfx_fill_rounded_rect(x, y, MYPC_CARD_W, MYPC_CARD_H, 8, EX_CARD);
        if(v->is_system) gfx_blend_rounded_rect(x, y, MYPC_CARD_W, MYPC_CARD_H, 8, 0x204CC2FF);

        /* drive glyph: optical = disc, otherwise a drive body with a status light */
        int gx = x + 12, gy = y + 14;
        if(v->optical) {
            gfx_fill_rounded_rect(gx, gy, 40, 40, 20, 0xFFC8CCD6);
            gfx_fill_rounded_rect(gx + 15, gy + 15, 10, 10, 5, EX_CARD);
        } else {
            png_image_t *ic = system_icon_get(SYSTEM_ICON_MYPC);
            if(ic) gfx_blit_scaled_argb_alpha(gx, gy, 40, 40, ic->pixels, ic->width, ic->height);
        }

        char name[48];
        if(v->is_system) sprintf(name, "Local Disk (%c:) - MyOS", letter);
        else if(v->optical) sprintf(name, "CD/DVD Drive");
        else sprintf(name, "Disk %d, partition %d", disk_no, v->part_no ? v->part_no : 1);
        if(!v->optical && v->dev >= 0 && v->part_no <= 1) disk_no++;
        if(!v->optical && (v->fs == FS_FAT12 || v->fs == FS_FAT16 || v->fs == FS_FAT32 || v->fs == FS_NTFS || v->fs == FS_EXFAT) && letter < 'Z') letter++;
        gfx_draw_string(x + 62, y + 8, name, EX_TEXT);

        char line[64], sz[24];
        uint32_t tmb = v->is_system && mypc_total_mb ? mypc_total_mb : (uint32_t)(v->sectors >> 11);
        fmt_size_mb(tmb, sz);
        if(v->fs == FS_EMPTY) sprintf(line, "No disc inserted");
        else if(v->label[0]) sprintf(line, "%s  %s  \"%s\"", volumes_fs_name(v->fs), sz, v->label);
        else sprintf(line, "%s  %s", volumes_fs_name(v->fs), sz);
        gfx_draw_string(x + 62, y + 28, line, EX_DIM);

        int bx = x + 62, by = y + 46, bw = MYPC_CARD_W - 74;
        if(v->is_system && mypc_total_mb) {
            uint32_t used = mypc_total_mb > mypc_free_mb ? mypc_total_mb - mypc_free_mb : 0;
            gfx_fill_rounded_rect(bx, by, bw, 8, 4, 0xFF3A3A42);
            int fw = (int)((uint32_t)bw * used / mypc_total_mb);
            if(fw < 8 && used) fw = 8;
            if(fw > 0) gfx_fill_rounded_rect(bx, by, fw, 8, 4, EX_ACCENT);
            char fr[40], fs2[24]; fmt_size_mb(mypc_free_mb, fs2); sprintf(fr, "%s free", fs2);
            gfx_draw_string(bx, y + 56, fr, EX_DIM);
        }
        else if(!fsx_supported(v->fs) && v->fs != FS_EMPTY) {
            gfx_draw_string(bx, by - 4, "Not readable yet", 0xFF6C6C76);
        }
        else if(!v->is_system && fsx_supported(v->fs)) {
            gfx_draw_string(bx, by - 4, "Click to open (read-only)", 0xFF7FD6A4);
        }
    }
}

static void explorer_paint_impl(window_t *self, int cx, int cy, int cw, int ch);
static void explorer_paint(window_t *self, int cx, int cy, int cw, int ch) { ex_enter(self); explorer_paint_impl(self, cx, cy, cw, ch); ex_leave(); }
static void explorer_paint_impl(window_t *self, int cx, int cy, int cw, int ch) {
    explorer_state_t *st = (explorer_state_t *)self->user_data;
    if(!st) return;

    gfx_fill_rect(cx, cy, self->w, ch, EX_BG);
    draw_sidebar(st, cx, cy, ch);

    int content_x = cx + SIDEBAR_WIDTH;
    int content_w = cw - SIDEBAR_WIDTH;

    if(st->mypc_view) {
        draw_mypc_view(content_x, cy, content_w, ch);
        return;
    }

    draw_toolbar(st, content_x, cy, content_w);

    int list_y = cy + EXPLORER_TOOLBAR_HEIGHT;

    if(!st->dir_loaded) {
        gfx_draw_string(content_x + 8, list_y + 8, "No filesystem mounted.", EX_DIM);
        return;
    }

    if(st->dir.num_entries == 0) {
        gfx_draw_string(content_x + 8, list_y + 8, "(empty folder)", EX_DIM);
        return;
    }

    int row = 0;
    for(uint32_t i = 0; i < st->dir.num_entries; i++) {
        struct dir_entry *e = &st->dir.entries[i];
        if(!e->name) continue;
        if(e->dir_attrs & LFN) continue;

        int row_y = list_y + row * EXPLORER_ROW_HEIGHT;
        if(row_y > cy + ch) break;

        if((int)i == st->selected_index) gfx_blend_rounded_rect(content_x + 4, row_y + 1, content_w - 8, EXPLORER_ROW_HEIGHT - 2, 6, EX_SEL);

        int is_dir = (e->dir_attrs & DIRECTORY) != 0;
        ditem_image_t im = ditems_icon_for_path(e->name, is_dir);
        if(im.pixels) gfx_blit_scaled_argb_alpha(content_x + 10, row_y + 3, 18, 18, im.pixels, im.w, im.h);
        gfx_draw_string(content_x + 36, row_y + (EXPLORER_ROW_HEIGHT - GFX_CHAR_ROWS) / 2, e->name, EX_TEXT);
        if(!is_dir && content_w > 260) {
            char sz[20]; fsu_format_size(e->file_size, sz, sizeof(sz));
            gfx_draw_string(content_x + content_w - 14 - (int)strlen(sz) * GFX_CHAR_COLS, row_y + (EXPLORER_ROW_HEIGHT - GFX_CHAR_ROWS) / 2, sz, EX_DIM);
        }

        row++;
    }
}

static int explorer_row_at(explorer_state_t *st, int rel_x, int rel_y) {
    (void)rel_x;
    if(rel_y < EXPLORER_TOOLBAR_HEIGHT) return -2;

    int row = 0;
    int target_row = (rel_y - EXPLORER_TOOLBAR_HEIGHT) / EXPLORER_ROW_HEIGHT;

    for(uint32_t i = 0; i < st->dir.num_entries; i++) {
        struct dir_entry *e = &st->dir.entries[i];
        if(!e->name) continue;
        if(e->dir_attrs & LFN) continue;

        if(row == target_row) return (int)i;
        row++;
    }

    return -1;
}

/* Handles a click at sidebar-relative coordinates (i.e. rel_x already
 * within [0, SIDEBAR_WIDTH)). Returns 1 if the click landed on a
 * sidebar row (whether or not that row did anything), 0 if it missed
 * the row list entirely (e.g. the "Favorites" header) -- the caller
 * doesn't currently need the distinction, but it mirrors
 * explorer_row_at()'s "-1 vs -2" pattern for clarity. */
static int handle_sidebar_click(explorer_state_t *st, int rel_x, int rel_y) {
    (void)rel_x;
    int list_y = 22;
    if(rel_y < list_y) return 0;

    int idx = (rel_y - list_y) / SIDEBAR_ROW_HEIGHT;
    if(idx < 0 || idx >= SIDEBAR_ITEM_COUNT) return 0;

    switch(idx) {
        case SIDEBAR_ITEM_MUSIC: explorer_go_to_user_subfolder(st, "Music"); break;
        case SIDEBAR_ITEM_PICTURES: explorer_go_to_user_subfolder(st, "Pictures"); break;
        case SIDEBAR_ITEM_DOCUMENTS: explorer_go_to_user_subfolder(st, "Documents"); break;
        case SIDEBAR_ITEM_RECYCLE_BIN: explorer_go_to_recycle_bin(st); break;
        case SIDEBAR_ITEM_MY_PC: st->mypc_view = 1; mypc_refresh(); break;
    }
    return 1;
}

static void explorer_click_impl(window_t *self, int rel_x, int rel_y);
static void explorer_click(window_t *self, int rel_x, int rel_y) { ex_enter(self); explorer_click_impl(self, rel_x, rel_y); ex_leave(); }
static void explorer_click_impl(window_t *self, int rel_x, int rel_y) {
    explorer_state_t *st = (explorer_state_t *)self->user_data;
    if(!st || !st->dir_loaded) return;
    int orig_x = rel_x, orig_y = rel_y;
    st->drag_idx = -1;

    if(rel_x < SIDEBAR_WIDTH) {
        explorer_leave_volume(st);               /* any sidebar place is on the system disk */
        handle_sidebar_click(st, rel_x, rel_y);
        return;
    }
    rel_x -= SIDEBAR_WIDTH;

    if(st->mypc_view) {
        /* Clicking the system drive opens its root; other volumes are listed only. */
        int cw = self->w - SIDEBAR_WIDTH;
        for(int i = 0; i < volumes_count(); i++) {
            int x, y; mypc_card_pos(i, cw, &x, &y);
            if(rel_x >= x && rel_x < x + MYPC_CARD_W && rel_y >= y && rel_y < y + MYPC_CARD_H) {
                const volume_t *v = volumes_get(i);
                if(!v) return;
                if(v->is_system) { explorer_leave_volume(st); st->mypc_view = 0; st->depth = 0; explorer_load_current(st); return; }
                if(!fsx_supported(v->fs)) {
                    char msg[64]; sprintf(msg, "%s drives can't be read yet", volumes_fs_name(v->fs));
                    desktop_toast(v->fs == FS_EMPTY ? "No disc in the drive" : msg);
                    return;
                }
                f32 *fs = fsx_mount(v);
                if(!fs) { desktop_toast("Could not read this drive"); return; }
                explorer_leave_volume(st);
                st->fs = fs; ex_enter(self);                 /* also covers the load below */
                st->mypc_view = 0; st->depth = 0; st->selected_index = -1;
                explorer_load_current(st);
                return;
            }
        }
        return;
    }

    if(rel_y < EXPLORER_TOOLBAR_HEIGHT) {
        if(rel_x >= 4 && rel_x < 44) {
            explorer_go_up(st);
            return;
        }
        if(rel_x >= 48 && rel_x < 48 + 88) {
            if(st->fs) { desktop_toast("This drive is read-only"); return; }
            start_new_folder_prompt(st);
            return;
        }
        return;
    }

    if(st->new_folder_prompt_open) {
        commit_new_folder(st);
        return;
    }

    int idx = explorer_row_at(st, rel_x, rel_y);
    if(idx < 0) {
        st->selected_index = -1;
        return;
    }

    if(idx == st->last_click_index && (pit_get_ticks() - st->last_click_tick) < EXPLORER_DOUBLE_CLICK_TICK_WINDOW) {
        struct dir_entry *e = &st->dir.entries[idx];
        if(e->dir_attrs & DIRECTORY) {
            explorer_enter(st, e);
        }
        else {
            explorer_open_file(st, e);
        }
        st->last_click_index = -1;
        st->last_click_tick = -1000;
    }
    else {
        st->selected_index = idx;
        st->last_click_index = idx;
        st->last_click_tick = pit_get_ticks();
        if(entry_is_real(&st->dir.entries[idx])) {      /* may become a drag */
            st->drag_idx = idx; st->drag_x = orig_x; st->drag_y = orig_y;
        }
    }
}

/* The pointer moved with the button held: once it has travelled a few
 * pixels from where the row was pressed, start a drag-and-drop of that row. */
static void explorer_drag(window_t *self, int rel_x, int rel_y) {
    explorer_state_t *st = (explorer_state_t *)self->user_data;
    if(!st || st->fs || st->drag_idx < 0 || st->drag_idx >= (int)st->dir.num_entries) return;
    int dx = rel_x - st->drag_x, dy = rel_y - st->drag_y;
    if(dx < 0) dx = -dx;
    if(dy < 0) dy = -dy;
    if(dx + dy < 10) return;

    struct dir_entry *e = &st->dir.entries[st->drag_idx];
    st->drag_idx = -1;
    if(!entry_is_real(e)) return;
    char path[FSU_PATH_MAX];
    explorer_build_entry_path(st, e, path, sizeof(path));
    dnd_begin(path, e->name, (e->dir_attrs & DIRECTORY) != 0);
}

static void explorer_mouse_up_impl(window_t *self, int rel_x, int rel_y);
static void explorer_mouse_up(window_t *self, int rel_x, int rel_y) { ex_enter(self); explorer_mouse_up_impl(self, rel_x, rel_y); ex_leave(); }
static void explorer_mouse_up_impl(window_t *self, int rel_x, int rel_y) {
    (void)rel_x; (void)rel_y;
    explorer_state_t *st = (explorer_state_t *)self->user_data;
    if(st) st->drag_idx = -1;
}

/* Something was dropped on this window. Works out which folder it landed
 * on -- a folder row, a sidebar entry, or otherwise the folder being shown --
 * and moves the dragged item there (or into the Recycle Bin). */
static int explorer_drop(window_t *self, int rel_x, int rel_y, const char *src) {
    explorer_state_t *st = (explorer_state_t *)self->user_data;
    if(!st || !src) return 0;

    char dest[FSU_PATH_MAX];
    dest[0] = '\0';

    if(rel_x < SIDEBAR_WIDTH) {
        int idx = (rel_y - 22) / SIDEBAR_ROW_HEIGHT;
        if(rel_y < 22 || idx < 0 || idx >= SIDEBAR_ITEM_COUNT) return 0;
        switch(idx) {
            case SIDEBAR_ITEM_MUSIC: fileops_join("/Users/User", "Music", dest, sizeof(dest)); break;
            case SIDEBAR_ITEM_PICTURES: fileops_join("/Users/User", "Pictures", dest, sizeof(dest)); break;
            case SIDEBAR_ITEM_DOCUMENTS: fileops_join("/Users/User", "Documents", dest, sizeof(dest)); break;
            case SIDEBAR_ITEM_RECYCLE_BIN: fileops_join("/", "RecycleBin", dest, sizeof(dest)); break;
            default: return 0;                         /* My PC is a view, not a folder */
        }
    }
    else {
        if(st->mypc_view) return 0;
        int row = explorer_row_at(st, rel_x - SIDEBAR_WIDTH, rel_y);
        if(row >= 0 && row < (int)st->dir.num_entries && entry_is_real(&st->dir.entries[row]) &&
           (st->dir.entries[row].dir_attrs & DIRECTORY)) {
            explorer_build_entry_path(st, &st->dir.entries[row], dest, sizeof(dest));   /* dropped on a folder */
        }
        else {
            explorer_current_path(st, dest, sizeof(dest));
        }
    }

    int ok;
    if(fileops_is_inside(dest, RECYCLE_BIN_PATH)) ok = fileops_trash(src);
    else ok = fileops_move_into(src, dest, NULL, 0);
    if(!ok) { desktop_toast("Could not move that here"); return 0; }
    explorer_load_current(st);
    return 1;
}

/* Bundles the window and which row (if any) was under the cursor when
 * the user right-clicked, so the single void* user_data that
 * context_menu_open() threads through to an action function can carry
 * both -- a context menu action only gets that one pointer back. */
typedef struct {
    window_t *win;
    int row_index; /* index into st->dir.entries, or -1 for empty space */
} explorer_menu_ctx_t;

static explorer_menu_ctx_t explorer_menu_ctx;

static explorer_state_t *ctx_state(void *user_data, struct dir_entry **out_entry) {
    explorer_menu_ctx_t *ctx = (explorer_menu_ctx_t *)user_data;
    explorer_state_t *st = (explorer_state_t *)ctx->win->user_data;
    if(out_entry) {
        *out_entry = (st && ctx->row_index >= 0 && ctx->row_index < (int)st->dir.num_entries) ? &st->dir.entries[ctx->row_index] : NULL;
    }
    return st;
}

/* True if the entry has a recognized "openable" action. */
static int entry_is_openable(struct dir_entry *e) {
    if(e->dir_attrs & DIRECTORY) return 1;
    const char *ext = last_dot(e->name);
    if(!ext) return 0;
    return strcasecmp(ext, ".app") == 0 || strcasecmp(ext, ".lnk") == 0 || strcasecmp(ext, ".mp3") == 0 || strcasecmp(ext, ".wav") == 0 || is_text_ext(ext);
}

static int entry_is_audio(struct dir_entry *e) {
    const char *ext = last_dot(e->name);
    return ext && (strcasecmp(ext, ".mp3") == 0 || strcasecmp(ext, ".wav") == 0);
}

static void action_explorer_open(void *user_data) {
    struct dir_entry *e; explorer_state_t *st = ctx_state(user_data, &e);
    if(!st || !e) return;
    if(e->dir_attrs & DIRECTORY) explorer_enter(st, e); else explorer_open_file(st, e);
}

static void action_explorer_play(void *user_data) {
    struct dir_entry *e; explorer_state_t *st = ctx_state(user_data, &e);
    if(!st || !e) return;
    char path[FSU_PATH_MAX]; explorer_entry_path(st, e, path, sizeof(path));
    launch_mediaplayer_with_file(path);
}

static void action_explorer_notepad(void *user_data) {
    struct dir_entry *e; explorer_state_t *st = ctx_state(user_data, &e);
    if(!st || !e) return;
    char path[FSU_PATH_MAX]; explorer_entry_path(st, e, path, sizeof(path));
    launch_notepad_with_file(path);
}

static void action_explorer_open_cmd(void *user_data) {
    struct dir_entry *e; explorer_state_t *st = ctx_state(user_data, &e);
    if(!st) return;
    char path[FSU_PATH_MAX];
    if(e && (e->dir_attrs & DIRECTORY) && strcmp(e->name, ".") != 0 && strcmp(e->name, "..") != 0) explorer_entry_path(st, e, path, sizeof(path));
    else explorer_current_path(st, path, sizeof(path));
    launch_cmd_at(path);
}

static void do_clipboard_copy(void *user_data, int cut) {
    struct dir_entry *e; explorer_state_t *st = ctx_state(user_data, &e);
    if(!st || !e || !entry_is_real(e)) return;
    char path[FSU_PATH_MAX]; explorer_entry_path(st, e, path, sizeof(path));
    clipboard_set_file(path, cut);
}
static void action_explorer_copy(void *u) { do_clipboard_copy(u, 0); }
static void action_explorer_cut(void *u) { do_clipboard_copy(u, 1); }

static void explorer_paste_into_current(explorer_state_t *st) {
    if(!clipboard_has_file()) return;
    const char *src = clipboard_file_path();
    char parent[FSU_PATH_MAX], name[48];
    fsu_split(src, parent, sizeof(parent), name, sizeof(name));
    if(!name[0]) return;

    char dir[FSU_PATH_MAX]; explorer_current_path(st, dir, sizeof(dir));
    int cut = clipboard_file_is_cut();
    char dst_name[48];
    if(cut && strcasecmp(parent, dir) == 0) { clipboard_clear_file(); return; } /* moving into the same folder: nothing to do */
    make_unique_name(dir, name, dst_name, sizeof(dst_name));

    char dst[FSU_PATH_MAX]; int n = (int)strlen(dir);
    for(int i = 0; i < n; i++) dst[i] = dir[i];
    if(n > 1) dst[n++] = '/';
    for(int i = 0; dst_name[i] && n < FSU_PATH_MAX - 1; i++) dst[n++] = dst_name[i];
    dst[n] = '\0';

    int is_dir = 0;
    if(!fsu_stat(src, &is_dir, NULL, NULL, NULL)) { clipboard_clear_file(); return; }
    /* Refuse to copy a folder into itself. */
    int src_len = (int)strlen(src);
    if(is_dir && strncmp(dst, src, (size_t)src_len) == 0 && (dst[src_len] == '/' || dst[src_len] == '\0')) return;

    if(is_dir) {
        if(fsu_copy_tree(src, dst) && cut) fsu_remove_dir(src, 1);
    }
    else {
        if(fsu_copy_file(src, dst) && cut) fsu_delete_file(src);
    }
    if(cut) clipboard_clear_file();
    explorer_load_current(st);
}

static void action_explorer_paste(void *user_data) {
    explorer_state_t *st = ctx_state(user_data, NULL);
    if(st) { desktop_busy_begin(); explorer_paste_into_current(st); desktop_busy_end(); }
}

static void explorer_delete_entry(explorer_state_t *st, struct dir_entry *e) {
    if(!entry_is_real(e)) return;
    char path[FSU_PATH_MAX]; explorer_entry_path(st, e, path, sizeof(path));
    int is_dir = (e->dir_attrs & DIRECTORY) != 0;

    if(!explorer_in_recycle_bin(st)) {
        /* Move to the Recycle Bin (create it if it's gone). */
        int d;
        if(!fsu_stat("/" RECYCLE_BIN_FOLDER_NAME, &d, NULL, NULL, NULL)) fsu_mkdir("/" RECYCLE_BIN_FOLDER_NAME);
        char bin_name[48]; make_unique_name("/" RECYCLE_BIN_FOLDER_NAME, e->name, bin_name, sizeof(bin_name));
        char dst[FSU_PATH_MAX]; int n = 0;
        const char *b = "/" RECYCLE_BIN_FOLDER_NAME "/";
        for(const char *c = b; *c; c++) dst[n++] = *c;
        for(int i = 0; bin_name[i] && n < FSU_PATH_MAX - 1; i++) dst[n++] = bin_name[i];
        dst[n] = '\0';
        if(is_dir) { if(fsu_copy_tree(path, dst)) fsu_remove_dir(path, 1); }
        else fsu_move_file(path, dst);
    }
    else {
        if(is_dir) fsu_remove_dir(path, 1); else fsu_delete_file(path);
    }
    explorer_load_current(st);
}

static void action_explorer_delete(void *user_data) {
    struct dir_entry *e; explorer_state_t *st = ctx_state(user_data, &e);
    if(st && e) explorer_delete_entry(st, e);
}

static void action_explorer_rename(void *user_data) {
    struct dir_entry *e; explorer_state_t *st = ctx_state(user_data, &e);
    if(!st || !e || !entry_is_real(e)) return;
    int n = 0; while(e->name[n] && n < 47) { st->rename_old[n] = e->name[n]; n++; } st->rename_old[n] = '\0';
    start_prompt(st, PROMPT_RENAME, e->name);
}

static void action_explorer_empty_bin(void *user_data) {
    explorer_state_t *st = ctx_state(user_data, NULL);
    if(!st || !explorer_in_recycle_bin(st)) return;
    int count = (int)st->dir.num_entries;
    char (*names)[48] = (char (*)[48])kmalloc((uint32_t)(count ? count : 1) * 48);
    uint8_t *dirs = (uint8_t *)kmalloc((uint32_t)(count ? count : 1));
    int cnt = 0;
    for(int i = 0; i < count; i++) {
        struct dir_entry *e = &st->dir.entries[i];
        if(!entry_is_real(e)) continue;
        int k = 0; while(e->name[k] && k < 47) { names[cnt][k] = e->name[k]; k++; } names[cnt][k] = '\0';
        dirs[cnt] = (e->dir_attrs & DIRECTORY) ? 1 : 0; cnt++;
    }
    for(int i = 0; i < cnt; i++) {
        char p[FSU_PATH_MAX]; int n = 0; const char *b = "/" RECYCLE_BIN_FOLDER_NAME "/";
        for(const char *c = b; *c; c++) p[n++] = *c;
        for(int k = 0; names[i][k] && n < FSU_PATH_MAX - 1; k++) p[n++] = names[i][k];
        p[n] = '\0';
        if(dirs[i]) fsu_remove_dir(p, 1); else fsu_delete_file(p);
    }
    kfree(names); kfree(dirs);
    explorer_load_current(st);
}

static int entry_is_openable_app(struct dir_entry *e) {
    return !(e->dir_attrs & DIRECTORY) && last_dot(e->name) && strcasecmp(last_dot(e->name), ".app") == 0;
}

static void action_explorer_create_shortcut(void *user_data) {
    struct dir_entry *e; explorer_state_t *st = ctx_state(user_data, &e);
    if(!st || !e || !master_fs) return;
    char target[FSU_PATH_MAX], here[FSU_PATH_MAX];
    explorer_build_entry_path(st, e, target, sizeof(target));
    explorer_current_path(st, here, sizeof(here));
    shortcut_create_for_path(here, target, NULL, 0);
    explorer_load_current(st);
}

static void action_explorer_pin_start(void *user_data) {
    struct dir_entry *e; explorer_state_t *st = ctx_state(user_data, &e);
    if(!st || !e || !master_fs) return;
    char target[FSU_PATH_MAX], name[48];
    explorer_build_entry_path(st, e, target, sizeof(target));
    int n = 0;                                  /* display name = file name without the extension */
    for(const char *c = e->name; *c && n < 47; c++) name[n++] = *c;
    name[n] = '\0';
    const char *dot = last_dot(name);
    if(dot && dot != name && ((e->dir_attrs & DIRECTORY) == 0)) name[dot - name] = '\0';
    startmenu_pin(name, target);
}

static void action_explorer_send_desktop(void *user_data) {
    struct dir_entry *e; explorer_state_t *st = ctx_state(user_data, &e);
    if(!st || !e || !master_fs) return;
    char target[FSU_PATH_MAX];
    explorer_build_entry_path(st, e, target, sizeof(target));
    if(shortcut_create_for_path(DESKTOP_FOLDER_PATH, target, NULL, 0)) desktop_toast("Shortcut added to the desktop");
}

static void action_explorer_new_folder(void *user_data) {
    explorer_state_t *st = ctx_state(user_data, NULL);
    if(st) start_new_folder_prompt(st);
}
static void action_explorer_new_text(void *user_data) {
    explorer_state_t *st = ctx_state(user_data, NULL);
    if(st) start_new_text_prompt(st);
}
static void action_explorer_refresh(void *user_data) {
    explorer_state_t *st = ctx_state(user_data, NULL);
    if(st) explorer_load_current(st);
}
static void action_explorer_up(void *user_data) {
    explorer_state_t *st = ctx_state(user_data, NULL);
    if(st) explorer_go_up(st);
}
static void set_sort(void *user_data, int mode) {
    explorer_state_t *st = ctx_state(user_data, NULL);
    if(!st) return;
    st->sort_mode = (uint8_t)mode;
    explorer_load_current(st);
}
static void action_sort_name(void *u) { set_sort(u, SORT_NAME); }
static void action_sort_size(void *u) { set_sort(u, SORT_SIZE); }
static void action_sort_type(void *u) { set_sort(u, SORT_TYPE); }

/* ---- Properties window ---- */
typedef struct { char lines[8][96]; int count; } props_state_t;

static void props_paint(window_t *self, int cx, int cy, int cw, int ch) {
    props_state_t *ps = (props_state_t *)self->user_data;
    gfx_fill_rect(cx, cy, cw, ch, 0xFFF3F3F3);
    if(!ps) return;
    gfx_fill_rect(cx + 14, cy + 14, 44, 44, 0xFFFFFFFF);
    gfx_draw_rect(cx + 14, cy + 14, 44, 44, 0xFFB0B0B0);
    gfx_draw_string(cx + 28, cy + 28, ps->lines[0][0] == '\1' ? "D" : "F", 0xFF404040);
    gfx_draw_string(cx + 70, cy + 26, ps->lines[1], 0xFF000000);
    gfx_hline(cx + 14, cy + 70, cw - 28, 0xFFC8C8C8);
    for(int i = 2; i < ps->count; i++) gfx_draw_string(cx + 18, cy + 82 + (i - 2) * 22, ps->lines[i], 0xFF202020);
}
static void props_destroy(window_t *self) { if(self->user_data) { kfree(self->user_data); self->user_data = NULL; } }

static void props_add(props_state_t *ps, const char *label, const char *value) {
    if(ps->count >= 8) return;
    char *l = ps->lines[ps->count++]; int n = 0;
    for(const char *c = label; *c && n < 40; c++) l[n++] = *c;
    for(const char *c = value; *c && n < 94; c++) l[n++] = *c;
    l[n] = '\0';
}

static void show_properties(explorer_state_t *st, struct dir_entry *e) {
    props_state_t *ps = (props_state_t *)kmalloc(sizeof(props_state_t));
    if(!ps) return;
    memset(ps, 0, sizeof(*ps));

    char dir[FSU_PATH_MAX]; explorer_current_path(st, dir, sizeof(dir));
    const char *title_name; int is_dir; uint32_t size = 0; uint16_t wd = 0, wt = 0;
    char full[FSU_PATH_MAX];
    if(e && entry_is_real(e)) {
        title_name = e->name; is_dir = (e->dir_attrs & DIRECTORY) != 0; size = e->file_size; wd = e->wr_date; wt = e->wr_time;
        explorer_entry_path(st, e, full, sizeof(full));
    }
    else {
        char par[FSU_PATH_MAX], nm[48]; fsu_split(dir, par, sizeof(par), nm, sizeof(nm));
        title_name = nm[0] ? "Folder" : "Local Disk (C:)"; is_dir = 1;
        for(int i = 0; dir[i] || i == 0; i++) { full[i] = dir[i]; if(!dir[i]) break; }
        if(nm[0]) title_name = st->depth > 0 ? st->path_names[st->depth - 1] : "Folder";
    }

    ps->lines[0][0] = is_dir ? '\1' : '\2'; ps->lines[0][1] = '\0'; ps->count = 1;
    char tn[48]; int k = 0; while(title_name[k] && k < 40) { tn[k] = title_name[k]; k++; } tn[k] = '\0';
    { char *l = ps->lines[ps->count++]; int n = 0; for(const char *c = tn; *c && n < 94; c++) l[n++] = *c; l[n] = '\0'; }

    props_add(ps, "Type:      ", is_dir ? "File folder" : (last_dot(tn) ? last_dot(tn) + 1 : "File"));
    char loc[100]; int n = 0; for(const char *c = dir; *c && n < 80; c++) loc[n++] = *c; loc[n] = '\0';
    props_add(ps, "Location:  ", loc);
    if(!is_dir) {
        char a[24], b[24], v[60]; fsu_format_size(size, a, sizeof(a)); fsu_format_number(size, b, sizeof(b));
        int p = 0; for(char *c = a; *c; c++) v[p++] = *c; v[p++] = ' '; v[p++] = '('; for(char *c = b; *c; c++) v[p++] = *c; const char *by = " bytes)"; for(const char *c = by; *c; c++) v[p++] = *c; v[p] = '\0';
        props_add(ps, "Size:      ", v);
    }
    if(wd) {
        char v[40]; int y = 1980 + (wd >> 9), mo = (wd >> 5) & 15, da = wd & 31, h = wt >> 11, mi = (wt >> 5) & 63;
        int p = 0;
        v[p++] = (char)('0' + mo / 10); v[p++] = (char)('0' + mo % 10); v[p++] = '/'; v[p++] = (char)('0' + da / 10); v[p++] = (char)('0' + da % 10); v[p++] = '/';
        v[p++] = (char)('0' + y / 1000); v[p++] = (char)('0' + (y / 100) % 10); v[p++] = (char)('0' + (y / 10) % 10); v[p++] = (char)('0' + y % 10); v[p++] = ' ';
        v[p++] = (char)('0' + h / 10); v[p++] = (char)('0' + h % 10); v[p++] = ':'; v[p++] = (char)('0' + mi / 10); v[p++] = (char)('0' + mi % 10); v[p] = '\0';
        props_add(ps, "Modified:  ", v);
    }
    if(is_dir && e && entry_is_real(e)) {
        struct directory d;
        if(fsu_open_dir(full, &d)) {
            int files = 0, dirs = 0;
            for(uint32_t i = 0; i < d.num_entries; i++) { if(!entry_is_real(&d.entries[i])) continue; if(d.entries[i].dir_attrs & DIRECTORY) dirs++; else files++; }
            free_directory(master_fs, &d);
            char v[40]; int p = 0; char t[12];
            int vals[2] = { files, dirs }; const char *sep[2] = { " files, ", " folders" };
            for(int q = 0; q < 2; q++) { int x = vals[q], m = 0; if(!x) t[m++] = '0'; while(x) { t[m++] = (char)('0' + x % 10); x /= 10; } for(int r = m - 1; r >= 0; r--) v[p++] = t[r]; for(const char *c = sep[q]; *c; c++) v[p++] = *c; }
            v[p] = '\0';
            props_add(ps, "Contains:  ", v);
        }
    }
    if(!is_dir && !e) { }
    else if(!is_dir) { }

    window_t *w = wm_create_window("Properties", 330, 210, 380, 270, 0xFFF3F3F3);
    if(!w) { kfree(ps); return; }
    w->user_data = ps; w->on_paint = props_paint; w->on_destroy = props_destroy;
}

static void action_explorer_properties(void *user_data) {
    struct dir_entry *e; explorer_state_t *st = ctx_state(user_data, &e);
    if(st) show_properties(st, e);
}

static void action_foreign_copy(void *user_data) {
    struct dir_entry *e; explorer_state_t *st = ctx_state(user_data, &e);
    if(!st || !st->fs || !e) return;
    ex_enter(((explorer_menu_ctx_t *)user_data)->win);
    char dst[192];
    if(foreign_copy_to_downloads(st, e, dst, sizeof(dst))) desktop_toast("Copied to Downloads");
    ex_leave();
}
static void action_foreign_refresh(void *user_data) {
    explorer_state_t *st = ctx_state(user_data, NULL);
    if(!st || !st->fs) return;
    ex_enter(((explorer_menu_ctx_t *)user_data)->win);
    explorer_load_current(st);
    ex_leave();
}

static void explorer_right_click_impl(window_t *self, int rel_x, int rel_y);
static void explorer_right_click(window_t *self, int rel_x, int rel_y) {
    ex_enter(self); explorer_right_click_impl(self, rel_x, rel_y); ex_leave();
}
static void explorer_right_click_impl(window_t *self, int rel_x, int rel_y) {
    explorer_state_t *st = (explorer_state_t *)self->user_data;
    if(!st || !st->dir_loaded) return;

    /* No context menu over the sidebar or the My PC disk-info panel. */
    if(rel_x < SIDEBAR_WIDTH || st->mypc_view) return;
    if(st->new_folder_prompt_open) return;

    int screen_x, screen_y, cw, ch;
    wm_get_client_rect(self, &screen_x, &screen_y, &cw, &ch);
    int menu_x = screen_x + rel_x;
    int menu_y = screen_y + rel_y;

    int idx = explorer_row_at(st, rel_x - SIDEBAR_WIDTH, rel_y);
    explorer_menu_ctx.win = self;
    explorer_menu_ctx.row_index = idx;

    if(st->fs) {                                   /* another drive: read-only menu */
        static context_menu_item_t fitems[4];
        int fn = 0;
        context_menu_item_t fit;
        if(idx >= 0 && idx < (int)st->dir.num_entries && entry_is_real(&st->dir.entries[idx]) && !(st->dir.entries[idx].dir_attrs & DIRECTORY)) {
            st->selected_index = idx;
            memset(&fit, 0, sizeof(fit)); fit.enabled = 1; context_menu_set_label(&fit, "Copy to Downloads"); fit.action = action_foreign_copy; fitems[fn++] = fit;
        }
        memset(&fit, 0, sizeof(fit)); fit.enabled = 1; context_menu_set_label(&fit, "Refresh"); fit.action = action_foreign_refresh; fitems[fn++] = fit;
        if(fn) context_menu_open(menu_x, menu_y, fitems, fn, &explorer_menu_ctx);
        return;
    }

    int in_bin = explorer_in_recycle_bin(st);

    if(idx >= 0 && idx < (int)st->dir.num_entries && entry_is_real(&st->dir.entries[idx])) {
        struct dir_entry *e = &st->dir.entries[idx];
        st->selected_index = idx;
        int is_dir = (e->dir_attrs & DIRECTORY) != 0;

        static context_menu_item_t items[20];
        int n = 0;
        context_menu_item_t it;

        memset(&it, 0, sizeof(it)); it.enabled = entry_is_openable(e) ? 1 : 0;
        context_menu_set_label(&it, "Open"); it.action = action_explorer_open; context_menu_set_hint(&it, "Enter"); items[n++] = it;

        if(entry_is_audio(e)) {
            memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Play in Media Player"); it.action = action_explorer_play; items[n++] = it;
        }
        if(!is_dir && !entry_is_openable_app(e)) {
            memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Open with Notepad"); it.action = action_explorer_notepad; items[n++] = it;
        }
        if(is_dir) {
            memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Open in Command Prompt"); it.action = action_explorer_open_cmd; items[n++] = it;
        }
        memset(&it, 0, sizeof(it)); it.separator = 1; items[n++] = it;

        memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Cut"); it.action = action_explorer_cut; context_menu_set_hint(&it, "Ctrl+X"); items[n++] = it;
        memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Copy"); it.action = action_explorer_copy; context_menu_set_hint(&it, "Ctrl+C"); items[n++] = it;

        if(!in_bin) {
            memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Create Shortcut"); it.action = action_explorer_create_shortcut; items[n++] = it;
            memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Send to Desktop (shortcut)"); it.action = action_explorer_send_desktop; items[n++] = it;
            memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Pin to Start"); it.action = action_explorer_pin_start; items[n++] = it;
        }
        memset(&it, 0, sizeof(it)); it.separator = 1; items[n++] = it;

        memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, in_bin ? "Delete permanently" : "Delete"); it.action = action_explorer_delete; context_menu_set_hint(&it, "Del"); items[n++] = it;
        memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Rename"); it.action = action_explorer_rename; items[n++] = it;
        memset(&it, 0, sizeof(it)); it.separator = 1; items[n++] = it;
        memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Properties"); it.action = action_explorer_properties; items[n++] = it;

        context_menu_open(menu_x, menu_y, items, n, &explorer_menu_ctx);
    }
    else {
        static const context_menu_item_t sort_items[] = {
            CM_ITEM("Name", action_sort_name, ""),
            CM_ITEM("Size", action_sort_size, ""),
            CM_ITEM("Type", action_sort_type, ""),
        };
        static context_menu_item_t sort_live[3];
        for(int i = 0; i < 3; i++) sort_live[i] = sort_items[i];
        sort_live[st->sort_mode % 3].checked = 1;

        static const context_menu_item_t new_items[] = {
            CM_ITEM("Folder", action_explorer_new_folder, ""),
            CM_ITEM("Text Document", action_explorer_new_text, ""),
        };

        static context_menu_item_t items[12];
        int n = 0;
        context_menu_item_t it;

        memset(&it, 0, sizeof(it)); it.enabled = 1; it.submenu = sort_live; it.submenu_count = 3; context_menu_set_label(&it, "Sort by"); items[n++] = it;
        memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Refresh"); it.action = action_explorer_refresh; context_menu_set_hint(&it, ""); items[n++] = it;
        if(st->depth > 0) {
            memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Go up"); it.action = action_explorer_up; items[n++] = it;
        }
        memset(&it, 0, sizeof(it)); it.separator = 1; items[n++] = it;

        if(in_bin) {
            memset(&it, 0, sizeof(it)); it.enabled = st->dir.num_entries > 2 ? 1 : 0; context_menu_set_label(&it, "Empty Recycle Bin"); it.action = action_explorer_empty_bin; items[n++] = it;
        }
        else {
            memset(&it, 0, sizeof(it)); it.enabled = clipboard_has_file() ? 1 : 0; context_menu_set_label(&it, "Paste"); it.action = action_explorer_paste; context_menu_set_hint(&it, "Ctrl+V"); items[n++] = it;
            memset(&it, 0, sizeof(it)); it.separator = 1; items[n++] = it;
            memset(&it, 0, sizeof(it)); it.enabled = 1; it.submenu = new_items; it.submenu_count = 2; context_menu_set_label(&it, "New"); items[n++] = it;
        }
        memset(&it, 0, sizeof(it)); it.separator = 1; items[n++] = it;
        memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Open in Command Prompt"); it.action = action_explorer_open_cmd; items[n++] = it;
        memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Properties"); it.action = action_explorer_properties; items[n++] = it;

        context_menu_open(menu_x, menu_y, items, n, &explorer_menu_ctx);
    }
}

static void explorer_key_impl(window_t *self, char c);
static void explorer_key(window_t *self, char c) { ex_enter(self); explorer_key_impl(self, c); ex_leave(); }
static void explorer_key_impl(window_t *self, char c) {
    explorer_state_t *st = (explorer_state_t *)self->user_data;
    if(!st) return;

    if(!st->new_folder_prompt_open) {
        /* File shortcuts (only while no name prompt is open). */
        explorer_menu_ctx.win = self;
        explorer_menu_ctx.row_index = st->selected_index;
        struct dir_entry *sel = (st->dir_loaded && st->selected_index >= 0 && st->selected_index < (int)st->dir.num_entries) ? &st->dir.entries[st->selected_index] : NULL;

        if(st->fs && (c == 3 || c == 24 || c == 22 || c == KEY_DELETE)) desktop_toast("This drive is read-only");
        else if(c == 3 && sel) action_explorer_copy(&explorer_menu_ctx);          /* Ctrl+C */
        else if(c == 24 && sel) action_explorer_cut(&explorer_menu_ctx);     /* Ctrl+X */
        else if(c == 22) explorer_paste_into_current(st);                    /* Ctrl+V */
        else if(c == KEY_DELETE && sel) explorer_delete_entry(st, sel);
        else if((c == '\n' || c == '\r') && sel && entry_is_openable(sel)) action_explorer_open(&explorer_menu_ctx);
        else if(c == '\b' && !st->mypc_view) explorer_go_up(st);
        else if(c == KEY_DOWN && st->dir_loaded && st->dir.num_entries) {
            int i = st->selected_index + 1; while(i < (int)st->dir.num_entries && !st->dir.entries[i].name) i++;
            if(i < (int)st->dir.num_entries) st->selected_index = i;
        }
        else if(c == KEY_UP && st->dir_loaded && st->selected_index > 0) {
            int i = st->selected_index - 1; while(i > 0 && !st->dir.entries[i].name) i--;
            st->selected_index = i;
        }
        return;
    }

    if(c == '\n' || c == '\r') {
        commit_new_folder(st);
    }
    else if(c == 27) {
        st->new_folder_prompt_open = 0;
        st->prompt_mode = 0;
    }
    else if(c == '\b' || c == 127) {
        if(st->new_folder_name_len > 0) {
            st->new_folder_name_len--;
            st->new_folder_name[st->new_folder_name_len] = '\0';
        }
    }
    else if(c >= ' ' && c < 127) {
        if(c != '/' && c != '\\' && c != ':' && c != '*' && c != '?' && c != '"' &&
           st->new_folder_name_len < EXPLORER_NAME_MAX - 1) {
            st->new_folder_name[st->new_folder_name_len++] = c;
            st->new_folder_name[st->new_folder_name_len] = '\0';
        }
    }
}

static void explorer_destroy(window_t *self) {
    { explorer_state_t *dst = (explorer_state_t *)self->user_data; if(dst && dst->fs) explorer_leave_volume(dst); }
    explorer_state_t *st = (explorer_state_t *)self->user_data;
    if(!st) return;
    if(st->dir_loaded) {
        free_directory(master_fs, &st->dir);
    }
    kfree(st);
    self->user_data = NULL;
}

/* Shared by launch_explorer()/launch_explorer_mypc()/
 * launch_explorer_recycle_bin() -- creates the window and common state,
 * then lets the caller decide what view it opens to (plain root listing,
 * My PC, or Recycle Bin) before the first paint happens, so opening
 * straight to one of those views from a desktop icon doesn't have to
 * launch normally and then navigate as a visible second step. */
/* Which cursor to show over a given client-relative point: the pointing
 * hand over the sidebar entries and the Up / New Folder buttons, an
 * I-beam over the folder-name field while it's open. Geometry mirrors
 * draw_toolbar()/draw_sidebar()/handle_sidebar_click() (same constants)
 * so the shape matches exactly what a click there would actually do. */
static int explorer_cursor_at(window_t *self, int rel_x, int rel_y) {
    explorer_state_t *st = (explorer_state_t *)self->user_data;
    if(!st) return CURSOR_DEFAULT;

    if(rel_x < SIDEBAR_WIDTH) {
        int list_y = 22;
        if(rel_y >= list_y && rel_y < list_y + SIDEBAR_ITEM_COUNT * SIDEBAR_ROW_HEIGHT) {
            return CURSOR_LINK;
        }
        return CURSOR_DEFAULT;
    }

    if(st->mypc_view) return CURSOR_DEFAULT;

    int content_x = rel_x - SIDEBAR_WIDTH;
    if(rel_y >= 4 && rel_y < EXPLORER_TOOLBAR_HEIGHT - 4) {
        if(st->new_folder_prompt_open) {
            int cx, cy, cw, ch;
            wm_get_client_rect(self, &cx, &cy, &cw, &ch);
            int content_w = cw - SIDEBAR_WIDTH;
            int path_x = 48 + 88 + 8;
            int field_w = content_w - path_x - 4;
            if(content_x >= path_x && content_x < path_x + field_w) return CURSOR_TEXT;
        }
        if(content_x >= 4 && content_x < 44) return CURSOR_LINK;      /* Up */
        if(content_x >= 48 && content_x < 48 + 88) return CURSOR_LINK; /* New Folder */
    }
    return CURSOR_DEFAULT;
}

static explorer_state_t *create_explorer_window(void) {
    /* Widened by SIDEBAR_WIDTH so the Favorites sidebar doesn't eat into
     * the file list's usable width (the old 420 was sized purely for
     * the toolbar+list, before the sidebar existed). */
    window_t *win = wm_create_window("Explorer", 260, 180, 420 + SIDEBAR_WIDTH, 320, 0xFFFFFFFF);
    if(!win) return NULL;

    /* Idempotent -- creates /Users/User/Music, /Users/User/Pictures,
     * /Users/User/Documents and /RecycleBin only if they don't already
     * exist yet, so this is safe to run on every launch rather than
     * just "the first ever". */
    favorites_ensure_folders(master_fs);

    explorer_state_t *st = (explorer_state_t *)kmalloc(sizeof(explorer_state_t));
    memset(st, 0, sizeof(explorer_state_t));
    st->selected_index = -1;
    st->last_click_index = -1;
    st->last_click_tick = -1000;
    st->drag_idx = -1;

    win->user_data = st;
    win->on_paint = explorer_paint;
    win->on_click = explorer_click;
    win->on_right_click = explorer_right_click;
    win->on_drag = explorer_drag;
    win->on_mouse_up = explorer_mouse_up;
    win->on_drop = explorer_drop;
    win->on_tick = explorer_tick;
    win->cursor_at = explorer_cursor_at;
    win->on_key = explorer_key;
    win->on_destroy = explorer_destroy;

    return st;
}

void launch_explorer(void) {
    explorer_state_t *st = create_explorer_window();
    if(!st) return;
    explorer_load_current(st);
}

/* Opens a new Explorer window straight to the My PC disk-info view --
 * used by the My PC desktop icon (see desktop.c's ICON_KIND_MYPC) so
 * double-clicking it goes directly there rather than opening a plain
 * Explorer window the user would then have to click My PC in. */
void launch_explorer_mypc(void) {
    explorer_state_t *st = create_explorer_window();
    if(!st) return;
    explorer_load_current(st); /* populates st->dir/dir_loaded, which draw_sidebar()/etc. still expect even in My PC view */
    st->mypc_view = 1;
    mypc_refresh();
}

/* Opens a new Explorer window straight to the Recycle Bin folder --
 * used by the Recycle Bin desktop icon (see desktop.c's
 * ICON_KIND_RECYCLE_BIN). */
void launch_explorer_recycle_bin(void) {
    explorer_state_t *st = create_explorer_window();
    if(!st) return;
    explorer_go_to_recycle_bin(st); /* loads st->dir itself -- no separate explorer_load_current() call needed here */
}

/* Walks an absolute path from the root, filling the Explorer's cluster
 * stack, then loads that folder. Components that don't exist stop the walk
 * at the last folder that did. */
static void explorer_go_to_path(explorer_state_t *st, const char *path) {
    if(!master_fs) return;
    st->mypc_view = 0;
    st->depth = 0;

    struct directory cur;
    populate_root_dir(master_fs, &cur);
    const char *p = path;
    while(*p && st->depth < EXPLORER_MAX_DEPTH) {
        while(*p == '/') p++;
        if(!*p) break;
        char comp[32]; int n = 0;
        while(*p && *p != '/' && n < 31) comp[n++] = *p++;
        comp[n] = '\0';
        while(*p && *p != '/') p++;               /* over-long name: skip the rest */

        uint32_t cluster;
        if(!find_subdir(&cur, comp, &cluster)) break;
        st->path_stack[st->depth] = cluster;
        fastcp(st->path_names[st->depth], comp, (uint32_t)n + 1);
        st->depth++;
        free_directory(master_fs, &cur);
        populate_dir(master_fs, &cur, cluster);
    }
    free_directory(master_fs, &cur);
    explorer_load_current(st);
}

void launch_explorer_at(const char *path) {
    explorer_state_t *st = create_explorer_window();
    if(!st) return;
    explorer_go_to_path(st, path ? path : "/");
}
