#ifndef FS_UTIL_H
#define FS_UTIL_H

#include "stdint.h"
#include "fat32.h"

/* Path-based helpers on top of the cluster-based FAT32 driver, shared by
 * the Command Prompt, Explorer and the Media Player. All paths are
 * absolute, '/'-separated internally ("/" = root, "/Users/User/Music").
 * fsu_normalize() accepts Windows-style input too ("C:\Users\User",
 * "..\Music", "dir\file.txt"). */

#define FSU_PATH_MAX 192

/* Joins `arg` onto `cwd` (unless arg is absolute), resolves "." and "..",
 * accepts '\' or '/', strips a leading drive letter ("C:"). */
void fsu_normalize(const char *cwd, const char *arg, char *out, int out_max);

/* Splits a normalized path into parent directory path and final name.
 * For "/" the name is empty. */
void fsu_split(const char *path, char *parent_out, int parent_max, char *name_out, int name_max);

/* Opens a directory by path; on success returns 1 and the caller must
 * free_directory(master_fs, out). */
int fsu_open_dir(const char *path, struct directory *out);

/* Case-insensitive lookup of `name` inside an opened directory.
 * Returns the entry index or -1. */
int fsu_find(const struct directory *d, const char *name);

/* Looks up a path. Returns 1 if it exists and fills *is_dir / *size /
 * date/time (any may be NULL). */
int fsu_stat(const char *path, int *is_dir, uint32_t *size, uint16_t *wr_date, uint16_t *wr_time);

int fsu_mkdir(const char *path);              /* 1 ok, 0 fail/exists   */
int fsu_delete_file(const char *path);        /* 1 ok                  */
int fsu_dir_is_empty(const char *path);       /* 1 if only "." / ".."  */
int fsu_remove_dir(const char *path, int recursive); /* 1 ok            */

/* Reads a whole file; caller kfree()s the result. *size gets the length. */
uint8_t *fsu_read_file(const char *path, uint32_t *size);
int fsu_write_file(const char *path, const uint8_t *data, uint32_t len);
int fsu_copy_file(const char *src, const char *dst);
int fsu_move_file(const char *src, const char *dst);   /* files only */
/* Recursive copy (files and folders). */
int fsu_copy_tree(const char *src, const char *dst);

/* Returns a pointer to the extension (including the dot) or "". */
const char *fsu_ext(const char *name);

/* Display helpers. */
void fsu_format_size(uint32_t bytes, char *out, int out_max);      /* "1.4 MB" style  */
void fsu_format_number(uint32_t value, char *out, int out_max);    /* "1,234,567"      */

#endif
