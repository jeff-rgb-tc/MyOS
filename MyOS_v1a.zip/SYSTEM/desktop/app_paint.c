/*
 * A functional paint window. Maintains its own persistent ARGB canvas
 * buffer (since the desktop repaints every window's client area fresh
 * each frame via on_paint -- without a backing buffer, anything drawn
 * directly to the gfx backbuffer would vanish the instant the next frame
 * redraws the window's background). Mouse clicks/drags plot into that
 * buffer; on_paint just blits it.
 *
 * Also supports saving the canvas to the FAT32 disk as either .png or
 * .bmp via a small modal-style save dialog drawn over the canvas.
 */

#include "stdint.h"
#include "stddef.h"
#include "app_paint.h"
#include "window.h"
#include "gfx.h"
#include "common.h"
#include "kernio.h"
#include "kheap.h"
#include "fat32.h"
#include "bmp.h"
#include "png_encode.h"
#include "pit.h"
#include "cursor_set.h"

#define PAINT_CANVAS_W 400
#define PAINT_CANVAS_H 250
#define PAINT_TOOLBAR_HEIGHT 32
#define PAINT_TOOL_STRIP_HEIGHT 28
#define PAINT_FILENAME_MAX 48
#define PAINT_SAVE_DIR_MAX_DEPTH 12
#define PAINT_SAVE_DIR_NAME_MAX 32
#define PAINT_SAVE_DIR_VISIBLE_ROWS 4

/* Zoom levels the canvas can be viewed at -- an index into this table
 * is stored rather than a raw factor, so cycling the zoom button is
 * just incrementing/wrapping an index. Screen pixels per canvas pixel;
 * canvas resolution itself (PAINT_CANVAS_W x PAINT_CANVAS_H) never
 * changes, only how large each of its pixels is drawn. */
#define PAINT_ZOOM_LEVEL_COUNT 4
static const int zoom_levels[PAINT_ZOOM_LEVEL_COUNT] = { 1, 2, 3, 4 };

#define PALETTE_COUNT 16
static const uint32_t palette[PALETTE_COUNT] = {
    0xFF000000, /* black */
    0xFF808080, /* gray */
    0xFFFFFFFF, /* white */
    0xFFC0C0C0, /* light gray */
    0xFFE03C3C, /* red */
    0xFF802020, /* dark red */
    0xFFE0C93C, /* yellow */
    0xFFE0993C, /* amber */
    0xFF3CB371, /* green */
    0xFF206040, /* dark green */
    0xFF3CA0E0, /* blue */
    0xFF203C80, /* navy */
    0xFFA35CE0, /* purple */
    0xFFE03CA0, /* magenta */
    0xFFE07A3C, /* orange */
    0xFF7A5030, /* brown */
};

/* Brush shapes/sizes, plus shape tools that draw an outline preview
 * while dragging and commit the final shape into the canvas on mouse
 * release (see on_mouse_up in window.h). */
typedef enum {
    TOOL_PENCIL,      /* 1px round dot -- finest brush */
    TOOL_BRUSH,       /* medium round brush */
    TOOL_BRUSH_LARGE, /* large round brush */
    TOOL_SQUARE,      /* medium square brush */
    TOOL_ERASER,      /* like TOOL_BRUSH_LARGE but always paints canvas-clear (0) */
    TOOL_LINE,
    TOOL_RECT,
    TOOL_RECT_FILLED,
    TOOL_ELLIPSE,
    TOOL_ELLIPSE_FILLED,
    TOOL_FILL,        /* flood fill */
    TOOL_PICK,        /* eyedropper: takes the colour under the pointer */
    TOOL_SPRAY,       /* airbrush */
    TOOL_COUNT
} paint_tool_t;

static const char *tool_labels[TOOL_COUNT] = {
    "Pencil", "Brush", "Big", "Square", "Eraser",
    "Line", "Rect", "RectF", "Oval", "OvalF", "Fill", "Pick", "Spray"
};

/* Brush radius in canvas pixels for each round/square brush tool --
 * TOOL_LINE/RECT/ELLIPSE... don't use this (they draw a 1px outline at
 * whatever zoom, not a stamped brush). */
static int tool_brush_radius(paint_tool_t tool) {
    switch(tool) {
        case TOOL_PENCIL: return 0;
        case TOOL_BRUSH: return 2;
        case TOOL_BRUSH_LARGE: return 5;
        case TOOL_SQUARE: return 3;
        case TOOL_ERASER: return 5;
        default: return 2;
    }
}

typedef enum {
    PAINT_FORMAT_PNG,
    PAINT_FORMAT_BMP,
} paint_save_format_t;

#define PAINT_UNDO_MAX 8

typedef struct {
    uint32_t *canvas; /* PAINT_CANVAS_W * PAINT_CANVAS_H, ARGB8888 */
    uint32_t *undo[PAINT_UNDO_MAX]; int undo_n;      /* snapshots taken before each stroke */
    uint32_t *redo[PAINT_UNDO_MAX]; int redo_n;
    int size_adj;                                    /* [ and ] make brushes smaller / bigger */
    uint32_t current_color;
    paint_tool_t tool;
    int zoom_index; /* index into zoom_levels[] */
    int last_x, last_y; /* previous drag point, for drawing continuous strokes; -1 = no previous point */

    /* Shape-tool preview: canvas-space start point of the current
     * drag, latched on the initial click, plus whether a drag is
     * currently in progress at all (so on_paint knows whether to draw
     * the live outline this frame). Only meaningful for the
     * TOOL_LINE / TOOL_RECT / TOOL_ELLIPSE (and their filled variants)
     * tools -- brush tools draw directly into the canvas as they go and
     * never set shape_active. */
    uint8_t shape_active;
    int shape_start_x, shape_start_y;
    int shape_cur_x, shape_cur_y;

    /* Save dialog state. When save_dialog_open is set, the whole client
     * area shows the dialog instead of the canvas/toolbar, and on_key
     * routes into the filename field instead of doing nothing. */
    uint8_t save_dialog_open;
    char filename[PAINT_FILENAME_MAX];
    int filename_len;
    paint_save_format_t format;
    char status_message[64]; /* transient "Saved as ..." / error feedback */

    /* Destination folder for the save dialog. Mirrors the explorer app's
     * approach: a stack of cluster numbers (one per path level) rather
     * than a string path, since that's what populate_dir() needs and
     * avoids re-parsing a path string on every navigation. depth == 0
     * means the root directory. */
    uint32_t save_dir_stack[PAINT_SAVE_DIR_MAX_DEPTH];
    char save_dir_names[PAINT_SAVE_DIR_MAX_DEPTH][PAINT_SAVE_DIR_NAME_MAX];
    int save_dir_depth;
    struct directory save_dir_listing; /* subfolders of the current save location */
    uint8_t save_dir_listing_loaded;
    int save_dir_scroll; /* index of first visible row, for the folder list */
    int save_dir_last_click_index;
    long long save_dir_last_click_tick; /* real wall-clock time (PIT ticks), see pit_get_ticks() */
} paint_state_t;

/* ---- undo / redo: whole-canvas snapshots (400x250x4 = 400 KB each, 8 deep) ---- */
static uint32_t *snapshot_of(paint_state_t *st) {
    uint32_t *c = (uint32_t *)kmalloc(PAINT_CANVAS_W * PAINT_CANVAS_H * sizeof(uint32_t));
    if(c) memcpy(c, st->canvas, PAINT_CANVAS_W * PAINT_CANVAS_H * sizeof(uint32_t));
    return c;
}
static void drop_list(uint32_t **list, int *n) { for(int i = 0; i < *n; i++) kfree(list[i]); *n = 0; }
static void push_list(uint32_t **list, int *n, uint32_t *snap) {
    if(!snap) return;
    if(*n == PAINT_UNDO_MAX) { kfree(list[0]); for(int i = 1; i < PAINT_UNDO_MAX; i++) list[i - 1] = list[i]; (*n)--; }
    list[(*n)++] = snap;
}
static void undo_push(paint_state_t *st) {            /* call right before a change */
    drop_list(st->redo, &st->redo_n);
    push_list(st->undo, &st->undo_n, snapshot_of(st));
}
static void paint_undo(paint_state_t *st) {
    if(st->undo_n == 0) return;
    push_list(st->redo, &st->redo_n, snapshot_of(st));
    uint32_t *prev = st->undo[--st->undo_n];
    memcpy(st->canvas, prev, PAINT_CANVAS_W * PAINT_CANVAS_H * sizeof(uint32_t));
    kfree(prev);
}
static void paint_redo(paint_state_t *st) {
    if(st->redo_n == 0) return;
    push_list(st->undo, &st->undo_n, snapshot_of(st));
    uint32_t *next = st->redo[--st->redo_n];
    memcpy(st->canvas, next, PAINT_CANVAS_W * PAINT_CANVAS_H * sizeof(uint32_t));
    kfree(next);
}

static uint32_t paint_rng = 12345;
static int paint_rand(int n) { paint_rng = paint_rng * 1103515245u + 12345u; return (int)((paint_rng >> 16) % (uint32_t)n); }

static uint32_t norm_px(uint32_t px) { return px == 0 ? 0xFFFFFFFFu : px; }   /* untouched cells look white */

/* Flood fill (4-connected). Each pixel is recoloured when it is pushed, so it is
 * pushed at most once and the stack never exceeds the canvas size. */
static void canvas_flood_fill(paint_state_t *st, int x, int y, uint32_t color) {
    if(x < 0 || y < 0 || x >= PAINT_CANVAS_W || y >= PAINT_CANVAS_H) return;
    uint32_t target = norm_px(st->canvas[y * PAINT_CANVAS_W + x]);
    if(target == color) return;
    int *stack = (int *)kmalloc(PAINT_CANVAS_W * PAINT_CANVAS_H * sizeof(int));
    if(!stack) return;
    int sp = 0;
    st->canvas[y * PAINT_CANVAS_W + x] = color;
    stack[sp++] = y * PAINT_CANVAS_W + x;
    while(sp > 0) {
        int idx = stack[--sp];
        int px = idx % PAINT_CANVAS_W, py = idx / PAINT_CANVAS_W;
        static const int dx[4] = { 1, -1, 0, 0 }, dy[4] = { 0, 0, 1, -1 };
        for(int k = 0; k < 4; k++) {
            int nx = px + dx[k], ny = py + dy[k];
            if(nx < 0 || ny < 0 || nx >= PAINT_CANVAS_W || ny >= PAINT_CANVAS_H) continue;
            int ni = ny * PAINT_CANVAS_W + nx;
            if(norm_px(st->canvas[ni]) != target) continue;
            st->canvas[ni] = color;
            stack[sp++] = ni;
        }
    }
    kfree(stack);
}

static uint32_t hue_color(int h) {                    /* h 0..359, full saturation and value */
    int region = h / 60, rem = (h % 60) * 255 / 60, r, g, b;
    switch(region) {
        case 0: r = 255; g = rem; b = 0; break;
        case 1: r = 255 - rem; g = 255; b = 0; break;
        case 2: r = 0; g = 255; b = rem; break;
        case 3: r = 0; g = 255 - rem; b = 255; break;
        case 4: r = rem; g = 0; b = 255; break;
        default: r = 255; g = 0; b = 255 - rem; break;
    }
    return 0xFF000000u | ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

static void canvas_put_pixel(paint_state_t *st, int x, int y, uint32_t color) {
    if(x < 0 || y < 0 || x >= PAINT_CANVAS_W || y >= PAINT_CANVAS_H) return;
    st->canvas[y * PAINT_CANVAS_W + x] = color;
}

/* Plots a filled circle of the given radius so single clicks and slow
 * drags leave a visible dot/line rather than a single hard-to-see
 * pixel. radius 0 plots just the center pixel (the Pencil tool). */
static void canvas_stamp_round(paint_state_t *st, int cx, int cy, int radius, uint32_t color) {
    if(radius <= 0) {
        canvas_put_pixel(st, cx, cy, color);
        return;
    }
    for(int dy = -radius; dy <= radius; dy++) {
        for(int dx = -radius; dx <= radius; dx++) {
            if(dx * dx + dy * dy <= radius * radius) {
                canvas_put_pixel(st, cx + dx, cy + dy, color);
            }
        }
    }
}

static void canvas_stamp_square(paint_state_t *st, int cx, int cy, int radius, uint32_t color) {
    for(int dy = -radius; dy <= radius; dy++) {
        for(int dx = -radius; dx <= radius; dx++) {
            canvas_put_pixel(st, cx + dx, cy + dy, color);
        }
    }
}

/* Stamps whatever brush shape the current tool uses at (cx, cy) --
 * shared by canvas_stamp_line below and the click/drag handlers, so a
 * single click and a drag both look the same regardless of tool. The
 * eraser reuses the round brush shape but always paints canvas-clear
 * (0) rather than st->current_color. */
static void canvas_stamp_tool(paint_state_t *st, int cx, int cy) {
    int radius = tool_brush_radius(st->tool);
    if(st->tool != TOOL_PENCIL) { radius += st->size_adj; if(radius < 0) radius = 0; }
    uint32_t color = (st->tool == TOOL_ERASER) ? 0 : st->current_color;
    if(st->tool == TOOL_SPRAY) {
        int R = 6 + st->size_adj * 2; if(R < 3) R = 3;
        for(int i = 0; i < 14; i++) {
            int dx = paint_rand(2 * R + 1) - R, dy = paint_rand(2 * R + 1) - R;
            if(dx * dx + dy * dy <= R * R) canvas_put_pixel(st, cx + dx, cy + dy, color);
        }
        return;
    }
    if(st->tool == TOOL_SQUARE) {
        canvas_stamp_square(st, cx, cy, radius, color);
    }
    else {
        canvas_stamp_round(st, cx, cy, radius, color);
    }
}

/* Bresenham's line algorithm, so dragging quickly doesn't leave gaps
 * between mouse-move samples -- each new sample connects to the last
 * with a solid stroke instead of just stamping isolated dots. Used both
 * for freehand brush strokes (stamping the brush shape along the line)
 * and, with a 1px stamp, for the Line shape tool's final commit. */
static void canvas_draw_line_shape(paint_state_t *st, int x0, int y0, int x1, int y1,
                                    void (*stamp)(paint_state_t *, int, int)) {
    int dx = x1 > x0 ? x1 - x0 : x0 - x1;
    int dy = y1 > y0 ? y1 - y0 : y0 - y1;
    int sx = x0 < x1 ? 1 : -1;
    int sy = y0 < y1 ? 1 : -1;
    int err = (dx > dy ? dx : -dy) / 2;

    while(1) {
        stamp(st, x0, y0);
        if(x0 == x1 && y0 == y1) break;
        int e2 = err;
        if(e2 > -dx) { err -= dy; x0 += sx; }
        if(e2 < dy) { err += dx; y0 += sy; }
    }
}

static void canvas_stamp_tool_cb(paint_state_t *st, int x, int y) {
    canvas_stamp_tool(st, x, y);
}

static void canvas_draw_line(paint_state_t *st, int x0, int y0, int x1, int y1) {
    canvas_draw_line_shape(st, x0, y0, x1, y1, canvas_stamp_tool_cb);
}

static void canvas_draw_rect_outline(paint_state_t *st, int x0, int y0, int x1, int y1, uint32_t color) {
    if(x1 < x0) { int t = x0; x0 = x1; x1 = t; }
    if(y1 < y0) { int t = y0; y0 = y1; y1 = t; }
    for(int x = x0; x <= x1; x++) {
        canvas_put_pixel(st, x, y0, color);
        canvas_put_pixel(st, x, y1, color);
    }
    for(int y = y0; y <= y1; y++) {
        canvas_put_pixel(st, x0, y, color);
        canvas_put_pixel(st, x1, y, color);
    }
}

static void canvas_draw_rect_filled(paint_state_t *st, int x0, int y0, int x1, int y1, uint32_t color) {
    if(x1 < x0) { int t = x0; x0 = x1; x1 = t; }
    if(y1 < y0) { int t = y0; y0 = y1; y1 = t; }
    for(int y = y0; y <= y1; y++) {
        for(int x = x0; x <= x1; x++) {
            canvas_put_pixel(st, x, y, color);
        }
    }
}

/* Midpoint ellipse algorithm, bounded by the box (x0,y0)-(x1,y1) --
 * standard 4-way-symmetric approach, drawn in two quadrant-slope
 * regions (region 1: slope shallower than 1, region 2: steeper). */
static void canvas_draw_ellipse(paint_state_t *st, int x0, int y0, int x1, int y1, uint32_t color, int filled) {
    if(x1 < x0) { int t = x0; x0 = x1; x1 = t; }
    if(y1 < y0) { int t = y0; y0 = y1; y1 = t; }
    int cx = (x0 + x1) / 2;
    int cy = (y0 + y1) / 2;
    int rx = (x1 - x0) / 2;
    int ry = (y1 - y0) / 2;
    if(rx <= 0 || ry <= 0) {
        canvas_draw_rect_filled(st, x0, y0, x1, y1, color);
        return;
    }

    long rx2 = (long)rx * rx;
    long ry2 = (long)ry * ry;
    long two_rx2 = 2 * rx2;
    long two_ry2 = 2 * ry2;
    long x = 0, y = ry;
    long px = 0, py = two_rx2 * y;

#define ELLIPSE_PLOT(ex, ey) do { \
    if(filled) { \
        for(int fx = cx - (ex); fx <= cx + (ex); fx++) { \
            canvas_put_pixel(st, fx, cy + (ey), color); \
            canvas_put_pixel(st, fx, cy - (ey), color); \
        } \
    } else { \
        canvas_put_pixel(st, cx + (ex), cy + (ey), color); \
        canvas_put_pixel(st, cx - (ex), cy + (ey), color); \
        canvas_put_pixel(st, cx + (ex), cy - (ey), color); \
        canvas_put_pixel(st, cx - (ex), cy - (ey), color); \
    } \
} while(0)

    /* Region 1: slope < 1 */
    long p1 = ry2 - rx2 * ry + rx2 / 4;
    while(px < py) {
        ELLIPSE_PLOT(x, y);
        x++;
        px += two_ry2;
        if(p1 < 0) {
            p1 += ry2 + px;
        }
        else {
            y--;
            py -= two_rx2;
            p1 += ry2 + px - py;
        }
    }

    /* Region 2: slope >= 1 */
    long p2 = ry2 * (x * 2 + 1) * (x * 2 + 1) / 4 + rx2 * (y - 1) * (y - 1) - rx2 * ry2;
    while(y >= 0) {
        ELLIPSE_PLOT(x, y);
        y--;
        py -= two_rx2;
        if(p2 > 0) {
            p2 += rx2 - py;
        }
        else {
            x++;
            px += two_ry2;
            p2 += rx2 - py + px;
        }
    }
#undef ELLIPSE_PLOT
}

/* Commits whichever shape tool is active between (x0,y0) and (x1,y1)
 * (canvas coordinates) into the canvas. Called once on mouse-up for
 * TOOL_LINE / TOOL_RECT / TOOL_ELLIPSE (and their filled variants);
 * brush tools never call this (they paint continuously in
 * canvas_stamp_tool as the mouse moves). */
static void canvas_commit_shape(paint_state_t *st, int x0, int y0, int x1, int y1) {
    switch(st->tool) {
        case TOOL_LINE:
            canvas_draw_line(st, x0, y0, x1, y1);
            break;
        case TOOL_RECT:
            canvas_draw_rect_outline(st, x0, y0, x1, y1, st->current_color);
            break;
        case TOOL_RECT_FILLED:
            canvas_draw_rect_filled(st, x0, y0, x1, y1, st->current_color);
            break;
        case TOOL_ELLIPSE:
            canvas_draw_ellipse(st, x0, y0, x1, y1, st->current_color, 0);
            break;
        case TOOL_ELLIPSE_FILLED:
            canvas_draw_ellipse(st, x0, y0, x1, y1, st->current_color, 1);
            break;
        default:
            break;
    }
}

static int tool_is_shape(paint_tool_t tool) {
    return tool == TOOL_LINE || tool == TOOL_RECT || tool == TOOL_RECT_FILLED
        || tool == TOOL_ELLIPSE || tool == TOOL_ELLIPSE_FILLED;
}


/* Toolbar geometry shared between drawing and hit-testing, same pattern
 * as the save dialog's DIALOG_* constants above. Two rows: a tool strip
 * (brush/shape selection + zoom) on top, a palette + Clear/Save row
 * below. */
#define TOOL_BUTTON_W 54
#define TOOL_BUTTON_GAP 2
#define ZOOM_BUTTON_W 40
#define SWATCH_SIZE 18
#define SWATCH_GAP 3

#define PX_BG     0xFF1E1E22
#define PX_PANEL  0xFF18181B
#define PX_BTN    0xFF34343B
#define PX_TEXT   0xFFF2F2F5
#define PX_DIM    0xFFA0A0AA
#define PX_ACCENT 0xFF4CC2FF

static void draw_tool_strip(paint_state_t *st, int cx, int cy, int cw) {
    gfx_fill_rect(cx, cy, cw, PAINT_TOOL_STRIP_HEIGHT, PX_PANEL);

    int bx = cx + 4;
    int by = cy + 2;
    int bh = PAINT_TOOL_STRIP_HEIGHT - 4;

    for(int i = 0; i < TOOL_COUNT; i++) {
        int x = bx + i * (TOOL_BUTTON_W + TOOL_BUTTON_GAP);
        int on = (st->tool == (paint_tool_t)i);
        gfx_fill_rounded_rect(x, by, TOOL_BUTTON_W, bh, 6, on ? PX_ACCENT : PX_BTN);
        int tw = (int)strlen(tool_labels[i]) * GFX_CHAR_COLS;
        gfx_draw_string(x + (TOOL_BUTTON_W - tw) / 2, by + (bh - 16) / 2, tool_labels[i], on ? 0xFF0E1620 : PX_TEXT);
    }

    /* Zoom control: current level as text, click to cycle -- geometry
     * mirrored in handle_tool_strip_click below. */
    int zoom_x = bx + TOOL_COUNT * (TOOL_BUTTON_W + TOOL_BUTTON_GAP) + 10;
    gfx_fill_rounded_rect(zoom_x, by, ZOOM_BUTTON_W, bh, 6, PX_BTN);
    char zoom_label[8];
    sprintf(zoom_label, "%dx", zoom_levels[st->zoom_index]);
    gfx_draw_string(zoom_x + 10, by + (bh - 16) / 2, zoom_label, PX_TEXT);
}

/* x positions of the buttons that follow the swatches (shared with the click handler) */
#define PB_CLEAR_X (6 + PALETTE_COUNT * (SWATCH_SIZE + SWATCH_GAP) + 12)
#define PB_SAVE_X  (PB_CLEAR_X + 62)
#define PB_UNDO_X  (PB_SAVE_X + 62)
#define PB_REDO_X  (PB_UNDO_X + 54)
#define PB_HUE_X   (PB_REDO_X + 54 + 8)
#define PB_HUE_W   120

static void pbutton(int x, int y, int w, const char *label, uint32_t bg, uint32_t fg) {
    gfx_fill_rounded_rect(x, y, w, SWATCH_SIZE, 5, bg);
    int tw = (int)strlen(label) * GFX_CHAR_COLS;
    gfx_draw_string(x + (w - tw) / 2, y + 1, label, fg);
}

static void draw_palette_row(paint_state_t *st, int cx, int cy, int cw) {
    gfx_fill_rect(cx, cy, cw, PAINT_TOOLBAR_HEIGHT, PX_PANEL);

    int sx = cx + 6;
    int sy = cy + (PAINT_TOOLBAR_HEIGHT - SWATCH_SIZE) / 2;

    for(int i = 0; i < PALETTE_COUNT; i++) {
        int x = sx + i * (SWATCH_SIZE + SWATCH_GAP);
        gfx_fill_rounded_rect(x, sy, SWATCH_SIZE, SWATCH_SIZE, 4, palette[i]);
        if(palette[i] == st->current_color) gfx_draw_rounded_outline(x - 2, sy - 2, SWATCH_SIZE + 4, SWATCH_SIZE + 4, 6, PX_ACCENT);
    }

    pbutton(cx + PB_CLEAR_X, sy, 56, "Clear", PX_BTN, PX_TEXT);
    pbutton(cx + PB_SAVE_X, sy, 56, "Save", 0xFF2E7D4F, PX_TEXT);
    pbutton(cx + PB_UNDO_X, sy, 48, "Undo", st->undo_n ? PX_BTN : 0xFF26262B, st->undo_n ? PX_TEXT : 0xFF6C6C76);
    pbutton(cx + PB_REDO_X, sy, 48, "Redo", st->redo_n ? PX_BTN : 0xFF26262B, st->redo_n ? PX_TEXT : 0xFF6C6C76);

    /* hue strip: click to pick a colour from the rainbow */
    for(int i = 0; i < PB_HUE_W; i++) gfx_fill_rect(cx + PB_HUE_X + i, sy, 1, SWATCH_SIZE, hue_color(i * 359 / (PB_HUE_W - 1)));
    gfx_draw_rounded_outline(cx + PB_HUE_X - 1, sy - 1, PB_HUE_W + 2, SWATCH_SIZE + 2, 3, 0xFF55555E);

    /* current colour + canvas size readout */
    int sw_x = cx + PB_HUE_X + PB_HUE_W + 10;
    gfx_fill_rounded_rect(sw_x, sy, SWATCH_SIZE, SWATCH_SIZE, 4, st->current_color);
    gfx_draw_rounded_outline(sw_x - 1, sy - 1, SWATCH_SIZE + 2, SWATCH_SIZE + 2, 4, 0xFFF2F2F5);
    char size_label[40];
    sprintf(size_label, "%dx%d px  [ ] size", PAINT_CANVAS_W, PAINT_CANVAS_H);
    gfx_draw_string(sw_x + SWATCH_SIZE + 10, sy + 1, size_label, PX_DIM);
}

/* --- save dialog: destination folder navigation, mirrors app_explorer.c --- */

static void save_dir_load_current(paint_state_t *st) {
    if(st->save_dir_listing_loaded) {
        free_directory(master_fs, &st->save_dir_listing);
        st->save_dir_listing_loaded = 0;
    }
    if(!master_fs) return;
    if(st->save_dir_depth == 0) {
        populate_root_dir(master_fs, &st->save_dir_listing);
    }
    else {
        populate_dir(master_fs, &st->save_dir_listing, st->save_dir_stack[st->save_dir_depth - 1]);
    }
    st->save_dir_listing_loaded = 1;
    st->save_dir_scroll = 0;
    st->save_dir_last_click_index = -1;
}

static void save_dir_enter(paint_state_t *st, struct dir_entry *e) {
    if(st->save_dir_depth >= PAINT_SAVE_DIR_MAX_DEPTH) return;
    st->save_dir_stack[st->save_dir_depth] = e->first_cluster;
    int i = 0;
    while(e->name[i] && i < PAINT_SAVE_DIR_NAME_MAX - 1) {
        st->save_dir_names[st->save_dir_depth][i] = e->name[i];
        i++;
    }
    st->save_dir_names[st->save_dir_depth][i] = '\0';
    st->save_dir_depth++;
    save_dir_load_current(st);
}

static void save_dir_go_up(paint_state_t *st) {
    if(st->save_dir_depth == 0) return;
    st->save_dir_depth--;
    save_dir_load_current(st);
}

/* --- save dialog: geometry shared between drawing and hit-testing ---
 * Laid out relative to the client area's top-left, since the dialog
 * fills the whole client area rather than floating over it. */
#define DIALOG_FIELD_Y 60
#define DIALOG_FIELD_H 24
#define DIALOG_PATH_Y 90
#define DIALOG_FOLDER_LIST_Y 112
#define DIALOG_FOLDER_ROW_H 18
#define DIALOG_FORMAT_Y (DIALOG_FOLDER_LIST_Y + PAINT_SAVE_DIR_VISIBLE_ROWS * DIALOG_FOLDER_ROW_H + 10)
#define DIALOG_BUTTON_Y (DIALOG_FORMAT_Y + DIALOG_FIELD_H + 12)
#define DIALOG_BUTTON_W 80
#define DIALOG_BUTTON_H 28

/* Builds the "/" or "/Users/User/Desktop"-style path string for the
 * current save location, for display only (navigation itself works off
 * save_dir_stack, not this string). */
static void save_dir_build_path(paint_state_t *st, char *out, int out_max) {
    int pos = 0;
    out[pos++] = '/';
    for(int i = 0; i < st->save_dir_depth && pos < out_max - 2; i++) {
        int j = 0;
        while(st->save_dir_names[i][j] && pos < out_max - 2) out[pos++] = st->save_dir_names[i][j++];
        if(i < st->save_dir_depth - 1) out[pos++] = '/';
    }
    out[pos] = '\0';
}

static void draw_save_dialog(paint_state_t *st, int cx, int cy, int cw, int ch) {
    gfx_fill_rect(cx, cy, cw, ch, 0xFFECECEC);
    gfx_draw_rect(cx, cy, cw, ch, 0xFF808080);

    gfx_draw_string(cx + 16, cy + 16, "Save drawing as:", 0xFF000000);

    /* Filename field */
    int field_x = cx + 16;
    int field_y = cy + DIALOG_FIELD_Y;
    int field_w = cw - 32;
    gfx_fill_rect(field_x, field_y, field_w, DIALOG_FIELD_H, 0xFFFFFFFF);
    gfx_draw_rect(field_x, field_y, field_w, DIALOG_FIELD_H, 0xFF000000);

    char field_text[PAINT_FILENAME_MAX + 2];
    int fp = 0;
    for(int i = 0; i < st->filename_len; i++) field_text[fp++] = st->filename[i];
    field_text[fp++] = '_';
    field_text[fp] = '\0';
    gfx_draw_string(field_x + 4, field_y + 4, field_text, 0xFF000000);

    /* Current destination folder path, plus an "Up" button to go back
     * to the parent folder (only shown when not already at the root). */
    char path_buf[128];
    save_dir_build_path(st, path_buf, sizeof(path_buf));
    gfx_draw_string(cx + 16, cy + DIALOG_PATH_Y, path_buf, 0xFF404040);
    if(st->save_dir_depth > 0) {
        int up_x = cx + cw - 16 - 40;
        gfx_fill_rect(up_x, cy + DIALOG_PATH_Y - 3, 40, 16, 0xFFD0D0D0);
        gfx_draw_rect(up_x, cy + DIALOG_PATH_Y - 3, 40, 16, 0xFF000000);
        gfx_draw_string(up_x + 6, cy + DIALOG_PATH_Y - 1, "Up", 0xFF000000);
    }

    /* Folder list: subfolders of the current destination only (files
     * are irrelevant here since we're picking a destination, not a
     * file). Double-click to enter, same as the explorer app. */
    int list_x = cx + 16;
    int list_y = cy + DIALOG_FOLDER_LIST_Y;
    int list_w = cw - 32;
    gfx_fill_rect(list_x, list_y, list_w, PAINT_SAVE_DIR_VISIBLE_ROWS * DIALOG_FOLDER_ROW_H, 0xFFFFFFFF);
    gfx_draw_rect(list_x, list_y, list_w, PAINT_SAVE_DIR_VISIBLE_ROWS * DIALOG_FOLDER_ROW_H, 0xFF000000);

    if(st->save_dir_listing_loaded) {
        int row = 0;
        uint32_t shown = 0;
        for(uint32_t i = 0; i < st->save_dir_listing.num_entries && row < PAINT_SAVE_DIR_VISIBLE_ROWS; i++) {
            struct dir_entry *e = &st->save_dir_listing.entries[i];
            if(e->dir_attrs & LFN) continue;
            if(!(e->dir_attrs & DIRECTORY)) continue;
            if((int)shown < st->save_dir_scroll) { shown++; continue; }
            shown++;
            int row_y = list_y + row * DIALOG_FOLDER_ROW_H;
            gfx_draw_string(list_x + 4, row_y + 2, "[D]", 0xFF9C7A00);
            gfx_draw_string(list_x + 28, row_y + 2, e->name, 0xFF000000);
            row++;
        }
        if(row == 0) {
            gfx_draw_string(list_x + 4, list_y + 2, "(no subfolders)", 0xFF808080);
        }
    }

    /* Format toggle: two boxes, PNG and BMP, click to select. */
    int fmt_x = cx + 16;
    int fmt_y = cy + DIALOG_FORMAT_Y;
    int fmt_w = 70;

    gfx_fill_rect(fmt_x, fmt_y, fmt_w, DIALOG_FIELD_H, st->format == PAINT_FORMAT_PNG ? 0xFF90C090 : 0xFFD0D0D0);
    gfx_draw_rect(fmt_x, fmt_y, fmt_w, DIALOG_FIELD_H, 0xFF000000);
    gfx_draw_string(fmt_x + 18, fmt_y + 4, "PNG", 0xFF000000);

    gfx_fill_rect(fmt_x + fmt_w + 8, fmt_y, fmt_w, DIALOG_FIELD_H, st->format == PAINT_FORMAT_BMP ? 0xFF90C090 : 0xFFD0D0D0);
    gfx_draw_rect(fmt_x + fmt_w + 8, fmt_y, fmt_w, DIALOG_FIELD_H, 0xFF000000);
    gfx_draw_string(fmt_x + fmt_w + 8 + 18, fmt_y + 4, "BMP", 0xFF000000);

    /* OK / Cancel buttons */
    int btn_y = cy + DIALOG_BUTTON_Y;
    gfx_fill_rect(cx + 16, btn_y, DIALOG_BUTTON_W, DIALOG_BUTTON_H, 0xFF90C090);
    gfx_draw_bevel(cx + 16, btn_y, DIALOG_BUTTON_W, DIALOG_BUTTON_H, 0xFFFFFFFF, 0xFF808080);
    gfx_draw_string(cx + 16 + 24, btn_y + 6, "Save", 0xFF000000);

    gfx_fill_rect(cx + 16 + DIALOG_BUTTON_W + 12, btn_y, DIALOG_BUTTON_W, DIALOG_BUTTON_H, 0xFFC09090);
    gfx_draw_bevel(cx + 16 + DIALOG_BUTTON_W + 12, btn_y, DIALOG_BUTTON_W, DIALOG_BUTTON_H, 0xFFFFFFFF, 0xFF808080);
    gfx_draw_string(cx + 16 + DIALOG_BUTTON_W + 12 + 14, btn_y + 6, "Cancel", 0xFF000000);

    if(st->status_message[0]) {
        gfx_draw_string(cx + 16, btn_y + DIALOG_BUTTON_H + 12, st->status_message, 0xFF802020);
    }
}

static void do_save(paint_state_t *st) {
    if(st->filename_len == 0 || !master_fs) {
        fastcp(st->status_message, "Enter a filename first.", 25);
        return;
    }

    struct directory dest;
    if(st->save_dir_depth == 0) {
        populate_root_dir(master_fs, &dest);
    }
    else {
        populate_dir(master_fs, &dest, st->save_dir_stack[st->save_dir_depth - 1]);
    }

    char full_name[PAINT_FILENAME_MAX + 8];
    int i = 0;
    while(i < st->filename_len) { full_name[i] = st->filename[i]; i++; }
    const char *ext = (st->format == PAINT_FORMAT_PNG) ? ".png" : ".bmp";
    int j = 0;
    while(ext[j]) full_name[i++] = ext[j++];
    full_name[i] = '\0';

    int ok;
    if(st->format == PAINT_FORMAT_PNG) {
        ok = png_save_to_file(st->canvas, PAINT_CANVAS_W, PAINT_CANVAS_H, master_fs, &dest, full_name);
    }
    else {
        ok = bmp_save_to_file(st->canvas, PAINT_CANVAS_W, PAINT_CANVAS_H, master_fs, &dest, full_name);
    }

    free_directory(master_fs, &dest);

    if(ok) {
        int p = 0;
        const char *prefix = "Saved as ";
        while(prefix[p]) { st->status_message[p] = prefix[p]; p++; }
        int k = 0;
        while(full_name[k] && p < 62) st->status_message[p++] = full_name[k++];
        st->status_message[p] = '\0';
        st->save_dialog_open = 0;
    }
    else {
        fastcp(st->status_message, "Save failed.", 13);
    }
}

/* Top-left of the canvas view within the client area, and where the
 * two toolbar rows sit -- shared between drawing and hit-testing so
 * they can never disagree about layout. Zoom is view-only: the canvas
 * is always PAINT_CANVAS_W x PAINT_CANVAS_H pixels of actual image
 * data (see the size readout in draw_palette_row); zooming in just
 * shows fewer of those pixels, each drawn larger, clipped to whatever
 * fits in the window rather than adding scrollbars. */
#define CANVAS_VIEW_X 4
#define CANVAS_VIEW_Y (PAINT_TOOL_STRIP_HEIGHT + PAINT_TOOLBAR_HEIGHT + 8)

/* How many canvas pixels are visible at the current zoom, clamped to
 * the canvas's actual size (so at 1x, or in a window big enough, the
 * whole canvas shows with no clipping at all). */
static void visible_canvas_extent(paint_state_t *st, int avail_w, int avail_h, int *out_w, int *out_h) {
    int zoom = zoom_levels[st->zoom_index];
    int vw = avail_w / zoom;
    int vh = avail_h / zoom;
    if(vw > PAINT_CANVAS_W) vw = PAINT_CANVAS_W;
    if(vh > PAINT_CANVAS_H) vh = PAINT_CANVAS_H;
    if(vw < 1) vw = 1;
    if(vh < 1) vh = 1;
    *out_w = vw;
    *out_h = vh;
}

static void paint_paint(window_t *self, int cx, int cy, int cw, int ch) {
    (void)cw;
    paint_state_t *st = (paint_state_t *)self->user_data;
    if(!st) return;

    gfx_fill_rect(cx, cy, self->w, ch, PX_BG);

    if(st->save_dialog_open) {
        draw_save_dialog(st, cx, cy, self->w - 4, ch);
        return;
    }

    draw_tool_strip(st, cx, cy, self->w - 4);
    draw_palette_row(st, cx, cy + PAINT_TOOL_STRIP_HEIGHT, self->w - 4);

    int canvas_screen_x = cx + CANVAS_VIEW_X;
    int canvas_screen_y = cy + CANVAS_VIEW_Y;
    int zoom = zoom_levels[st->zoom_index];

    int avail_w = self->w - 8;
    int avail_h = ch - CANVAS_VIEW_Y - 4;
    int vis_w, vis_h;
    visible_canvas_extent(st, avail_w, avail_h, &vis_w, &vis_h);

    /* Straight into the back buffer: one write per screen pixel instead of a
     * fill call per canvas pixel (100 000 calls per frame at 1x). Untouched
     * cells (0) show as white. */
    {
        gfx_surface_t *bb = gfx_backbuffer();
        int sw = (int)bb->width, sh = (int)bb->height;
        for(int y = 0; y < vis_h; y++) {
            const uint32_t *src = st->canvas + y * PAINT_CANVAS_W;
            for(int zy = 0; zy < zoom; zy++) {
                int py = canvas_screen_y + y * zoom + zy;
                if(py < 0 || py >= sh) continue;
                uint32_t *dst = bb->pixels + py * sw;
                for(int x = 0; x < vis_w; x++) {
                    uint32_t px = src[x] ? src[x] : 0xFFFFFFFFu;
                    int dx0 = canvas_screen_x + x * zoom;
                    for(int zx = 0; zx < zoom; zx++) {
                        int pxx = dx0 + zx;
                        if(pxx >= 0 && pxx < sw) dst[pxx] = px;
                    }
                }
            }
        }
    }

    /* Live outline preview while dragging a shape tool -- drawn directly
     * to the screen (not into st->canvas) so it disappears again if the
     * drag is abandoned; canvas_commit_shape only runs on mouse-up. */
    if(st->shape_active && tool_is_shape(st->tool)) {
        int x0 = st->shape_start_x, y0 = st->shape_start_y;
        int x1 = st->shape_cur_x, y1 = st->shape_cur_y;
        if(x1 < x0) { int t = x0; x0 = x1; x1 = t; }
        if(y1 < y0) { int t = y0; y0 = y1; y1 = t; }
        int px0 = canvas_screen_x + x0 * zoom;
        int py0 = canvas_screen_y + y0 * zoom;
        int pw = (x1 - x0 + 1) * zoom;
        int ph = (y1 - y0 + 1) * zoom;
        gfx_draw_rect(px0, py0, pw, ph, PX_ACCENT);
    }

    gfx_draw_rect(canvas_screen_x - 1, canvas_screen_y - 1, vis_w * zoom + 2, vis_h * zoom + 2, 0xFF55555E);
}

static int point_in_canvas(paint_state_t *st, int rel_x, int rel_y, int *out_cx, int *out_cy) {
    int zoom = zoom_levels[st->zoom_index];
    int cx = (rel_x - CANVAS_VIEW_X) / zoom;
    int cy = (rel_y - CANVAS_VIEW_Y) / zoom;

    if(rel_x < CANVAS_VIEW_X || rel_y < CANVAS_VIEW_Y || cx >= PAINT_CANVAS_W || cy >= PAINT_CANVAS_H) {
        return 0;
    }

    *out_cx = cx;
    *out_cy = cy;
    return 1;
}

/* rel_y here is relative to the tool strip's own top (row 1), not the
 * whole client area -- see paint_click, which subtracts the row offset
 * before calling this. */
static void handle_tool_strip_click(paint_state_t *st, int rel_x, int rel_y) {
    int bx = 4;
    int by = 2;
    int bh = PAINT_TOOL_STRIP_HEIGHT - 4;

    if(rel_y < by || rel_y >= by + bh) return;

    for(int i = 0; i < TOOL_COUNT; i++) {
        int x = bx + i * (TOOL_BUTTON_W + TOOL_BUTTON_GAP);
        if(rel_x >= x && rel_x < x + TOOL_BUTTON_W) {
            st->tool = (paint_tool_t)i;
            st->shape_active = 0;
            return;
        }
    }

    int zoom_x = bx + TOOL_COUNT * (TOOL_BUTTON_W + TOOL_BUTTON_GAP) + 10;
    if(rel_x >= zoom_x && rel_x < zoom_x + ZOOM_BUTTON_W) {
        st->zoom_index = (st->zoom_index + 1) % PAINT_ZOOM_LEVEL_COUNT;
    }
}

/* rel_y here is relative to the palette row's own top (row 2). */
static void handle_palette_row_click(paint_state_t *st, int rel_x, int rel_y) {
    int sy = (PAINT_TOOLBAR_HEIGHT - SWATCH_SIZE) / 2;

    if(rel_y < sy - 2 || rel_y > sy + SWATCH_SIZE + 2) return;

    int sx = 6;
    for(int i = 0; i < PALETTE_COUNT; i++) {
        int x = sx + i * (SWATCH_SIZE + SWATCH_GAP);
        if(rel_x >= x && rel_x < x + SWATCH_SIZE) {
            st->current_color = palette[i];
            return;
        }
    }

    if(rel_x >= PB_CLEAR_X && rel_x < PB_CLEAR_X + 56) {
        undo_push(st);
        memset(st->canvas, 0, PAINT_CANVAS_W * PAINT_CANVAS_H * sizeof(uint32_t));
        return;
    }
    if(rel_x >= PB_SAVE_X && rel_x < PB_SAVE_X + 56) {
        st->save_dialog_open = 1;
        st->status_message[0] = '\0';
        st->save_dir_depth = 0;
        save_dir_load_current(st);
        return;
    }
    if(rel_x >= PB_UNDO_X && rel_x < PB_UNDO_X + 48) { paint_undo(st); return; }
    if(rel_x >= PB_REDO_X && rel_x < PB_REDO_X + 48) { paint_redo(st); return; }
    if(rel_x >= PB_HUE_X && rel_x < PB_HUE_X + PB_HUE_W) {
        st->current_color = hue_color((rel_x - PB_HUE_X) * 359 / (PB_HUE_W - 1));
        return;
    }
}

static void handle_save_dialog_click(paint_state_t *st, int rel_x, int rel_y) {
    /* "Up" button, to the right of the path line -- only present/clickable
     * when not already at the root (see draw_save_dialog). */
    if(st->save_dir_depth > 0) {
        int up_y = DIALOG_PATH_Y - 3;
        if(rel_y >= up_y && rel_y < up_y + 16) {
            /* Reconstruct the same x range draw_save_dialog used: cw isn't
             * passed in here, but the dialog always fills self->w - 4, and
             * this click handler is only ever called with rel_x/rel_y
             * already relative to that same client area, so recompute the
             * button's left edge the same way rather than plumbing cw
             * through -- self->w isn't available here either, so instead
             * just treat any click on this row as "Up" (there's nothing
             * else on it to the left of the button in practice, since the
             * path text is short and the button sits far to the right). */
            if(rel_x > 0) {
                save_dir_go_up(st);
                return;
            }
        }
    }

    /* Folder list rows. */
    int list_y = DIALOG_FOLDER_LIST_Y;
    if(rel_y >= list_y && rel_y < list_y + PAINT_SAVE_DIR_VISIBLE_ROWS * DIALOG_FOLDER_ROW_H
       && st->save_dir_listing_loaded) {
        int clicked_row = (rel_y - list_y) / DIALOG_FOLDER_ROW_H;
        int row = 0;
        uint32_t shown = 0;
        for(uint32_t i = 0; i < st->save_dir_listing.num_entries; i++) {
            struct dir_entry *e = &st->save_dir_listing.entries[i];
            if(e->dir_attrs & LFN) continue;
            if(!(e->dir_attrs & DIRECTORY)) continue;
            if((int)shown < st->save_dir_scroll) { shown++; continue; }
            shown++;
            if(row == clicked_row) {
                int idx = (int)i;
                if(idx == st->save_dir_last_click_index && (pit_get_ticks() - st->save_dir_last_click_tick) < 12) {
                    save_dir_enter(st, e);
                    st->save_dir_last_click_index = -1;
                    st->save_dir_last_click_tick = -1000;
                }
                else {
                    st->save_dir_last_click_index = idx;
                    st->save_dir_last_click_tick = pit_get_ticks();
                }
                return;
            }
            row++;
        }
        return;
    }

    int fmt_x = 16, fmt_y = DIALOG_FORMAT_Y, fmt_w = 70;

    if(rel_y >= fmt_y && rel_y < fmt_y + DIALOG_FIELD_H) {
        if(rel_x >= fmt_x && rel_x < fmt_x + fmt_w) {
            st->format = PAINT_FORMAT_PNG;
            return;
        }
        if(rel_x >= fmt_x + fmt_w + 8 && rel_x < fmt_x + fmt_w + 8 + fmt_w) {
            st->format = PAINT_FORMAT_BMP;
            return;
        }
    }

    int btn_y = DIALOG_BUTTON_Y;
    if(rel_y >= btn_y && rel_y < btn_y + DIALOG_BUTTON_H) {
        if(rel_x >= 16 && rel_x < 16 + DIALOG_BUTTON_W) {
            do_save(st);
            return;
        }
        if(rel_x >= 16 + DIALOG_BUTTON_W + 12 && rel_x < 16 + DIALOG_BUTTON_W + 12 + DIALOG_BUTTON_W) {
            st->save_dialog_open = 0;
            st->status_message[0] = '\0';
            return;
        }
    }
}

static void paint_click(window_t *self, int rel_x, int rel_y) {
    paint_state_t *st = (paint_state_t *)self->user_data;
    if(!st) return;

    if(st->save_dialog_open) {
        handle_save_dialog_click(st, rel_x, rel_y);
        return;
    }

    if(rel_y < PAINT_TOOL_STRIP_HEIGHT) {
        handle_tool_strip_click(st, rel_x, rel_y);
        st->last_x = -1;
        st->last_y = -1;
        return;
    }
    if(rel_y < PAINT_TOOL_STRIP_HEIGHT + PAINT_TOOLBAR_HEIGHT) {
        handle_palette_row_click(st, rel_x, rel_y - PAINT_TOOL_STRIP_HEIGHT);
        st->last_x = -1;
        st->last_y = -1;
        return;
    }

    int cx, cy;
    if(!point_in_canvas(st, rel_x, rel_y, &cx, &cy)) return;

    if(st->tool == TOOL_PICK) {
        st->current_color = norm_px(st->canvas[cy * PAINT_CANVAS_W + cx]);
        return;
    }
    undo_push(st);
    if(st->tool == TOOL_FILL) {
        canvas_flood_fill(st, cx, cy, st->current_color);
        return;
    }

    if(tool_is_shape(st->tool)) {
        /* Shape tools don't touch the canvas until mouse-up -- just
         * latch the start point and let on_paint draw the live outline
         * preview (see paint_mouse_up for the actual commit). */
        st->shape_active = 1;
        st->shape_start_x = cx;
        st->shape_start_y = cy;
        st->shape_cur_x = cx;
        st->shape_cur_y = cy;
    }
    else {
        canvas_stamp_tool(st, cx, cy);
        st->last_x = cx;
        st->last_y = cy;
    }
}

static void paint_drag(window_t *self, int rel_x, int rel_y) {
    paint_state_t *st = (paint_state_t *)self->user_data;
    if(!st || st->save_dialog_open) return;
    if(st->tool == TOOL_FILL || st->tool == TOOL_PICK) return;      /* one-click tools */

    int cx, cy;
    int in_canvas = point_in_canvas(st, rel_x, rel_y, &cx, &cy);

    if(tool_is_shape(st->tool)) {
        /* Keep updating the preview endpoint even if the drag momentarily
         * leaves the canvas area -- clamp to the nearest in-bounds
         * canvas pixel instead of freezing the preview, so a drag that
         * overshoots the window edge still tracks sensibly. */
        if(in_canvas) {
            st->shape_cur_x = cx;
            st->shape_cur_y = cy;
        }
        return;
    }

    if(!in_canvas) {
        st->last_x = -1;
        st->last_y = -1;
        return;
    }

    if(st->last_x >= 0 && st->last_y >= 0) {
        canvas_draw_line(st, st->last_x, st->last_y, cx, cy);
    }
    else {
        canvas_stamp_tool(st, cx, cy);
    }

    st->last_x = cx;
    st->last_y = cy;
}

static void paint_mouse_up(window_t *self, int rel_x, int rel_y) {
    paint_state_t *st = (paint_state_t *)self->user_data;
    if(!st || st->save_dialog_open) return;
    if(!st->shape_active) return;

    int cx, cy;
    if(point_in_canvas(st, rel_x, rel_y, &cx, &cy)) {
        st->shape_cur_x = cx;
        st->shape_cur_y = cy;
    }
    /* Otherwise commit using the last in-bounds point tracked during the
     * drag (st->shape_cur_x/y), same clamping behavior as paint_drag. */

    canvas_commit_shape(st, st->shape_start_x, st->shape_start_y, st->shape_cur_x, st->shape_cur_y);
    st->shape_active = 0;
}

static void paint_key(window_t *self, char c) {
    paint_state_t *st = (paint_state_t *)self->user_data;
    if(!st) return;
    if(!st->save_dialog_open) {
        if(c == 26) paint_undo(st);                                   /* Ctrl+Z */
        else if(c == 25) paint_redo(st);                              /* Ctrl+Y */
        else if(c == 19) { st->save_dialog_open = 1; st->status_message[0] = '\0'; st->save_dir_depth = 0; save_dir_load_current(st); }   /* Ctrl+S */
        else if(c == ']') { if(st->size_adj < 10) st->size_adj++; }
        else if(c == '[') { if(st->size_adj > -2) st->size_adj--; }
        return;
    }

    if(c == '\n' || c == '\r') {
        do_save(st);
    }
    else if(c == '\b' || c == 127) {
        if(st->filename_len > 0) {
            st->filename_len--;
            st->filename[st->filename_len] = '\0';
        }
    }
    else if(c >= ' ' && c < 127) {
        /* Reject characters that are awkward/invalid in FAT32 short
         * names rather than let them silently corrupt the save. */
        if(c != '/' && c != '\\' && c != ':' && c != '*' && c != '?' && c != '"' &&
           st->filename_len < PAINT_FILENAME_MAX - 1) {
            st->filename[st->filename_len++] = c;
            st->filename[st->filename_len] = '\0';
        }
    }
}

static void paint_destroy(window_t *self) {
    paint_state_t *st = (paint_state_t *)self->user_data;
    if(!st) return;
    if(st->canvas) kfree(st->canvas);
    drop_list(st->undo, &st->undo_n);
    drop_list(st->redo, &st->redo_n);
    if(st->save_dir_listing_loaded) free_directory(master_fs, &st->save_dir_listing);
    kfree(st);
    self->user_data = NULL;
}

/* Which cursor to show over a given client-relative point: a crosshair
 * over the drawing canvas (precision pointing is the whole point of
 * that area), the pointing hand over the toolbar buttons, and an I-beam
 * over the save dialog's filename field while that dialog is open. */
static int paint_cursor_at(window_t *self, int rel_x, int rel_y) {
    paint_state_t *st = (paint_state_t *)self->user_data;
    if(!st) return CURSOR_DEFAULT;

    if(st->save_dialog_open) {
        /* Same x extent draw_save_dialog() uses for the filename field
         * (paint_paint() gives it cw = self->w - 4, and the field is
         * inset 16px from each side of that). */
        int field_x = 16;
        int field_w = (self->w - 4) - 32;
        if(rel_x >= field_x && rel_x < field_x + field_w
           && rel_y >= DIALOG_FIELD_Y && rel_y < DIALOG_FIELD_Y + DIALOG_FIELD_H) {
            return CURSOR_TEXT;
        }
        return CURSOR_DEFAULT;
    }

    if(rel_y < PAINT_TOOL_STRIP_HEIGHT + PAINT_TOOLBAR_HEIGHT) {
        return CURSOR_LINK; /* tool strip + palette/Clear/Save row */
    }

    int cx, cy;
    if(point_in_canvas(st, rel_x, rel_y, &cx, &cy)) {
        return CURSOR_PRECISION;
    }
    return CURSOR_DEFAULT;
}

void launch_paint(void) {
    /* Window height must be tall enough for both the normal
     * toolbar+canvas view AND the save dialog (which now includes a
     * folder-navigation list, taller than the original filename-only
     * version) -- whichever is bigger. The +40 padding budget covers
     * title bar and margins. */
    int canvas_view_h = PAINT_CANVAS_H + PAINT_TOOL_STRIP_HEIGHT + PAINT_TOOLBAR_HEIGHT + 44;
    int save_dialog_h = DIALOG_BUTTON_Y + DIALOG_BUTTON_H + 12 + 16 + 40;
    int win_h = canvas_view_h > save_dialog_h ? canvas_view_h : save_dialog_h;

    /* Window width must fit the wider of the canvas view and the tool
     * strip (10 labeled tool buttons + zoom control no longer fit in a
     * canvas-width-only window the way the old single-row, palette-only
     * toolbar did). */
    int canvas_view_w = PAINT_CANVAS_W + 16;
    int tool_strip_w = 4 + TOOL_COUNT * (TOOL_BUTTON_W + TOOL_BUTTON_GAP) + 10 + ZOOM_BUTTON_W + 16;
    int win_w = canvas_view_w > tool_strip_w ? canvas_view_w : tool_strip_w;

    window_t *win = wm_create_window("Paint", 320, 160,
                                      win_w, win_h,
                                      0xFF1E1E22);
    if(!win) return;

    paint_state_t *st = (paint_state_t *)kmalloc(sizeof(paint_state_t));
    memset(st, 0, sizeof(paint_state_t));

    st->canvas = (uint32_t *)kmalloc(PAINT_CANVAS_W * PAINT_CANVAS_H * sizeof(uint32_t));
    memset(st->canvas, 0, PAINT_CANVAS_W * PAINT_CANVAS_H * sizeof(uint32_t));

    st->current_color = 0xFF000000;
    st->tool = TOOL_PENCIL;
    st->zoom_index = 0; /* zoom_levels[0] == 1x */
    st->last_x = -1;
    st->last_y = -1;
    st->format = PAINT_FORMAT_PNG;
    fastcp(st->filename, "drawing", 8);
    st->filename_len = 7;
    st->save_dir_last_click_index = -1;
    st->save_dir_last_click_tick = -1000;

    win->user_data = st;
    win->static_content = 1;   /* only changes on input: lets the desktop idle */
    win->on_paint = paint_paint;
    win->on_click = paint_click;
    win->on_drag = paint_drag;
    win->cursor_at = paint_cursor_at;
    win->on_mouse_up = paint_mouse_up;
    win->on_key = paint_key;
    win->on_destroy = paint_destroy;
}
