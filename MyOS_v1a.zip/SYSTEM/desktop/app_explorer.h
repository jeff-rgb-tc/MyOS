#ifndef APP_EXPLORER_H
#define APP_EXPLORER_H

/* Launches a functional file explorer window: real FAT32 directory
 * listing, click-to-select, double-click to enter a folder, and an "Up"
 * button to go back to the parent directory. */
void launch_explorer(void);

/* Same, but opens straight to the My PC disk-info view -- used by the
 * desktop's My PC icon (see desktop.c). */
void launch_explorer_mypc(void);

/* Same, but opens straight to the Recycle Bin folder -- used by the
 * desktop's Recycle Bin icon (see desktop.c). */
void launch_explorer_recycle_bin(void);

/* Opens a new Explorer window showing the folder at the given absolute
 * path (falls back to the root if the path does not exist). */
void launch_explorer_at(const char *path);

#endif
