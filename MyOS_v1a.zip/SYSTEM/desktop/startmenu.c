#include "stdint.h"
#include "stddef.h"
#include "startmenu.h"
#include "taskbar.h"
#include "window.h"
#include "gfx.h"
#include "apps.h"
#include "common.h"
#include "kernio.h"
#include "power.h"
#include "mouse.h"
#include "desktop.h"
#include "settings.h"
#include "png.h"
#include "kheap.h"
#include "pit.h"
#include "system_icons.h"
#include "cursor_set.h"
#include "context_menu.h"
#include "shortcut.h"
#include "fileops.h"
#include "desktop_items.h"
#include "keyboard.h"
#include "app_explorer.h"

/* ====================================================================== */
/* Model: a tree of folders, apps and .lnk shortcuts                       */
/* ====================================================================== */
#define SM_MAX_NODES 200
#define SM_MAX_ROWS  260
#define PROGRAMS_DIR "/Start Menu/Programs"
#define PINNED_DIR   "/Start Menu/Pinned"      /* .lnk files shown in the "Pinned" block at the top */

typedef struct {
    char name[40];
    char path[72];             /* folders: "Accessories/Tools" (identity for expand state) */
    int parent;                /* node index or -1 */
    uint8_t is_folder;
    uint8_t expanded;
    app_entry_t *app;          /* registry app, or NULL */
    char target[SC_TARGET_MAX];/* shortcuts: what to open */
    char lnk_path[96];         /* shortcuts: the .lnk file (for "remove") */
    const uint32_t *icon_px;   /* cached icon */
    int icon_w, icon_h;
    uint8_t icon_ready;
    uint8_t pinned;            /* a .lnk from PINNED_DIR: listed in the "Pinned" block */
} sm_node_t;

static sm_node_t nodes[SM_MAX_NODES];
static int node_count = 0;

#define EXPANDED_MAX 24
static char expanded_paths[EXPANDED_MAX][72];
static int expanded_count = 0;

static int is_expanded_path(const char *p) {
    for(int i = 0; i < expanded_count; i++) if(strcasecmp(expanded_paths[i], p) == 0) return 1;
    return 0;
}
static void set_expanded_path(const char *p, int on) {
    for(int i = 0; i < expanded_count; i++) {
        if(strcasecmp(expanded_paths[i], p) == 0) {
            if(!on) { for(int j = i; j < expanded_count - 1; j++) memcpy(expanded_paths[j], expanded_paths[j + 1], 72); expanded_count--; }
            return;
        }
    }
    if(on && expanded_count < EXPANDED_MAX) { int n = 0; while(p[n] && n < 71) { expanded_paths[expanded_count][n] = p[n]; n++; } expanded_paths[expanded_count][n] = '\0'; expanded_count++; }
}

static void copy_str(char *dst, int max, const char *src) {
    int i = 0;
    while(src && src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

static int add_node(const char *name, int parent, int is_folder) {
    if(node_count >= SM_MAX_NODES) return -1;
    sm_node_t *n = &nodes[node_count];
    memset(n, 0, sizeof(*n));
    copy_str(n->name, sizeof(n->name), name);
    n->parent = parent;
    n->is_folder = (uint8_t)is_folder;
    return node_count++;
}

/* Finds or creates the folder chain for "A/B/C" and returns the last node. */
static int ensure_folder(const char *path) {
    int parent = -1;
    char built[72]; built[0] = '\0'; int blen = 0;
    const char *p = path;
    while(*p) {
        char part[40]; int n = 0;
        while(*p && *p != '/' && n < 39) part[n++] = *p++;
        part[n] = '\0';
        while(*p == '/') p++;
        if(!n) continue;
        if(blen > 0 && blen < 70) built[blen++] = '/';
        for(int i = 0; i < n && blen < 70; i++) built[blen++] = part[i];
        built[blen] = '\0';

        int found = -1;
        for(int i = 0; i < node_count; i++) {
            if(nodes[i].is_folder && nodes[i].parent == parent && strcasecmp(nodes[i].name, part) == 0) { found = i; break; }
        }
        if(found < 0) {
            found = add_node(part, parent, 1);
            if(found < 0) return parent;
            copy_str(nodes[found].path, sizeof(nodes[found].path), built);
            nodes[found].expanded = (uint8_t)is_expanded_path(built);
        }
        parent = found;
    }
    return parent;
}

static void scan_programs(const char *dir, int parent_folder, int depth) {
    if(depth > 3) return;
    struct directory d;
    if(!fsu_open_dir(dir, &d)) return;
    for(uint32_t i = 0; i < d.num_entries && node_count < SM_MAX_NODES - 1; i++) {
        struct dir_entry *e = &d.entries[i];
        if(!e->name || (e->dir_attrs & LFN) || e->name[0] == '.' || (e->dir_attrs & 0x08)) continue;
        char full[FSU_PATH_MAX];
        fileops_join(dir, e->name, full, sizeof(full));
        if(e->dir_attrs & DIRECTORY) {
            /* chain relative to the parent folder's path */
            char rel[72];
            if(parent_folder >= 0) fileops_join(nodes[parent_folder].path, e->name, rel, sizeof(rel));
            else copy_str(rel, sizeof(rel), e->name);
            int f = ensure_folder(rel);
            if(f >= 0) scan_programs(full, f, depth + 1);
        }
        else {
            const char *dot = NULL;
            for(const char *c = e->name; *c; c++) if(*c == '.') dot = c;
            if(!dot || strcasecmp(dot, ".lnk") != 0) continue;
            shortcut_t sc;
            if(!shortcut_load(full, &sc)) continue;
            int n = add_node(sc.name, parent_folder, 0);
            if(n < 0) break;
            copy_str(nodes[n].target, sizeof(nodes[n].target), sc.target);
            copy_str(nodes[n].lnk_path, sizeof(nodes[n].lnk_path), full);
        }
    }
    free_directory(master_fs, &d);
}

/* Pinned items: the .lnk files in /Start Menu/Pinned, shown at the very top. */
static void scan_pinned(void) {
    struct directory d;
    if(!fsu_open_dir(PINNED_DIR, &d)) return;
    for(uint32_t i = 0; i < d.num_entries && node_count < SM_MAX_NODES - 1; i++) {
        struct dir_entry *e = &d.entries[i];
        if(!e->name || (e->dir_attrs & LFN) || (e->dir_attrs & (DIRECTORY | 0x08)) || e->name[0] == '.') continue;
        const char *dot = NULL;
        for(const char *c = e->name; *c; c++) if(*c == '.') dot = c;
        if(!dot || strcasecmp(dot, ".lnk") != 0) continue;
        char full[FSU_PATH_MAX];
        fileops_join(PINNED_DIR, e->name, full, sizeof(full));
        shortcut_t sc;
        if(!shortcut_load(full, &sc)) continue;
        int n = add_node(sc.name, -1, 0);
        if(n < 0) break;
        copy_str(nodes[n].target, sizeof(nodes[n].target), sc.target);
        copy_str(nodes[n].lnk_path, sizeof(nodes[n].lnk_path), full);
        nodes[n].pinned = 1;
    }
    free_directory(master_fs, &d);
}

static void rebuild_model(void) {
    node_count = 0;
    for(int i = 0; i < apps_count(); i++) {
        app_entry_t *a = apps_get(i);
        if(!a) continue;
        int parent = a->folder[0] ? ensure_folder(a->folder) : -1;
        int n = add_node(a->name, parent, 0);
        if(n < 0) break;
        nodes[n].app = a;
    }
    scan_programs(PROGRAMS_DIR, -1, 0);
    scan_pinned();
}

/* ====================================================================== */
/* View state                                                              */
/* ====================================================================== */
#define PANEL_W 392
#define RAIL_W 46
#define HEADER_H 58
#define ROW_H 38
#define HEAD_ROW_H 26
#define ICON_PX 26
#define SB_W 6

static uint8_t open_flag = 0;
static int scroll_px = 0;
static int sel_row = -1;
static char query[28];
static int qlen = 0;
static uint8_t power_open = 0;
static uint8_t thumb_drag = 0;
static int thumb_grab = 0;

typedef struct { int node; char letter; int depth; int y; int h; } sm_row_t;   /* node == -1: letter header */
static sm_row_t rows[SM_MAX_ROWS];
static int row_count = 0;
static int content_h = 0;

static char upper_of(char c) { return (c >= 'a' && c <= 'z') ? (char)(c - 32) : c; }

static int name_less(int a, int b) { return strcasecmp(nodes[a].name, nodes[b].name) < 0; }

static void add_row(int node, char letter, int depth) {
    if(row_count >= SM_MAX_ROWS) return;
    rows[row_count].node = node; rows[row_count].letter = letter; rows[row_count].depth = depth;
    rows[row_count].h = node < 0 ? HEAD_ROW_H : ROW_H;
    row_count++;
}

static void emit_children(int parent, int depth) {
    int idx[SM_MAX_NODES], n = 0;
    for(int i = 0; i < node_count; i++) if(nodes[i].parent == parent && !nodes[i].pinned) idx[n++] = i;
    for(int i = 1; i < n; i++) {                       /* insertion sort by name */
        int key = idx[i], j = i - 1;
        while(j >= 0 && name_less(key, idx[j])) { idx[j + 1] = idx[j]; j--; }
        idx[j + 1] = key;
    }
    char last = 0;
    for(int k = 0; k < n; k++) {
        int i = idx[k];
        if(depth == 0) {
            char L = upper_of(nodes[i].name[0]);
            if(!(L >= 'A' && L <= 'Z')) L = '#';
            if(L != last) { add_row(-1, L, 0); last = L; }
        }
        add_row(i, 0, depth);
        if(nodes[i].is_folder && nodes[i].expanded) emit_children(i, depth + 1);
    }
}

static int contains_nocase(const char *hay, const char *needle) {
    int hn = (int)strlen(hay), nn = (int)strlen(needle);
    for(int i = 0; i + nn <= hn; i++) {
        int ok = 1;
        for(int j = 0; j < nn && ok; j++) if(upper_of(hay[i + j]) != upper_of(needle[j])) ok = 0;
        if(ok) return 1;
    }
    return 0;
}

static void build_rows(void) {
    row_count = 0;
    if(qlen == 0) {
        /* "Pinned" block first (letter value 1 = the \"Pinned\" header), then the A-Z list. */
        int pin[SM_MAX_NODES], np = 0;
        for(int i = 0; i < node_count; i++) if(nodes[i].pinned) pin[np++] = i;
        for(int i = 1; i < np; i++) {
            int key = pin[i], j = i - 1;
            while(j >= 0 && name_less(key, pin[j])) { pin[j + 1] = pin[j]; j--; }
            pin[j + 1] = key;
        }
        if(np) { add_row(-1, 1, 0); for(int k = 0; k < np; k++) add_row(pin[k], 0, 0); }
        emit_children(-1, 0);
    }
    else {
        int idx[SM_MAX_NODES], n = 0;
        for(int i = 0; i < node_count; i++) if(!nodes[i].is_folder && !nodes[i].pinned && contains_nocase(nodes[i].name, query)) idx[n++] = i;
        for(int i = 1; i < n; i++) {
            int key = idx[i], j = i - 1;
            while(j >= 0 && name_less(key, idx[j])) { idx[j + 1] = idx[j]; j--; }
            idx[j + 1] = key;
        }
        for(int k = 0; k < n; k++) add_row(idx[k], 0, 0);
    }
    int y = 0;
    for(int i = 0; i < row_count; i++) { rows[i].y = y; y += rows[i].h; }
    content_h = y;
}

static uint32_t open_t0 = 0;
#define SM_ANIM_MS 140

/* Pixels the panel is still below its final position (0 once the open animation is over). */
static int anim_offset(void) {
    if(!open_flag || !settings_current()->animations) return 0;
    uint32_t el = pit_get_ms() - open_t0;
    if(el >= SM_ANIM_MS) return 0;
    int inv = 1000 - (int)(el * 1000 / SM_ANIM_MS);
    int ease = 1000 - (int)(((uint32_t)inv * (uint32_t)inv * (uint32_t)inv) / 1000000u);
    return 34 - (34 * ease) / 1000;
}

int startmenu_animating(void) { return open_flag && settings_current()->animations && (pit_get_ms() - open_t0) < SM_ANIM_MS; }

typedef struct { int x, y, w, h; int list_x, list_w, list_top, list_bottom; } geo_t;

static void geometry(geo_t *g) {
    int wx, wy, ww, wh;
    taskbar_work_area(&wx, &wy, &ww, &wh);          /* the screen minus the taskbar, wherever it is docked */
    int avail = wh - 8;
    g->h = avail < 620 ? avail : 620;
    if(g->h < 240) g->h = 240;
    g->w = PANEL_W;
    int dock = taskbar_get_dock();
    g->x = (dock == TASKBAR_DOCK_RIGHT) ? wx + ww - PANEL_W - 2 : wx + 2;
    g->y = (dock == TASKBAR_DOCK_TOP) ? wy + 2 : wy + wh - 2 - g->h;
    { int off = anim_offset(); g->y += (dock == TASKBAR_DOCK_TOP) ? -off : off; }
    g->list_x = g->x + RAIL_W;
    g->list_w = g->w - RAIL_W;
    g->list_top = g->y + HEADER_H;
    g->list_bottom = g->y + g->h - 8;
}

static int max_scroll(const geo_t *g) {
    int view = g->list_bottom - g->list_top;
    return content_h > view ? content_h - view : 0;
}

static void clamp_scroll(const geo_t *g) {
    int m = max_scroll(g);
    if(scroll_px > m) scroll_px = m;
    if(scroll_px < 0) scroll_px = 0;
}

static void ensure_row_visible(int r) {
    geo_t g; geometry(&g);
    if(r < 0 || r >= row_count) return;
    int view = g.list_bottom - g.list_top;
    if(rows[r].y < scroll_px) scroll_px = rows[r].y;
    if(rows[r].y + rows[r].h > scroll_px + view) scroll_px = rows[r].y + rows[r].h - view;
    clamp_scroll(&g);
}

/* ====================================================================== */
/* Open / close                                                            */
/* ====================================================================== */
int startmenu_is_open(void) { return open_flag; }

void startmenu_close(void) {
    open_flag = 0; power_open = 0; thumb_drag = 0;
    qlen = 0; query[0] = '\0';
}

void startmenu_toggle(void) {
    if(open_flag) { startmenu_close(); return; }
    rebuild_model();
    qlen = 0; query[0] = '\0';
    scroll_px = 0; sel_row = -1; power_open = 0; thumb_drag = 0;
    open_flag = 1;
    open_t0 = pit_get_ms();
    build_rows();
}

/* ====================================================================== */
/* Icons                                                                   */
/* ====================================================================== */
static void resolve_icon(sm_node_t *n) {
    if(n->icon_ready) return;
    n->icon_ready = 1;
    ditem_image_t im = { NULL, 0, 0 };
    if(n->is_folder) im = ditems_icon_for_path("", 1);
    else if(n->app) {
        app_icon_t *ic = apps_get_icon(n->app);
        if(ic && ic->pixels) { im.pixels = ic->pixels; im.w = (int)ic->width; im.h = (int)ic->height; }
    }
    else {
        shortcut_t sc; copy_str(sc.name, sizeof(sc.name), n->name); copy_str(sc.target, sizeof(sc.target), n->target);
        app_entry_t *a = shortcut_target_app(&sc);
        if(a) {
            app_icon_t *ic = apps_get_icon(a);
            if(ic && ic->pixels) { im.pixels = ic->pixels; im.w = (int)ic->width; im.h = (int)ic->height; }
        }
        else {
            int is_dir = 0;
            fsu_stat(n->target, &is_dir, NULL, NULL, NULL);
            im = ditems_icon_for_path(n->target, is_dir);
        }
    }
    n->icon_px = im.pixels; n->icon_w = im.w; n->icon_h = im.h;
}

/* The power-menu glyphs are black artwork with transparency. A light copy
 * (same alpha, white colour) is made once so they read on the dark panel
 * without any backing tile. */
static uint32_t *tinted[3];
static int tinted_w[3], tinted_h[3];
static const uint32_t *light_icon(int which, system_icon_id_t id, int *w, int *h) {
    if(!tinted[which]) {
        png_image_t *src = system_icon_get(id);
        if(!src || !src->pixels) return NULL;
        uint32_t cnt = src->width * src->height;
        tinted[which] = (uint32_t *)kmalloc(cnt * 4);
        if(!tinted[which]) return NULL;
        for(uint32_t i = 0; i < cnt; i++) tinted[which][i] = (src->pixels[i] & 0xFF000000u) | 0x00F2F2F5u;
        tinted_w[which] = (int)src->width; tinted_h[which] = (int)src->height;
    }
    *w = tinted_w[which]; *h = tinted_h[which];
    return tinted[which];
}

/* Avatar from Settings, same source the old menu header used. */
static png_image_t avatar;
static uint8_t avatar_loaded = 0;
static char avatar_path_cached[SETTINGS_STRING_MAX];

static void ensure_avatar(void) {
    settings_t *s = settings_current();
    if(strcmp(avatar_path_cached, s->avatar_path) == 0 && (avatar_loaded || !s->avatar_path[0])) return;
    if(avatar_loaded) { png_free(&avatar); avatar_loaded = 0; }
    copy_str(avatar_path_cached, sizeof(avatar_path_cached), s->avatar_path);
    if(avatar_path_cached[0]) avatar_loaded = png_load_from_file(avatar_path_cached, &avatar) ? 1 : 0;
}

/* ====================================================================== */
/* Drawing                                                                 */
/* ====================================================================== */
#define C_PANEL   0xFF202024
#define C_RAIL    0xFF18181B
#define C_HOVER   0x2EFFFFFF
#define C_SEL     0x40FFFFFF
#define C_TEXT    0xFFF2F2F5
#define C_DIM     0xFFA0A0AA
#define C_ACCENT  0xFF4CC2FF

static void chevron(int cx, int cy, int down, uint32_t col) {
    if(down) {
        gfx_draw_line_thick(cx - 4, cy - 2, cx, cy + 2, 1.6, col);
        gfx_draw_line_thick(cx, cy + 2, cx + 4, cy - 2, 1.6, col);
    }
    else {
        gfx_draw_line_thick(cx - 2, cy - 4, cx + 2, cy, 1.6, col);
        gfx_draw_line_thick(cx + 2, cy, cx - 2, cy + 4, 1.6, col);
    }
}

typedef struct { int x, y, w, h; } rect_t;
static rect_t rail_button(const geo_t *g, int from_bottom) {
    rect_t r = { g->x + 5, g->y + g->h - 8 - (from_bottom + 1) * 40, RAIL_W - 10, 36 };
    return r;
}
enum { RB_POWER = 0, RB_SETTINGS = 1, RB_DOCS = 2 };

static rect_t power_panel(const geo_t *g) {
    rect_t pb = rail_button(g, RB_POWER);
    rect_t r = { pb.x, pb.y - 3 * 38 - 16, 176, 3 * 38 + 10 };
    if(r.y < g->y + 4) r.y = g->y + 4;
    return r;
}

static int in_rect(int x, int y, rect_t r) { return x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h; }

static void draw_rail_glyph(int which, rect_t r, uint32_t col) {
    int cx = r.x + r.w / 2, cy = r.y + r.h / 2;
    if(which == RB_POWER) {
        /* ring with a gap at the top and a stem */
        for(int a = 0; a < 360; a += 12) {
            if(a > 320 || a < 40) continue;
            double t = a * 0.017453292519943295, s, c;
            __asm__("fsincos" : "=t"(c), "=u"(s) : "0"(t));
            double t2 = (a + 12) * 0.017453292519943295, s2, c2;
            __asm__("fsincos" : "=t"(c2), "=u"(s2) : "0"(t2));
            gfx_draw_line_thick(cx + s * 7, cy - c * 7, cx + s2 * 7, cy - c2 * 7, 1.8, col);
        }
        gfx_draw_line_thick(cx, cy - 9, cx, cy - 1, 1.9, col);
    }
    else if(which == RB_SETTINGS) {
        for(int a = 0; a < 360; a += 45) {
            double t = a * 0.017453292519943295, s, c;
            __asm__("fsincos" : "=t"(c), "=u"(s) : "0"(t));
            gfx_draw_line_thick(cx + s * 6, cy - c * 6, cx + s * 9, cy - c * 9, 2.6, col);
        }
        gfx_fill_circle(cx, cy, 7, col);
        gfx_fill_circle(cx, cy, 3, C_RAIL);
    }
    else {
        ditem_image_t im = ditems_icon_for_path("", 1);
        if(im.pixels) gfx_blit_scaled_argb_alpha(cx - 11, cy - 11, 22, 22, (uint32_t *)im.pixels, (uint32_t)im.w, (uint32_t)im.h);
    }
}

static void thumb_geometry(const geo_t *g, int *ty, int *th) {
    int track_h = g->list_bottom - g->list_top;
    int m = max_scroll(g);
    int h = m > 0 ? (track_h * track_h) / (track_h + m) : track_h;
    if(h < 28) h = 28;
    if(h > track_h) h = track_h;
    *th = h;
    *ty = g->list_top + (m > 0 ? (scroll_px * (track_h - h)) / m : 0);
}

void startmenu_draw(void) {
    if(!open_flag) return;
    geo_t g; geometry(&g);
    mouse_state_t *ms = mouse_get_state();
    build_rows();
    clamp_scroll(&g);

    gfx_draw_shadow(g.x, g.y, g.w, g.h, 10, 24, 6, 110);
    gfx_fill_rounded_rect(g.x, g.y, g.w, g.h, 10, C_PANEL);

    /* ---- rows (clipped by repainting the margins afterwards) ---- */
    int view_top = g.list_top, view_bot = g.list_bottom;
    int hover_row = -1;
    int sb_visible = max_scroll(&g) > 0;
    int row_right = g.list_x + g.list_w - (sb_visible ? SB_W + 8 : 6);

    for(int r = 0; r < row_count; r++) {
        int y = view_top + rows[r].y - scroll_px;
        if(y + rows[r].h <= view_top || y >= view_bot) continue;
        if(rows[r].node < 0) {
            char s[2] = { rows[r].letter, '\0' };
            gfx_draw_string(g.list_x + 16, y + (HEAD_ROW_H - 16) / 2 + 2, rows[r].letter == 1 ? "Pinned" : s, C_ACCENT);
            continue;
        }
        sm_node_t *n = &nodes[rows[r].node];
        int rx = g.list_x + 6, rw = row_right - rx;
        int inside = ms->x >= rx && ms->x < rx + rw && ms->y >= y && ms->y < y + rows[r].h && ms->y >= view_top && ms->y < view_bot;
        if(inside) hover_row = r;
        if(inside || r == sel_row) gfx_blend_rounded_rect(rx, y + 1, rw, rows[r].h - 2, 6, r == sel_row ? C_SEL : C_HOVER);

        int indent = rows[r].depth * 18;
        int tx = rx + 10 + indent;
        if(n->is_folder) chevron(tx + 4, y + rows[r].h / 2, n->expanded, C_DIM);
        int ix = tx + 16;
        resolve_icon(n);
        if(n->icon_px) gfx_blit_scaled_argb_alpha(ix, y + (rows[r].h - ICON_PX) / 2, ICON_PX, ICON_PX, (uint32_t *)n->icon_px, (uint32_t)n->icon_w, (uint32_t)n->icon_h);
        else gfx_fill_rounded_rect(ix, y + (rows[r].h - ICON_PX) / 2, ICON_PX, ICON_PX, 6, 0xFF4A4A54);

        char label[40]; copy_str(label, sizeof(label), n->name);
        int max_chars = (row_right - (ix + ICON_PX + 10) - 6) / GFX_CHAR_COLS;
        int len = (int)strlen(label);
        if(len > max_chars && max_chars > 3) { label[max_chars - 2] = '.'; label[max_chars - 1] = '.'; label[max_chars] = '\0'; }
        gfx_draw_string(ix + ICON_PX + 10, y + (rows[r].h - 16) / 2, label, C_TEXT);
    }
    if(row_count == 0) {
        const char *msg = qlen ? "No results" : "No apps";
        gfx_draw_string(g.list_x + 18, view_top + 14, msg, C_DIM);
    }

    /* ---- repaint header and bottom margin over any overflowing rows ---- */
    gfx_blend_rounded_rect_ex(g.list_x, g.y, g.list_w, HEADER_H, 10, C_PANEL | 0xFF000000u, GFX_CORNER_TR);
    gfx_blend_rounded_rect_ex(g.list_x, g.list_bottom, g.list_w, g.y + g.h - g.list_bottom, 10, C_PANEL | 0xFF000000u, GFX_CORNER_BR);

    /* ---- header: avatar + name, or the search box ---- */
    if(qlen == 0) {
        ensure_avatar();
        int ax = g.list_x + 14, ay = g.y + (HEADER_H - 34) / 2;
        if(avatar_loaded && avatar.pixels) gfx_blit_scaled_argb_alpha(ax, ay, 34, 34, avatar.pixels, avatar.width, avatar.height);
        else gfx_fill_circle(ax + 17, ay + 17, 17, 0xFF606068);
        settings_t *s = settings_current();
        gfx_draw_string(ax + 34 + 10, g.y + HEADER_H / 2 - 17, s->username[0] ? s->username : "User", C_TEXT);
        gfx_draw_string(ax + 34 + 10, g.y + HEADER_H / 2 + 1, "Type to search apps", 0xFF7C7C86);
    }
    else {
        int bx = g.list_x + 10, by = g.y + 11, bw = g.list_w - 20;
        gfx_fill_rounded_rect(bx, by, bw, 36, 8, 0xFF2C2C32);
        gfx_draw_rounded_outline(bx, by, bw, 36, 8, 0xFF4CC2FF);
        int maxc = (bw - 24) / GFX_CHAR_COLS;
        const char *shown = query + (qlen > maxc ? qlen - maxc : 0);
        gfx_draw_string(bx + 12, by + 10, shown, C_TEXT);
        int caret = (qlen > maxc ? maxc : qlen) * GFX_CHAR_COLS;
        if((pit_get_ms() / 500) % 2 == 0) gfx_fill_rect(bx + 12 + caret, by + 9, 1, 18, C_ACCENT);
    }
    gfx_blend_rounded_rect_ex(g.list_x + 8, g.y + HEADER_H - 1, g.list_w - 16, 1, 0, 0x1CFFFFFF, 0);

    /* ---- scroll bar: thin, widens when the pointer is near it ---- */
    if(sb_visible) {
        int ty, th; thumb_geometry(&g, &ty, &th);
        int sbx = g.x + g.w - SB_W - 6;
        int near_bar = thumb_drag || (ms->x >= sbx - 10 && ms->x < g.x + g.w && ms->y >= g.list_top && ms->y < g.list_bottom);
        int w = near_bar ? SB_W + 3 : SB_W - 2;
        int x = g.x + g.w - w - 5;
        gfx_blend_rounded_rect(x, g.list_top, w, g.list_bottom - g.list_top, w / 2, 0x16FFFFFF);
        gfx_fill_rounded_rect(x, ty, w, th, w / 2, thumb_drag ? 0xFFB4B4BE : (near_bar ? 0xFF9A9AA4 : 0xFF6E6E78));
    }

    /* ---- rail ---- */
    gfx_blend_rounded_rect_ex(g.x, g.y, RAIL_W, g.h, 10, C_RAIL | 0xFF000000u, GFX_CORNER_TL | GFX_CORNER_BL);
    for(int b = 0; b < 3; b++) {
        rect_t r = rail_button(&g, b);
        int hot = in_rect(ms->x, ms->y, r) || (b == RB_POWER && power_open);
        if(hot) gfx_blend_rounded_rect(r.x, r.y, r.w, r.h, 6, C_HOVER);
        draw_rail_glyph(b, r, C_TEXT);
    }
    gfx_draw_rounded_outline(g.x, g.y, g.w, g.h, 10, 0x30FFFFFF);

    /* ---- power flyout ---- */
    if(power_open) {
        rect_t p = power_panel(&g);
        gfx_draw_shadow(p.x, p.y, p.w, p.h, 8, 14, 4, 100);
        gfx_fill_rounded_rect(p.x, p.y, p.w, p.h, 8, 0xFF2A2A30);
        gfx_draw_rounded_outline(p.x, p.y, p.w, p.h, 8, 0x30FFFFFF);
        static const char *labels[3] = { "Sleep", "Restart", "Shut down" };
        static const system_icon_id_t ids[3] = { SYSTEM_ICON_SLEEP, SYSTEM_ICON_RESTART, SYSTEM_ICON_SHUTDOWN };
        for(int i = 0; i < 3; i++) {
            int iy = p.y + 5 + i * 38;
            if(ms->x >= p.x + 4 && ms->x < p.x + p.w - 4 && ms->y >= iy && ms->y < iy + 36)
                gfx_blend_rounded_rect(p.x + 4, iy, p.w - 8, 36, 6, C_HOVER);
            int w, h;
            const uint32_t *px = light_icon(i, ids[i], &w, &h);
            if(px) gfx_blit_scaled_argb_alpha(p.x + 12, iy + 6, 24, 24, (uint32_t *)px, (uint32_t)w, (uint32_t)h);
            gfx_draw_string(p.x + 46, iy + 10, labels[i], C_TEXT);
        }
    }
    (void)hover_row;
}

/* ====================================================================== */
/* Actions                                                                 */
/* ====================================================================== */
static void launch_node(int ni) {
    sm_node_t *n = &nodes[ni];
    startmenu_close();
    if(n->app) { apps_launch(n->app); return; }
    shortcut_t sc;
    copy_str(sc.name, sizeof(sc.name), n->name);
    copy_str(sc.target, sizeof(sc.target), n->target);
    desktop_working_for_ms(1000);
    shortcut_open(&sc);
}

static void toggle_folder(int ni) {
    nodes[ni].expanded = !nodes[ni].expanded;
    set_expanded_path(nodes[ni].path, nodes[ni].expanded);
    build_rows();
}

static void activate_row(int r) {
    if(r < 0 || r >= row_count || rows[r].node < 0) return;
    int ni = rows[r].node;
    if(nodes[ni].is_folder) toggle_folder(ni); else launch_node(ni);
}

static int row_at(const geo_t *g, int x, int y) {
    if(x < g->list_x || x >= g->list_x + g->list_w || y < g->list_top || y >= g->list_bottom) return -1;
    int rel = y - g->list_top + scroll_px;
    for(int r = 0; r < row_count; r++) if(rel >= rows[r].y && rel < rows[r].y + rows[r].h) return rows[r].node >= 0 ? r : -1;
    return -1;
}

static void do_power(int which) {
    startmenu_close();
    if(which == 0) desktop_enter_sleep();                      /* returns when woken */
    else if(which == 1) { desktop_show_transition_screen("Restarting..."); power_reboot(); }
    else { desktop_show_transition_screen("Shutting down..."); power_shutdown(); }
}

int startmenu_click(int x, int y) {
    if(!open_flag) return 0;
    geo_t g; geometry(&g);

    if(power_open) {
        rect_t p = power_panel(&g);
        if(in_rect(x, y, p)) {
            int i = (y - p.y - 5) / 38;
            if(i >= 0 && i < 3) do_power(i);
            return 1;
        }
        power_open = 0;                      /* click elsewhere just closes the flyout */
        if(!(x >= g.x && x < g.x + g.w && y >= g.y && y < g.y + g.h)) { startmenu_close(); return 0; }
    }

    if(!(x >= g.x && x < g.x + g.w && y >= g.y && y < g.y + g.h)) { startmenu_close(); return 0; }

    /* rail */
    if(x < g.x + RAIL_W) {
        for(int b = 0; b < 3; b++) {
            rect_t r = rail_button(&g, b);
            if(!in_rect(x, y, r)) continue;
            if(b == RB_POWER) { power_open = 1; }
            else if(b == RB_SETTINGS) { startmenu_close(); for(int i = 0; i < apps_count(); i++) { app_entry_t *a = apps_get(i); if(a && strcasecmp(a->name, "Settings") == 0) { apps_launch(a); break; } } }
            else { startmenu_close(); launch_explorer_at("/Users/User"); }
            return 1;
        }
        return 1;
    }

    /* scroll bar */
    if(max_scroll(&g) > 0 && x >= g.x + g.w - SB_W - 16 && y >= g.list_top && y < g.list_bottom) {
        int ty, th; thumb_geometry(&g, &ty, &th);
        if(y >= ty && y < ty + th) { thumb_drag = 1; thumb_grab = y - ty; }
        else { scroll_px += (y < ty ? -1 : 1) * (g.list_bottom - g.list_top - 40); clamp_scroll(&g); }
        return 1;
    }

    int r = row_at(&g, x, y);
    if(r >= 0) { sel_row = r; activate_row(r); }
    return 1;
}

void startmenu_motion(int x, int y) {
    (void)x;
    if(!open_flag || !thumb_drag) return;
    geo_t g; geometry(&g);
    int ty, th; thumb_geometry(&g, &ty, &th);
    int track = g.list_bottom - g.list_top - th;
    int m = max_scroll(&g);
    if(track > 0 && m > 0) {
        int pos = y - thumb_grab - g.list_top;
        if(pos < 0) pos = 0;
        if(pos > track) pos = track;
        scroll_px = (pos * m) / track;
    }
}

void startmenu_mouse_up(void) { thumb_drag = 0; }

void startmenu_scroll(int rows_delta) {
    if(!open_flag) return;
    geo_t g; geometry(&g);
    scroll_px += rows_delta * ROW_H * 3 / 2 * 2;
    clamp_scroll(&g);
}

/* ---- right click: create a desktop shortcut ---- */
static void action_sm_open(void *u) { launch_node((int)(uint32_t)u); }
/* The .lnk target for a node: "app:Name" (built-in), the .app path, or its own target. */
static void node_target(const sm_node_t *n, char *target) {
    if(n->app) {
        int k = 0; const char *pre = n->app->app_path[0] ? "" : "app:";
        while(*pre) target[k++] = *pre++;
        const char *src = n->app->app_path[0] ? n->app->app_path : n->app->name;
        for(const char *c = src; *c && k < SC_TARGET_MAX - 1; c++) target[k++] = *c;
        target[k] = '\0';
    }
    else copy_str(target, SC_TARGET_MAX, n->target);
}

static void action_sm_desktop_shortcut(void *u) {
    int ni = (int)(uint32_t)u;
    if(ni < 0 || ni >= node_count) return;
    sm_node_t *n = &nodes[ni];
    char target[SC_TARGET_MAX];
    node_target(n, target);
    if(shortcut_create(DESKTOP_FOLDER_PATH, n->name, target, NULL, 0)) {
        desktop_refresh_items();
        desktop_toast("Shortcut added to the desktop");
    }
    else desktop_toast("Could not create the shortcut");
}

/* Pins `target` (a path or "app:Name") to the top of the Start menu. Used by the
 * Start menu's own right-click menu and by Explorer's "Pin to Start". */
int startmenu_pin(const char *name, const char *target) {
    if(!name || !target || !target[0]) return 0;
    if(!fsu_stat("/Start Menu", NULL, NULL, NULL, NULL)) fsu_mkdir("/Start Menu");
    if(!fsu_stat(PINNED_DIR, NULL, NULL, NULL, NULL)) fsu_mkdir(PINNED_DIR);

    struct directory d;
    if(fsu_open_dir(PINNED_DIR, &d)) {
        int dup = 0;
        for(uint32_t i = 0; i < d.num_entries && !dup; i++) {
            struct dir_entry *e = &d.entries[i];
            if(!e->name || (e->dir_attrs & (LFN | DIRECTORY)) || e->name[0] == '.') continue;
            char full[FSU_PATH_MAX];
            fileops_join(PINNED_DIR, e->name, full, sizeof(full));
            shortcut_t sc;
            if(shortcut_load(full, &sc) && strcasecmp(sc.target, target) == 0) dup = 1;
        }
        free_directory(master_fs, &d);
        if(dup) { desktop_toast("Already pinned to Start"); return 1; }
    }
    if(shortcut_create(PINNED_DIR, name, target, NULL, 0)) {
        if(open_flag) { rebuild_model(); build_rows(); }
        desktop_toast("Pinned to Start");
        return 1;
    }
    desktop_toast("Could not pin it to Start");
    return 0;
}

static void action_sm_pin(void *u) {
    int ni = (int)(uint32_t)u;
    if(ni < 0 || ni >= node_count) return;
    char target[SC_TARGET_MAX];
    node_target(&nodes[ni], target);
    startmenu_pin(nodes[ni].name, target);
}
static void action_sm_remove(void *u) {
    int ni = (int)(uint32_t)u;
    if(ni < 0 || ni >= node_count || !nodes[ni].lnk_path[0]) return;
    if(!fileops_trash(nodes[ni].lnk_path)) { desktop_toast("Could not remove that shortcut"); return; }
    rebuild_model(); build_rows();           /* the row disappears at once */
    sel_row = -1;
}

int startmenu_right_click(int x, int y) {
    if(!open_flag) return 0;
    geo_t g; geometry(&g);
    if(!(x >= g.x && x < g.x + g.w && y >= g.y && y < g.y + g.h)) return 0;
    int r = row_at(&g, x, y);
    if(r < 0 || nodes[rows[r].node].is_folder) return 1;
    int ni = rows[r].node;
    static context_menu_item_t items[4];
    int n = 0;
    context_menu_item_t it;
    memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Open"); it.action = action_sm_open; items[n++] = it;
    if(!nodes[ni].pinned) { memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Pin to Start"); it.action = action_sm_pin; items[n++] = it; }
    memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, "Create desktop shortcut"); it.action = action_sm_desktop_shortcut; items[n++] = it;
    if(nodes[ni].lnk_path[0]) { memset(&it, 0, sizeof(it)); it.enabled = 1; context_menu_set_label(&it, nodes[ni].pinned ? "Unpin from Start" : "Remove from Start menu"); it.action = action_sm_remove; items[n++] = it; }
    context_menu_open(x, y, items, n, (void *)(uint32_t)ni);
    return 1;
}

/* ---- keyboard ---- */
static void move_sel(int dir) {
    if(row_count == 0) return;
    int r = sel_row;
    for(int tries = 0; tries < row_count; tries++) {
        r += dir;
        if(r < 0) { r = 0; break; }
        if(r >= row_count) { r = row_count - 1; break; }
        if(rows[r].node >= 0) break;
    }
    if(rows[r].node >= 0) { sel_row = r; ensure_row_visible(r); }
}

void startmenu_key(char c) {
    if(!open_flag) return;
    geo_t g; geometry(&g);
    if(power_open) { if(c == 27) power_open = 0; return; }

    if(c == 27) {
        if(qlen) { qlen = 0; query[0] = '\0'; scroll_px = 0; sel_row = -1; build_rows(); }
        else startmenu_close();
        return;
    }
    if(c == '\n') {
        if(sel_row < 0 && qlen) { for(int r = 0; r < row_count; r++) if(rows[r].node >= 0) { sel_row = r; break; } }
        activate_row(sel_row);
        return;
    }
    if(c == KEY_DOWN) { move_sel(1); return; }
    if(c == KEY_UP) { move_sel(-1); return; }
    if(c == KEY_PGDN) { scroll_px += g.list_bottom - g.list_top - 40; clamp_scroll(&g); return; }
    if(c == KEY_PGUP) { scroll_px -= g.list_bottom - g.list_top - 40; clamp_scroll(&g); return; }
    if(c == KEY_HOME) { scroll_px = 0; sel_row = -1; move_sel(1); return; }
    if(c == KEY_END) { scroll_px = max_scroll(&g); sel_row = row_count; move_sel(-1); return; }
    if(c == KEY_RIGHT || c == KEY_LEFT) {
        if(sel_row >= 0 && sel_row < row_count && rows[sel_row].node >= 0 && nodes[rows[sel_row].node].is_folder) {
            int ni = rows[sel_row].node;
            int want = (c == KEY_RIGHT);
            if((int)nodes[ni].expanded != want) toggle_folder(ni);
        }
        return;
    }
    if((c == 8 || c == 127) && qlen > 0) { query[--qlen] = '\0'; sel_row = -1; scroll_px = 0; build_rows(); return; }
    if(c >= 32 && c < 127 && qlen < (int)sizeof(query) - 1) {
        query[qlen++] = c; query[qlen] = '\0';
        sel_row = -1; scroll_px = 0; build_rows();
        for(int r = 0; r < row_count; r++) if(rows[r].node >= 0) { sel_row = r; break; }   /* Enter opens the best match */
    }
}

int startmenu_cursor_at(int x, int y) {
    if(!open_flag) return -1;
    geo_t g; geometry(&g);
    if(!(x >= g.x && x < g.x + g.w && y >= g.y && y < g.y + g.h)) return -1;
    if(power_open) {
        rect_t p = power_panel(&g);
        if(in_rect(x, y, p)) return CURSOR_LINK;
    }
    if(x < g.x + RAIL_W) {
        for(int b = 0; b < 3; b++) if(in_rect(x, y, rail_button(&g, b))) return CURSOR_LINK;
        return CURSOR_DEFAULT;
    }
    if(max_scroll(&g) > 0 && x >= g.x + g.w - SB_W - 16 && y >= g.list_top && y < g.list_bottom) return CURSOR_LINK;
    if(row_at(&g, x, y) >= 0) return CURSOR_LINK;
    return CURSOR_DEFAULT;
}
