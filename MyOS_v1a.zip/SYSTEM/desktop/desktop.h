#ifndef DESKTOP_H
#define DESKTOP_H

#include "stdint.h"

/* Entry point for the graphical desktop. Assumes VESA graphics, the PS/2
 * mouse driver, and interrupts are already initialized by kernel_main.
 * Never returns under normal operation -- this replaces the old
 * text-console main loop once the desktop takes over the screen. */
void desktop_run();

/* Reloads the desktop wallpaper from settings_current()->wallpaper_path --
 * called by the Settings app after the user picks a new one and saves
 * it, so the change is visible immediately. */
void reload_background(void);

/* Draws a black screen with the given centered message (e.g. "Shutting
 * down..." / "Restarting...") and presents it, then returns -- the
 * caller (taskbar.c's Shut Down/Restart menu items) is expected to call
 * power_shutdown()/power_reboot() immediately afterward, which is what
 * actually stops/resets the machine. This function itself does not
 * loop or wait; its only job is to get the transition message on
 * screen before whatever happens next (a real shutdown/reboot, or on
 * hardware where neither magic-port trick works, power_shutdown()'s own
 * halt loop) takes over. */
void desktop_show_transition_screen(const char *message);

/* Enters the software "sleep" state (see power.h's comment on why this
 * isn't real ACPI suspend): dims to black, shows a short message, and
 * blocks until any key is pressed or the mouse is clicked, then
 * returns, letting the desktop's normal render loop resume exactly
 * where it left off. Called by taskbar.c's Sleep menu item. */
void desktop_enter_sleep(void);

/* Share of time the CPU was busy (not halted in the idle loop), 0..100,
 * averaged over the last half second. */
int desktop_cpu_usage(void);

/* Copies up to `max` of the most recent half-second CPU samples (oldest
 * first) into `out` and returns how many were written. */
int desktop_cpu_history(uint8_t *out, int max);

/* Runs ONE iteration of the desktop loop (input, ticks, redraw/present, or
 * a short halt when idle). Called by the .app syscall layer at every point
 * where an app waits or presents, so the desktop stays fully interactive
 * while an app runs. */
void desktop_pump(void);

/* Busy indicators. desktop_busy_begin()/end() nest (a counter); while any
 * is open the pointer is the animated busy spinner. desktop_working_for_ms()
 * shows the arrow-with-spinner "working in background" cursor for a fixed
 * time -- used right after launching something so the click gets feedback. */
void desktop_busy_begin(void);
void desktop_busy_end(void);
void desktop_working_for_ms(uint32_t ms);

/* Shows a short message pill above the taskbar for a few seconds. */
void desktop_toast(const char *msg);

/* Re-reads the Desktop folder now (after something created a shortcut or
 * file there) so its icon appears immediately. */
void desktop_refresh_items(void);

/* Keeps the busy spinner turning during a long blocking operation by
 * redrawing only the cursor sprite (cheap; safe to call from anywhere). */
void desktop_busy_tick(void);

#endif
