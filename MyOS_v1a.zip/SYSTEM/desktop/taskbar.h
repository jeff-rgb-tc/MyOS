#ifndef DESKTOP_TASKBAR_H
#define DESKTOP_TASKBAR_H

#define TASKBAR_HEIGHT 32        /* thickness when docked at the top or bottom */
#define TASKBAR_SIDE_WIDTH 168   /* thickness when docked at the left or right */

/* Where the taskbar sits. Stored in settings.ini ([taskbar] dock=). */
enum { TASKBAR_DOCK_BOTTOM = 0, TASKBAR_DOCK_TOP = 1, TASKBAR_DOCK_LEFT = 2, TASKBAR_DOCK_RIGHT = 3 };
int  taskbar_get_dock(void);
void taskbar_set_dock(int dock);                 /* also saves the setting */
/* The part of the screen that is not covered by the taskbar (where windows maximize to). */
void taskbar_work_area(int *x, int *y, int *w, int *h);

/* Sets up the taskbar's own resources (currently: the Start button icon).
 * Call once at desktop startup, after the FAT32 filesystem is mounted. */
void taskbar_init();

/* Draws the taskbar strip along the bottom of the screen: a Start button,
 * one button per open window, and a clock-less status area on the right
 * (no RTC driver is wired up yet, so we show a simple tick counter
 * instead of a real clock). Also draws the Start menu popup on top if
 * it's currently open. */
void taskbar_draw();

/* Handles a left-click at (x, y). If the Start menu is open, this checks
 * menu items first (the menu floats above the taskbar and can be clicked
 * even though it's not part of the taskbar strip itself). Otherwise
 * behaves as before: returns 1 if the click landed on the taskbar strip
 * and was consumed, 0 if the caller should treat it as a desktop/window
 * click instead. */
int taskbar_handle_click(int x, int y);

/* True if the on-screen point falls within the taskbar strip at all. */
int taskbar_contains(int x, int y);

/* True if the Start menu popup is currently open. Useful for the desktop
 * loop to know whether a click outside the menu should close it. */
int taskbar_start_menu_open();

/* Closes the Start menu if it's open. Safe to call unconditionally. */
void taskbar_close_start_menu();

/* Which cursor shape (a cursor_kind_t value, see cursor_set.h -- 0/
 * CURSOR_DEFAULT if none of the below apply) the mouse should show at
 * (x, y): the pointing hand over the Start button, task buttons, and
 * (while the Start menu is open) its app/system items, and the person-
 * select cursor specifically over the profile avatar/name at the top of
 * the Start menu. Returned as a plain int, same reasoning as
 * window_t::cursor_at in window.h -- this header doesn't need to
 * include cursor_set.h just for the enum. Only meaningful to call when
 * taskbar_contains(x, y) or taskbar_start_menu_open() is true; returns
 * CURSOR_DEFAULT (0) otherwise. */
int taskbar_cursor_at(int x, int y);
int taskbar_volume_open();
void taskbar_mouse_motion(int x, int y);
void taskbar_mouse_up();

#endif

