#ifndef APP_CLOCK_H
#define APP_CLOCK_H

/* Clock: three tabs -- an analog + digital world clock face driven by the
 * CMOS RTC, a stopwatch with laps, and a countdown timer. Only one Clock
 * window exists at a time; launching it again focuses the existing one.
 * Keys: 1/2/3 or Tab switch tabs, Space start/stop, L lap, R reset. */
void launch_clock(void);

#endif
