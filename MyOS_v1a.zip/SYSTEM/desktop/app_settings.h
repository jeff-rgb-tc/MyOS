#ifndef APP_SETTINGS_H
#define APP_SETTINGS_H

/* Launches the Settings window: System (read-only PC/OS info),
 * Personalization (wallpaper, brightness, resolution preference), and
 * Profile (username, avatar) tabs. */
void launch_settings(void);

#endif
