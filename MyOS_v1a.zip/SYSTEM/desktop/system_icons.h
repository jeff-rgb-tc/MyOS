#ifndef SYSTEM_ICONS_H
#define SYSTEM_ICONS_H

#include "png.h"

/* The handful of built-in icons that aren't tied to any app in apps.c's
 * registry -- desktop.c's My PC/Recycle Bin desktop icons, and
 * taskbar.c's Sleep/Restart/Shut Down Start menu items. Loaded from
 * /SYSTEM/res/icons/<name>.png, lazily and cached the same way
 * apps_get_icon() caches each app's icon (see apps.c) -- a shared
 * module instead of duplicating that lazy-load-and-cache logic in both
 * desktop.c and taskbar.c. */
typedef enum {
    SYSTEM_ICON_MYPC = 0,
    SYSTEM_ICON_RECYCLE_BIN,
    SYSTEM_ICON_SLEEP,
    SYSTEM_ICON_RESTART,
    SYSTEM_ICON_SHUTDOWN,
    SYSTEM_ICON_COUNT,
} system_icon_id_t;

/* Returns the requested icon's image, loading it from disk on first use
 * and returning the cached copy on every call after that. Returns NULL
 * if the icon's file is missing/unreadable -- callers should fall back
 * to a placeholder or text-only label in that case, the same way
 * apps_get_icon() callers already do for a missing app icon. */
png_image_t *system_icon_get(system_icon_id_t id);

#endif
