#include "cursor_set.h"
#include "stdio.h"
#include "kernio.h"
#include "common.h"
#include "cursor_ani.h"
#include "fs_util.h"
#include "kheap.h"
#include "pit.h"
#include "driver_loader.h"
#include "desktop.h"

typedef struct {
    const char *path;
    cursor_image_t image;
    uint8_t load_attempted;
    /* Optional animated version (.ani). When it loads, it wins over the
     * static .cur above, which stays as the fallback for a missing or
     * unparseable .ani (so deleting the .ani file just gets you the old
     * still cursor back). */
    const char *ani_path;
    cursor_anim_t anim;
    uint8_t ani_state;      /* 0 = not tried yet, 1 = loaded, 2 = unavailable */
} cursor_slot_t;

static cursor_slot_t slots[CURSOR_COUNT] = {
    [CURSOR_DEFAULT]          = { "/SYSTEM/res/cursors/normal_select.cur", {0}, 0 },
    [CURSOR_TEXT]             = { "/SYSTEM/res/cursors/text_select.cur", {0}, 0 },
    [CURSOR_LINK]             = { "/SYSTEM/res/cursors/link_select.cur", {0}, 0 },
    [CURSOR_MOVE]             = { "/SYSTEM/res/cursors/move.cur", {0}, 0 },
    [CURSOR_RESIZE_H]         = { "/SYSTEM/res/cursors/horizontal_resize.cur", {0}, 0 },
    [CURSOR_RESIZE_V]         = { "/SYSTEM/res/cursors/vertical_resize.cur", {0}, 0 },
    [CURSOR_RESIZE_DIAG_1]    = { "/SYSTEM/res/cursors/diagonal_resize_1.cur", {0}, 0 },
    [CURSOR_RESIZE_DIAG_2]    = { "/SYSTEM/res/cursors/diagonal_resize_2.cur", {0}, 0 },
    [CURSOR_UNAVAILABLE]      = { "/SYSTEM/res/cursors/unavailable.cur", {0}, 0 },
    [CURSOR_BUSY]             = { "/SYSTEM/res/cursors/busy.cur", {0}, 0, "/SYSTEM/res/cursors/busy.ani", {0}, 0 },
    [CURSOR_WORKING]          = { "/SYSTEM/res/cursors/working_in_background.cur", {0}, 0, "/SYSTEM/res/cursors/working_in_background.ani", {0}, 0 },
    [CURSOR_HELP]             = { "/SYSTEM/res/cursors/help_select.cur", {0}, 0 },
    [CURSOR_PRECISION]        = { "/SYSTEM/res/cursors/precision_select.cur", {0}, 0 },
    [CURSOR_HANDWRITING]      = { "/SYSTEM/res/cursors/handwriting.cur", {0}, 0 },
    [CURSOR_PERSON]           = { "/SYSTEM/res/cursors/person_select.cur", {0}, 0 },
    [CURSOR_LOCATION]         = { "/SYSTEM/res/cursors/location_select.cur", {0}, 0 },
    [CURSOR_ALTERNATE]        = { "/SYSTEM/res/cursors/alternate_select.cur", {0}, 0 },
};

/* .cur files are tiny (a few KB); read the whole thing in one shot into
 * a generously-sized stack buffer, same approach desktop.c's old single-
 * cursor load_cursor() already used. */
#define CUR_READ_BUFFER_SIZE 65536

static int load_cursor_file(const char *path, cursor_image_t *out) {
    FILE *f = fopen(path, NULL);
    if(!f) return 0;

    static uint8_t cur_buffer[CUR_READ_BUFFER_SIZE];
    uint32_t total_read = 0;
    size_t chunk;
    while((chunk = fread(cur_buffer + total_read, 1, CUR_READ_BUFFER_SIZE - total_read, f)) > 0) {
        total_read += chunk;
        if(total_read >= CUR_READ_BUFFER_SIZE) break;
    }
    fclose(f);

    return cursor_load_from_memory(cur_buffer, total_read, out);
}

/* Loads the slot's .ani on first use (the whole file is read into a
 * temporary heap buffer -- animated cursors are ~130 KB, too big for the
 * static buffer the single-frame loader uses -- decoded, and the buffer
 * freed again). Returns 1 if the slot now has a usable animation. */
static int ensure_animation(cursor_slot_t *slot) {
    if(!slot->ani_path) return 0;
    if(slot->ani_state == 0) {
        slot->ani_state = 2;
        /* The display driver's descriptor can switch animation off
         * (/Drivers/display/vesa-fb.drv, [settings] cursor_animation=0);
         * the still .cur cursors are used instead. */
        if(!driver_setting_int("vesa-fb", "cursor_animation", 1)) return 0;
        uint32_t size = 0;
        uint8_t *data = fsu_read_file(slot->ani_path, &size);
        if(data) {
            if(size > 0 && cursor_ani_load_from_memory(data, size, &slot->anim)) {
                slot->ani_state = 1;
            }
            else {
                printf("cursor_set: could not parse %s, using the still cursor\n", slot->ani_path);
                desktop_toast("Animated cursor could not be read - using the still cursor");
            }
            kfree(data);
        }
        else {
            desktop_toast("Animated cursor file missing on the disk - using the still cursor");
        }
    }
    return slot->ani_state == 1;
}

/* Interrupt-safe: returns what is ALREADY loaded (the current animation frame, or the still image);
 * never touches the disk or the heap. NULL if that cursor has not been loaded yet. */
cursor_image_t *cursor_set_peek(cursor_kind_t kind) {
    if(kind < 0 || kind >= CURSOR_COUNT) return NULL;
    cursor_slot_t *slot = &slots[kind];
    if(slot->ani_state == 1) {
        const cursor_image_t *frame = cursor_ani_image_at(&slot->anim, pit_get_ms());
        if(frame && frame->pixels) return (cursor_image_t *)frame;
    }
    return slot->image.pixels ? &slot->image : NULL;
}

/* Loads the pointers the not-responding watchdog may need, up front, while loading is still allowed. */
void cursor_set_preload(void) {
    cursor_set_get(CURSOR_DEFAULT);
    cursor_set_get(CURSOR_BUSY);
    cursor_set_get(CURSOR_WORKING);
}

int cursor_set_is_animated(cursor_kind_t kind) {
    if(kind < 0 || kind >= CURSOR_COUNT) return 0;
    return ensure_animation(&slots[kind]);
}

/* Changes every time the visible frame of an animated cursor changes
 * (and is a constant for still cursors), so the desktop can tell whether
 * the cursor needs a repaint without redrawing everything at 100 Hz. */
int cursor_set_animation_token(cursor_kind_t kind) {
    if(kind < 0 || kind >= CURSOR_COUNT) return 0;
    cursor_slot_t *slot = &slots[kind];
    if(!ensure_animation(slot)) return 0;
    return cursor_ani_step_at(&slot->anim, pit_get_ms());
}

cursor_image_t *cursor_set_get(cursor_kind_t kind) {
    if(kind < 0 || kind >= CURSOR_COUNT) return NULL;

    cursor_slot_t *slot = &slots[kind];

    if(ensure_animation(slot)) {
        const cursor_image_t *frame = cursor_ani_image_at(&slot->anim, pit_get_ms());
        if(frame && frame->pixels) return (cursor_image_t *)frame;
    }

    if(!slot->load_attempted) {
        slot->load_attempted = 1;
        if(!load_cursor_file(slot->path, &slot->image)) {
            printf("cursor_set: failed to load %s\n", slot->path);
            if(kind == CURSOR_DEFAULT) {
                /* The default cursor always needs SOMETHING usable --
                 * fall back to the built-in arrow shape rather than
                 * leaving the mouse invisible if its file is somehow
                 * missing (matches the old single-cursor
                 * load_cursor()'s same fallback). */
                cursor_build_default_arrow(&slot->image);
            }
            else {
                return NULL;
            }
        }
    }

    return slot->image.pixels ? &slot->image : NULL;
}
