#ifndef SETTINGS_H
#define SETTINGS_H

#include "stdint.h"

/* Persisted user preferences -- lives at /Users/User/settings.ini
 * (same directory/ini-writing pattern as desktop_ini.c's
 * DESKTOP_INI_PATH). Loaded once at desktop startup (settings_load(),
 * called from desktop_run()) and kept in memory the rest of the
 * session; settings_save() is called by app_settings.c whenever the
 * user changes something in the Settings app.
 *
 * Two different kinds of setting live here, and they behave
 * differently on write:
 *  - Things the desktop itself reads live (wallpaper path, brightness,
 *    username, avatar path) take effect immediately once saved -- the
 *    desktop re-reads settings_current() on its next frame.
 *  - Display resolution is saved but NOT applied live: changing video
 *    mode after paging/the heap/open windows already assume the
 *    current framebuffer size and address is a much bigger, riskier
 *    change than this settings module makes on its own (see
 *    app_settings.c's Personalization tab for the "takes effect after
 *    restart" messaging shown to the user). set_vmode() in vesa.c does
 *    not currently read this preference at all -- the saved value is
 *    honored by a future boot-time change, not by this module. */
#define SETTINGS_STRING_MAX 64

typedef struct {
    char wallpaper_path[SETTINGS_STRING_MAX];
    int brightness; /* 0-100, 100 = normal (no dimming). Software-only -- see app_settings.c's Personalization tab comment for why this can't be real display backlight control. */
    int resolution_width;  /* 0 = "use automatic/default", otherwise a value from vesa.h's preferred_modes list */
    int resolution_height;

    char username[SETTINGS_STRING_MAX];
    char avatar_path[SETTINGS_STRING_MAX]; /* empty = no avatar set, Start menu falls back to a placeholder */

    int volume; /* 0-100 master volume (applied via audio_set_volume), default 70 */
    int muted;  /* 1 = muted */

    int taskbar_dock; /* 0 bottom, 1 top, 2 left, 3 right (see taskbar.h) */
    int animations;   /* 1 = window / Start menu animations on (default) */
} settings_t;

/* Loads settings from disk into the in-memory copy returned by
 * settings_current(), applying documented defaults for anything the
 * file doesn't have (or if the file doesn't exist yet at all -- a
 * fresh disk image). Safe to call once at startup; nothing else needs
 * to call this again during a session (settings_save() keeps the
 * in-memory copy authoritative after that). */
void settings_load(void);

/* Writes the current in-memory settings out to disk. Called by
 * app_settings.c after any change the user makes. */
void settings_save(void);

/* Returns a pointer to the live, in-memory settings -- callers read
 * fields directly (e.g. settings_current()->brightness) and
 * app_settings.c writes fields directly before calling settings_save().
 * Always non-NULL after settings_load() has run once. */
settings_t *settings_current(void);

#endif
