#ifndef APP_TASKMGR_H
#define APP_TASKMGR_H

/* Task Manager: lists every open window with its state and size, lets you
 * switch to or end one, and shows live CPU load, kernel heap usage,
 * uptime and display info on a Performance tab, and every loaded driver
 * (descriptors under /Drivers plus built-ins) with its live status on a Drivers tab. Opens from the Start menu
 * or with Ctrl+Shift+Esc; only one instance exists at a time.
 * Keys: Up/Down select, Enter switch to, Delete end task, Tab switch tab. */
void launch_taskmgr(void);

#endif
