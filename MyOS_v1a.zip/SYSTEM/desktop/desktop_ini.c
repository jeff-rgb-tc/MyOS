/*
 * Reads/writes desktop.ini, which lives at /Users/User/Desktop/desktop.ini
 * on the FAT32 disk. Also responsible for making sure that whole path
 * exists in the first place -- a fresh disk image won't have it yet, so
 * ensure_desktop_path() walks/creates each directory level by level.
 */

#include "stdint.h"
#include "stddef.h"
#include "desktop_ini.h"
#include "ini.h"
#include "fat32.h"
#include "common.h"
#include "kernio.h"
#include "kheap.h"
#include "stdio.h"

#define DESKTOP_INI_PATH "/Users/User/Desktop/desktop.ini"

/* Finds a subdirectory entry by name within an already-populated
 * directory listing, or NULL if it isn't there. */
static struct dir_entry *find_subdir(struct directory *dir, const char *name) {
    for(uint32_t i = 0; i < dir->num_entries; i++) {
        struct dir_entry *e = &dir->entries[i];
        if(e->name && (e->dir_attrs & DIRECTORY) && strcmp(e->name, name) == 0) {
            return e;
        }
    }
    return NULL;
}

/* Walks into (or creates, if missing) a single path component. Frees
 * the directory passed in via *dir and replaces it with the child
 * directory's listing -- callers should treat *dir as "moved into"
 * rather than reusable afterward. */
static void step_into_or_create(struct directory *dir, const char *name) {
    struct dir_entry *existing = find_subdir(dir, name);

    uint32_t cluster;
    if(existing) {
        cluster = existing->first_cluster;
    }
    else {
        mkdir(master_fs, dir, (char *)name);
        /* mkdir() updates *dir in place with the new entry appended, so
         * look it up again now that it exists. */
        existing = find_subdir(dir, name);
        if(!existing) {
            printf("desktop_ini: failed to create directory '%s'\n", name);
            cluster = 0;
        }
        else {
            cluster = existing->first_cluster;
        }
    }

    free_directory(master_fs, dir);
    if(cluster) {
        populate_dir(master_fs, dir, cluster);
    }
    else {
        memset(dir, 0, sizeof(struct directory));
    }
}

/* Ensures /Users/User/Desktop exists on the disk, creating any missing
 * directory along the way. Returns 1 on success (the final directory
 * listing is left in *out_desktop_dir, which the caller owns and must
 * free_directory() when done), 0 if master_fs isn't mounted. */
static int ensure_desktop_path(struct directory *out_desktop_dir) {
    if(!master_fs) return 0;

    struct directory current;
    populate_root_dir(master_fs, &current);

    step_into_or_create(&current, "Users");
    step_into_or_create(&current, "User");
    step_into_or_create(&current, "Desktop");

    *out_desktop_dir = current;
    return 1;
}

int desktop_ini_load(desktop_icon_entry_t *out_entries, int max_entries) {
    FILE *f = fopen(DESKTOP_INI_PATH, NULL);
    if(!f) {
        return 0; /* no saved layout yet -- not an error, just nothing to load */
    }

    uint32_t capacity = 16384;
    uint8_t *buffer = (uint8_t *)kmalloc(capacity);
    uint32_t total = 0;

    size_t chunk;
    while((chunk = fread(buffer + total, 1, capacity - total, f)) > 0) {
        total += chunk;
        if(total >= capacity) break; /* desktop.ini should never realistically be this large */
    }
    fclose(f);

    ini_document_t doc;
    ini_parse((const char *)buffer, total, &doc);
    kfree(buffer);

    int count = 0;
    for(int i = 0; i < doc.section_count && count < max_entries; i++) {
        const char *name = ini_get(&doc, doc.sections[i].name, "name");
        const char *type = ini_get(&doc, doc.sections[i].name, "type");
        int x, y;
        int has_x = ini_get_int(&doc, doc.sections[i].name, "x", &x);
        int has_y = ini_get_int(&doc, doc.sections[i].name, "y", &y);

        /* "name" is only required for an app icon (ICON_KIND_APP) --
         * My PC/Recycle Bin entries have no app to name, just a type. */
        desktop_icon_kind_t kind = ICON_KIND_APP;
        if(type && strcmp(type, "mypc") == 0) kind = ICON_KIND_MYPC;
        else if(type && strcmp(type, "recycle") == 0) kind = ICON_KIND_RECYCLE_BIN;
        else if(!name) {
            continue; /* app-kind entry with no name -- malformed, skip */
        }

        if(!has_x || !has_y) {
            continue; /* malformed section -- skip rather than guess */
        }

        desktop_icon_entry_t *entry = &out_entries[count];
        entry->kind = kind;
        entry->app_name[0] = '\0';
        if(kind == ICON_KIND_APP && name) {
            int j = 0;
            while(name[j] && j < (int)sizeof(entry->app_name) - 1) {
                entry->app_name[j] = name[j];
                j++;
            }
            entry->app_name[j] = '\0';
        }
        entry->x = x;
        entry->y = y;
        count++;
    }

    return count;
}

/* Appends `text` to *pos within `buf`, advancing *pos by however many
 * bytes were written. This kernel's sprintf() always returns 0 (it
 * doesn't report the formatted length), so building up a multi-line
 * buffer with running position tracking has to measure each piece with
 * strlen() itself rather than trusting sprintf's return value. */
static void append_str(char *buf, uint32_t *pos, const char *text) {
    uint32_t len = strlen(text);
    for(uint32_t i = 0; i < len; i++) {
        buf[*pos + i] = text[i];
    }
    *pos += len;
}

static void append_int(char *buf, uint32_t *pos, int value) {
    char digits[12];
    char *s = itos((uint32_t)value, digits, sizeof(digits));
    append_str(buf, pos, s);
}

void desktop_ini_save(const desktop_icon_entry_t *entries, int count) {
    struct directory desktop_dir;
    if(!ensure_desktop_path(&desktop_dir)) {
        return;
    }

    /* Each entry needs at most ~120 bytes (generous headroom for
     * name/type/x/y lines plus the section header), so size the buffer
     * for the worst case up front -- desktop.ini is always small enough
     * that this is cheap and avoids needing a growable buffer here. */
    uint32_t capacity = (uint32_t)count * 160 + 64;
    char *text = (char *)kmalloc(capacity);
    uint32_t pos = 0;

    for(int i = 0; i < count; i++) {
        append_str(text, &pos, "[icon");
        append_int(text, &pos, i);
        append_str(text, &pos, "]\n");

        if(entries[i].kind == ICON_KIND_APP) {
            append_str(text, &pos, "name=");
            append_str(text, &pos, entries[i].app_name);
            append_str(text, &pos, "\n");
            append_str(text, &pos, "type=app\n");
        }
        else if(entries[i].kind == ICON_KIND_MYPC) {
            append_str(text, &pos, "type=mypc\n");
        }
        else if(entries[i].kind == ICON_KIND_RECYCLE_BIN) {
            append_str(text, &pos, "type=recycle\n");
        }

        append_str(text, &pos, "x=");
        append_int(text, &pos, entries[i].x);
        append_str(text, &pos, "\n");

        append_str(text, &pos, "y=");
        append_int(text, &pos, entries[i].y);
        append_str(text, &pos, "\n\n");
    }

    writeFile(master_fs, &desktop_dir, (uint8_t *)text, "desktop.ini", pos);

    kfree(text);
    free_directory(master_fs, &desktop_dir);
}
