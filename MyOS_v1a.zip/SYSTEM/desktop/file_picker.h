#ifndef FILE_PICKER_H
#define FILE_PICKER_H

#include "stdint.h"

/* A simple in-window folder-browsing file picker -- lets the user
 * navigate the FAT32 disk and click a file instead of typing its full
 * path by hand (see app_settings.c's Personalization/Profile tabs,
 * which use this for picking a wallpaper/avatar PNG). Not a separate
 * window: draws/handles clicks within whatever rectangle the owning
 * window's on_paint/on_click gives it, the same "modal panel within the
 * window" approach app_paint.c's save dialog already uses (see that
 * file's draw_save_dialog()/handle_save_dialog_click(), which this
 * mirrors) rather than opening a second wm_create_window().
 */

#define FILE_PICKER_MAX_ENTRIES 128
#define FILE_PICKER_NAME_MAX 32
#define FILE_PICKER_PATH_MAX 192
#define FILE_PICKER_MAX_DEPTH 12

typedef struct {
    char name[FILE_PICKER_NAME_MAX];
    uint8_t is_dir;
} file_picker_entry_t;

typedef struct {
    uint8_t open;

    /* Extension filter -- only files ending in this (case-insensitive)
     * are listed; folders are always listed regardless. Pass NULL/empty
     * to show every file. */
    char extension_filter[8];

    /* Current folder's path, as a stack of cluster numbers (mirrors
     * app_explorer.c's own path_stack approach) plus the matching
     * display names, so Up/navigation and building the full path string
     * for a selected file both work the same way Explorer's already
     * does. */
    uint32_t path_stack[FILE_PICKER_MAX_DEPTH];
    char path_names[FILE_PICKER_MAX_DEPTH][FILE_PICKER_NAME_MAX];
    int depth;

    file_picker_entry_t entries[FILE_PICKER_MAX_ENTRIES];
    int entry_count;
    int scroll;
    int last_click_index;
    long long last_click_tick;

    /* Set by file_picker_handle_click() the moment the user double-
     * clicks a (non-directory) file -- the caller checks this right
     * after its on_click handler calls file_picker_handle_click(), and
     * if set, reads file_picker_selected_path() and closes the picker
     * itself (the picker doesn't close on its own, so the caller stays
     * in control of what happens with the selection). Cleared by
     * file_picker_open(). */
    uint8_t file_chosen;
    char selected_path[FILE_PICKER_PATH_MAX];
} file_picker_t;

/* Opens the picker at the filesystem root, ready to draw/handle clicks.
 * extension_filter may be NULL for no filtering (e.g. "png" to only
 * show *.png files and folders). */
void file_picker_open(file_picker_t *fp, const char *extension_filter);

void file_picker_close(file_picker_t *fp);

/* Draws the picker's folder list + Up button within the given
 * rectangle (screen coordinates, from the owning window's on_paint). */
void file_picker_draw(file_picker_t *fp, int x, int y, int w, int h);

/* Handles a click at the same coordinates file_picker_draw() was given
 * (i.e. also screen coordinates, NOT client-relative -- the caller
 * passes through whatever it already computed for its own on_paint
 * rect, so both stay in exact agreement about where the picker sits).
 * Double-clicking a file sets fp->file_chosen and fp->selected_path;
 * the caller is responsible for checking that after every call and
 * closing the picker if so. */
void file_picker_handle_click(file_picker_t *fp, int x, int y, int w, int h);

#endif
