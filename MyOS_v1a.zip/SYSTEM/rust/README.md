# Rust in MyOS (experimental, not part of the default build)

Nothing here has been compiled: the machine this was written on has no `rustc`/`cargo`. Treat it as a starting
point. If it does not build for you (the target JSON's data-layout is toolchain-version sensitive), fix it there
-- the default build (`make`) never touches this directory.

    rustup toolchain install nightly && rustup component add rust-src --toolchain nightly
    cd SYSTEM/rust
    cargo +nightly build --release -Z build-std=core --target i686-myos.json
    # -> target/i686-myos/release/libmyos_rs.a ; link it into the kernel by adding it to OBJECTS in kernel/Makefile
    # and declaring in C:  uint32_t rs_fnv1a(const uint8_t *data, size_t len);

First candidates to port (they already have host tests in tools/hosttest): fsx.c readers, PNG/inflate, MP3 decode.
