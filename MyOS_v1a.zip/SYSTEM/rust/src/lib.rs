//! First Rust piece of MyOS: leaf routines with a C ABI, so they can replace C code one function at a time.
//! Build (nightly): cargo build --release -Z build-std=core --target i686-myos.json   (see rust/README.md)
#![no_std]

use core::panic::PanicInfo;

extern "C" {
    /// Provided by the kernel (kernel/common.c): prints a message and halts.
    fn PANIC(msg: *const u8) -> !;
}

#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    unsafe { PANIC(b"rust panic\0".as_ptr()) }
}

/// FNV-1a over a byte buffer (same function the host tests use to compare file contents).
#[no_mangle]
pub extern "C" fn rs_fnv1a(data: *const u8, len: usize) -> u32 {
    let mut h: u32 = 2166136261;
    if data.is_null() {
        return h;
    }
    let bytes = unsafe { core::slice::from_raw_parts(data, len) };
    for &b in bytes {
        h ^= b as u32;
        h = h.wrapping_mul(16777619);
    }
    h
}

/// Bounds-checked little-endian u32 read: the kind of helper the filesystem readers (fsx.c) are built from.
#[no_mangle]
pub extern "C" fn rs_read_le32(data: *const u8, len: usize, offset: usize, out: *mut u32) -> i32 {
    if data.is_null() || out.is_null() || offset.checked_add(4).map_or(true, |end| end > len) {
        return -1;
    }
    let bytes = unsafe { core::slice::from_raw_parts(data.add(offset), 4) };
    unsafe { *out = u32::from_le_bytes([bytes[0], bytes[1], bytes[2], bytes[3]]) };
    0
}
