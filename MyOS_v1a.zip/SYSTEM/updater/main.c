/* update -- the MyOS updater.
 *
 * Copies the system files of the running (Live) MyOS onto an MyOS that is
 * already installed on a hard disk. Unlike installer.app it never partitions
 * or formats anything: files are overwritten in place, /Users (your files and
 * settings) is not touched, driver settings you changed are kept.
 * All the real work happens in the kernel's installer service; this program
 * starts it, calls myos_install_step() repeatedly and draws the progress. */
#include <myos/myos.h>
#include <myos/ui.h>

enum { PAGE_WELCOME, PAGE_PROGRESS, PAGE_DONE, PAGE_FAILED };

#define W 520
#define H 330

static const char *error_text(int err) {
    switch(err) {
        case MYOS_E_INST_DISK:    return "No installed MyOS, or no update disc in the CD/DVD drive.";
        case MYOS_E_INST_IO:      return "The disk reported a read/write error.";
        case MYOS_E_INST_BUSY:    return "An update is already running.";
        case MYOS_E_NOMEM:        return "Out of memory.";
        case MYOS_E_PERM:         return "The updater has no system permission.";
        case MYOS_E_FAIL:         return "The system disk is not available.";
        default:                  return "Unexpected error.";
    }
}

static const char *error_hint(int err) {
    switch(err) {
        case MYOS_E_INST_DISK:    return "Insert the new MyOS ISO in the CD/DVD drive (or boot it) and try again.";
        case MYOS_E_INST_IO:      return "Check the disk is attached as IDE/ATA (not AHCI/NVMe) and retry.";
        case MYOS_E_PERM:         return "Start it from /APPS/update/update.app.";
        default:                  return "";
    }
}

int app_main(void) {
    int win = myos_window_create("MyOS Update", W, H);
    if(win < 0) return 1;

    myos_ui_t ui;
    myos_ui_init(&ui, win);

    int page = PAGE_WELCOME;
    int fail_err = 0;
    char fail_detail[64] = "";
    myos_install_status_t st;
    memset(&st, 0, sizeof(st));
    int working = 0;

    for(;;) {
        myos_clear(win, MYOS_COLOR_BG);
        myos_text_scaled(win, 24, 18, "MyOS Update", MYOS_COLOR_TEXT, 2);

        if(page == PAGE_WELCOME) {
            myos_ui_label(&ui, 24, 70, "Update MyOS on your hard disk to this version.", MYOS_COLOR_TEXT);
            myos_ui_label(&ui, 24, 100, "It will:", MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 40, 122, "- replace the system, apps and kernel files", MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 40, 144, "- keep your files and settings (/Users)", MYOS_COLOR_OK);
            myos_ui_label(&ui, 40, 166, "- NOT format or repartition the disk", MYOS_COLOR_OK);
            myos_ui_label(&ui, 24, 196, "Two ways: start it from the new MyOS ISO (Live), or, from the", MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 24, 216, "installed system, with the new ISO in the CD/DVD drive.", MYOS_COLOR_TEXT_DIM);
            if(myos_ui_button(&ui, 1, W - 250, H - 56, 110, 34, "Close", MYOS_UI_NORMAL)) return 0;
            if(myos_ui_button(&ui, 2, W - 130, H - 56, 110, 34, "Update", MYOS_UI_ACCENT)) {
                int rc = myos_update_begin();
                if(rc < 0) { fail_err = rc; fail_detail[0] = 0; page = PAGE_FAILED; }
                else { working = 1; memset(&st, 0, sizeof(st)); page = PAGE_PROGRESS; myos_busy(1); }
            }
        }
        else if(page == PAGE_PROGRESS) {
            myos_ui_label(&ui, 24, 70, st.stage[0] ? st.stage : "Starting...", MYOS_COLOR_TEXT);
            myos_ui_progress(&ui, 24, 100, W - 48, 14, (int)st.percent, 100);
            char line[64];
            snprintf(line, sizeof(line), "%d%%", (int)st.percent);
            myos_ui_label(&ui, 24, 124, line, MYOS_COLOR_TEXT_DIM);
            if(st.files_total) {
                snprintf(line, sizeof(line), "Files: %d / %d", (int)st.files_done, (int)st.files_total);
                myos_ui_label(&ui, 24, 146, line, MYOS_COLOR_TEXT_DIM);
            }
            myos_ui_label(&ui, 24, 178, st.detail, MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 24, 230, "Do not turn off the computer.", MYOS_COLOR_WARN);
        }
        else if(page == PAGE_DONE) {
            myos_ui_label(&ui, 24, 70, "MyOS has been updated.", MYOS_COLOR_OK);
            myos_ui_label(&ui, 24, 102, "Remove the disc (or eject the ISO), then restart.", MYOS_COLOR_TEXT_DIM);
            if(myos_ui_button(&ui, 3, W - 250, H - 56, 110, 34, "Close", MYOS_UI_NORMAL)) return 0;
            if(myos_ui_button(&ui, 4, W - 130, H - 56, 110, 34, "Restart now", MYOS_UI_ACCENT)) myos_reboot();
        }
        else { /* PAGE_FAILED */
            myos_ui_label(&ui, 24, 70, "The update failed.", MYOS_COLOR_DANGER);
            myos_ui_label(&ui, 24, 102, error_text(fail_err), MYOS_COLOR_TEXT);
            myos_ui_label(&ui, 24, 130, fail_detail, MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 24, 160, error_hint(fail_err), MYOS_COLOR_WARN);
            { char code[40]; snprintf(code, sizeof(code), "Error code: %d", fail_err);
              myos_ui_label(&ui, 24, 190, code, MYOS_COLOR_TEXT_DIM); }
            if(myos_ui_button(&ui, 5, W - 250, H - 56, 110, 34, "Close", MYOS_UI_NORMAL)) return 0;
            if(myos_ui_button(&ui, 6, W - 130, H - 56, 110, 34, "Try again", MYOS_UI_ACCENT)) page = PAGE_WELCOME;
        }
        myos_ui_end_frame(&ui);

        if(working) {
            int rc = myos_install_step(&st);
            if(rc < 0 || st.state == MYOS_INST_FAILED) {
                working = 0; myos_busy(0);
                fail_err = rc < 0 ? rc : st.error;
                memcpy(fail_detail, st.detail, sizeof(fail_detail));
                page = PAGE_FAILED;
            } else if(st.state == MYOS_INST_DONE) {
                working = 0; myos_busy(0);
                page = PAGE_DONE;
            }
        }

        myos_event_t ev;
        int got = myos_wait_event(win, &ev, working ? 1 : -1);
        if(got) {
            if(ev.type == MYOS_EV_CLOSE) {
                if(working) continue;
                break;
            }
            myos_ui_event(&ui, &ev);
        }
        while(myos_poll_event(win, &ev)) {
            if(ev.type == MYOS_EV_CLOSE) { if(!working) return 0; continue; }
            myos_ui_event(&ui, &ev);
        }
    }
    return 0;
}
