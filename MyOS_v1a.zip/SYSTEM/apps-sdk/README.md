# MyOS SDK

Everything you need to write programs for MyOS and ship them as a single
`.app` file.

```
apps-sdk/
  include/myos/   abi.h  myos.h  libc.h  ui.h        <- the headers you #include
  lib/            libmyos.c  ui.c  crt0.S  app.ld     <- compiled into every app
  tools/          mkapp.py  appinfo.py                <- ELF -> .app, and a validator
  myos-app.mk     the build rules your Makefile includes
  examples/       hello  doodle  snake  files         <- four complete apps
  docs/           API.md  FORMAT.md  GUIDE.md
```

## Quick start

You need a 32-bit C compiler (`i686-elf-gcc`, or plain `gcc` with `-m32`
support), GNU `ld` and Python 3. **nasm is not needed.**

```sh
cd apps-sdk/examples/hello
make            # -> build/hello.app
make info       # validates it with the same checks the kernel applies
make install    # copies it to ../../../APPS/hello/ (with its icon)
```

Then rebuild the disk image as usual (`make run`, `make iso`...): `/APPS`
is scanned at boot and every `.app` found there appears in the **Start
menu** with the name and icon from its manifest. You can also run any
`.app` from Explorer by opening it.

### Your first app

```c
// main.c
#include <myos/myos.h>

int app_main(void) {
    int win = myos_window_create("My app", 320, 200);   // client area 320x200
    myos_clear(win, MYOS_COLOR_BG);
    myos_text(win, 20, 20, "Hello from my own app!", MYOS_COLOR_TEXT);

    myos_event_t ev;
    while (myos_wait_event(win, &ev, -1)) {             // sleep until something happens
        if (ev.type == MYOS_EV_CLOSE) break;            // user pressed the close box
    }
    return 0;
}
```

```make
# Makefile
APP_NAME = myapp
SRC      = main.c
MANIFEST = app.ini
include /path/to/apps-sdk/myos-app.mk
```

```ini
; app.ini
[app]
name = My App
version = 1.0.0
author = Me
description = What it does
permissions = audio, file_write, clipboard   ; only what you use
icon = icon.png                              ; 64x64 PNG
```

## How apps run (read this once)

* An app is a normal ring-3 program. It gets its own 8 MB image and a 1 MB
  stack at a fixed address; the kernel cannot be touched from it, and every
  pointer it passes to a system call is range-checked.
* Your windows are **real desktop windows**: they move, minimize, maximize
  and resize like any other, show up in the taskbar and in Task Manager, and
  use the system look. You draw into a per-window surface with the `myos_*`
  drawing calls; the picture stays until you draw over it, so you only
  redraw when something changed.
* Input arrives as **events** (mouse, keyboard, close, resize, focus,
  timers). `myos_wait_event` sleeps until one arrives while the **desktop
  keeps running** -- dragging windows, other windows, the taskbar and cursor
  animation all stay live while your app waits.
* Time passes only inside system calls. There is no preemption: **an app
  that computes for more than ~10 seconds without calling the kernel is
  stopped by a watchdog** ("not responding"). Long loops should call
  `myos_yield()` regularly (it also lets the screen update).
* **Never make a blocking call in the middle of drawing a frame.**
  `myos_sleep`, `myos_beep`, `myos_audio_play` and `myos_wait_event` let the
  desktop paint your window as it currently is, so blocking half-way
  through a redraw shows a half-drawn picture. Draw the whole frame first,
  then wait.
* **One .app runs at a time** (an app can open up to 8 windows). Launching
  a second one shows a message instead. The kernel has no per-process
  address spaces yet; see "Limits" below.

## Permissions

An app declares what it needs in `app.ini`; the kernel enforces it:

| permission   | allows                                                        |
|--------------|---------------------------------------------------------------|
| `file_write` | create / overwrite / delete files and folders under `/Users`  |
| `audio`      | play sound (`myos_audio_play`, `myos_beep`)                   |
| `clipboard`  | read and write the system clipboard                           |

Reading files anywhere is always allowed. These permissions protect the
system from *bugs* in well-meaning programs and document what an app does;
there is no signing or user-consent prompt yet, so they are not a defence
against deliberately hostile software.

## Limits

* One running app at a time; 8 windows per app; up to 4 timers per window.
* 8 MB for code + data + heap (`malloc` uses what is left after your
  program); 1 MB stack. Window surfaces live in kernel memory (32 MB total).
* Fixed 8x16 bitmap font (ASCII).
* No threads, no networking, no floating-point formatting in `snprintf`
  (use `myos_ftoa`), no `FILE*` -- files go through the `myos_file_*` calls.
* Apps are loaded at a fixed address; link them with `lib/app.ld` (the
  makefile does).

## More

* `docs/API.md`   -- reference for every function and constant
* `docs/GUIDE.md` -- patterns: event loops, game loops, timers, files, sound
* `docs/FORMAT.md` -- the `.app` file format and the syscall ABI
