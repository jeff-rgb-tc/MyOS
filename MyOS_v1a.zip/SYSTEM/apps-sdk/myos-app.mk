# ---------------------------------------------------------------------------
# myos-app.mk -- the build rules for a MyOS app. Include it from your app's
# Makefile:
#
#     APP_NAME = hello            # output: build/hello.app
#     SRC      = main.c other.c   # your C sources
#     MANIFEST = app.ini          # name, version, author, permissions, icon
#     include ../../myos-app.mk   # path to this file inside the SDK
#
#     make            build build/<APP_NAME>.app
#     make install    copy it (and its icon) to <MyOS>/APPS/<APP_NAME>/ so it
#                     appears in the Start menu on the next disk build
#     make info       validate the .app with the same checks the kernel uses
#     make clean
#
# Toolchain: i686-elf-gcc/ld if installed, otherwise the host gcc/ld in 32-bit
# mode. nasm is NOT needed.
# ---------------------------------------------------------------------------

SDK := $(patsubst %/,%,$(dir $(lastword $(MAKEFILE_LIST))))

ifneq ($(shell command -v i686-elf-gcc 2>/dev/null),)
  CC := i686-elf-gcc
  LD := i686-elf-ld
  ARCH :=
else
  CC := gcc
  LD := ld -m elf_i386
  ARCH := -m32
endif

APP_NAME ?= app
MANIFEST ?= app.ini
MYOS_ROOT ?= $(SDK)/../..
BUILD := build

CFLAGS += $(ARCH) -O2 -Wall -Wextra -std=gnu99 -ffreestanding -fno-pic -fno-pie \
          -fno-stack-protector -fno-asynchronous-unwind-tables \
          -mno-sse -mno-mmx -march=i686 -I$(SDK)/include

# newer binutils warn about the single read-write-execute segment a flat app
# image has; the flag only exists from binutils 2.39 on
NO_RWX_WARN := $(shell $(LD) --help 2>/dev/null | grep -o -m1 -e '--no-warn-rwx-segments')

LIBGCC := $(shell $(CC) $(ARCH) -print-libgcc-file-name 2>/dev/null)
ifeq ($(wildcard $(LIBGCC)),)
  LIBGCC :=
endif

OBJS     := $(patsubst %.c,$(BUILD)/%.o,$(SRC))
# optional SDK libraries: SDK_LIBS = gfx3d   (see include/myos/gfx3d.h)
SDK_EXTRA := $(patsubst %,$(BUILD)/sdk_%.o,$(SDK_LIBS))
LIB_OBJS := $(BUILD)/sdk_libmyos.o $(BUILD)/sdk_ui.o $(BUILD)/sdk_crt0.o $(SDK_EXTRA)

all: $(BUILD)/$(APP_NAME).app

$(BUILD):
	@mkdir -p $(BUILD)

$(BUILD)/%.o: %.c | $(BUILD)
	$(CC) $(CFLAGS) -c $< -o $@

# the SDK library is compiled without loop->memset rewriting, so memset/memcpy
# can't be turned into calls to themselves
$(BUILD)/sdk_libmyos.o: $(SDK)/lib/libmyos.c | $(BUILD)
	$(CC) $(CFLAGS) -fno-tree-loop-distribute-patterns -c $< -o $@
$(BUILD)/sdk_ui.o: $(SDK)/lib/ui.c | $(BUILD)
	$(CC) $(CFLAGS) -c $< -o $@
$(BUILD)/sdk_%.o: $(SDK)/lib/%.c | $(BUILD)
	$(CC) $(CFLAGS) -c $< -o $@
$(BUILD)/sdk_crt0.o: $(SDK)/lib/crt0.S | $(BUILD)
	$(CC) $(ARCH) -c $< -o $@

$(BUILD)/$(APP_NAME).elf: $(OBJS) $(LIB_OBJS) $(SDK)/lib/app.ld
	$(LD) $(NO_RWX_WARN) -T $(SDK)/lib/app.ld -nostdlib -o $@ $(BUILD)/sdk_crt0.o $(OBJS) $(BUILD)/sdk_libmyos.o $(BUILD)/sdk_ui.o $(SDK_EXTRA) $(LIBGCC)

$(BUILD)/$(APP_NAME).app: $(BUILD)/$(APP_NAME).elf $(wildcard $(MANIFEST))
	python3 $(SDK)/tools/mkapp.py $< -o $@ $(if $(wildcard $(MANIFEST)),--manifest $(MANIFEST),--name "$(APP_NAME)")

info: $(BUILD)/$(APP_NAME).app
	python3 $(SDK)/tools/appinfo.py $<

install: $(BUILD)/$(APP_NAME).app
	mkdir -p $(MYOS_ROOT)/APPS/$(APP_NAME)
	cp $< $(MYOS_ROOT)/APPS/$(APP_NAME)/$(APP_NAME).app
	@echo "installed to $(MYOS_ROOT)/APPS/$(APP_NAME)/ -- rebuild the disk image (make iso / make img) to see it in the Start menu"

clean:
	rm -rf $(BUILD)

.PHONY: all info install clean
