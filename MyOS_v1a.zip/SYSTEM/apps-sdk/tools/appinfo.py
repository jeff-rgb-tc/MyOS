#!/usr/bin/env python3
"""
appinfo.py -- inspect and validate a .app file with exactly the rules the
kernel's loader applies (kernel/app_format.c).

    appinfo.py hello.app                 print the manifest, exit 1 if invalid
    appinfo.py hello.app --extract-icon icon.png
"""
import struct
import sys
import zlib

IMAGE_MAX = 0x00800000
ABI_LEVEL = 3
PERMS = {0x01: "file_write", 0x02: "audio", 0x04: "clipboard", 0x08: "system"}


def cstr(b):
    return b.split(b"\0", 1)[0].decode("ascii", "replace")


def parse(data):
    """Returns (info dict, error string or None)."""
    if len(data) < 8:
        return {}, "file too small"
    if data[:4] != b"MYAP":
        return {}, "not a .app file (bad magic)"
    version = struct.unpack_from("<I", data, 4)[0]
    info = {"version": version}
    if version == 1:
        if len(data) < 16:
            return info, "file too small"
        entry, size = struct.unpack_from("<II", data, 8)
        info.update(image_offset=16, entry=entry, code_size=size, mem_size=size, abi=1,
                    perms=0x7, name="App", icon_offset=0, icon_size=0, ver="", author="", desc="")
    elif version == 2:
        if len(data) < 192:
            return info, "file too small"
        # offsets 8..47: header_size, entry, code_size, mem_size, abi, perms, flags, icon_off, icon_size, crc
        (hdr, entry, size, mem, abi, perms, _flags, ioff, isize, crc) = struct.unpack_from("<10I", data, 8)
        info.update(header_size=hdr, entry=entry, code_size=size, mem_size=mem, abi=abi, perms=perms,
                    icon_offset=ioff, icon_size=isize, crc=crc, image_offset=hdr,
                    name=cstr(data[48:80]), ver=cstr(data[80:96]), author=cstr(data[96:128]),
                    desc=cstr(data[128:192]))
        if hdr != 192:
            return info, "unsupported header size"
        if abi > ABI_LEVEL:
            return info, "needs a newer MyOS (ABI level too high)"
        if abi < 1:
            return info, "invalid ABI level"
        if size <= len(data) and len(data) - size >= hdr:
            if (zlib.crc32(data[hdr:hdr + size]) & 0xFFFFFFFF) != crc:
                return info, "checksum mismatch (file damaged?)"
    else:
        return info, "unsupported .app version"
    if info["code_size"] == 0:
        return info, "empty program"
    if info["mem_size"] < info["code_size"]:
        return info, "memory size smaller than code size"
    if info["mem_size"] > IMAGE_MAX:
        return info, "program too large (over 8 MB)"
    if info["image_offset"] > len(data) or len(data) - info["image_offset"] < info["code_size"]:
        return info, "file is truncated"
    if info["entry"] >= info["code_size"]:
        return info, "entry point outside the program"
    return info, None


def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__)
        sys.exit(0 if args else 1)
    data = open(args[0], "rb").read()
    info, err = parse(data)
    if info:
        perms = [n for b, n in PERMS.items() if info.get("perms", 0) & b] or ["none"]
        print(f"format version : {info['version']}")
        print(f"name           : {info.get('name', '')}")
        if info["version"] == 2:
            print(f"app version    : {info['ver']}")
            print(f"author         : {info['author']}")
            print(f"description    : {info['desc']}")
        print(f"ABI level      : {info.get('abi')}")
        print(f"permissions    : {', '.join(perms)}")
        print(f"stored image   : {info.get('code_size')} bytes")
        print(f"memory image   : {info.get('mem_size')} bytes (bss {info.get('mem_size', 0) - info.get('code_size', 0)})")
        print(f"entry offset   : 0x{info.get('entry', 0):x}")
        print(f"icon           : {info.get('icon_size', 0)} bytes" if info.get("icon_size") else "icon           : none")
    if "--extract-icon" in args:
        out = args[args.index("--extract-icon") + 1]
        if info.get("icon_size"):
            open(out, "wb").write(data[info["icon_offset"]:info["icon_offset"] + info["icon_size"]])
            print(f"icon written to {out}")
        else:
            print("no embedded icon")
    if err:
        print(f"INVALID: {err}")
        sys.exit(1)
    print("OK: the kernel will accept this file")


if __name__ == "__main__":
    main()
