#!/usr/bin/env python3
"""
mkapp.py -- turns a linked MyOS program (ELF32, linked with lib/app.ld) into
a .app file: header (name, version, author, permissions, optional icon, CRC)
+ program image.

    mkapp.py program.elf -o hello.app [--manifest app.ini] [--icon icon.png]
             [--name N] [--version V] [--author A] [--description D]
             [--permissions file_write,audio,clipboard,system]

It reads the ELF program headers directly (no objcopy/nm needed). Bytes that
exist in the file become the stored image; the zero-initialised tail
(.bss) is recorded as a size only, so it costs nothing on disk.

app.ini (all keys optional):
    [app]
    name = Hello
    version = 1.0.0
    author = You
    description = One line about the app
    permissions = file_write, audio, clipboard
    icon = icon.png          ; 64x64 PNG recommended

Command-line options override the manifest. See docs/FORMAT.md.
"""
import argparse
import configparser
import os
import struct
import sys
import zlib

APP_BASE = 0x40000000
IMAGE_MAX = 0x00800000
HEADER_SIZE = 192
ABI_LEVEL = 2          # level written for ordinary apps; "system" apps need 3
ABI_LEVEL_SYSTEM = 3
PERMS = {"file_write": 0x01, "audio": 0x02, "clipboard": 0x04, "system": 0x08}
ICON_MAX = 64 * 1024


def fail(msg):
    print(f"mkapp: error: {msg}", file=sys.stderr)
    sys.exit(1)


def read_elf(path):
    data = open(path, "rb").read()
    if data[:4] != b"\x7fELF" or data[4] != 1 or data[5] != 1:
        fail(f"{path} is not a little-endian 32-bit ELF file")
    (e_type, e_machine, _v, e_entry, e_phoff, _shoff, _flags, _ehsize,
     e_phentsize, e_phnum) = struct.unpack_from("<HHIIIIIHHH", data, 16)
    if e_machine != 3:
        fail("not an i386 ELF (compile with -m32 / i686-elf-gcc)")
    segments = []
    for i in range(e_phnum):
        (p_type, p_offset, p_vaddr, _pa, p_filesz, p_memsz, _fl, _al) = struct.unpack_from(
            "<IIIIIIII", data, e_phoff + i * e_phentsize)
        if p_type == 1 and p_memsz:
            segments.append((p_vaddr, p_offset, p_filesz, p_memsz))
    if not segments:
        fail("no loadable segments found")
    return data, e_entry, sorted(segments)


def build_image(data, entry, segments):
    lowest = segments[0][0]
    if lowest != APP_BASE:
        fail(f"program is linked at 0x{lowest:08x}, but .app files load at 0x{APP_BASE:08x} "
             f"-- link with lib/app.ld")
    stored_end = max(v + fsz for v, _o, fsz, _m in segments) - APP_BASE
    mem_end = max(v + msz for v, _o, _f, msz in segments) - APP_BASE
    if mem_end > IMAGE_MAX:
        fail(f"program needs {mem_end} bytes of memory; the limit is {IMAGE_MAX} (8 MB)")
    image = bytearray(stored_end)
    for vaddr, off, fsz, _m in segments:
        image[vaddr - APP_BASE: vaddr - APP_BASE + fsz] = data[off: off + fsz]
    entry_off = entry - APP_BASE
    if not (0 <= entry_off < len(image)):
        fail(f"entry point 0x{entry:08x} is outside the program image")
    return bytes(image), mem_end, entry_off


def png_info(icon):
    if icon[:8] != b"\x89PNG\r\n\x1a\n":
        fail("icon is not a PNG file")
    w, h = struct.unpack_from(">II", icon, 16)
    return w, h


def fixed(text, size, what):
    raw = text.encode("ascii", "replace")
    if len(raw) >= size:
        fail(f"{what} is too long ({len(raw)} bytes, max {size - 1})")
    return raw.ljust(size, b"\0")


def main():
    ap = argparse.ArgumentParser(description="Build a MyOS .app from a linked ELF")
    ap.add_argument("elf")
    ap.add_argument("-o", "--output", required=True)
    ap.add_argument("--manifest")
    ap.add_argument("--name"); ap.add_argument("--version"); ap.add_argument("--author")
    ap.add_argument("--description"); ap.add_argument("--permissions"); ap.add_argument("--icon")
    a = ap.parse_args()

    cfg = {"name": "", "version": "1.0", "author": "", "description": "", "permissions": "", "icon": ""}
    base_dir = os.path.dirname(os.path.abspath(a.manifest)) if a.manifest else "."
    if a.manifest:
        cp = configparser.ConfigParser(inline_comment_prefixes=(";", "#"))
        if not cp.read(a.manifest):
            fail(f"cannot read manifest {a.manifest}")
        if cp.has_section("app"):
            for k in cfg:
                if cp.has_option("app", k):
                    cfg[k] = cp.get("app", k).strip()
    for k in cfg:
        v = getattr(a, k, None)
        if v is not None:
            cfg[k] = v
            if k == "icon":
                base_dir = "."
    if not cfg["name"]:
        cfg["name"] = os.path.splitext(os.path.basename(a.output))[0]

    perms = 0
    for p in [x.strip().lower() for x in cfg["permissions"].replace(";", ",").split(",") if x.strip()]:
        if p not in PERMS:
            fail(f"unknown permission '{p}' (known: {', '.join(PERMS)})")
        perms |= PERMS[p]

    abi_level = ABI_LEVEL_SYSTEM if perms & PERMS["system"] else ABI_LEVEL

    data, entry, segs = read_elf(a.elf)
    image, mem_size, entry_off = build_image(data, entry, segs)

    icon = b""
    if cfg["icon"]:
        ipath = cfg["icon"] if os.path.isabs(cfg["icon"]) else os.path.join(base_dir, cfg["icon"])
        if not os.path.exists(ipath):
            fail(f"icon file not found: {ipath}")
        icon = open(ipath, "rb").read()
        if len(icon) > ICON_MAX:
            fail(f"icon is {len(icon)} bytes; the limit is {ICON_MAX}")
        w, h = png_info(icon)
        if w != h or w < 16 or w > 256:
            print(f"mkapp: warning: icon is {w}x{h}; a square 64x64 PNG looks best", file=sys.stderr)

    icon_offset = HEADER_SIZE + len(image) if icon else 0
    header = struct.pack(
        "<4sIIIIIIIIIII", b"MYAP", 2, HEADER_SIZE, entry_off, len(image), mem_size, abi_level, perms, 0,
        icon_offset, len(icon), zlib.crc32(image) & 0xFFFFFFFF)
    header += fixed(cfg["name"], 32, "name") + fixed(cfg["version"], 16, "version") \
        + fixed(cfg["author"], 32, "author") + fixed(cfg["description"], 64, "description")
    assert len(header) == HEADER_SIZE, len(header)

    with open(a.output, "wb") as f:
        f.write(header); f.write(image); f.write(icon)

    pnames = [n for n, b in PERMS.items() if perms & b] or ["none"]
    print(f"wrote {a.output}: '{cfg['name']}' v{cfg['version']}, {len(image)} bytes stored, "
          f"{mem_size} in memory, permissions: {', '.join(pnames)}"
          + (f", icon {len(icon)} bytes" if icon else ""))


if __name__ == "__main__":
    main()
