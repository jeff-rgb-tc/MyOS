/* Host-side simulation of the desktop + kernel around a real .app: the REAL syscall.c
 * and window.c/gfx.c run against the app's REAL source (libmyos + the
 * example), driven by a scripted "user". Everything the real desktop does
 * to an app window -- calling its on_click/on_key/cursor_at/on_tick hooks,
 * painting it with wm_draw_all() -- is done the same way here. */
#ifndef SIM_OUT
#define SIM_OUT "./"
#endif
#include "stdint.h"
#include "stddef.h"
#include "gfx.h"
#include "window.h"
#include "keyboard.h"
#include "myos/abi.h"

extern void app_loader_dummy(void);
int app_main(void);
uint32_t syscall_dispatch(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
void syscall_reset_state(uint32_t, uint32_t);
void syscall_cleanup_app(void);
extern void harness_set_mouse(int, int, int);
extern int simfs_size(const char *);
void simfs_init(void);

static int sys3(int n, int a, int b, int c) { int r; __asm__ volatile("int $0x80" : "=a"(r) : "0"(n), "b"(a), "c"(b), "d"(c) : "memory"); return r; }
static void out(const char *s) { int n = 0; while(s[n]) n++; sys3(4, 1, (int)s, n); }
static void outi(const char *label, int v) {
    char b[48]; int n = 0; while(label[n]) { b[n] = label[n]; n++; }
    b[n++] = '='; char t[16]; int m = 0, neg = v < 0; if(neg) v = -v; if(!v) t[m++] = '0'; while(v) { t[m++] = '0' + v % 10; v /= 10; }
    if(neg) b[n++] = '-'; while(m) b[n++] = t[--m]; b[n++] = '\n'; sys3(4, 1, (int)b, n);
}

/* ---- kernel services the syscall layer expects ---- */
static uint32_t sim_ms = 5000;
uint32_t pit_get_ms(void) { return sim_ms; }
uint8_t keyboard_get_modifiers(void) { return 0; }
int audio_is_available(void) { return 1; }
const char *audio_active_driver_name(void) { return "Sim AC97"; }
static int audio_calls, audio_samples;
void audio_set_format(uint32_t r, uint8_t c) { (void)r; (void)c; }
void audio_queue(const int16_t *s, uint32_t n) { (void)s; audio_calls++; audio_samples += (int)n; }
static int audio_ready_flag = 1;
int audio_ready_for_more(void) { audio_ready_flag = !audio_ready_flag; return audio_ready_flag; }  /* alternate: exercises the wait path */
void audio_flush(void) {}
static int busy_calls;
void desktop_busy_begin(void) { busy_calls++; }
void desktop_busy_end(void) { busy_calls--; }
int app_is_running(void) { return 1; }
void app_note_syscall(void) {}
const char *app_loader_current_name(void) { return "simapp"; }

static long jb[5];
void app_exit_return(void) { __builtin_longjmp(jb, 1); }
uint32_t myos_sim_syscall(uint32_t n, uint32_t a, uint32_t b, uint32_t c, uint32_t d) { return syscall_dispatch(n, a, b, c, d); }

/* ---- the scripted user ---- */
static window_t *awin(void) { for(int i = 0; i < wm_window_count(); i++) { window_t *w = wm_window_at_index(i); if(w && w->user_data) return w; } return 0; }
static void ev_move(int x, int y) { window_t *w = awin(); if(w && w->cursor_at) w->cursor_at(w, x, y); }
static void ev_down(int x, int y) { window_t *w = awin(); if(w && w->on_click) w->on_click(w, x, y); }
static void ev_drag(int x, int y) { window_t *w = awin(); if(w && w->on_drag) w->on_drag(w, x, y); }
static void ev_up(int x, int y) { window_t *w = awin(); if(w && w->on_mouse_up) w->on_mouse_up(w, x, y); }
static void ev_key(int c) { window_t *w = awin(); if(w && w->on_key) w->on_key(w, (char)c); }
static void ev_close(void) { window_t *w = awin(); if(w && w->on_close_request) w->on_close_request(w); }
static void ev_click(int x, int y) { ev_move(x, y); ev_down(x, y); ev_up(x, y); }
static void ev_type(const char *s) { for(; *s; s++) ev_key(*s); }

static void dump(const char *path) {
    gfx_surface_t *b = gfx_backbuffer();
    int fd = sys3(5, (int)path, 0x241, 0644);
    uint32_t hdr[2] = { b->width, b->height };
    sys3(4, fd, (int)hdr, 8);
    uint32_t total = b->width * b->height * 4, done = 0;
    while(done < total) { int r = sys3(4, fd, (int)b->pixels + done, total - done); if(r <= 0) break; done += r; }
    sys3(6, fd, 0, 0);
}
static void shot(const char *name) {
    gfx_surface_t *b = gfx_backbuffer();
    for(uint32_t y = 0; y < b->height; y++) for(uint32_t x = 0; x < b->width; x++) {
        uint32_t t = y * 255 / b->height; b->pixels[y * b->width + x] = 0xFF000000 | ((20 + t / 12) << 16) | ((34 + t / 9) << 8) | (80 + t / 3);
    }
    wm_draw_all();
    char path[160]; int n = 0; for(const char *o = SIM_OUT; *o; o++) path[n++] = *o; path[n++] = 's'; path[n++] = 'i'; path[n++] = 'm'; path[n++] = '_'; for(const char *p = name; *p; p++) path[n++] = *p;
    const char *e = ".raw"; for(; *e; e++) path[n++] = *e; path[n] = 0;
    dump(path);
}

static int step_no = 0;
static int finished = 0;
#include SCRIPT_FILE

void desktop_pump(void) {
    sim_ms += 16;
    wm_tick_all();
    step_no++;
    script(step_no);
    if(step_no > 4000) { out("TIMEOUT: app never closed\n"); finished = 2; app_exit_return(); }
}

void _start(void) {
    gfx_init(); wm_init(); simfs_init();
    harness_set_mouse(1270, 700, 0);
    syscall_reset_state(2, SIM_PERMS);
    if(__builtin_setjmp(jb) == 0) {
        int rc = app_main();
        outi("app_main returned", rc);
    }
    syscall_cleanup_app();
    outi("windows left after cleanup", wm_window_count());
    outi("busy balance", busy_calls);
    outi("audio_calls", audio_calls);
    outi("audio_samples", audio_samples);
    report();
    sys3(1, 0, 0, 0);
    for(;;);
}
