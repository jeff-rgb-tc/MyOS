/* Host-side stand-ins for kernel services, so the real desktop code can render offscreen. */
#include "stdint.h"
#include "stddef.h"
#include "png.h"
#include "icon.h"
#include "mouse.h"
#include "rtc.h"
#include "settings.h"
#include "cursor.h"
#include "audio.h"

static int sys3(int n,int a,int b,int c){int r;__asm__ volatile("int $0x80":"=a"(r):"0"(n),"b"(a),"c"(b),"d"(c):"memory");return r;}

static char heap[48*1024*1024]; static uint32_t heap_pos;
void *kmalloc(uint32_t n){ n=(n+15)&~15u; if(heap_pos+n>sizeof(heap)) return 0; void*p=heap+heap_pos; heap_pos+=n; return p; }
void kfree(void *p){ (void)p; }
void *krealloc(void*p,uint32_t n){ (void)p; return kmalloc(n); }
void kheap_get_stats(uint32_t*t,uint32_t*f,uint32_t*a){ if(t)*t=16u*1024*1024; if(f)*f=11u*1024*1024+300000; if(a)*a=842; }

#ifndef NO_LIBC_STUBS
void *memset(void *p,int c,long n){ unsigned char*q=p; while(n-->0)*q++=(unsigned char)c; return p; }
void *memcpy(void *d,const void*s,long n){ unsigned char*a=d;const unsigned char*b=s; while(n-->0)*a++=*b++; return d; }
int memcmp(const void*a,const void*b,long n){ const unsigned char*x=a,*y=b; while(n-->0){ if(*x!=*y) return *x-*y; x++;y++;} return 0; }
long strlen(const char*s){ long n=0; while(s[n]) n++; return n; }
int strcmp(const char*a,const char*b){ while(*a&&*a==*b){a++;b++;} return (unsigned char)*a-(unsigned char)*b; }
void fastcp(char*d,char*s,uint32_t n){ memcpy(d,s,n); }
#endif
#ifdef NO_LIBC_STUBS
void *memcpy(void*,const void*,unsigned);
void fastcp(char*d,char*s,uint32_t n){ memcpy(d,s,n); }
#endif

/* minimal sprintf: %d %u %x %s %c with optional 0 and width */
static int fmt_num(char*o,unsigned v,int base,int neg,int width,int zero){
    char t[16]; int n=0; if(v==0)t[n++]='0'; while(v){ t[n++]="0123456789abcdef"[v%base]; v/=base; }
    int p=0; int total=n+(neg?1:0);
    if(neg && zero) o[p++]='-';
    while(total<width){ o[p++]= zero?'0':' '; total++; }
    if(neg && !zero) o[p++]='-';
    while(n) o[p++]=t[--n]; return p;
}
int vsprintf_(char*o,const char*f,__builtin_va_list ap){
    char*s=o;
    while(*f){
        if(*f!='%'){ *o++=*f++; continue; }
        f++; int zero=0,width=0;
        if(*f=='0'){ zero=1; f++; }
        while(*f>='0'&&*f<='9') width=width*10+(*f++-'0');
        switch(*f){
            case 'd': { int v=__builtin_va_arg(ap,int); o+=fmt_num(o,v<0?-v:v,10,v<0,width,zero); break; }
            case 'u': { unsigned v=__builtin_va_arg(ap,unsigned); o+=fmt_num(o,v,10,0,width,zero); break; }
            case 'x': { unsigned v=__builtin_va_arg(ap,unsigned); o+=fmt_num(o,v,16,0,width,zero); break; }
            case 's': { const char*a=__builtin_va_arg(ap,const char*); while(*a)*o++=*a++; break; }
            case 'c': { *o++=(char)__builtin_va_arg(ap,int); break; }
            case '%': *o++='%'; break;
        }
        f++;
    }
    *o=0; return (int)(o-s);
}
int sprintf(char*o,char*f,...){ __builtin_va_list ap; __builtin_va_start(ap,f); int r=vsprintf_(o,f,ap); __builtin_va_end(ap); return r; }
int printf(char*f,...){ (void)f; return 0; }

uint32_t get_screen_width(void){ return 1280; }
uint32_t get_screen_height(void){ return 720; }
uint32_t get_framebuffer_addr(void){ return 0; }
uint32_t get_screen_pitch(void){ return 0; }

long long fake_ticks = 4231;
long long pit_get_ticks(void){ return fake_ticks; }

static mouse_state_t ms;
mouse_state_t *mouse_get_state(void){ return &ms; }
void harness_set_mouse(int x,int y,int down){ ms.x=x; ms.y=y; ms.buttons=down?1:0; }
int mouse_button_down(uint8_t b){ return (ms.buttons & b)!=0; }

void rtc_read_time(rtc_time_t*t){ t->hours=14; t->minutes=37; t->seconds=42; }
void rtc_read_date(rtc_date_t*d){ d->year=2026; d->month=10; d->day=14; }

static settings_t st;
settings_t *settings_current(void){ return &st; }
void settings_save(void){}

uint8_t audio_get_volume(void){ return 65; }
int audio_is_muted(void){ return 0; }
void audio_set_volume(uint8_t v){ (void)v; }
void audio_set_muted(int m){ (void)m; }

void power_shutdown(void){} void power_reboot(void){}
#include "installer.h"
int installer_disk_count(void){ return 0; }
int installer_disk_info(int i, myos_diskinfo_t *o){ (void)i; (void)o; return -3; }
int installer_begin(int i){ (void)i; return -3; }
int installer_step(myos_install_status_t *s){ (void)s; return -3; }
void installer_cancel(void){}
int installer_begin_update(void){ return -3; }
void desktop_toast(const char *m){ (void)m; }
void taskbar_work_area(int *x,int *y,int *w,int *h){ *x=0; *y=0; *w=1024; *h=768-32; }
void desktop_show_transition_screen(const char*m){ (void)m; }
void desktop_enter_sleep(void){}

int desktop_cpu_usage(void){ return 34; }
int desktop_cpu_history(uint8_t*out,int max){
    static const uint8_t h[60]={4,6,5,9,12,8,7,15,22,18,14,11,9,8,25,41,55,48,36,28,20,17,13,10,9,8,12,18,26,33,45,62,71,58,44,35,29,24,19,15,12,10,14,21,30,38,34,27,22,18,16,20,28,36,41,37,33,31,34,34};
    int n=max<60?max:60; for(int i=0;i<n;i++) out[i]=h[60-n+i]; return n;
}
void fsu_format_size(uint32_t b,char*o,int m){ (void)m; unsigned mb10=(b/1024)*10/1024; sprintf(o,"%d.%d MB",(int)(mb10/10),(int)(mb10%10)); }

/* files: our pre-converted .rgba blobs stand in for the FAT32 PNGs */
static const char *map_path(const char*p,char*out){
    const char*base=p; for(const char*c=p;*c;c++) if(*c=='/') base=c+1;
    char*o=out; const char*pre="/tmp/h/"; while(*pre)*o++=*pre++;
    if(!strcmp(p,"/SYSTEM/res/backgrounds/background_1.png")){ const char*b="bg"; while(*b)*o++=*b++; }
    else { while(*base && *base!='.') *o++=*base++; }
    const char*e=".rgba"; while(*e)*o++=*e++; *o=0; return out;
}
int png_load_from_file(const char*path,png_image_t*out){
    char m[128]; map_path(path,m);
    int fd=sys3(5,(int)m,0,0); if(fd<0) return 0;
    uint32_t hdr[2]; if(sys3(3,fd,(int)hdr,8)!=8){ sys3(6,fd,0,0); return 0; }
    uint32_t*px=kmalloc(hdr[0]*hdr[1]*4); uint32_t want=hdr[0]*hdr[1]*4, got=0;
    while(got<want){ int r=sys3(3,fd,(int)px+got,want-got); if(r<=0) break; got+=r; }
    sys3(6,fd,0,0); out->width=hdr[0]; out->height=hdr[1]; out->pixels=px; return 1;
}
void png_free(png_image_t*i){ (void)i; }
int icon_load_from_file(const char*p,icon_image_t*o){ (void)p;(void)o; return 0; }
png_image_t *system_icon_get(int id){
    static png_image_t ic[5]; static int loaded[5];
    const char*names[5]={"/x/mypc.png","/x/recycle.png","/x/sleep.png","/x/reset.png","/x/shutdown.png"};
    if(id<0||id>4) return 0;
    if(!loaded[id]){ loaded[id]=png_load_from_file(names[id],&ic[id])?1:-1; }
    return loaded[id]>0?&ic[id]:0;
}
cursor_image_t *cursor_set_get(int k){ (void)k; return 0; }

/* apps registry (same names/paths as apps.c) */
#include "apps.h"
static app_entry_t apps_tab[10];
static const char *names_[10]={"Command Prompt","Explorer","Paint","Media Player","Notepad","Calculator","Calendar","Clock","Task Manager","Settings"};
static const char *icons_[10]={"/APPS/cmd/cmd.png","/APPS/explorer/explorer.png","/APPS/paint/paint.png","/APPS/mediaplayer/mediaplayer.png","/APPS/notepad/notepad.png","/APPS/calculator/calculator.png","/APPS/calendar/calendar.png","/APPS/clock/clock.png","/APPS/taskmgr/taskmgr.png","/APPS/settings/settings.png"};
void apps_init(){ for(int i=0;i<10;i++){ int j=0; while(names_[i][j]){apps_tab[i].name[j]=names_[i][j];j++;} int k=0; while(icons_[i][k]){apps_tab[i].icon_path[k]=icons_[i][k];k++;} } }
int apps_count(){ return 10; }
app_entry_t *apps_get(int i){ return (i>=0&&i<10)?&apps_tab[i]:0; }
app_icon_t *apps_get_icon(app_entry_t*a){
    if(!a->icon_load_attempted){ a->icon_load_attempted=1; png_image_t p; if(png_load_from_file(a->icon_path,&p)){ a->icon.width=p.width;a->icon.height=p.height;a->icon.pixels=p.pixels; } }
    return a->icon.pixels?&a->icon:0;
}
