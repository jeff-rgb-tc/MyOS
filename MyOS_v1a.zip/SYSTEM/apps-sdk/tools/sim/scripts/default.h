/* Default scenario: look at the first frame, then close the window. */
#define SIM_PERMS (MYOS_PERM_FILE_WRITE | MYOS_PERM_AUDIO | MYOS_PERM_CLIPBOARD)
static void report(void) { }
static void script(int n) {
    if(n == 3) shot("first_frame");
    if(n == 8) ev_close();
}
