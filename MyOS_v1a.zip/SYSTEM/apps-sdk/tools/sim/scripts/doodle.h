#define SIM_PERMS MYOS_PERM_FILE_WRITE
static void report(void) { outi("doodle.bmp size", simfs_size("/Users/User/doodle.bmp")); }
static void script(int n) {
    switch(n) {
        case 3: shot("doodle_0"); break;
        case 4: ev_click(172, 22); break;                              /* pick blue */
        case 6: ev_move(60, 100); ev_down(60, 100); break;
        case 7: ev_drag(120, 170); break;
        case 8: ev_drag(200, 120); break;
        case 9: ev_drag(280, 190); break;
        case 10: ev_up(280, 190); break;
        case 11: ev_click(142, 22); break;                             /* pick orange */
        case 12: ev_down(100, 220); break;
        case 13: ev_drag(300, 230); break;
        case 14: ev_up(300, 230); break;
        case 15: ev_key('s'); break;
        case 18: shot("doodle_1"); break;
        case 22: ev_close(); break;
    }
}
