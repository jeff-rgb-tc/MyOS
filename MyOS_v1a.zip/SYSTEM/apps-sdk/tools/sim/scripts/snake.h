#define SIM_PERMS (MYOS_PERM_AUDIO | MYOS_PERM_FILE_WRITE)
static void report(void) { outi("snake.score size", simfs_size("/Users/User/snake.score")); }
static int shots;
static void script(int n) {
    if(n == 20) shot("snake_0");
    if(n == 60) ev_key(MYOS_KEY_DOWN);
    if(n == 100) ev_key(MYOS_KEY_LEFT);
    if(n == 130) shot("snake_1");
    if(n == 400 && !shots) { shots = 1; shot("snake_over"); }
    if(n == 420) ev_key(' ');
    if(n == 450) ev_close();
}
