#define SIM_PERMS 0
static void report(void) { out("files script done\n"); }
static void script(int n) {
    switch(n) {
        case 3: shot("files_0"); break;
        case 4: ev_key(MYOS_KEY_DOWN); ev_key(MYOS_KEY_DOWN); ev_key(MYOS_KEY_DOWN); ev_key(MYOS_KEY_DOWN); break;
        case 6: shot("files_1"); break;
        case 8: ev_key(MYOS_KEY_UP); ev_key('\n'); break;                 /* into /Users */
        case 10: ev_key('\n'); break;                                     /* into /Users/User */
        case 12: ev_key(MYOS_KEY_DOWN); break;
        case 14: shot("files_2"); break;
        case 16: { window_t *w = awin(); w->w += 120; w->h += 40; } break;   /* user resizes the window */
        case 19: shot("files_3"); break;
        case 22: ev_close(); break;
    }
}
