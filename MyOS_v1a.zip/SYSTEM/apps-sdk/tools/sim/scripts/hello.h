#define SIM_PERMS MYOS_PERM_AUDIO
static void report(void) { out("hello script done\n"); }
static void script(int n) {
    switch(n) {
        case 3: shot("hello_0"); break;
        case 5: ev_click(60, 115); break;
        case 7: ev_click(60, 115); break;
        case 9: ev_click(60, 115); break;
        case 11: ev_click(60, 156); break;               /* checkbox */
        case 13: ev_click(100, 234); break;              /* focus textbox */
        case 15: ev_type("Anna"); ev_key('\n'); break;
        case 18: ev_move(120, 194); ev_down(120, 194); ev_drag(170, 194); break;   /* slider drag */
        case 20: ev_up(170, 194); break;
        case 22: ev_click(290, 234); break;              /* beep button */
        case 24: shot("hello_1"); break;
        case 30: ev_close(); break;
    }
}
