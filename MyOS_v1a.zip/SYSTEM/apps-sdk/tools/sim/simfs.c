/* In-memory filesystem + misc kernel stand-ins for the .app simulation. */
#include "stdint.h"
#include "stddef.h"
#include "fat32.h"

extern void *kmalloc(uint32_t);
extern void kfree(void *);
extern void *memcpy(void *, const void *, unsigned);
extern void *memset(void *, int, unsigned);
extern unsigned strlen(const char *);

struct f32 *master_fs = 0;

typedef struct { char path[96]; uint8_t *data; uint32_t size; int is_dir; } sf_t;
static sf_t files[64];
static int nfiles;

static int eq(const char *a, const char *b) { while(*a && *a == *b) { a++; b++; } return *a == *b; }

static sf_t *find(const char *p) { for(int i = 0; i < nfiles; i++) if(eq(files[i].path, p)) return &files[i]; return 0; }

static void add(const char *path, const char *text, int is_dir) {
    sf_t *f = &files[nfiles++];
    unsigned n = strlen(path); memcpy(f->path, path, n + 1);
    f->is_dir = is_dir;
    if(text) { f->size = strlen(text); f->data = kmalloc(f->size + 1); memcpy(f->data, text, f->size + 1); }
}

void simfs_init(void) {
    add("/", 0, 1); add("/Users", 0, 1); add("/Users/User", 0, 1); add("/SYSTEM", 0, 1); add("/APPS", 0, 1); add("/Drivers", 0, 1);
    add("/readme.txt", "Welcome to MyOS!\nThis is a plain text file shown by the\nFiles example app through the SDK's\nmyos_file_read() call.\n\nLine 7: the quick brown fox.\n", 0);
    add("/Users/User/notes.txt", "Shopping list\n- milk\n- bread\n- batteries\n", 0);
    add("/Users/User/todo.md", "# TODO\n* write more apps\n* ship the SDK\n", 0);
    add("/Users/User/photo.bmp", "BM....binary....", 0);
    add("/SYSTEM/boot.cfg", "root=hd0\n", 0);
}

int fsu_open_dir(const char *path, struct directory *out) {
    sf_t *d = find(path);
    if(!d || !d->is_dir) return 0;
    int plen = (int)strlen(path), n = 0;
    struct dir_entry *es = kmalloc(sizeof(struct dir_entry) * 64);
    for(int i = 0; i < nfiles; i++) {
        const char *p = files[i].path;
        if(eq(p, path)) continue;
        int pre = (plen == 1) ? 1 : plen + 1;
        int ok = 1;
        for(int k = 0; k < plen && ok; k++) if(p[k] != path[k]) ok = 0;
        if(!ok || (plen > 1 && p[plen] != '/')) continue;
        const char *rest = p + pre;
        int slash = 0; for(const char *q = rest; *q; q++) if(*q == '/') slash = 1;
        if(slash || !*rest) continue;
        es[n].name = (char *)rest; es[n].dir_attrs = files[i].is_dir ? DIRECTORY : 0; es[n].file_size = files[i].size;
        es[n].first_cluster = 0; es[n].wr_time = es[n].wr_date = 0; n++;
    }
    out->entries = es; out->num_entries = n; out->cluster = 0;
    return 1;
}
void free_directory(struct f32 *fs, struct directory *d) { (void)fs; kfree(d->entries); }

int fsu_stat(const char *path, int *is_dir, uint32_t *size, uint16_t *d, uint16_t *t) {
    sf_t *f = find(path); if(!f) return 0;
    if(is_dir) *is_dir = f->is_dir; if(size) *size = f->size; if(d) *d = 0; if(t) *t = 0; return 1;
}
uint8_t *fsu_read_file(const char *path, uint32_t *size) {
    sf_t *f = find(path); if(!f || f->is_dir) return 0;
    uint8_t *c = kmalloc(f->size + 1); memcpy(c, f->data, f->size); c[f->size] = 0; if(size) *size = f->size; return c;
}
int fsu_write_file(const char *path, const uint8_t *data, uint32_t len) {
    sf_t *f = find(path);
    if(!f) {
        /* parent must exist */
        char parent[96]; unsigned n = strlen(path); memcpy(parent, path, n + 1);
        int i = (int)n; while(i > 0 && parent[i] != '/') i--; if(i == 0) parent[1] = 0; else parent[i] = 0;
        sf_t *pd = find(parent); if(!pd || !pd->is_dir || nfiles >= 64) return 0;
        add(path, 0, 0); f = find(path);
    }
    if(f->data) kfree(f->data);
    f->data = kmalloc(len + 1); memcpy(f->data, data, len); f->size = len; return 1;
}
int fsu_delete_file(const char *path) {
    for(int i = 0; i < nfiles; i++) if(eq(files[i].path, path) && !files[i].is_dir) { files[i] = files[--nfiles]; return 1; }
    return 0;
}
int fsu_mkdir(const char *path) { if(find(path) || nfiles >= 64) return 0; add(path, 0, 1); return 1; }
const char *fsu_ext(const char *name) { const char *e = 0; for(; *name; name++) if(*name == '.') e = name; return e; }

static char clip[512];
void clipboard_set_text(const char *t) { unsigned n = strlen(t); if(n > 511) n = 511; memcpy(clip, t, n); clip[n] = 0; }
const char *clipboard_get_text(void) { return clip; }

/* a peek for the test script: does a path exist and how big is it? */
int simfs_size(const char *path) { sf_t *f = find(path); return f ? (int)f->size : -1; }
