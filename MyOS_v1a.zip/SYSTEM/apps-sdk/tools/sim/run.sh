#!/bin/sh
# Runs a MyOS app on your PC against the REAL kernel syscall layer and window
# manager, driven by a script that plays the user, and saves screenshots.
#
#   tools/sim/run.sh <app-dir> [script.h] [output-dir]
#
# <app-dir>   folder containing your app's .c files (all of them are compiled)
# script.h    scenario (see tools/sim/scripts/*.h); default: first frame, then close
# output-dir  where sim_*.raw / sim_*.png go (default ./sim-out)
#
# Needs: gcc with -m32 support and a Linux that can run 32-bit programs, and
# Pillow for the PNG conversion (the .raw files are written regardless).
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
SDK=$(cd "$HERE/../.." && pwd)
SYS=$(cd "$SDK/.." && pwd)                      # the SYSTEM directory
APP=$(cd "$1" && pwd)
SCRIPT=${2:-$HERE/scripts/default.h}
SCRIPT=$(cd "$(dirname "$SCRIPT")" && pwd)/$(basename "$SCRIPT")
OUT=${3:-./sim-out}
mkdir -p "$OUT"; OUT=$(cd "$OUT" && pwd)
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

KF="-m32 -O2 -fno-strict-aliasing -fwrapv -ffreestanding -fno-stack-protector -fno-pic -fno-pie \
    -fno-tree-loop-distribute-patterns -std=gnu99 -w -I$SYS/kernel -I$SYS/desktop -I$SDK/include \
    -DSYSCALL_HOST_SIM -DNO_LIBC_STUBS"
AF="-m32 -O2 -ffreestanding -fno-stack-protector -fno-pic -fno-pie -mno-sse -mno-mmx -march=i686 \
    -std=gnu99 -Wall -Wextra -I$SDK/include -DMYOS_HOST_SIM"

cd "$WORK"
gcc $KF -DSCRIPT_FILE="\"$SCRIPT\"" -DSIM_OUT="\"$OUT/\"" -c "$HERE/appsim.c" -o appsim.o
for f in "$SYS/kernel/syscall.c" "$SYS/desktop/window.c" "$SYS/desktop/gfx.c" \
         "$SYS/desktop/datetime_util.c" "$SYS/kernel/font.c" "$HERE/stubs.c" "$HERE/simfs.c"; do
    gcc $KF -c "$f" -o "$(basename "$f").o"
done
gcc $AF -fno-tree-loop-distribute-patterns -c "$SDK/lib/libmyos.c" -o libmyos.o
gcc $AF -c "$SDK/lib/ui.c" -o ui.o
n=0
for f in "$APP"/*.c; do gcc $AF -c "$f" -o "app$n.o"; n=$((n+1)); done
gcc -m32 -nostdlib -static -no-pie -Wl,--build-id=none -o sim ./*.o

cd "$OUT"
"$WORK/sim"
python3 "$HERE/raw2png.py" "$OUT" || echo "(Pillow not available: the sim_*.raw dumps are 8-byte header + BGRA pixels)"
