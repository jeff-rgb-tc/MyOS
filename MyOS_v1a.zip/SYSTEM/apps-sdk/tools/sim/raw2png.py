#!/usr/bin/env python3
"""Converts the simulator's raw framebuffer dumps (sim_*.raw) to PNG (needs Pillow)."""
import glob, struct, sys
from PIL import Image
for p in sorted(glob.glob((sys.argv[1] if len(sys.argv) > 1 else ".") + "/sim_*.raw")):
    d = open(p, "rb").read()
    w, h = struct.unpack("<II", d[:8])
    Image.frombuffer("RGBA", (w, h), d[8:], "raw", "BGRA", 0, 1).convert("RGB").save(p[:-4] + ".png")
    print("wrote", p[:-4] + ".png")
