#ifndef MYOS_H
#define MYOS_H

/* ===========================================================================
 * MyOS SDK -- the application API.
 *
 * Include this one header. Everything here is a thin, typed wrapper over the
 * kernel's syscall ABI (abi.h); nothing runs in the kernel on your behalf
 * except what you ask for. A program is:
 *
 *     #include <myos/myos.h>
 *     int app_main(void) {
 *         int win = myos_window_create("Hello", 320, 200);
 *         ...draw, then loop: myos_wait_event(win, &ev, -1)...
 *         return 0;
 *     }
 *
 * Coordinates are CLIENT coordinates: (0,0) is the top-left of your window's
 * content area. Colors are 0xAARRGGBB; alpha 0xFF is opaque. Drawing goes to
 * the window's own surface and stays there until you draw over it, so you
 * redraw only when something changed (an event arrived, a timer fired).
 * =========================================================================== */

#include <stdint.h>
#include <stddef.h>
#include <myos/abi.h>
#include <myos/libc.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MYOS_RGB(r, g, b)      (0xFF000000u | ((uint32_t)(r) << 16) | ((uint32_t)(g) << 8) | (uint32_t)(b))
#define MYOS_ARGB(a, r, g, b)  (((uint32_t)(a) << 24) | ((uint32_t)(r) << 16) | ((uint32_t)(g) << 8) | (uint32_t)(b))

#define MYOS_CHAR_W 8      /* the system font is a fixed 8x16 */
#define MYOS_CHAR_H 16

/* The desktop's own palette, so apps can match the system look. */
#define MYOS_COLOR_BG        0xFF1E1E22
#define MYOS_COLOR_CARD      0xFF2A2A30
#define MYOS_COLOR_TEXT      0xFFF2F2F5
#define MYOS_COLOR_TEXT_DIM  0xFFA0A0AA
#define MYOS_COLOR_ACCENT    0xFF4CC2FF
#define MYOS_COLOR_DANGER    0xFFC42B1C
#define MYOS_COLOR_OK        0xFF5FD38D
#define MYOS_COLOR_WARN      0xFFFFB454

/* ---- raw syscall --------------------------------------------------------- */
#ifdef MYOS_HOST_SIM
/* Test builds (see tools/): the "kernel" is linked into the same process. */
extern uint32_t myos_sim_syscall(uint32_t num, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t a4);
static inline int32_t myos_syscall(uint32_t num, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t a4) {
    return (int32_t)myos_sim_syscall(num, a1, a2, a3, a4);
}
#else
static inline int32_t myos_syscall(uint32_t num, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t a4) {
    int32_t ret;
    __asm__ volatile("int $0x80" : "=a"(ret) : "a"(num), "b"(a1), "d"(a2), "S"(a3), "D"(a4) : "memory", "cc");
    return ret;
}
#endif
#define MYOS_PTR(p) ((uint32_t)(uintptr_t)(p))

/* ---- process & time ------------------------------------------------------ */
void     myos_exit(int code) __attribute__((noreturn));
uint32_t myos_ticks_ms(void);                 /* since boot, 10 ms resolution */
void     myos_sleep(uint32_t ms);             /* desktop keeps running meanwhile */
void     myos_yield(void);                    /* let the desktop draw one frame; call this in any long loop */
#define  myos_present myos_yield              /* v1 name */
uint32_t myos_random(void);                   /* 32 random bits */
int      myos_random_range(int lo, int hi);   /* inclusive */
int      myos_sysinfo(myos_sysinfo_t *out);
int      myos_datetime(myos_datetime_t *out); /* real-time clock */
void     myos_log(const char *text);          /* kernel log line (tagged with your app name) */
void     myos_busy(int on);                   /* animated busy cursor while you compute */

/* ---- windows ------------------------------------------------------------- */
/* Opens a centred window with a client area of w x h. Returns a handle >= 0,
 * or a negative MYOS_E_* code. Up to 8 windows per app. */
int  myos_window_create(const char *title, int w, int h);
int  myos_window_create_ex(const myos_window_desc_t *desc);
int  myos_window_close(int win);
int  myos_window_set_title(int win, const char *title);
int  myos_window_size(int win, int *w, int *h);
int  myos_window_set_cursor(int win, int cursor);        /* MYOS_CURSOR_* while over the client area */
/* Periodic timer: delivers MYOS_EV_TIMER with .key == id every interval_ms
 * (min 10). id 0..3; interval 0 stops it. */
int  myos_window_set_timer(int win, int id, int interval_ms);

/* ---- drawing (into the window surface) ------------------------------------ */
int  myos_clear(int win, uint32_t color);
int  myos_fill_rect(int win, int x, int y, int w, int h, uint32_t color);
int  myos_round_rect(int win, int x, int y, int w, int h, int radius, uint32_t color);
int  myos_round_rect_ex(int win, int x, int y, int w, int h, int radius, uint32_t color, int corners);
int  myos_outline(int win, int x, int y, int w, int h, int radius, uint32_t color);   /* 1 px */
int  myos_line(int win, int x0, int y0, int x1, int y1, int width, uint32_t color);   /* antialiased */
int  myos_line_f(int win, float x0, float y0, float x1, float y1, float width, uint32_t color);
int  myos_circle(int win, int cx, int cy, int r, uint32_t color);
int  myos_text(int win, int x, int y, const char *text, uint32_t color);
int  myos_text_scaled(int win, int x, int y, const char *text, uint32_t color, int scale);
int  myos_gradient(int win, int x, int y, int w, int h, int radius, uint32_t top, uint32_t bottom);
/* Copies a w x h block of ARGB pixels (row length `stride` pixels) to (x, y).
 * With alpha != 0 the pixels' alpha channel is blended; otherwise it is a
 * plain copy -- the fast path for software-rendered frames and images. */
int  myos_blit(int win, int x, int y, int w, int h, const uint32_t *pixels, int stride, int alpha);

/* Stretches a src_w x src_h ARGB image into the dst rectangle (nearest-neighbour,
 * done by the kernel's optimised scaler). alpha != 0 blends by the pixels' alpha.
 * Render at a low resolution and scale up for a cheap 2x/3x speed-up. */
int  myos_blit_scaled(int win, int dst_x, int dst_y, int dst_w, int dst_h,
                      const uint32_t *pixels, int src_w, int src_h, int alpha);

/* Beep on the PC speaker (no sound card needed, up to 1 s; needs the audio permission). */
int  myos_speaker_beep(int freq_hz, int duration_ms);

/* A short notification pill above the taskbar (like the system's own toasts). */
int  myos_toast(const char *text);

/* ---- events -------------------------------------------------------------- */
/* Non-blocking. win may be MYOS_ANY_WINDOW. Returns 1 and fills *ev, or 0. */
int  myos_poll_event(int win, myos_event_t *ev);
/* Blocks until an event arrives or timeout_ms passes (-1 = no timeout, 0 =
 * poll). The desktop stays alive while you wait. Returns 1 or 0 (timeout). */
int  myos_wait_event(int win, myos_event_t *ev, int timeout_ms);

/* ---- files --------------------------------------------------------------- */
/* Absolute paths ("/Users/User/notes.txt"). Reading works anywhere; writing,
 * deleting and creating folders need MYOS_PERM_FILE_WRITE and only work under
 * /Users. All return a negative MYOS_E_* on failure. */
int  myos_file_read(const char *path, void *buffer, uint32_t length, uint32_t offset);
int  myos_file_write(const char *path, const void *data, uint32_t length, int append);
int  myos_file_stat(const char *path, myos_stat_t *st);
int  myos_dir_read(const char *path, int index, myos_dirent_t *entry);   /* 1 = got one, 0 = end */
int  myos_file_delete(const char *path);
int  myos_dir_create(const char *path);

/* System installer (needs the "system" permission; only /APPS/installer/installer.app gets it) */
int  myos_disk_count(void);
int  myos_disk_info(int index, myos_diskinfo_t *out);
int  myos_install_begin(int disk_index);
#define MYOS_INSTALL_BACKUP 0x1   /* keep /Users across the format */
#define MYOS_INSTALL_X64    0x2   /* reserved (refused: no 64-bit build yet) */
int  myos_install_begin_ex(int disk_index, unsigned flags);
int  myos_update_begin(void);          /* update.app: update the installed system, keep user data */
int  myos_install_step(myos_install_status_t *st);
void myos_install_cancel(void);
void myos_reboot(void);
/* Reads a whole file into a malloc'd buffer (NUL-terminated for convenience;
 * *size excludes the NUL). free() it. NULL on failure. */
uint8_t *myos_file_load(const char *path, uint32_t *size);

/* ---- sound (needs MYOS_PERM_AUDIO) ----------------------------------------- */
int  myos_audio_play(const int16_t *samples, uint32_t sample_count, uint32_t rate, int channels);
void myos_audio_stop(void);
/* Plays a tone: sine, freq in Hz, duration in ms (blocks while queueing). */
int  myos_beep(int freq_hz, int duration_ms);

/* ---- clipboard (needs MYOS_PERM_CLIPBOARD) ---------------------------------- */
int  myos_clipboard_set(const char *text);
int  myos_clipboard_get(char *buffer, int max);   /* returns length */

#ifdef __cplusplus
}
#endif
#endif
