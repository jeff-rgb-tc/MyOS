#ifndef MYOS_ABI_H
#define MYOS_ABI_H

/* ===========================================================================
 * MyOS application binary interface (ABI level 2)
 *
 * This ONE header is shared by the kernel (kernel/syscall.c, app_loader.c)
 * and by the SDK (include/myos/myos.h). Anything that crosses the ring3/ring0
 * boundary -- syscall numbers, argument structs, event layout, the .app file
 * header -- is defined here and nowhere else, so the two sides cannot drift
 * apart. Never change the meaning of an existing number or field; only add.
 *
 * Calling convention (interrupt 0x80):
 *     eax = syscall number
 *     ebx, edx, esi, edi = arguments 1..4
 *     eax = return value on exit (negative = error, see MYOS_E_*)
 * Anything needing more than four values passes a pointer to a struct below.
 * Every pointer is validated by the kernel; a bad pointer makes the call fail
 * (or, for strings, be rejected) instead of touching kernel memory.
 * =========================================================================== */

#include <stdint.h>

#define MYOS_ABI_LEVEL 3

/* ---- memory map of a running app ---------------------------------------- */
#define MYOS_APP_BASE        0x40000000u            /* image is loaded here          */
#define MYOS_APP_IMAGE_MAX   0x00800000u            /* 8 MB: code + data + bss + heap */
#define MYOS_APP_STACK_SIZE  0x00100000u            /* 1 MB stack above the image    */
#define MYOS_APP_TOP         (MYOS_APP_BASE + MYOS_APP_IMAGE_MAX + MYOS_APP_STACK_SIZE)

/* ---- error codes (syscall return values < 0) ----------------------------- */
#define MYOS_OK        0
#define MYOS_E_FAIL   (-1)   /* generic failure / bad handle           */
#define MYOS_E_PERM   (-2)   /* manifest did not request the permission */
#define MYOS_E_ARG    (-3)   /* bad argument or bad pointer             */
#define MYOS_E_NOENT  (-4)   /* file/directory not found                */
#define MYOS_E_NOMEM  (-5)   /* kernel out of memory                    */
#define MYOS_E_INST_PAYLOAD (-10) /* installer: boot loader payload missing from the system disk */
#define MYOS_E_INST_DISK    (-11) /* installer: target disk unusable / too small / is the running disk */
#define MYOS_E_INST_IO      (-12) /* installer: a disk read or write failed */
#define MYOS_E_INST_BUSY    (-13) /* installer: an installation is already running */

/* ---- permissions (manifest "permissions", enforced by the kernel) -------- */
#define MYOS_PERM_FILE_WRITE 0x01u   /* create/modify/delete files under /Users */
#define MYOS_PERM_AUDIO      0x02u   /* play sound                              */
#define MYOS_PERM_CLIPBOARD  0x04u   /* read/write the system clipboard         */
#define MYOS_PERM_SYSTEM     0x08u   /* partition/format disks, install the OS (only honoured for the system installer) */

/* ---- syscall numbers ----------------------------------------------------- */
/* 0..6 are the original v1 calls and keep their v1 meaning. */
#define SYS_EXIT             0   /* (code)                                          */
#define SYS_CREATE_WINDOW    1   /* v1: (title, w, h) -> handle; prefer WINDOW_CREATE_EX */
#define SYS_FILL_RECT        2   /* (win, myos_rect_t*, color)                      */
#define SYS_DRAW_STRING      3   /* (win, myos_point_t*, str, color)                */
#define SYS_PRESENT          4   /* ()  redraw the desktop now (same as YIELD)      */
#define SYS_POLL_EVENT       5   /* (win, myos_event_t*) -> 1 event / 0 none        */
#define SYS_SLEEP_MS         6   /* (ms)  sleeps, keeping the desktop alive         */
#define SYS_YIELD            7   /* ()  let the desktop run one frame               */
#define SYS_TICKS_MS         8   /* () -> milliseconds since boot (10 ms steps)     */
#define SYS_SYSINFO          9   /* (myos_sysinfo_t*)                               */
#define SYS_DATETIME        10   /* (myos_datetime_t*) real-time clock              */
#define SYS_RANDOM          11   /* () -> 32 pseudo-random bits                     */
#define SYS_LOG             12   /* (str)  write a line to the kernel log           */
#define SYS_SET_BUSY        13   /* (on)  show/hide the animated busy cursor        */

#define SYS_WINDOW_CREATE_EX 20  /* (myos_window_desc_t*) -> handle                 */
#define SYS_WINDOW_CLOSE     21  /* (win)                                           */
#define SYS_WINDOW_SET_TITLE 22  /* (win, str)                                      */
#define SYS_WINDOW_GET_SIZE  23  /* (win, myos_size_t*)  client size                */
#define SYS_WINDOW_SET_CURSOR 24 /* (win, MYOS_CURSOR_*) cursor over the client area */
#define SYS_WINDOW_SET_TIMER 25  /* (win, id, interval_ms) 0 interval = stop        */

#define SYS_DRAW_CLEAR       30  /* (win, color)                                    */
#define SYS_DRAW_ROUND_RECT  31  /* (win, myos_round_rect_t*)  filled, alpha-aware  */
#define SYS_DRAW_OUTLINE     32  /* (win, myos_outline_t*)                          */
#define SYS_DRAW_LINE        33  /* (win, myos_line_t*)        antialiased, any width */
#define SYS_DRAW_CIRCLE      34  /* (win, myos_circle_t*)                           */
#define SYS_DRAW_TEXT        35  /* (win, myos_text_t*)        8x16 font, integer scale */
#define SYS_DRAW_BLIT        36  /* (win, myos_blit_t*)        copy an ARGB pixel buffer */
#define SYS_DRAW_GRADIENT    37  /* (win, myos_gradient_t*)    vertical gradient        */
#define SYS_DRAW_BLIT_SCALED 38  /* (win, myos_blit_scaled_t*) stretch an ARGB buffer to a rectangle (hardware-style 2D scaler) */

#define SYS_WAIT_EVENT       41  /* (win, myos_event_t*, timeout_ms) -> 1 / 0 timeout; -1 = forever */

#define SYS_FILE_READ        50  /* (myos_file_io_t*)  -> bytes read                 */
#define SYS_FILE_WRITE       51  /* (myos_file_io_t*)  -> bytes written              */
#define SYS_FILE_STAT        52  /* (path, myos_stat_t*)                            */
#define SYS_DIR_READ         53  /* (path, index, myos_dirent_t*) -> 1 / 0 at end   */
#define SYS_FILE_DELETE      54  /* (path)                                          */
#define SYS_DIR_CREATE       55  /* (path)                                          */

#define SYS_AUDIO_PLAY       60  /* (myos_audio_t*)  queue PCM, blocks while the card is full */
#define SYS_AUDIO_STOP       61  /* ()  drop queued sound                            */

#define SYS_BEEP             91  /* (freq_hz, ms)  PC-speaker beep, works without a sound card (needs audio permission) */
#define SYS_TOAST            90  /* (str)  show a short notification pill above the taskbar */

#define SYS_CLIP_SET         70  /* (str)                                           */
#define SYS_CLIP_GET         71  /* (buf, max) -> length                            */

/* ABI level 3: system installer (needs MYOS_PERM_SYSTEM and is only honoured for
 * /APPS/installer/installer.app -- no other program may touch raw disks). */
#define SYS_DISK_COUNT       80  /* () -> number of installable disks               */
#define SYS_DISK_INFO        81  /* (index, myos_diskinfo_t*)                       */
#define SYS_INSTALL_BEGIN    82  /* (disk index) start installing                   */
#define SYS_INSTALL_STEP     83  /* (myos_install_status_t*) do the next chunk      */
#define SYS_INSTALL_CANCEL   84  /* ()                                              */
#define SYS_REBOOT           85  /* ()  restart the machine (installer: "Restart now") */
#define SYS_UPDATE_BEGIN     86  /* ()  update an installed system in place (update.app); progress via SYS_INSTALL_STEP */

/* Pass as the window argument to POLL/WAIT_EVENT to receive events from any
 * of the app's windows (each event carries its window in .window). */
#define MYOS_ANY_WINDOW      (-1)

/* ---- events -------------------------------------------------------------- */
#define MYOS_EV_NONE         0
#define MYOS_EV_MOUSE_DOWN   1   /* .x .y client coords, .button = MYOS_BTN_* */
#define MYOS_EV_MOUSE_UP     2   /* left button only                           */
#define MYOS_EV_MOUSE_MOVE   3
#define MYOS_EV_KEY          4   /* .key = ASCII or MYOS_KEY_*, .mods          */
#define MYOS_EV_CLOSE        5   /* user pressed the close box; app decides    */
#define MYOS_EV_RESIZE       6   /* .x .y = new client size; redraw everything */
#define MYOS_EV_FOCUS        7   /* .key = 1 gained, 0 lost                    */
#define MYOS_EV_TIMER        8   /* .key = timer id from SYS_WINDOW_SET_TIMER   */
#define MYOS_EV_WHEEL        9   /* .x .y pointer, .key = notches, + = scroll down (needs a mouse with a wheel) */

#define MYOS_BTN_LEFT   1
#define MYOS_BTN_RIGHT  2

#define MYOS_MOD_SHIFT  0x01
#define MYOS_MOD_CTRL   0x02
#define MYOS_MOD_ALT    0x04
#define MYOS_MOD_CAPS   0x08

/* Non-ASCII keys arrive as these values in .key (always 0..255). */
#define MYOS_KEY_UP     0x81
#define MYOS_KEY_DOWN   0x82
#define MYOS_KEY_LEFT   0x83
#define MYOS_KEY_RIGHT  0x84
#define MYOS_KEY_HOME   0x85
#define MYOS_KEY_END    0x86
#define MYOS_KEY_PGUP   0x87
#define MYOS_KEY_PGDN   0x88
#define MYOS_KEY_DELETE 0x89
#define MYOS_KEY_INSERT 0x8A
#define MYOS_KEY_F1     0x90   /* F2..F12 follow consecutively: MYOS_KEY_F1 + n - 1 */

typedef struct {
    int32_t type;      /* MYOS_EV_* */
    int32_t window;    /* handle of the window the event belongs to */
    int32_t x, y;
    int32_t key;
    int32_t button;
    int32_t mods;
    int32_t time_ms;   /* SYS_TICKS_MS when it happened */
} myos_event_t;        /* 32 bytes */

/* The v1 layout, still used for apps built against ABI level 1. */
typedef struct { int32_t type, x, y, key; } myos_event_v1_t;

/* ---- cursors (values match the kernel's cursor_kind_t) -------------------- */
#define MYOS_CURSOR_DEFAULT    0
#define MYOS_CURSOR_TEXT       1
#define MYOS_CURSOR_LINK       2
#define MYOS_CURSOR_MOVE       3
#define MYOS_CURSOR_RESIZE_H   4
#define MYOS_CURSOR_RESIZE_V   5
#define MYOS_CURSOR_UNAVAILABLE 8
#define MYOS_CURSOR_BUSY       9
#define MYOS_CURSOR_WORKING    10
#define MYOS_CURSOR_HELP       11
#define MYOS_CURSOR_PRECISION  12

/* ---- argument structs (all fields 32-bit; pointers are app addresses) ----- */
typedef struct { int32_t x, y, w, h; } myos_rect_t;
typedef struct { int32_t x, y; } myos_point_t;
typedef struct { int32_t w, h; } myos_size_t;

#define MYOS_WIN_CENTER 0x01u   /* ignore x,y and centre on the desktop */

typedef struct {
    uint32_t title;        /* char* */
    int32_t  x, y;         /* top-left; ignored with MYOS_WIN_CENTER or when < 0 */
    int32_t  w, h;         /* CLIENT size in pixels (the kernel adds title bar/borders) */
    uint32_t flags;
    uint32_t bg_color;     /* 0xAARRGGBB initial fill; 0 = default dark */
    uint32_t reserved;
} myos_window_desc_t;

/* Which corners are rounded in round-rect/gradient calls. */
#define MYOS_CORNER_TL 1
#define MYOS_CORNER_TR 2
#define MYOS_CORNER_BL 4
#define MYOS_CORNER_BR 8
#define MYOS_CORNER_ALL 15

typedef struct { int32_t x, y, w, h, radius; uint32_t color; int32_t corners; int32_t reserved; } myos_round_rect_t;
typedef struct { int32_t x, y, w, h, radius; uint32_t color; int32_t reserved[2]; } myos_outline_t;
/* Coordinates and width are in 1/16 pixel so lines can be placed sub-pixel. */
typedef struct { int32_t x0, y0, x1, y1; int32_t width; uint32_t color; int32_t reserved[2]; } myos_line_t;
typedef struct { int32_t cx, cy, r; uint32_t color; } myos_circle_t;
typedef struct { int32_t x, y; uint32_t color; int32_t scale; uint32_t text; uint32_t flags; int32_t reserved[2]; } myos_text_t;
#define MYOS_BLIT_ALPHA 0x01u   /* blend by the pixels' alpha instead of copying */
typedef struct { int32_t x, y, w, h; uint32_t pixels; int32_t stride; uint32_t flags; int32_t reserved; } myos_blit_t;
typedef struct { int32_t x, y, w, h, radius; uint32_t top, bottom; int32_t corners; } myos_gradient_t;
/* Source pixels (src_w x src_h, row length `stride`) stretched into the dst rectangle. */
typedef struct { int32_t dst_x, dst_y, dst_w, dst_h; uint32_t pixels; int32_t src_w, src_h, stride; uint32_t flags; int32_t reserved[3]; } myos_blit_scaled_t;

typedef struct {
    uint32_t abi_level;
    uint32_t screen_w, screen_h;
    uint32_t uptime_ms;
    uint32_t heap_total_kb, heap_free_kb;   /* kernel heap */
    uint32_t cpu_percent;
    uint32_t audio_available;
    uint32_t window_count;                  /* windows on the whole desktop */
    char     os_version[16];
    char     audio_driver[24];
} myos_sysinfo_t;

typedef struct {
    int32_t year, month, day;
    int32_t hour, minute, second;
    int32_t weekday;                        /* 0 = Sunday */
    int32_t reserved;
} myos_datetime_t;

#define MYOS_FILE_APPEND 0x01u              /* FILE_WRITE: add to the end instead of replacing */
typedef struct {
    uint32_t path;                          /* char* */
    uint32_t buffer;                        /* void* data in/out */
    uint32_t length;                        /* bytes to read / write */
    uint32_t offset;                        /* FILE_READ: starting byte; FILE_WRITE: unused */
    uint32_t flags;
} myos_file_io_t;

typedef struct { uint32_t size, is_dir, date, time; } myos_stat_t;

/* Installer ---------------------------------------------------------------- */
typedef struct {
    char     model[52];       /* e.g. "VBOX HARDDISK"                          */
    uint32_t size_mb;         /* capacity in MiB (0 = unknown)                 */
    uint32_t usable;          /* 1 if the installer can use it                 */
    uint32_t reason;          /* if !usable: 1 too small, 2 it is the running system disk */
    uint32_t has_filesystem;  /* 1 if a FAT32 volume is already there (will be erased) */
    uint32_t part_mb;         /* size the new MyOS partition will get          */
} myos_diskinfo_t;

#define MYOS_INST_RUNNING  0
#define MYOS_INST_DONE     1
#define MYOS_INST_FAILED   2
typedef struct {
    uint32_t state;           /* MYOS_INST_*                                   */
    uint32_t percent;         /* 0..100                                        */
    int32_t  error;           /* MYOS_E_* when state == FAILED                 */
    uint32_t files_done, files_total;
    char     stage[48];       /* "Writing boot loader", "Formatting", ...      */
    char     detail[64];      /* current file name                             */
} myos_install_status_t;
typedef struct { char name[64]; uint32_t size, is_dir; } myos_dirent_t;

typedef struct {
    uint32_t samples;                       /* int16_t* interleaved PCM */
    uint32_t count;                         /* number of int16 samples (frames * channels) */
    uint32_t sample_rate;                   /* e.g. 44100 */
    uint32_t channels;                      /* 1 or 2 */
} myos_audio_t;

/* ---- the .app file format ------------------------------------------------- *
 * [ myos_app_header_t (192 bytes) ][ image: code_size bytes ][ icon PNG, optional ]
 * The image is loaded verbatim at MYOS_APP_BASE; mem_size - code_size trailing
 * bytes are zeroed (bss). entry_offset is relative to the image start.
 * See docs/FORMAT.md. Version 1 files (16-byte header) are still accepted. */
#define MYOS_APP_MAGIC "MYAP"
#define MYOS_APP_HEADER_SIZE 192u

typedef struct {
    char     magic[4];        /* "MYAP" */
    uint32_t version;         /* 2 */
    uint32_t header_size;     /* 192; the image starts here */
    uint32_t entry_offset;
    uint32_t code_size;       /* bytes of image stored in the file */
    uint32_t mem_size;        /* bytes of image in memory (>= code_size, includes bss) */
    uint32_t abi_level;       /* lowest kernel ABI level this app needs */
    uint32_t permissions;     /* MYOS_PERM_* */
    uint32_t flags;           /* reserved, 0 */
    uint32_t icon_offset;     /* from file start, 0 = no embedded icon */
    uint32_t icon_size;
    uint32_t crc32;           /* CRC-32 (IEEE) of the stored image */
    char     name[32];
    char     version_str[16];
    char     author[32];
    char     description[64];
} __attribute__((packed)) myos_app_header_t;

/* Compile-time guards: the kernel and every app must agree on these sizes. */
typedef char myos_assert_header_size[(sizeof(myos_app_header_t) == MYOS_APP_HEADER_SIZE) ? 1 : -1];
typedef char myos_assert_event_size[(sizeof(myos_event_t) == 32) ? 1 : -1];
typedef char myos_assert_dirent_size[(sizeof(myos_dirent_t) == 72) ? 1 : -1];
typedef char myos_assert_diskinfo_size[(sizeof(myos_diskinfo_t) == 72) ? 1 : -1];
typedef char myos_assert_install_size[(sizeof(myos_install_status_t) == 132) ? 1 : -1];

#endif
