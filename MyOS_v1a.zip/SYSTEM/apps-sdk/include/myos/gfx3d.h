/* myos/gfx3d.h -- a small software 3D renderer for apps.
 *
 * MyOS has no GPU driver, so "3D acceleration" is this: a fast z-buffered,
 * flat/Gouraud-shaded triangle rasteriser plus matrix math, running in your
 * app. Render into a small off-screen buffer and let the kernel's scaler blow it
 * up (myos_blit_scaled) -- 2x scaling makes it four times cheaper.
 *
 * Add `SDK_LIBS = gfx3d` to your Makefile (before the include line).
 *
 *   static myos_g3d_t g;
 *   myos_g3d_init(&g, 240, 180);
 *   ...per frame:
 *   myos_g3d_clear(&g, 0xFF101018);
 *   myos_mat4 model = myos_mat4_mul(myos_mat4_translate(0,0,5), myos_mat4_rotate_y(angle));
 *   myos_g3d_draw_mesh(&g, &cube_mesh, &model, &proj, MYOS_G3D_CULL_BACK);
 *   myos_blit_scaled(win, 0, 0, 480, 360, g.color, g.w, g.h, 0);
 *
 * Coordinates: right-handed model space, camera at the origin looking down +Z. */
#ifndef MYOS_GFX3D_H
#define MYOS_GFX3D_H

#include <myos/myos.h>

typedef struct { float x, y, z; } myos_vec3;
typedef struct { float m[16]; } myos_mat4;           /* row-major, column vectors: v' = M * v */

myos_vec3 myos_vec3_make(float x, float y, float z);
myos_vec3 myos_vec3_sub(myos_vec3 a, myos_vec3 b);
myos_vec3 myos_vec3_cross(myos_vec3 a, myos_vec3 b);
float     myos_vec3_dot(myos_vec3 a, myos_vec3 b);
myos_vec3 myos_vec3_normalize(myos_vec3 v);

myos_mat4 myos_mat4_identity(void);
myos_mat4 myos_mat4_mul(myos_mat4 a, myos_mat4 b);   /* a * b: b is applied first */
myos_mat4 myos_mat4_translate(float x, float y, float z);
myos_mat4 myos_mat4_scale(float x, float y, float z);
myos_mat4 myos_mat4_rotate_x(float radians);
myos_mat4 myos_mat4_rotate_y(float radians);
myos_mat4 myos_mat4_rotate_z(float radians);
myos_mat4 myos_mat4_perspective(float fov_radians, float aspect, float znear, float zfar);

float myos_sinf(float x);
float myos_cosf(float x);

/* A triangle mesh. tri_color may be NULL (then base_color of the draw call is used). */
typedef struct {
    const myos_vec3 *verts; int vert_count;
    const uint16_t *indices; int tri_count;          /* 3 indices per triangle */
    const uint32_t *tri_color;                       /* optional: one 0xAARRGGBB per triangle */
} myos_mesh_t;

#define MYOS_G3D_CULL_BACK   0x01   /* skip triangles facing away (counter-clockwise = front) */
#define MYOS_G3D_NO_LIGHT    0x02   /* draw the plain colour, no shading */
#define MYOS_G3D_WIREFRAME   0x04

typedef struct {
    int w, h;
    uint32_t *color;                                 /* w*h pixels, 0xAARRGGBB: hand it to myos_blit / myos_blit_scaled */
    float *depth;
    myos_vec3 light;                                 /* direction TOWARDS the light, normalised */
    float ambient;                                   /* 0..1, default 0.25 */
    uint32_t base_color;                             /* used when the mesh has no tri_color */
    int tris_drawn;                                  /* stats, reset by myos_g3d_clear */
} myos_g3d_t;

int  myos_g3d_init(myos_g3d_t *g, int w, int h);     /* 0 on success */
void myos_g3d_free(myos_g3d_t *g);
void myos_g3d_clear(myos_g3d_t *g, uint32_t color);  /* colour + depth */
void myos_g3d_draw_mesh(myos_g3d_t *g, const myos_mesh_t *mesh, const myos_mat4 *model,
                        const myos_mat4 *proj, int flags);

/* Handy ready-made meshes (unit size, centred on the origin). */
const myos_mesh_t *myos_mesh_cube(void);
const myos_mesh_t *myos_mesh_pyramid(void);

#endif
