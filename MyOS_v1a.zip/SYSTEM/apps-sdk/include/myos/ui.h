#ifndef MYOS_UI_H
#define MYOS_UI_H

/* A small immediate-mode widget toolkit (buttons, labels, check boxes,
 * sliders, progress bars, text boxes) that draws in the system's own style.
 *
 * "Immediate mode" means you call the widget functions every time you redraw
 * and they both draw AND report interaction -- there are no widget objects
 * to create or destroy. The usual loop:
 *
 *     myos_ui_t ui;  myos_ui_init(&ui, win);
 *     for (;;) {
 *         myos_event_t ev;
 *         myos_wait_event(win, &ev, -1);
 *         if (ev.type == MYOS_EV_CLOSE) break;
 *         myos_ui_event(&ui, &ev);           // feed every event in
 *
 *         myos_clear(win, MYOS_COLOR_BG);
 *         if (myos_ui_button(&ui, 1, 20, 20, 100, 32, "Click me", MYOS_UI_ACCENT)) clicks++;
 *         myos_ui_end_frame(&ui);            // once per redraw
 *     }
 *
 * Every interactive widget takes an `id` (any non-zero int, unique within
 * the window) so the toolkit can remember which one is being pressed. */

#include <myos/myos.h>

typedef enum { MYOS_UI_NORMAL = 0, MYOS_UI_ACCENT, MYOS_UI_DANGER, MYOS_UI_FLAT } myos_ui_style_t;

typedef struct {
    int win;
    int mx, my;                 /* last pointer position (client coords) */
    int down;                   /* left button held */
    int pressed, released;      /* edge flags: true only for the redraw after the event */
    int key, mods;              /* latest MYOS_EV_KEY this frame, 0 if none */
    int keys[16];               /* ALL keys received since the last end_frame (typing can outrun redraws) */
    int key_count;
    int active;                 /* id of the widget being pressed / dragged */
    int focus;                  /* id of the text box that has the keyboard */
    int focus_claimed;
} myos_ui_t;

void myos_ui_init(myos_ui_t *ui, int win);
/* Feed every event you receive (it ignores the ones it doesn't use). */
void myos_ui_event(myos_ui_t *ui, const myos_event_t *ev);
/* Call once at the end of each redraw: clears the one-shot edge flags. */
void myos_ui_end_frame(myos_ui_t *ui);

int  myos_ui_hover(const myos_ui_t *ui, int x, int y, int w, int h);

/* Returns 1 on the redraw where the button was clicked (released over it). */
int  myos_ui_button(myos_ui_t *ui, int id, int x, int y, int w, int h, const char *label, myos_ui_style_t style);
void myos_ui_label(myos_ui_t *ui, int x, int y, const char *text, uint32_t color);
void myos_ui_label_centered(myos_ui_t *ui, int x, int y, int w, int h, const char *text, uint32_t color);
/* Toggles *value when clicked; returns 1 when it changed. */
int  myos_ui_checkbox(myos_ui_t *ui, int id, int x, int y, const char *label, int *value);
/* Drag to set *value in [min, max]; returns 1 while it changes. */
int  myos_ui_slider(myos_ui_t *ui, int id, int x, int y, int w, int *value, int min, int max);
void myos_ui_progress(myos_ui_t *ui, int x, int y, int w, int h, int value, int max);
/* Editable single-line text (ASCII). Click to focus; returns 1 when Enter is pressed. */
int  myos_ui_textbox(myos_ui_t *ui, int id, int x, int y, int w, char *buffer, int capacity);
/* Card background with a hairline outline. */
void myos_ui_panel(myos_ui_t *ui, int x, int y, int w, int h);

#endif
