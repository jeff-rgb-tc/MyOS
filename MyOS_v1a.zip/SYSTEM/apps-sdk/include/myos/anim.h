/* myos/anim.h -- animation helpers (header only, no extra library needed).
 *
 *   myos_tween_t t;
 *   myos_tween_start(&t, 0.0f, 100.0f, 300, MYOS_EASE_OUT_CUBIC);   // 300 ms
 *   ...every frame:
 *   float x = myos_tween_value(&t);        // current value
 *   if(!myos_tween_done(&t)) redraw soon;
 *
 * Drive redraws with myos_window_set_timer(win, 0, 16) so animations stay smooth
 * (the desktop only redraws an app's window when it has an event or a timer). */
#ifndef MYOS_ANIM_H
#define MYOS_ANIM_H

#include <myos/myos.h>

enum {
    MYOS_EASE_LINEAR = 0, MYOS_EASE_IN_QUAD, MYOS_EASE_OUT_QUAD, MYOS_EASE_IN_OUT_QUAD,
    MYOS_EASE_OUT_CUBIC, MYOS_EASE_IN_OUT_CUBIC, MYOS_EASE_OUT_BACK, MYOS_EASE_OUT_BOUNCE
};

/* Maps progress t in [0,1] through an easing curve. */
static inline float myos_ease(int kind, float t) {
    if(t <= 0.0f) return 0.0f;
    if(t >= 1.0f) return 1.0f;
    switch(kind) {
        case MYOS_EASE_IN_QUAD:      return t * t;
        case MYOS_EASE_OUT_QUAD:     return 1.0f - (1.0f - t) * (1.0f - t);
        case MYOS_EASE_IN_OUT_QUAD:  return t < 0.5f ? 2.0f * t * t : 1.0f - 2.0f * (1.0f - t) * (1.0f - t);
        case MYOS_EASE_OUT_CUBIC:    { float u = 1.0f - t; return 1.0f - u * u * u; }
        case MYOS_EASE_IN_OUT_CUBIC: { float u = 1.0f - t; return t < 0.5f ? 4.0f * t * t * t : 1.0f - 4.0f * u * u * u; }
        case MYOS_EASE_OUT_BACK:     { float u = t - 1.0f; return 1.0f + 2.70158f * u * u * u + 1.70158f * u * u; }
        case MYOS_EASE_OUT_BOUNCE: {
            if(t < 1.0f / 2.75f) return 7.5625f * t * t;
            if(t < 2.0f / 2.75f) { t -= 1.5f / 2.75f; return 7.5625f * t * t + 0.75f; }
            if(t < 2.5f / 2.75f) { t -= 2.25f / 2.75f; return 7.5625f * t * t + 0.9375f; }
            t -= 2.625f / 2.75f; return 7.5625f * t * t + 0.984375f;
        }
        default: return t;
    }
}

typedef struct { float from, to; uint32_t t0, duration_ms; int easing; } myos_tween_t;

static inline void myos_tween_start(myos_tween_t *tw, float from, float to, uint32_t duration_ms, int easing) {
    tw->from = from; tw->to = to; tw->t0 = myos_ticks_ms(); tw->duration_ms = duration_ms ? duration_ms : 1; tw->easing = easing;
}
static inline int myos_tween_done(const myos_tween_t *tw) { return (uint32_t)(myos_ticks_ms() - tw->t0) >= tw->duration_ms; }
static inline float myos_tween_value(const myos_tween_t *tw) {
    uint32_t el = myos_ticks_ms() - tw->t0;
    float t = el >= tw->duration_ms ? 1.0f : (float)el / (float)tw->duration_ms;
    return tw->from + (tw->to - tw->from) * myos_ease(tw->easing, t);
}

/* Blends two 0xAARRGGBB colours; t in [0,1]. */
static inline uint32_t myos_color_lerp(uint32_t a, uint32_t b, float t) {
    if(t < 0.0f) t = 0.0f;
    if(t > 1.0f) t = 1.0f;
    uint32_t out = 0;
    for(int sh = 0; sh < 32; sh += 8) {
        float ca = (float)((a >> sh) & 0xFF), cb = (float)((b >> sh) & 0xFF);
        out |= (uint32_t)(ca + (cb - ca) * t + 0.5f) << sh;
    }
    return out;
}

#endif
