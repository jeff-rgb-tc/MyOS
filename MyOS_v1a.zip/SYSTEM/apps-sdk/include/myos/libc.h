#ifndef MYOS_LIBC_H
#define MYOS_LIBC_H

/* A small freestanding C library: just the parts programs reach for. It
 * lives inside your .app (there is no shared library in this OS), so unused
 * functions are not linked in. */

#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>

#ifdef __cplusplus
extern "C" {
#endif

/* string.h */
void  *memset(void *dst, int c, size_t n);
void  *memcpy(void *dst, const void *src, size_t n);
void  *memmove(void *dst, const void *src, size_t n);
int    memcmp(const void *a, const void *b, size_t n);
size_t strlen(const char *s);
int    strcmp(const char *a, const char *b);
int    strncmp(const char *a, const char *b, size_t n);
char  *strcpy(char *dst, const char *src);
char  *strncpy(char *dst, const char *src, size_t n);
char  *strcat(char *dst, const char *src);
char  *strchr(const char *s, int c);
char  *strrchr(const char *s, int c);
char  *strstr(const char *hay, const char *needle);

/* ctype.h */
int toupper(int c);
int tolower(int c);
int isdigit(int c);
int isalpha(int c);
int isspace(int c);

/* stdlib.h -- malloc is a first-fit allocator over the free space between
 * your program's end and the 8 MB image limit. */
void *malloc(size_t n);
void  free(void *p);
void *calloc(size_t n, size_t size);
void *realloc(void *p, size_t n);
size_t myos_heap_free(void);          /* bytes still available to malloc */
int   atoi(const char *s);
int   abs(int v);
int   rand(void);                      /* deterministic LCG; use myos_random() for entropy */
void  srand(unsigned seed);
#define RAND_MAX 0x7FFFFFFF
void  qsort(void *base, size_t count, size_t size, int (*cmp)(const void *, const void *));

/* stdio.h subset: formatted output into memory. Supports %d %i %u %x %X %c
 * %s %p %% with width, '0' and '-' flags and '*' width. No floating point
 * (format those yourself: see myos_ftoa). */
int snprintf(char *buf, size_t size, const char *fmt, ...) __attribute__((format(printf, 3, 4)));
int vsnprintf(char *buf, size_t size, const char *fmt, va_list ap);
int myos_ftoa(char *buf, size_t size, double v, int decimals);

/* math (x87): enough for graphics and games. */
double myos_sin(double radians);
double myos_cos(double radians);
double myos_sqrt(double v);
double myos_atan2(double y, double x);
#define MYOS_PI 3.14159265358979323846

#define MYOS_MIN(a, b) ((a) < (b) ? (a) : (b))
#define MYOS_MAX(a, b) ((a) > (b) ? (a) : (b))
#define MYOS_CLAMP(v, lo, hi) ((v) < (lo) ? (lo) : ((v) > (hi) ? (hi) : (v)))

#ifdef __cplusplus
}
#endif
#endif
