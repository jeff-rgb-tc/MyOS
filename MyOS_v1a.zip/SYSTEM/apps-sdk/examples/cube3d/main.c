/* cube3d -- demo of the SDK's software 3D renderer (myos/gfx3d.h) and the
 * animation helpers (myos/anim.h). Drag with the mouse to spin the shape,
 * click the buttons to switch mesh / wireframe. A bouncy tween animates the
 * scale whenever you switch. The scene is rendered at 240x180 and stretched
 * 2x by the kernel scaler (myos_blit_scaled). */
#include <myos/myos.h>
#include <myos/ui.h>
#include <myos/anim.h>
#include <myos/gfx3d.h>

#define RW 240
#define RH 180
#define W (RW * 2)
#define H (RH * 2 + 44)

int app_main(void) {
    int win = myos_window_create("3D Demo", W, H);
    if(win < 0) return 1;
    myos_ui_t ui;
    myos_ui_init(&ui, win);
    myos_window_set_timer(win, 0, 20);

    static myos_g3d_t g;
    if(myos_g3d_init(&g, RW, RH) != 0) { myos_toast("3D Demo: out of memory"); return 1; }
    myos_mat4 proj = myos_mat4_perspective(1.1f, (float)RW / (float)RH, 0.2f, 50.0f);

    float rx = 0.5f, ry = 0.0f, vy = 1.2f, vx = 0.4f;   /* angles + spin speed */
    int mesh = 0, wire = 0, dragging = 0, lx = 0, ly = 0;
    myos_tween_t pop;
    myos_tween_start(&pop, 0.2f, 1.0f, 600, MYOS_EASE_OUT_BACK);
    uint32_t last = myos_ticks_ms(), fps_t0 = last; int frames = 0, fps = 0;

    for(;;) {
        uint32_t now = myos_ticks_ms();
        float dt = (float)(now - last) / 1000.0f; last = now;
        if(!dragging) { ry += vy * dt; rx += vx * dt; }

        float s = myos_tween_value(&pop);
        myos_mat4 model = myos_mat4_mul(myos_mat4_translate(0, 0, 2.6f),
                          myos_mat4_mul(myos_mat4_rotate_y(ry),
                          myos_mat4_mul(myos_mat4_rotate_x(rx), myos_mat4_scale(s, s, s))));
        myos_g3d_clear(&g, 0xFF14141A);
        myos_g3d_draw_mesh(&g, mesh ? myos_mesh_pyramid() : myos_mesh_cube(), &model, &proj,
                           MYOS_G3D_CULL_BACK | (wire ? MYOS_G3D_WIREFRAME : 0));

        myos_clear(win, MYOS_COLOR_BG);
        myos_blit_scaled(win, 0, 0, RW * 2, RH * 2, g.color, g.w, g.h, 0);

        char buf[48];
        snprintf(buf, sizeof(buf), "%d fps  %d tris", fps, g.tris_drawn);
        myos_text(win, 8, 8, buf, 0xFFF2F2F5);
        if(myos_ui_button(&ui, 1, 8, RH * 2 + 6, 110, 32, mesh ? "Cube" : "Pyramid", MYOS_UI_NORMAL)) {
            mesh ^= 1; myos_tween_start(&pop, 0.2f, 1.0f, 600, MYOS_EASE_OUT_BACK);
        }
        if(myos_ui_button(&ui, 2, 126, RH * 2 + 6, 110, 32, wire ? "Solid" : "Wireframe", MYOS_UI_NORMAL)) wire ^= 1;
        myos_ui_end_frame(&ui);

        frames++;
        if(now - fps_t0 >= 1000) { fps = frames; frames = 0; fps_t0 = now; }

        myos_event_t ev;
        myos_wait_event(win, &ev, -1);
        for(;;) {
            if(ev.type == MYOS_EV_CLOSE) { myos_g3d_free(&g); return 0; }
            if(ev.type == MYOS_EV_MOUSE_DOWN && ev.y < RH * 2) { dragging = 1; lx = ev.x; ly = ev.y; }
            else if(ev.type == MYOS_EV_MOUSE_UP) dragging = 0;
            else if(ev.type == MYOS_EV_MOUSE_MOVE && dragging) {
                ry += (float)(ev.x - lx) * 0.015f; rx += (float)(ev.y - ly) * 0.015f; lx = ev.x; ly = ev.y;
            }
            if(ev.type != MYOS_EV_TIMER) myos_ui_event(&ui, &ev);
            if(!myos_poll_event(win, &ev)) break;
        }
    }
}
