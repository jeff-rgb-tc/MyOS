/* hello -- the smallest useful MyOS app: a window, a click counter, a
 * checkbox, a slider and a text box, using the toolkit in <myos/ui.h>.
 *
 * Shows: window creation, the event loop, redrawing only when something
 * happened, closing cleanly when the user presses the close box. */
#include <myos/myos.h>
#include <myos/ui.h>

int app_main(void) {
    int win = myos_window_create("Hello, MyOS", 360, 300);
    if(win < 0) return 1;

    myos_ui_t ui;
    myos_ui_init(&ui, win);

    int clicks = 0, dark_title = 1, volume = 40, want_beep = 0;
    char name[32] = "";
    char greeting[64] = "Type your name below";

    for(;;) {
        /* Draw the whole UI. It is cheap, and immediate-mode widgets draw
         * and report clicks in the same call. */
        myos_clear(win, MYOS_COLOR_BG);
        myos_text_scaled(win, 20, 16, "Hello!", MYOS_COLOR_TEXT, 3);
        myos_ui_label(&ui, 22, 70, greeting, MYOS_COLOR_TEXT_DIM);

        if(myos_ui_button(&ui, 1, 20, 100, 120, 34, "Click me", MYOS_UI_ACCENT)) clicks++;
        char line[40];
        snprintf(line, sizeof(line), "Clicked %d time%s", clicks, clicks == 1 ? "" : "s");
        myos_ui_label(&ui, 156, 109, line, MYOS_COLOR_TEXT);

        myos_ui_checkbox(&ui, 2, 20, 150, "Show a checkbox", &dark_title);
        myos_ui_slider(&ui, 3, 20, 184, 200, &volume, 0, 100);
        snprintf(line, sizeof(line), "%d%%", volume);
        myos_ui_label(&ui, 232, 186, line, MYOS_COLOR_TEXT_DIM);

        if(myos_ui_textbox(&ui, 4, 20, 220, 220, name, sizeof(name)) && name[0]) {
            snprintf(greeting, sizeof(greeting), "Nice to meet you, %s!", name);
        }
        if(myos_ui_button(&ui, 5, 250, 220, 90, 28, "Beep", MYOS_UI_NORMAL)) want_beep = 1;
        myos_ui_progress(&ui, 20, 262, 320, 8, clicks % 11, 10);

        myos_ui_end_frame(&ui);

        /* Anything that BLOCKS (sound, sleep) goes after the frame is fully
         * drawn: while a call blocks the desktop keeps painting your window
         * as it is, so blocking in the middle of drawing would show a
         * half-finished frame. */
        if(want_beep) { want_beep = 0; myos_beep(660, 120); }

        /* Sleep until the next event. The desktop keeps running meanwhile. */
        myos_event_t ev;
        myos_wait_event(win, &ev, -1);
        if(ev.type == MYOS_EV_CLOSE) break;
        myos_ui_event(&ui, &ev);
        /* Fold any other events that arrived meanwhile into the same redraw. */
        while(myos_poll_event(win, &ev)) {
            if(ev.type == MYOS_EV_CLOSE) return 0;
            myos_ui_event(&ui, &ev);
        }
    }
    return 0;
}
