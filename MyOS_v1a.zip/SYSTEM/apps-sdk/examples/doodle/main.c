/* doodle -- a tiny paint program. Shows software rendering into your own
 * pixel buffer and blitting it (the fast path for games and image apps),
 * mouse events with drag, keyboard shortcuts, and saving a file (a 24-bit
 * BMP under /Users, which needs the file_write permission). */
#include <myos/myos.h>
#include <myos/ui.h>

#define CW 420
#define CH 320
#define CANVAS_W 400
#define CANVAS_H 230
#define CANVAS_X 10
#define CANVAS_Y 44

static uint32_t canvas[CANVAS_W * CANVAS_H];
static const uint32_t palette[] = { 0xFF000000, 0xFFE5484D, 0xFFF5A524, 0xFFFFE066, 0xFF4ADE80, 0xFF4CC2FF, 0xFF8B7CFF, 0xFFFFFFFF };
#define NCOLORS ((int)(sizeof(palette) / sizeof(palette[0])))

static void stamp(int cx, int cy, int radius, uint32_t color) {
    for(int y = -radius; y <= radius; y++) {
        for(int x = -radius; x <= radius; x++) {
            int px = cx + x, py = cy + y;
            if(x * x + y * y <= radius * radius + radius && px >= 0 && py >= 0 && px < CANVAS_W && py < CANVAS_H)
                canvas[py * CANVAS_W + px] = color;
        }
    }
}

/* Draws a thick line into the canvas by stamping along it. */
static void stroke(int x0, int y0, int x1, int y1, int radius, uint32_t color) {
    int dx = x1 - x0, dy = y1 - y0;
    int steps = (abs(dx) > abs(dy) ? abs(dx) : abs(dy));
    if(steps == 0) steps = 1;
    for(int i = 0; i <= steps; i++) stamp(x0 + dx * i / steps, y0 + dy * i / steps, radius, color);
}

static int save_bmp(const char *path) {
    int row = CANVAS_W * 3;                              /* 400*3 = 1200, already a multiple of 4 */
    uint32_t size = 54 + (uint32_t)row * CANVAS_H;
    uint8_t *f = (uint8_t *)malloc(size);
    if(!f) return -1;
    memset(f, 0, 54);
    f[0] = 'B'; f[1] = 'M';
    *(uint32_t *)(f + 2) = size;  *(uint32_t *)(f + 10) = 54;  *(uint32_t *)(f + 14) = 40;
    *(int32_t *)(f + 18) = CANVAS_W;  *(int32_t *)(f + 22) = CANVAS_H;
    *(uint16_t *)(f + 26) = 1;  *(uint16_t *)(f + 28) = 24;
    for(int y = 0; y < CANVAS_H; y++) {                  /* BMP rows run bottom-up, BGR order */
        uint8_t *o = f + 54 + (CANVAS_H - 1 - y) * row;
        for(int x = 0; x < CANVAS_W; x++) {
            uint32_t p = canvas[y * CANVAS_W + x];
            o[x * 3] = (uint8_t)p; o[x * 3 + 1] = (uint8_t)(p >> 8); o[x * 3 + 2] = (uint8_t)(p >> 16);
        }
    }
    int r = myos_file_write(path, f, size, 0);
    free(f);
    return r;
}

int app_main(void) {
    int win = myos_window_create("Doodle", CW, CH);
    if(win < 0) return 1;
    myos_window_set_cursor(win, MYOS_CURSOR_PRECISION);

    myos_ui_t ui;
    myos_ui_init(&ui, win);
    for(int i = 0; i < CANVAS_W * CANVAS_H; i++) canvas[i] = 0xFFFFFFFF;

    int color = 0, brush = 3, drawing = 0, last_x = 0, last_y = 0;
    char status[64] = "Draw with the mouse. S saves, C clears.";

    for(;;) {
        myos_clear(win, MYOS_COLOR_BG);
        for(int i = 0; i < NCOLORS; i++) {                       /* palette swatches */
            int x = 10 + i * 30;
            myos_round_rect(win, x, 10, 24, 24, 6, palette[i]);
            if(i == color) myos_outline(win, x - 2, 8, 28, 28, 8, 0xFFF2F2F5);
            if(myos_ui_hover(&ui, x, 10, 24, 24) && ui.pressed) color = i;
        }
        myos_ui_slider(&ui, 20, 262, 14, 80, &brush, 1, 12);
        if(myos_ui_button(&ui, 21, 352, 10, 58, 26, "Clear", MYOS_UI_NORMAL))
            for(int i = 0; i < CANVAS_W * CANVAS_H; i++) canvas[i] = 0xFFFFFFFF;

        myos_blit(win, CANVAS_X, CANVAS_Y, CANVAS_W, CANVAS_H, canvas, CANVAS_W, 0);
        myos_outline(win, CANVAS_X - 1, CANVAS_Y - 1, CANVAS_W + 2, CANVAS_H + 2, 0, 0x40FFFFFF);
        myos_text(win, 12, CH - 30, status, MYOS_COLOR_TEXT_DIM);
        myos_ui_end_frame(&ui);

        myos_event_t ev;
        myos_wait_event(win, &ev, -1);
        do {
            if(ev.type == MYOS_EV_CLOSE) return 0;
            myos_ui_event(&ui, &ev);
            int cx = ev.x - CANVAS_X, cy = ev.y - CANVAS_Y;
            if(ev.type == MYOS_EV_MOUSE_DOWN && ev.button == MYOS_BTN_LEFT &&
               cx >= 0 && cy >= 0 && cx < CANVAS_W && cy < CANVAS_H) {
                drawing = 1; last_x = cx; last_y = cy; stamp(cx, cy, brush, palette[color]);
            }
            else if(ev.type == MYOS_EV_MOUSE_MOVE && drawing && ev.button == MYOS_BTN_LEFT) {
                stroke(last_x, last_y, cx, cy, brush, palette[color]); last_x = cx; last_y = cy;
            }
            else if(ev.type == MYOS_EV_MOUSE_UP) drawing = 0;
            else if(ev.type == MYOS_EV_KEY) {
                if(ev.key == 'c' || ev.key == 'C') for(int i = 0; i < CANVAS_W * CANVAS_H; i++) canvas[i] = 0xFFFFFFFF;
                if(ev.key == 's' || ev.key == 'S') {
                    int r = save_bmp("/Users/User/doodle.bmp");
                    snprintf(status, sizeof(status), r >= 0 ? "Saved /Users/User/doodle.bmp" : "Save failed (%d)", r);
                }
                if(ev.key >= '1' && ev.key <= '0' + NCOLORS) color = ev.key - '1';
            }
        } while(myos_poll_event(win, &ev));
    }
}
