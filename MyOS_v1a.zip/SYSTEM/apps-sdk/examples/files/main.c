/* files -- a small file browser and text viewer. Shows the directory and
 * file APIs (myos_dir_read / myos_file_stat / myos_file_load), keyboard
 * navigation, list scrolling and resizable layout (it redraws on
 * MYOS_EV_RESIZE and uses the window's current size). Read-only, so it
 * needs no permissions. */
#include <myos/myos.h>
#include <myos/ui.h>

#define MAX_ENTRIES 128
#define ROW 24

static char cwd[120] = "/";
static myos_dirent_t entries[MAX_ENTRIES];
static int count, sel, scroll;
static char preview[2048];
static int preview_len;

static int cmp_entries(const void *a, const void *b) {
    const myos_dirent_t *x = (const myos_dirent_t *)a, *y = (const myos_dirent_t *)b;
    if(x->is_dir != y->is_dir) return (int)y->is_dir - (int)x->is_dir;      /* folders first */
    for(int i = 0; x->name[i] || y->name[i]; i++) {
        int p = tolower((unsigned char)x->name[i]), q = tolower((unsigned char)y->name[i]);
        if(p != q) return p - q;
    }
    return 0;
}

static void join(char *out, int max, const char *dir, const char *name) {
    snprintf(out, (size_t)max, "%s%s%s", dir, (dir[strlen(dir) - 1] == '/') ? "" : "/", name);
}

static void load_preview(void) {
    preview_len = 0; preview[0] = 0;
    if(sel >= count || entries[sel].is_dir) return;
    char path[200];
    join(path, sizeof(path), cwd, entries[sel].name);
    int n = myos_file_read(path, preview, sizeof(preview) - 1, 0);
    if(n <= 0) return;
    for(int i = 0; i < n; i++) {                        /* show only printable text */
        unsigned char c = (unsigned char)preview[i];
        if(c != '\n' && (c < 32 || c > 126)) { preview[i] = '.'; }
    }
    preview[n] = 0; preview_len = n;
}

static void load_dir(void) {
    count = 0; sel = 0; scroll = 0;
    myos_dirent_t e;
    for(int i = 0; count < MAX_ENTRIES && myos_dir_read(cwd, i, &e) == 1; i++) entries[count++] = e;
    qsort(entries, (size_t)count, sizeof(entries[0]), cmp_entries);
    load_preview();
}

static void go_up(void) {
    if(strcmp(cwd, "/") == 0) return;
    char *slash = strrchr(cwd, '/');
    if(slash == cwd) cwd[1] = 0; else *slash = 0;
    load_dir();
}

static void open_selected(void) {
    if(sel >= count || !entries[sel].is_dir) return;
    char path[120];
    join(path, sizeof(path), cwd, entries[sel].name);
    strncpy(cwd, path, sizeof(cwd) - 1);
    load_dir();
}

static void draw(myos_ui_t *ui, int win, int w, int h) {
    myos_clear(win, MYOS_COLOR_BG);
    myos_round_rect(win, 10, 10, w - 20, 30, 8, MYOS_COLOR_CARD);
    char head[140];
    snprintf(head, sizeof(head), "%s", cwd);
    myos_text(win, 20, 17, head, MYOS_COLOR_TEXT);

    int list_w = (w - 30) / 2, top = 48, rows = (h - top - 10) / ROW;
    myos_ui_panel(ui, 10, top, list_w, rows * ROW + 8);
    if(sel < scroll) scroll = sel;
    if(sel >= scroll + rows) scroll = sel - rows + 1;
    for(int r = 0; r < rows && scroll + r < count; r++) {
        int i = scroll + r, y = top + 4 + r * ROW;
        if(i == sel) myos_round_rect(win, 14, y, list_w - 8, ROW - 2, 6, 0xFF3A3A44);
        uint32_t col = entries[i].is_dir ? MYOS_COLOR_ACCENT : MYOS_COLOR_TEXT;
        char name[40];
        snprintf(name, sizeof(name), "%s%s", entries[i].is_dir ? "[+] " : "    ", entries[i].name);
        int max_chars = (list_w - 100) / MYOS_CHAR_W;
        if((int)strlen(name) > max_chars && max_chars > 3) { name[max_chars - 2] = '.'; name[max_chars - 1] = '.'; name[max_chars] = 0; }
        myos_text(win, 20, y + 4, name, col);
        if(!entries[i].is_dir) {
            char sz[16];
            if(entries[i].size >= 1024) snprintf(sz, sizeof(sz), "%u KB", entries[i].size / 1024);
            else snprintf(sz, sizeof(sz), "%u B", entries[i].size);
            myos_text(win, 10 + list_w - 12 - (int)strlen(sz) * MYOS_CHAR_W, y + 4, sz, MYOS_COLOR_TEXT_DIM);
        }
    }
    if(count == 0) myos_text(win, 24, top + 14, "(empty)", MYOS_COLOR_TEXT_DIM);

    int px = 20 + list_w;
    myos_ui_panel(ui, px, top, w - px - 10, rows * ROW + 8);
    if(preview_len == 0) {
        myos_text(win, px + 14, top + 14, count && entries[sel].is_dir ? "Folder - press Enter" : "No preview", MYOS_COLOR_TEXT_DIM);
    }
    else {
        int x = px + 12, y = top + 10, max_cols = (w - px - 34) / MYOS_CHAR_W;
        char line[96]; int n = 0;
        for(int i = 0; i <= preview_len && y < top + rows * ROW - 8; i++) {
            char c = preview[i];
            if(c == '\n' || c == 0 || n >= max_cols || n >= (int)sizeof(line) - 1) {
                line[n] = 0; myos_text(win, x, y, line, MYOS_COLOR_TEXT); y += 18; n = 0;
                if(c == 0) break;
                if(c != '\n') line[n++] = c;
            }
            else line[n++] = c;
        }
    }
    myos_ui_end_frame(ui);
}

int app_main(void) {
    int win = myos_window_create("Files", 640, 420);
    if(win < 0) return 1;
    myos_ui_t ui;
    myos_ui_init(&ui, win);
    load_dir();

    for(;;) {
        int w, h;
        myos_window_size(win, &w, &h);
        draw(&ui, win, w, h);

        myos_event_t ev;
        myos_wait_event(win, &ev, -1);
        do {
            if(ev.type == MYOS_EV_CLOSE) return 0;
            myos_ui_event(&ui, &ev);
            if(ev.type == MYOS_EV_KEY) {
                int old = sel;
                if(ev.key == MYOS_KEY_DOWN && sel + 1 < count) sel++;
                else if(ev.key == MYOS_KEY_UP && sel > 0) sel--;
                else if(ev.key == '\n') open_selected();
                else if(ev.key == 8 || ev.key == MYOS_KEY_LEFT) go_up();
                if(sel != old) load_preview();
            }
            else if(ev.type == MYOS_EV_MOUSE_DOWN && ev.button == MYOS_BTN_LEFT) {
                int row = (ev.y - 52) / ROW, list_w = (w - 30) / 2;
                if(ev.x >= 10 && ev.x < 10 + list_w && ev.y >= 52 && scroll + row < count) {
                    int clicked = scroll + row;
                    if(clicked == sel) open_selected(); else { sel = clicked; load_preview(); }
                }
            }
        } while(myos_poll_event(win, &ev));
    }
}
