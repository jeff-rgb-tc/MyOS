/* snake -- keyboard input, a periodic timer as the game clock, random
 * numbers, sound effects and a saved high score (file read + write).
 * Arrow keys or WASD steer, Space restarts after game over. */
#include <myos/myos.h>

#define COLS 24
#define ROWS 16
#define CELL 20
#define HUD  36
#define HS_PATH "/Users/User/snake.score"

static int sx[COLS * ROWS], sy[COLS * ROWS];
static int len, dir, next_dir, fx, fy, score, best, alive, tick_ms;

static void place_food(void) {
    for(;;) {
        fx = myos_random_range(0, COLS - 1);
        fy = myos_random_range(0, ROWS - 1);
        int clash = 0;
        for(int i = 0; i < len; i++) if(sx[i] == fx && sy[i] == fy) { clash = 1; break; }
        if(!clash) return;
    }
}

static void new_game(void) {
    len = 3; dir = next_dir = 1; score = 0; alive = 1; tick_ms = 140;
    for(int i = 0; i < len; i++) { sx[i] = COLS / 2 - i; sy[i] = ROWS / 2; }
    place_food();
}

static void load_best(void) {
    char buf[16] = "";
    int n = myos_file_read(HS_PATH, buf, sizeof(buf) - 1, 0);
    best = n > 0 ? atoi(buf) : 0;
}

static void save_best(void) {
    char buf[16];
    int n = snprintf(buf, sizeof(buf), "%d", best);
    myos_file_write(HS_PATH, buf, (uint32_t)n, 0);      /* needs the file_write permission */
}

static void step(int win) {
    if(!alive) return;
    dir = next_dir;
    static const int dx[4] = { 0, 1, 0, -1 }, dy[4] = { -1, 0, 1, 0 };   /* up right down left */
    int nx = sx[0] + dx[dir], ny = sy[0] + dy[dir];
    int hit = nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS;
    for(int i = 0; i < len - 1 && !hit; i++) if(sx[i] == nx && sy[i] == ny) hit = 1;
    if(hit) {
        alive = 0;
        myos_beep(160, 300);
        if(score > best) { best = score; save_best(); }
        myos_window_set_timer(win, 0, 0);
        return;
    }
    int ate = (nx == fx && ny == fy);
    if(ate) len++;
    for(int i = len - 1; i > 0; i--) { sx[i] = sx[i - 1]; sy[i] = sy[i - 1]; }
    sx[0] = nx; sy[0] = ny;
    if(ate) {
        score++;
        myos_beep(880, 60);
        place_food();
        if(tick_ms > 70) { tick_ms -= 4; myos_window_set_timer(win, 0, tick_ms); }   /* speed up */
    }
}

static void draw(int win) {
    myos_clear(win, MYOS_COLOR_BG);
    char buf[48];
    snprintf(buf, sizeof(buf), "Score %d    Best %d", score, best);
    myos_text(win, 12, 10, buf, MYOS_COLOR_TEXT);

    myos_round_rect(win, 0, HUD, COLS * CELL, ROWS * CELL, 0, 0xFF16161A);
    myos_circle(win, fx * CELL + CELL / 2, HUD + fy * CELL + CELL / 2, CELL / 2 - 3, 0xFFE5484D);
    for(int i = len - 1; i >= 0; i--) {
        uint32_t c = i == 0 ? 0xFF8CF0B0 : MYOS_COLOR_OK;
        myos_round_rect(win, sx[i] * CELL + 1, HUD + sy[i] * CELL + 1, CELL - 2, CELL - 2, i == 0 ? 7 : 5, c);
    }
    if(!alive) {
        myos_round_rect(win, 90, HUD + 110, 300, 90, 12, 0xE0101014);
        myos_text_scaled(win, 140, HUD + 122, "Game over", 0xFFFF6B5E, 2);
        myos_text(win, 128, HUD + 164, "Press Space to play again", MYOS_COLOR_TEXT_DIM);
    }
}

int app_main(void) {
    int win = myos_window_create("Snake", COLS * CELL, HUD + ROWS * CELL);
    if(win < 0) return 1;
    load_best();
    new_game();
    myos_window_set_timer(win, 0, tick_ms);
    draw(win);

    for(;;) {
        myos_event_t ev;
        myos_wait_event(win, &ev, -1);
        if(ev.type == MYOS_EV_CLOSE) return 0;
        if(ev.type == MYOS_EV_TIMER) step(win);
        else if(ev.type == MYOS_EV_KEY) {
            int k = ev.key, want = -1;
            if(k == MYOS_KEY_UP || k == 'w' || k == 'W') want = 0;
            else if(k == MYOS_KEY_RIGHT || k == 'd' || k == 'D') want = 1;
            else if(k == MYOS_KEY_DOWN || k == 's' || k == 'S') want = 2;
            else if(k == MYOS_KEY_LEFT || k == 'a' || k == 'A') want = 3;
            if(want >= 0 && want != (dir + 2) % 4) next_dir = want;      /* no 180-degree turns */
            if(k == ' ' && !alive) { new_game(); myos_window_set_timer(win, 0, tick_ms); }
        }
        draw(win);
    }
}
