/* 2048 -- arrow keys / WASD slide the tiles, equal tiles merge. N = new game. */
#include <myos/myos.h>

#define SZ 4
#define CELL 92
#define GAP 8
#define HUD 56
#define SAVE "/Users/User/2048.score"

static int b[SZ][SZ], score, best, over;

static void add_tile(void) {
    int cx[SZ * SZ], cy[SZ * SZ], n = 0;
    for(int y = 0; y < SZ; y++) for(int x = 0; x < SZ; x++) if(!b[y][x]) { cx[n] = x; cy[n] = y; n++; }
    if(!n) return;
    int k = myos_random_range(0, n - 1);
    b[cy[k]][cx[k]] = myos_random_range(0, 9) == 0 ? 4 : 2;
}

static int can_move(void) {
    for(int y = 0; y < SZ; y++) for(int x = 0; x < SZ; x++) {
        if(!b[y][x]) return 1;
        if(x + 1 < SZ && b[y][x] == b[y][x + 1]) return 1;
        if(y + 1 < SZ && b[y][x] == b[y + 1][x]) return 1;
    }
    return 0;
}

static void new_game(void) {
    for(int y = 0; y < SZ; y++) for(int x = 0; x < SZ; x++) b[y][x] = 0;
    score = 0; over = 0; add_tile(); add_tile();
}

/* Slides one line (4 values) towards index 0; returns 1 if anything changed. */
static int slide(int *l) {
    int out[SZ] = { 0, 0, 0, 0 }, n = 0, merged_last = 0, changed = 0;
    for(int i = 0; i < SZ; i++) {
        if(!l[i]) continue;
        if(n > 0 && out[n - 1] == l[i] && !merged_last) { out[n - 1] *= 2; score += out[n - 1]; merged_last = 1; }
        else { out[n++] = l[i]; merged_last = 0; }
    }
    for(int i = 0; i < SZ; i++) { if(l[i] != out[i]) changed = 1; l[i] = out[i]; }
    return changed;
}

static int move(int dir) {            /* 0 up, 1 right, 2 down, 3 left */
    int moved = 0;
    for(int i = 0; i < SZ; i++) {
        int l[SZ];
        for(int j = 0; j < SZ; j++) {
            switch(dir) { case 0: l[j] = b[j][i]; break; case 1: l[j] = b[i][SZ - 1 - j]; break;
                          case 2: l[j] = b[SZ - 1 - j][i]; break; default: l[j] = b[i][j]; }
        }
        if(slide(l)) moved = 1;
        for(int j = 0; j < SZ; j++) {
            switch(dir) { case 0: b[j][i] = l[j]; break; case 1: b[i][SZ - 1 - j] = l[j]; break;
                          case 2: b[SZ - 1 - j][i] = l[j]; break; default: b[i][j] = l[j]; }
        }
    }
    return moved;
}

static uint32_t tile_col(int v) {
    switch(v) {
        case 0: return 0xFF2A2A30;   case 2: return 0xFF3C3C46;    case 4: return 0xFF4A4A5C;
        case 8: return 0xFFCF7A2E;   case 16: return 0xFFD9672B;   case 32: return 0xFFDB4E3A;
        case 64: return 0xFFD92D2D;  case 128: return 0xFFC9A227;  case 256: return 0xFFC9A227;
        case 512: return 0xFF5FB86E; case 1024: return 0xFF3FA6A0; case 2048: return 0xFF4CC2FF;
        default: return 0xFF9B6BFF;
    }
}

static void draw(int win) {
    myos_clear(win, MYOS_COLOR_BG);
    char buf[48];
    snprintf(buf, sizeof(buf), "Score %d   Best %d", score, best);
    myos_text(win, 12, 10, buf, MYOS_COLOR_TEXT);
    myos_text(win, 12, 32, "Arrows / WASD to move, N = new game", MYOS_COLOR_TEXT_DIM);
    for(int y = 0; y < SZ; y++) for(int x = 0; x < SZ; x++) {
        int px = GAP + x * (CELL + GAP), py = HUD + y * (CELL + GAP);
        myos_round_rect(win, px, py, CELL, CELL, 8, tile_col(b[y][x]));
        if(b[y][x]) {
            snprintf(buf, sizeof(buf), "%d", b[y][x]);
            int sc = b[y][x] < 100 ? 3 : (b[y][x] < 1000 ? 2 : 1) ;
            int tw = (int)strlen(buf) * 8 * sc;
            myos_text_scaled(win, px + (CELL - tw) / 2, py + (CELL - 16 * sc) / 2, buf, MYOS_COLOR_TEXT, sc);
        }
    }
    if(over) {
        myos_round_rect(win, 60, HUD + 150, 280, 80, 12, 0xE0101014);
        myos_text_scaled(win, 96, HUD + 162, "Game over", 0xFFFF6B5E, 2);
        myos_text(win, 100, HUD + 200, "Press N for a new game", MYOS_COLOR_TEXT_DIM);
    }
}

int app_main(void) {
    int win = myos_window_create("2048", GAP + SZ * (CELL + GAP), HUD + SZ * (CELL + GAP));
    if(win < 0) return 1;
    char sb[16] = "";
    int n = myos_file_read(SAVE, sb, sizeof(sb) - 1, 0);
    best = n > 0 ? atoi(sb) : 0;
    new_game();
    draw(win);
    for(;;) {
        myos_event_t ev;
        myos_wait_event(win, &ev, -1);
        if(ev.type == MYOS_EV_CLOSE) return 0;
        if(ev.type == MYOS_EV_KEY) {
            int k = ev.key, d = -1;
            if(k == MYOS_KEY_UP || k == 'w' || k == 'W') d = 0;
            else if(k == MYOS_KEY_RIGHT || k == 'd' || k == 'D') d = 1;
            else if(k == MYOS_KEY_DOWN || k == 's' || k == 'S') d = 2;
            else if(k == MYOS_KEY_LEFT || k == 'a' || k == 'A') d = 3;
            else if(k == 'n' || k == 'N') new_game();
            if(d >= 0 && !over && move(d)) {
                add_tile();
                if(score > best) { best = score; int m = snprintf(sb, sizeof(sb), "%d", best); myos_file_write(SAVE, sb, (uint32_t)m, 0); }
                if(!can_move()) over = 1;
            }
        }
        draw(win);
    }
}
