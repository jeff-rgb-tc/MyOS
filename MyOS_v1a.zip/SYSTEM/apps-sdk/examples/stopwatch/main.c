/* stopwatch -- a stopwatch with laps and a countdown timer.
 * Two tabs; both keep running while you look at the other one. */
#include <myos/myos.h>
#include <myos/ui.h>

#define W 360
#define H 380
#define MAX_LAPS 8

enum { TAB_STOPWATCH, TAB_TIMER };

/* stopwatch */
static int sw_running = 0;
static uint32_t sw_start_ms = 0, sw_acc_ms = 0;
static uint32_t laps[MAX_LAPS];
static int lap_count = 0;

/* countdown */
static int cd_running = 0, cd_done = 0;
static uint32_t cd_set_s = 300;          /* what the timer is set to */
static uint32_t cd_end_ms = 0, cd_left_ms = 300000;

static uint32_t sw_elapsed(void) { return sw_acc_ms + (sw_running ? myos_ticks_ms() - sw_start_ms : 0); }

static void fmt_time(uint32_t ms, char *out, int cap, int with_cs) {
    uint32_t s = ms / 1000, m = s / 60;
    if(with_cs) snprintf(out, cap, "%02d:%02d.%02d", (int)m, (int)(s % 60), (int)((ms % 1000) / 10));
    else        snprintf(out, cap, "%02d:%02d", (int)m, (int)(s % 60));
}

static void tick_countdown(void) {
    if(!cd_running) return;
    uint32_t now = myos_ticks_ms();
    if((int32_t)(cd_end_ms - now) <= 0) {
        cd_running = 0; cd_done = 1; cd_left_ms = 0;
        myos_beep(880, 200); myos_beep(1100, 300);
    } else cd_left_ms = cd_end_ms - now;
}

int app_main(void) {
    int win = myos_window_create("Stopwatch", W, H);
    if(win < 0) return 1;
    myos_ui_t ui;
    myos_ui_init(&ui, win);
    myos_window_set_timer(win, 0, 40);       /* redraw ~25 times a second */

    int tab = TAB_STOPWATCH;
    for(;;) {
        tick_countdown();

        myos_clear(win, MYOS_COLOR_BG);
        if(myos_ui_button(&ui, 1, 16, 12, 160, 30, "Stopwatch", tab == TAB_STOPWATCH ? MYOS_UI_ACCENT : MYOS_UI_NORMAL)) tab = TAB_STOPWATCH;
        if(myos_ui_button(&ui, 2, 184, 12, 160, 30, "Timer", tab == TAB_TIMER ? MYOS_UI_ACCENT : MYOS_UI_NORMAL)) tab = TAB_TIMER;

        char buf[32];
        if(tab == TAB_STOPWATCH) {
            fmt_time(sw_elapsed(), buf, sizeof(buf), 1);
            myos_text_scaled(win, (W - (int)strlen(buf) * 8 * 4) / 2, 70, buf, MYOS_COLOR_TEXT, 4);

            if(myos_ui_button(&ui, 3, 16, 130, 104, 36, sw_running ? "Stop" : "Start", sw_running ? MYOS_UI_DANGER : MYOS_UI_ACCENT)) {
                if(sw_running) { sw_acc_ms += myos_ticks_ms() - sw_start_ms; sw_running = 0; }
                else { sw_start_ms = myos_ticks_ms(); sw_running = 1; }
            }
            if(myos_ui_button(&ui, 4, 128, 130, 104, 36, "Lap", MYOS_UI_NORMAL) && sw_running) {
                if(lap_count == MAX_LAPS) { for(int i = 1; i < MAX_LAPS; i++) laps[i - 1] = laps[i]; lap_count--; }
                laps[lap_count++] = sw_elapsed();
            }
            if(myos_ui_button(&ui, 5, 240, 130, 104, 36, "Reset", MYOS_UI_NORMAL)) {
                sw_running = 0; sw_acc_ms = 0; lap_count = 0;
            }
            for(int i = 0; i < lap_count; i++) {
                char t[24]; fmt_time(laps[i], t, sizeof(t), 1);
                snprintf(buf, sizeof(buf), "Lap %d", i + 1);
                int y = 184 + (lap_count - 1 - i) * 22;
                myos_ui_label(&ui, 24, y, buf, MYOS_COLOR_TEXT_DIM);
                myos_ui_label(&ui, 200, y, t, MYOS_COLOR_TEXT);
            }
        } else {
            fmt_time(cd_running || cd_done ? cd_left_ms : cd_set_s * 1000, buf, sizeof(buf), 0);
            myos_text_scaled(win, (W - (int)strlen(buf) * 8 * 5) / 2, 70, buf, cd_done ? MYOS_COLOR_WARN : MYOS_COLOR_TEXT, 5);
            if(cd_done) myos_ui_label_centered(&ui, 0, 118, W, 20, "Time is up!", MYOS_COLOR_WARN);

            if(!cd_running) {
                if(myos_ui_button(&ui, 6, 16, 150, 76, 32, "-1 min", MYOS_UI_NORMAL) && cd_set_s > 60) { cd_set_s -= 60; cd_done = 0; }
                if(myos_ui_button(&ui, 7, 100, 150, 76, 32, "+1 min", MYOS_UI_NORMAL) && cd_set_s < 5940) { cd_set_s += 60; cd_done = 0; }
                if(myos_ui_button(&ui, 8, 184, 150, 76, 32, "-10 s", MYOS_UI_NORMAL) && cd_set_s > 10) { cd_set_s -= 10; cd_done = 0; }
                if(myos_ui_button(&ui, 9, 268, 150, 76, 32, "+10 s", MYOS_UI_NORMAL) && cd_set_s < 5990) { cd_set_s += 10; cd_done = 0; }
            }
            if(myos_ui_button(&ui, 10, 16, 210, 160, 38, cd_running ? "Pause" : "Start", cd_running ? MYOS_UI_DANGER : MYOS_UI_ACCENT)) {
                if(cd_running) { tick_countdown(); cd_running = 0; }
                else {
                    if(cd_done || cd_left_ms == 0 || cd_left_ms > cd_set_s * 1000) { cd_left_ms = cd_set_s * 1000; cd_done = 0; }
                    cd_end_ms = myos_ticks_ms() + cd_left_ms; cd_running = 1;
                }
            }
            if(myos_ui_button(&ui, 11, 184, 210, 160, 38, "Reset", MYOS_UI_NORMAL)) { cd_running = 0; cd_done = 0; cd_left_ms = cd_set_s * 1000; }
        }
        myos_ui_end_frame(&ui);

        myos_event_t ev;
        myos_wait_event(win, &ev, -1);
        if(ev.type == MYOS_EV_CLOSE) return 0;
        if(ev.type != MYOS_EV_TIMER) myos_ui_event(&ui, &ev);
        while(myos_poll_event(win, &ev)) {
            if(ev.type == MYOS_EV_CLOSE) return 0;
            if(ev.type != MYOS_EV_TIMER) myos_ui_event(&ui, &ev);
        }
    }
}
