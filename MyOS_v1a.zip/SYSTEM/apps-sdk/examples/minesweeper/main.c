/* minesweeper -- 9x9 board, 10 mines. Left click opens a cell, right click
 * flags it, N starts a new game. The first click is always safe. */
#include <myos/myos.h>

#define N 9
#define MINES 10
#define CELL 30
#define HUD 44

static uint8_t mine[N][N], open_[N][N], flag[N][N], near_[N][N];
static int placed, lost, won, flags, opened;
static uint32_t t_start;
static uint32_t t_end;

static void new_game(void) {
    for(int y = 0; y < N; y++) for(int x = 0; x < N; x++) mine[y][x] = open_[y][x] = flag[y][x] = near_[y][x] = 0;
    placed = lost = won = flags = opened = 0; t_start = 0; t_end = 0;
}

static void place_mines(int sx, int sy) {
    int left = MINES;
    while(left) {
        int x = myos_random_range(0, N - 1), y = myos_random_range(0, N - 1);
        if(mine[y][x] || (x >= sx - 1 && x <= sx + 1 && y >= sy - 1 && y <= sy + 1)) continue;
        mine[y][x] = 1; left--;
    }
    for(int y = 0; y < N; y++) for(int x = 0; x < N; x++) {
        int c = 0;
        for(int dy = -1; dy <= 1; dy++) for(int dx = -1; dx <= 1; dx++) {
            int nx = x + dx, ny = y + dy;
            if((dx || dy) && nx >= 0 && ny >= 0 && nx < N && ny < N && mine[ny][nx]) c++;
        }
        near_[y][x] = (uint8_t)c;
    }
    placed = 1; t_start = myos_ticks_ms();
}

static void flood(int sx, int sy) {
    static int stack[N * N * 4][2];
    int sp = 0;
    stack[sp][0] = sx; stack[sp][1] = sy; sp++;
    while(sp > 0) {
        sp--;
        int x = stack[sp][0], y = stack[sp][1];
        if(x < 0 || y < 0 || x >= N || y >= N || open_[y][x] || flag[y][x]) continue;
        open_[y][x] = 1; opened++;
        if(near_[y][x] == 0)
            for(int dy = -1; dy <= 1; dy++) for(int dx = -1; dx <= 1; dx++)
                if((dx || dy) && sp < N * N * 4 - 1) { stack[sp][0] = x + dx; stack[sp][1] = y + dy; sp++; }
    }
}

static void click(int x, int y, int right) {
    if(lost || won || x < 0 || y < 0 || x >= N || y >= N) return;
    if(right) {
        if(!open_[y][x]) { flag[y][x] ^= 1; flags += flag[y][x] ? 1 : -1; }
        return;
    }
    if(flag[y][x] || open_[y][x]) return;
    if(!placed) place_mines(x, y);
    if(mine[y][x]) { lost = 1; t_end = myos_ticks_ms(); myos_beep(120, 400); return; }
    flood(x, y);
    if(opened == N * N - MINES) { won = 1; t_end = myos_ticks_ms(); myos_beep(880, 150); myos_beep(1175, 250); }
}

static void draw(int win) {
    static const uint32_t num_col[9] = { 0, 0xFF4CC2FF, 0xFF5FD38D, 0xFFFF6B6B, 0xFF9B8CFF, 0xFFFFB454, 0xFF3DDBD9, 0xFFF2F2F5, 0xFFA0A0AA };
    myos_clear(win, MYOS_COLOR_BG);
    char buf[48];
    uint32_t secs = placed ? ((won || lost ? t_end : myos_ticks_ms()) - t_start) / 1000 : 0;
    snprintf(buf, sizeof(buf), "Mines %d    Time %d", MINES - flags, (int)secs);
    myos_text(win, 12, 14, buf, MYOS_COLOR_TEXT);
    if(lost) myos_text(win, 190, 14, "Boom! N = new", MYOS_COLOR_DANGER);
    else if(won) myos_text(win, 190, 14, "You won! N = new", MYOS_COLOR_OK);

    for(int y = 0; y < N; y++) for(int x = 0; x < N; x++) {
        int px = x * CELL + 1, py = HUD + y * CELL + 1;
        if(open_[y][x]) {
            myos_round_rect(win, px, py, CELL - 2, CELL - 2, 4, 0xFF16161A);
            if(near_[y][x]) { char d[2] = { (char)('0' + near_[y][x]), 0 }; myos_text(win, px + 10, py + 6, d, num_col[near_[y][x]]); }
        } else {
            myos_round_rect(win, px, py, CELL - 2, CELL - 2, 4, 0xFF34343B);
            if(flag[y][x]) myos_text(win, px + 10, py + 6, "F", MYOS_COLOR_WARN);
        }
        if(lost && mine[y][x]) { myos_round_rect(win, px, py, CELL - 2, CELL - 2, 4, 0xFF5A1E22); myos_circle(win, px + CELL / 2 - 1, py + CELL / 2 - 1, 7, 0xFFE5484D); }
    }
}

int app_main(void) {
    int win = myos_window_create("Minesweeper", N * CELL, HUD + N * CELL);
    if(win < 0) return 1;
    new_game();
    myos_window_set_timer(win, 0, 500);          /* keeps the clock moving */
    draw(win);
    for(;;) {
        myos_event_t ev;
        myos_wait_event(win, &ev, -1);
        if(ev.type == MYOS_EV_CLOSE) return 0;
        if(ev.type == MYOS_EV_MOUSE_DOWN) click(ev.x / CELL, (ev.y - HUD) / CELL, ev.button == MYOS_BTN_RIGHT);
        else if(ev.type == MYOS_EV_KEY && (ev.key == 'n' || ev.key == 'N')) new_game();
        draw(win);
    }
}
