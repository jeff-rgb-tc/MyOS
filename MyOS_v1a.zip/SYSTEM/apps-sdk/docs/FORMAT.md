# The .app file format and system-call ABI

Everything here is defined in code by `include/myos/abi.h`, the single header
shared by the kernel and the SDK. If this document and `abi.h` ever
disagree, `abi.h` wins.

## File layout (version 2)

```
offset  size  field
0       4     magic "MYAP"
4       4     version = 2
8       4     header_size = 192 (the image starts here)
12      4     entry_offset      (relative to the image start)
16      4     code_size         (bytes of image stored in the file)
20      4     mem_size          (bytes of image in memory; >= code_size)
24      4     abi_level         (lowest kernel ABI level the app needs; now 2)
28      4     permissions       (bit 0 file_write, bit 1 audio, bit 2 clipboard, bit 3 system -- honoured only for /APPS/installer/installer.app)
32      4     flags             (reserved, 0)
36      4     icon_offset       (from file start; 0 = no icon)
40      4     icon_size         (bytes of PNG)
44      4     crc32             (IEEE CRC-32 of the stored image)
48      32    name              (NUL-padded ASCII)
80      16    version string
96      32    author
128     64    description
192     ...   image (code_size bytes), then the optional icon PNG
```

All integers are little-endian. `tools/mkapp.py` writes this; `tools/appinfo.py`
checks it with the same rules as `kernel/app_format.c`.

The kernel **rejects** a file if: the magic is wrong; the version is unknown;
`header_size` is not 192; `abi_level` is newer than the kernel's; the CRC does
not match; `code_size` is zero, larger than `mem_size`, or past the end of
the file; `mem_size` exceeds 8 MB; or `entry_offset` is outside the image. A
bad *icon* is simply ignored. Every number is range-checked against the real
file length before it is used.

**Version 1** files (a 16-byte header: magic, version, entry_offset,
code_size) are still accepted and run with the v1 event layout.

## Loading

1. The file is read and validated (`app_format_parse`).
2. 8 MB at `0x40000000` and a 1 MB stack at `0x40800000` are mapped
   user-accessible and zeroed. The stored image is copied to the base; the
   zeroed remainder up to `mem_size` is the program's `.bss`.
3. The kernel switches to ring 3 at `base + entry_offset` with a fresh stack.
4. When the program calls `SYS_EXIT`, faults, or is stopped by the watchdog,
   control returns to the loader, which closes any windows the program left
   open, stops its sound, frees its memory and (for a crash) shows a message.

Memory map of a running app:

```
0x40000000  image (.text .rodata .data .bss) ... _end   <- malloc heap grows from here
            ...                                   ... up to 0x407FF000
0x40800000  stack (1 MB, grows down from 0x40900000)
```

## System calls

`int 0x80`; `eax` = number, `ebx edx esi edi` = arguments 1-4, result in
`eax` (negative = `MYOS_E_*`). Larger arguments are passed as pointers to
the structs in `abi.h`. The numbered list lives in `abi.h` (`SYS_*`); the
friendly wrappers in `include/myos/myos.h` are the supported way to call
them. Interrupts are enabled for the duration of every call.

Calls 0-6 keep their version-1 meaning so old binaries still run.

## Compatibility rules

* Numbers and struct fields are never repurposed, only added.
* A new feature that old kernels lack raises `abi_level`; the loader then
  refuses to run the app with a clear message instead of misbehaving.
* The kernel uses the app's `abi_level` to pick the event layout (16-byte v1
  or 32-byte v2).
