# Programming guide

## The shape of every app

```c
int app_main(void) {
    int win = myos_window_create("Title", 400, 300);
    draw(win);                                   // draw the first frame
    for (;;) {
        myos_event_t ev;
        myos_wait_event(win, &ev, -1);           // sleep until something happens
        if (ev.type == MYOS_EV_CLOSE) return 0;
        handle(&ev);                             // update your state
        draw(win);                               // redraw
    }
}
```

Waiting costs nothing: while you sleep in `myos_wait_event` the desktop runs
normally and the CPU idles.

## Draining the queue

Events can arrive faster than you redraw (typing, dragging). Handle every
queued event, then redraw once:

```c
myos_wait_event(win, &ev, -1);
do { handle(&ev); } while (myos_poll_event(win, &ev));
draw(win);
```

## Game loops: use a timer

Do not spin on `myos_sleep` -- ask the kernel for a heartbeat:

```c
myos_window_set_timer(win, 0, 16);               // ~60 ticks per second
for (;;) {
    myos_wait_event(win, &ev, -1);
    if (ev.type == MYOS_EV_TIMER) { update(); draw(win); }
    else if (ev.type == MYOS_EV_KEY) ...
}
```

The clock has 10 ms resolution, so timers faster than 10 ms are clamped. See
`examples/snake`.

## Drawing efficiently

Widgets and shapes are system calls. For a handful of widgets redrawing on
every event is instant. For pixel-level work (images, fractals, emulators)
render into a `uint32_t` buffer in your own memory and `myos_blit` it once per
frame (`examples/doodle`).

Draw a complete frame before you block -- see the rule in the README.

## Saving and loading

```c
// manifest: permissions = file_write
myos_dir_create("/Users/User/MyApp");
myos_file_write("/Users/User/MyApp/save.dat", &state, sizeof state, 0);

uint32_t size;
uint8_t *data = myos_file_load("/Users/User/MyApp/save.dat", &size);   // NULL if missing
if (data) { ...; free(data); }
```

## Asking before closing

`MYOS_EV_CLOSE` is a request. To keep the window open (unsaved work), just
ignore the event -- the close box does nothing until you act. To confirm,
open a second window as a dialog and wait for its answer.

## Debugging

* `myos_log("text")` writes a tagged line to the kernel log (visible in the
  QEMU serial/console output).
* If your app stops with a message above the taskbar, the text says why:
  `page fault`, `general protection fault`, `not responding` (watchdog),
  `bad magic`, `checksum mismatch`, `needs a newer MyOS`...
* `make info` validates your `.app` exactly like the loader will.
* Division by zero, null dereferences and wild pointers raise CPU faults;
  they end *your app* only -- the desktop keeps running.

## Tips

* Keep `malloc` usage modest: 8 MB minus your program is all there is.
* Use `MYOS_COLOR_*` and `myos_ui_*` so your app looks like part of the system.
* Request only the permissions you use.
* Test resizing: handle `MYOS_EV_RESIZE` by redrawing with `myos_window_size`.

## Testing without booting the OS

`tools/sim/run.sh` runs your app on your PC against the **real kernel
system-call layer and window manager**, with a script playing the user, and
saves screenshots:

```sh
tools/sim/run.sh examples/hello tools/sim/scripts/hello.h ./out
```

A scenario is a small C header (see `tools/sim/scripts/*.h`) with a
`script(step)` function that injects events -- `ev_click(x, y)`,
`ev_type("text")`, `ev_key(k)`, `ev_drag(...)`, `ev_close()` -- and takes
screenshots with `shot("name")`; `report()` can print facts such as
`simfs_size("/Users/User/out.bmp")`. The simulator also checks that the app
leaves no windows behind and balances `myos_busy` calls. It needs a gcc with
`-m32` and a Linux that can run 32-bit programs; the PNG conversion needs
Pillow. It does not emulate ring 3, paging or the real audio hardware -- do a
final run in the OS itself.
