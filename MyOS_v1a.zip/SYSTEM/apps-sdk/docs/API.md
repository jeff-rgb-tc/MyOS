# API reference

Include `<myos/myos.h>` (and `<myos/ui.h>` for widgets). All coordinates are
**client coordinates** -- (0,0) is the top-left of your window's content area.
Colors are `0xAARRGGBB`; use `MYOS_RGB(r,g,b)` for opaque colors. Functions
that can fail return a negative `MYOS_E_*` code (`MYOS_E_FAIL -1`,
`MYOS_E_PERM -2`, `MYOS_E_ARG -3`, `MYOS_E_NOENT -4`, `MYOS_E_NOMEM -5`).

The program entry point is `int app_main(void)`; its return value is the exit
code. Returning (or calling `myos_exit`) ends the app and closes its windows.

## Process and time

| function | description |
|---|---|
| `void myos_exit(int code)` | End the program. |
| `uint32_t myos_ticks_ms(void)` | Milliseconds since boot (10 ms resolution). |
| `void myos_sleep(uint32_t ms)` | Wait; the desktop keeps running. |
| `void myos_yield(void)` | Let the desktop draw one frame. Call it in long computations. |
| `uint32_t myos_random(void)` | 32 random bits. `myos_random_range(lo, hi)` is inclusive. |
| `int myos_sysinfo(myos_sysinfo_t*)` | Screen size, uptime, CPU %, heap, audio driver... |
| `int myos_datetime(myos_datetime_t*)` | Real-time clock: year month day hour minute second weekday. |
| `void myos_log(const char*)` | Line in the kernel log, tagged with your app's name. |
| `void myos_busy(int on)` | Show the animated busy cursor while you compute. |

## Windows

| function | description |
|---|---|
| `int myos_window_create(title, w, h)` | Centred window with a `w` x `h` client area (the kernel adds the title bar). Returns a handle >= 0. |
| `int myos_window_create_ex(const myos_window_desc_t*)` | Same with position (`x`,`y`), `MYOS_WIN_CENTER`, and a background color. |
| `int myos_window_close(win)` | Close a window. |
| `int myos_window_set_title(win, title)` | |
| `int myos_window_size(win, &w, &h)` | Current client size (changes when the user resizes). |
| `int myos_window_set_cursor(win, MYOS_CURSOR_*)` | Pointer shape over the client area: `DEFAULT TEXT LINK MOVE RESIZE_H RESIZE_V UNAVAILABLE HELP PRECISION`. |
| `int myos_window_set_timer(win, id, ms)` | Periodic `MYOS_EV_TIMER` (`.key == id`), id 0-3, min 10 ms; `ms == 0` stops it. |

Users can resize app windows. The kernel then gives you a surface of the new
size (keeping the old picture in the top-left corner) and sends
`MYOS_EV_RESIZE`; redraw using `myos_window_size`.

## Drawing

All calls draw into the window's surface and are clipped to it.

| function | description |
|---|---|
| `myos_clear(win, color)` | Fill the whole surface. |
| `myos_fill_rect(win, x, y, w, h, color)` | Rectangle; translucent if alpha < 255. |
| `myos_round_rect(win, x, y, w, h, radius, color)` | Rounded rectangle, antialiased, alpha-aware. `myos_round_rect_ex(..., corners)` rounds only the corners in the mask (`MYOS_CORNER_TL/TR/BL/BR`). |
| `myos_outline(win, x, y, w, h, radius, color)` | 1 px outline (rounded when `radius > 0`). |
| `myos_line(win, x0, y0, x1, y1, width, color)` | Antialiased line, any width. `myos_line_f` takes `float` coordinates. |
| `myos_circle(win, cx, cy, r, color)` | Filled antialiased circle. |
| `myos_text(win, x, y, text, color)` | System font, 8x16 px per character. `myos_text_scaled(..., scale)` multiplies it 1-8x. |
| `myos_gradient(win, x, y, w, h, radius, top, bottom)` | Vertical gradient. |
| `myos_blit(win, x, y, w, h, pixels, stride, alpha)` | Copy a block of ARGB pixels (`stride` = row length in pixels). Fast path for software-rendered frames and images; `alpha != 0` blends by the pixels' alpha. |

Drawing is cheap but each call is a system call: a UI with a few dozen
widgets redraws instantly, but for per-pixel work render into your own buffer
and `myos_blit` it once.

## Events

```c
myos_event_t ev;
int myos_poll_event(win, &ev);               // 1 = got one, 0 = none (never blocks)
int myos_wait_event(win, &ev, timeout_ms);   // blocks; -1 = forever, 0 = poll; returns 0 on timeout
```

Pass `MYOS_ANY_WINDOW` as `win` to receive events from all your windows (each
event carries its window handle in `.window`).

| `ev.type` | meaning | fields |
|---|---|---|
| `MYOS_EV_MOUSE_DOWN` | button pressed | `x y button` (`MYOS_BTN_LEFT/RIGHT`) |
| `MYOS_EV_MOUSE_UP` | left button released | `x y` |
| `MYOS_EV_MOUSE_MOVE` | pointer moved over the window (or dragged) | `x y`; `button == MYOS_BTN_LEFT` while dragging |
| `MYOS_EV_KEY` | key pressed (auto-repeat included) | `key` (ASCII, or `MYOS_KEY_*`), `mods` |
| `MYOS_EV_CLOSE` | the user pressed the close box -- **you decide**: save, then return, or ignore it | |
| `MYOS_EV_RESIZE` | the user resized the window | `x y` = new client size |
| `MYOS_EV_FOCUS` | focus changed | `key` = 1 gained / 0 lost |
| `MYOS_EV_TIMER` | a timer fired | `key` = timer id |
| `MYOS_EV_WHEEL` | the mouse wheel turned over the window | `x y`, `key` = notches (positive = scroll down) |

`ev.mods` is a mask of `MYOS_MOD_SHIFT/CTRL/ALT/CAPS`. Ctrl+letter arrives as
the control code (Ctrl+C = 3). Special keys: `MYOS_KEY_UP/DOWN/LEFT/RIGHT/HOME/END/PGUP/PGDN/DELETE/INSERT`,
`MYOS_KEY_F1 + n - 1` for F1-F12. Mouse-move events are coalesced, so a busy
app never falls behind a flood of motion.

If someone ends your task from Task Manager the app is terminated at once and
no `MYOS_EV_CLOSE` is sent.

## Files

Absolute paths only (`/Users/User/notes.txt`); `..` components are rejected.

| function | description |
|---|---|
| `int myos_file_read(path, buf, len, offset)` | Bytes read (0 at/after end). Works anywhere. |
| `int myos_file_write(path, data, len, append)` | Create/replace (or append). Needs `file_write`; only under `/Users`. |
| `int myos_file_stat(path, &st)` | `size is_dir date time`. |
| `int myos_dir_read(path, index, &entry)` | `entry.name/size/is_dir`; returns 1, or 0 past the last entry. |
| `int myos_file_delete(path)`, `int myos_dir_create(path)` | Need `file_write`, under `/Users`. |
| `uint8_t *myos_file_load(path, &size)` | Whole file in a `malloc` buffer (NUL-terminated); `free()` it. |

## Sound (needs `audio`)

| function | description |
|---|---|
| `int myos_audio_play(samples, count, rate, channels)` | Queue interleaved `int16_t` PCM (1 or 2 channels). Blocks while the card's queue is full, keeping the desktop alive. |
| `void myos_audio_stop(void)` | Drop queued sound. |
| `int myos_beep(freq_hz, duration_ms)` | A sine tone with soft edges. |

## Clipboard (needs `clipboard`)

`myos_clipboard_set(text)`, `myos_clipboard_get(buf, max)` (returns length; text up to 511 characters).

## C library (`<myos/libc.h>`)

`memset memcpy memmove memcmp strlen strcmp strncmp strcpy strncpy strcat strchr strrchr strstr
toupper tolower isdigit isalpha isspace malloc free calloc realloc atoi abs rand srand qsort
snprintf vsnprintf` plus `myos_ftoa` (decimal formatting of a `double`),
`myos_sin/cos/sqrt/atan2` (x87), `MYOS_MIN/MAX/CLAMP`, `myos_heap_free()`.
`snprintf` supports `%d %i %u %x %X %c %s %p %%` with width, `0` and `-` flags and `*`
width -- not floating point.

## Widgets (`<myos/ui.h>`)

Immediate-mode: call the widget every time you redraw; it draws and reports
interaction. Feed every event to `myos_ui_event(&ui, &ev)` and end each
redraw with `myos_ui_end_frame(&ui)`. Each interactive widget needs a unique
non-zero `id` within the window.

| function | returns |
|---|---|
| `myos_ui_button(&ui, id, x, y, w, h, label, style)` | 1 on the redraw where it was clicked. Styles `MYOS_UI_NORMAL/ACCENT/DANGER/FLAT`. |
| `myos_ui_checkbox(&ui, id, x, y, label, &value)` | 1 when toggled. |
| `myos_ui_slider(&ui, id, x, y, w, &value, min, max)` | 1 while the value changes (range up to +-500000). |
| `myos_ui_textbox(&ui, id, x, y, w, buffer, capacity)` | 1 when Enter is pressed. Handles typing and backspace. |
| `myos_ui_progress(&ui, x, y, w, h, value, max)`, `myos_ui_label(...)`, `myos_ui_label_centered(...)`, `myos_ui_panel(...)` | drawing only |
| `myos_ui_hover(&ui, x, y, w, h)` | whether the pointer is inside the rectangle |

## Palette

`MYOS_COLOR_BG 0xFF1E1E22`, `CARD 0xFF2A2A30`, `TEXT 0xFFF2F2F5`, `TEXT_DIM 0xFFA0A0AA`,
`ACCENT 0xFF4CC2FF`, `DANGER 0xFFC42B1C`, `OK 0xFF5FD38D`, `WARN 0xFFFFB454` -- the
desktop's own colors, so your app matches the system.


## Added in v8

**Kernel calls** (all additive; old apps keep working)

| Function | What it does |
|---|---|
| `myos_blit_scaled(win, dx, dy, dw, dh, pixels, sw, sh, alpha)` | Stretches an ARGB image into a rectangle with the kernel's scaler. Render small, scale up. |
| `myos_toast(text)` | Shows a short notification pill above the taskbar. |
| `myos_speaker_beep(freq, ms)` | PC-speaker beep (needs the `audio` permission, max 1 s). Works with no sound card. |

**Header-only: `<myos/anim.h>`** -- `myos_ease()` (linear, quad, cubic, back, bounce),
`myos_tween_t` (`myos_tween_start / _value / _done`) and `myos_color_lerp()`.
Drive redraws with `myos_window_set_timer(win, 0, 16)` so animation stays smooth.

**Optional library: `<myos/gfx3d.h>`** -- software 3D: matrices, z-buffered flat-shaded triangle
rasteriser, wireframe, a cube and a pyramid mesh. Enable with `SDK_LIBS = gfx3d` in your Makefile.
See `examples/cube3d`. MyOS has no GPU driver, so this is CPU rendering; render at a small size and
use `myos_blit_scaled`.

**Example apps:** `stopwatch`, `minesweeper`, `game2048`, `cube3d`.
