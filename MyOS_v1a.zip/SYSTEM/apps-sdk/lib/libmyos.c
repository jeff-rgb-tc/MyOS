/* libmyos: syscall wrappers + the small C library. See the headers in include/myos.
 *
 * Built with -ffreestanding -fno-tree-loop-distribute-patterns (the SDK
 * makefile does this) so GCC never rewrites the loops below into calls to
 * the very functions they implement. */

#include <myos/myos.h>

/* ======================================================================== */
/* syscall wrappers                                                          */
/* ======================================================================== */
void myos_exit(int code) {
    myos_syscall(SYS_EXIT, (uint32_t)code, 0, 0, 0);
    for(;;) { }
}

uint32_t myos_ticks_ms(void) { return (uint32_t)myos_syscall(SYS_TICKS_MS, 0, 0, 0, 0); }
void myos_sleep(uint32_t ms) { myos_syscall(SYS_SLEEP_MS, ms, 0, 0, 0); }
void myos_yield(void) { myos_syscall(SYS_YIELD, 0, 0, 0, 0); }
uint32_t myos_random(void) { return (uint32_t)myos_syscall(SYS_RANDOM, 0, 0, 0, 0); }
int myos_random_range(int lo, int hi) {
    if(hi <= lo) return lo;
    return lo + (int)(myos_random() % (uint32_t)(hi - lo + 1));
}
int myos_sysinfo(myos_sysinfo_t *out) { return myos_syscall(SYS_SYSINFO, MYOS_PTR(out), 0, 0, 0); }
int myos_datetime(myos_datetime_t *out) { return myos_syscall(SYS_DATETIME, MYOS_PTR(out), 0, 0, 0); }
void myos_log(const char *text) { myos_syscall(SYS_LOG, MYOS_PTR(text), 0, 0, 0); }
void myos_busy(int on) { myos_syscall(SYS_SET_BUSY, (uint32_t)on, 0, 0, 0); }

int myos_window_create_ex(const myos_window_desc_t *d) { return myos_syscall(SYS_WINDOW_CREATE_EX, MYOS_PTR(d), 0, 0, 0); }
int myos_window_create(const char *title, int w, int h) {
    myos_window_desc_t d;
    memset(&d, 0, sizeof(d));
    d.title = MYOS_PTR(title);
    d.x = d.y = -1;
    d.w = w; d.h = h;
    d.flags = MYOS_WIN_CENTER;
    return myos_window_create_ex(&d);
}
int myos_window_close(int win) { return myos_syscall(SYS_WINDOW_CLOSE, (uint32_t)win, 0, 0, 0); }
int myos_window_set_title(int win, const char *t) { return myos_syscall(SYS_WINDOW_SET_TITLE, (uint32_t)win, MYOS_PTR(t), 0, 0); }
int myos_window_size(int win, int *w, int *h) {
    myos_size_t s;
    int r = myos_syscall(SYS_WINDOW_GET_SIZE, (uint32_t)win, MYOS_PTR(&s), 0, 0);
    if(r == 0) { if(w) *w = s.w; if(h) *h = s.h; }
    return r;
}
int myos_window_set_cursor(int win, int cursor) { return myos_syscall(SYS_WINDOW_SET_CURSOR, (uint32_t)win, (uint32_t)cursor, 0, 0); }
int myos_window_set_timer(int win, int id, int ms) { return myos_syscall(SYS_WINDOW_SET_TIMER, (uint32_t)win, (uint32_t)id, (uint32_t)ms, 0); }

int myos_clear(int win, uint32_t color) { return myos_syscall(SYS_DRAW_CLEAR, (uint32_t)win, color, 0, 0); }
int myos_fill_rect(int win, int x, int y, int w, int h, uint32_t color) {
    myos_rect_t r = { x, y, w, h };
    return myos_syscall(SYS_FILL_RECT, (uint32_t)win, MYOS_PTR(&r), color, 0);
}
int myos_round_rect_ex(int win, int x, int y, int w, int h, int radius, uint32_t color, int corners) {
    myos_round_rect_t r = { x, y, w, h, radius, color, corners, 0 };
    return myos_syscall(SYS_DRAW_ROUND_RECT, (uint32_t)win, MYOS_PTR(&r), 0, 0);
}
int myos_round_rect(int win, int x, int y, int w, int h, int radius, uint32_t color) {
    return myos_round_rect_ex(win, x, y, w, h, radius, color, MYOS_CORNER_ALL);
}
int myos_outline(int win, int x, int y, int w, int h, int radius, uint32_t color) {
    myos_outline_t o = { x, y, w, h, radius, color, { 0, 0 } };
    return myos_syscall(SYS_DRAW_OUTLINE, (uint32_t)win, MYOS_PTR(&o), 0, 0);
}
int myos_line_f(int win, float x0, float y0, float x1, float y1, float width, uint32_t color) {
    myos_line_t l = { (int32_t)(x0 * 16.0f), (int32_t)(y0 * 16.0f), (int32_t)(x1 * 16.0f), (int32_t)(y1 * 16.0f),
                      (int32_t)(width * 16.0f), color, { 0, 0 } };
    return myos_syscall(SYS_DRAW_LINE, (uint32_t)win, MYOS_PTR(&l), 0, 0);
}
int myos_line(int win, int x0, int y0, int x1, int y1, int width, uint32_t color) {
    myos_line_t l = { x0 * 16 + 8, y0 * 16 + 8, x1 * 16 + 8, y1 * 16 + 8, width * 16, color, { 0, 0 } };
    return myos_syscall(SYS_DRAW_LINE, (uint32_t)win, MYOS_PTR(&l), 0, 0);
}
int myos_circle(int win, int cx, int cy, int r, uint32_t color) {
    myos_circle_t c = { cx, cy, r, color };
    return myos_syscall(SYS_DRAW_CIRCLE, (uint32_t)win, MYOS_PTR(&c), 0, 0);
}
int myos_text_scaled(int win, int x, int y, const char *text, uint32_t color, int scale) {
    myos_text_t t = { x, y, color, scale, MYOS_PTR(text), 0, { 0, 0 } };
    return myos_syscall(SYS_DRAW_TEXT, (uint32_t)win, MYOS_PTR(&t), 0, 0);
}
int myos_text(int win, int x, int y, const char *text, uint32_t color) {
    return myos_text_scaled(win, x, y, text, color, 1);
}
int myos_gradient(int win, int x, int y, int w, int h, int radius, uint32_t top, uint32_t bottom) {
    myos_gradient_t g = { x, y, w, h, radius, top, bottom, MYOS_CORNER_ALL };
    return myos_syscall(SYS_DRAW_GRADIENT, (uint32_t)win, MYOS_PTR(&g), 0, 0);
}
int myos_blit(int win, int x, int y, int w, int h, const uint32_t *pixels, int stride, int alpha) {
    myos_blit_t b = { x, y, w, h, MYOS_PTR(pixels), stride, alpha ? MYOS_BLIT_ALPHA : 0u, 0 };
    return myos_syscall(SYS_DRAW_BLIT, (uint32_t)win, MYOS_PTR(&b), 0, 0);
}

int myos_blit_scaled(int win, int dst_x, int dst_y, int dst_w, int dst_h, const uint32_t *pixels, int src_w, int src_h, int alpha) {
    myos_blit_scaled_t b = { dst_x, dst_y, dst_w, dst_h, MYOS_PTR(pixels), src_w, src_h, src_w, alpha ? MYOS_BLIT_ALPHA : 0u, { 0, 0, 0 } };
    return myos_syscall(SYS_DRAW_BLIT_SCALED, (uint32_t)win, MYOS_PTR(&b), 0, 0);
}

int myos_speaker_beep(int f, int ms) { return myos_syscall(SYS_BEEP, (uint32_t)f, (uint32_t)ms, 0, 0); }

int myos_toast(const char *text) { return myos_syscall(SYS_TOAST, MYOS_PTR(text), 0, 0, 0); }

int myos_poll_event(int win, myos_event_t *ev) { return myos_syscall(SYS_POLL_EVENT, (uint32_t)win, MYOS_PTR(ev), 0, 0); }
int myos_wait_event(int win, myos_event_t *ev, int timeout_ms) {
    return myos_syscall(SYS_WAIT_EVENT, (uint32_t)win, MYOS_PTR(ev), timeout_ms < 0 ? 0xFFFFFFFFu : (uint32_t)timeout_ms, 0);
}

int myos_file_read(const char *path, void *buffer, uint32_t length, uint32_t offset) {
    myos_file_io_t io = { MYOS_PTR(path), MYOS_PTR(buffer), length, offset, 0 };
    return myos_syscall(SYS_FILE_READ, MYOS_PTR(&io), 0, 0, 0);
}
int myos_file_write(const char *path, const void *data, uint32_t length, int append) {
    myos_file_io_t io = { MYOS_PTR(path), MYOS_PTR(data), length, 0, append ? MYOS_FILE_APPEND : 0u };
    return myos_syscall(SYS_FILE_WRITE, MYOS_PTR(&io), 0, 0, 0);
}
int myos_file_stat(const char *path, myos_stat_t *st) { return myos_syscall(SYS_FILE_STAT, MYOS_PTR(path), MYOS_PTR(st), 0, 0); }
int myos_dir_read(const char *path, int index, myos_dirent_t *e) { return myos_syscall(SYS_DIR_READ, MYOS_PTR(path), (uint32_t)index, MYOS_PTR(e), 0); }
int myos_file_delete(const char *path) { return myos_syscall(SYS_FILE_DELETE, MYOS_PTR(path), 0, 0, 0); }
int myos_dir_create(const char *path) { return myos_syscall(SYS_DIR_CREATE, MYOS_PTR(path), 0, 0, 0); }

int myos_disk_count(void) { return myos_syscall(SYS_DISK_COUNT, 0, 0, 0, 0); }
int myos_disk_info(int index, myos_diskinfo_t *out) { return myos_syscall(SYS_DISK_INFO, (uint32_t)index, MYOS_PTR(out), 0, 0); }
int myos_install_begin(int disk_index) { return myos_syscall(SYS_INSTALL_BEGIN, (uint32_t)disk_index, 0, 0, 0); }
int myos_install_begin_ex(int disk_index, unsigned flags) { return myos_syscall(SYS_INSTALL_BEGIN, (uint32_t)disk_index, flags, 0, 0); }
int myos_install_step(myos_install_status_t *st) { return myos_syscall(SYS_INSTALL_STEP, MYOS_PTR(st), 0, 0, 0); }
void myos_install_cancel(void) { myos_syscall(SYS_INSTALL_CANCEL, 0, 0, 0, 0); }
int myos_update_begin(void) { return myos_syscall(SYS_UPDATE_BEGIN, 0, 0, 0, 0); }
void myos_reboot(void) { myos_syscall(SYS_REBOOT, 0, 0, 0, 0); }

uint8_t *myos_file_load(const char *path, uint32_t *size) {
    myos_stat_t st;
    if(myos_file_stat(path, &st) < 0 || st.is_dir) return NULL;
    uint8_t *buf = (uint8_t *)malloc(st.size + 1);
    if(!buf) return NULL;
    int n = st.size ? myos_file_read(path, buf, st.size, 0) : 0;
    if(n < 0) { free(buf); return NULL; }
    buf[n] = 0;
    if(size) *size = (uint32_t)n;
    return buf;
}

int myos_audio_play(const int16_t *samples, uint32_t sample_count, uint32_t rate, int channels) {
    myos_audio_t a = { MYOS_PTR(samples), sample_count, rate, (uint32_t)channels };
    return myos_syscall(SYS_AUDIO_PLAY, MYOS_PTR(&a), 0, 0, 0);
}
void myos_audio_stop(void) { myos_syscall(SYS_AUDIO_STOP, 0, 0, 0, 0); }

int myos_beep(int freq_hz, int duration_ms) {
    enum { RATE = 22050, CHUNK = 1024 };
    if(freq_hz < 20 || freq_hz > 10000 || duration_ms <= 0 || duration_ms > 5000) return MYOS_E_ARG;
    static int16_t buf[CHUNK];
    uint32_t total = (uint32_t)duration_ms * RATE / 1000u;
    uint32_t fade = RATE / 200u;                         /* 5 ms ramps: no clicks */
    /* Sine by rotating a vector -- one sin/cos for the whole tone, then only multiplies. */
    double step = 2.0 * MYOS_PI * freq_hz / RATE;
    double c = myos_cos(step), s = myos_sin(step), x = 1.0, y = 0.0;
    uint32_t done = 0;
    while(done < total) {
        uint32_t n = total - done < CHUNK ? total - done : CHUNK;
        for(uint32_t i = 0; i < n; i++) {
            double env = 1.0;
            uint32_t pos = done + i;
            if(pos < fade) env = (double)pos / fade;
            else if(total - pos < fade) env = (double)(total - pos) / fade;
            buf[i] = (int16_t)(y * 9000.0 * env);
            double nx = x * c - y * s;
            y = x * s + y * c;
            x = nx;
        }
        int r = myos_audio_play(buf, n, RATE, 1);
        if(r < 0) return r;
        done += n;
    }
    return MYOS_OK;
}

int myos_clipboard_set(const char *text) { return myos_syscall(SYS_CLIP_SET, MYOS_PTR(text), 0, 0, 0); }
int myos_clipboard_get(char *buffer, int max) { return myos_syscall(SYS_CLIP_GET, MYOS_PTR(buffer), (uint32_t)max, 0, 0); }

/* ======================================================================== */
/* string.h / ctype.h                                                        */
/* ======================================================================== */
void *memset(void *dst, int c, size_t n) {
    unsigned char *d = (unsigned char *)dst;
    while(n--) *d++ = (unsigned char)c;
    return dst;
}
void *memcpy(void *dst, const void *src, size_t n) {
    unsigned char *d = (unsigned char *)dst; const unsigned char *s = (const unsigned char *)src;
    while(n--) *d++ = *s++;
    return dst;
}
void *memmove(void *dst, const void *src, size_t n) {
    unsigned char *d = (unsigned char *)dst; const unsigned char *s = (const unsigned char *)src;
    if(d < s) { while(n--) *d++ = *s++; }
    else { d += n; s += n; while(n--) *--d = *--s; }
    return dst;
}
int memcmp(const void *a, const void *b, size_t n) {
    const unsigned char *x = (const unsigned char *)a, *y = (const unsigned char *)b;
    for(; n; n--, x++, y++) if(*x != *y) return *x - *y;
    return 0;
}
size_t strlen(const char *s) { size_t n = 0; while(s[n]) n++; return n; }
int strcmp(const char *a, const char *b) {
    while(*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}
int strncmp(const char *a, const char *b, size_t n) {
    for(; n; n--, a++, b++) { if(*a != *b) return (unsigned char)*a - (unsigned char)*b; if(!*a) return 0; }
    return 0;
}
char *strcpy(char *dst, const char *src) { char *d = dst; while((*d++ = *src++)) { } return dst; }
char *strncpy(char *dst, const char *src, size_t n) {
    size_t i = 0;
    for(; i < n && src[i]; i++) dst[i] = src[i];
    for(; i < n; i++) dst[i] = 0;
    return dst;
}
char *strcat(char *dst, const char *src) { strcpy(dst + strlen(dst), src); return dst; }
char *strchr(const char *s, int c) {
    for(;; s++) { if(*s == (char)c) return (char *)s; if(!*s) return NULL; }
}
char *strrchr(const char *s, int c) {
    const char *last = NULL;
    for(;; s++) { if(*s == (char)c) last = s; if(!*s) return (char *)last; }
}
char *strstr(const char *hay, const char *needle) {
    size_t n = strlen(needle);
    if(!n) return (char *)hay;
    for(; *hay; hay++) if(*hay == *needle && strncmp(hay, needle, n) == 0) return (char *)hay;
    return NULL;
}
int toupper(int c) { return (c >= 'a' && c <= 'z') ? c - 32 : c; }
int tolower(int c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }
int isdigit(int c) { return c >= '0' && c <= '9'; }
int isalpha(int c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'); }
int isspace(int c) { return c == ' ' || (c >= 9 && c <= 13); }

/* ======================================================================== */
/* stdlib.h                                                                  */
/* ======================================================================== */
typedef struct { uint32_t size; uint32_t free; uint32_t pad0, pad1; } blk_t;   /* 16 bytes keeps payloads 16-aligned */

#ifdef MYOS_HOST_SIM
static char sim_heap[16 * 1024 * 1024] __attribute__((aligned(16)));
#define HEAP_START ((uintptr_t)sim_heap)
#define HEAP_END   ((uintptr_t)sim_heap + sizeof(sim_heap))
#else
extern char _end[];                                   /* end of .bss, from app.ld */
#define HEAP_START (((uintptr_t)_end + 15u) & ~(uintptr_t)15u)
#define HEAP_END   ((uintptr_t)(MYOS_APP_BASE + MYOS_APP_IMAGE_MAX - 0x1000u))
#endif

static int heap_ready = 0;
static uintptr_t heap_lo, heap_hi;

static void heap_init(void) {
    heap_lo = HEAP_START;
    heap_hi = HEAP_END & ~(uintptr_t)15u;
    blk_t *b = (blk_t *)heap_lo;
    b->size = (uint32_t)(heap_hi - heap_lo - sizeof(blk_t));
    b->free = 1;
    heap_ready = 1;
}

void *malloc(size_t n) {
    if(!heap_ready) heap_init();
    if(n == 0) n = 1;
    n = (n + 15u) & ~(size_t)15u;
    for(uintptr_t p = heap_lo; p < heap_hi; ) {
        blk_t *b = (blk_t *)p;
        if(b->free) {
            /* merge with following free blocks first */
            for(;;) {
                uintptr_t nx = p + sizeof(blk_t) + b->size;
                if(nx >= heap_hi) break;
                blk_t *nb = (blk_t *)nx;
                if(!nb->free) break;
                b->size += (uint32_t)(sizeof(blk_t) + nb->size);
            }
            if(b->size >= n) {
                if(b->size >= n + sizeof(blk_t) + 16) {            /* split */
                    blk_t *rest = (blk_t *)(p + sizeof(blk_t) + n);
                    rest->size = (uint32_t)(b->size - n - sizeof(blk_t));
                    rest->free = 1;
                    b->size = (uint32_t)n;
                }
                b->free = 0;
                return (void *)(p + sizeof(blk_t));
            }
        }
        p += sizeof(blk_t) + b->size;
    }
    return NULL;
}

void free(void *ptr) {
    if(!ptr || !heap_ready) return;
    uintptr_t p = (uintptr_t)ptr - sizeof(blk_t);
    if(p < heap_lo || p >= heap_hi) return;
    ((blk_t *)p)->free = 1;
}

void *calloc(size_t n, size_t size) {
    size_t total = n * size;
    if(size && total / size != n) return NULL;
    void *p = malloc(total);
    if(p) memset(p, 0, total);
    return p;
}

void *realloc(void *ptr, size_t n) {
    if(!ptr) return malloc(n);
    if(n == 0) { free(ptr); return NULL; }
    blk_t *b = (blk_t *)((uintptr_t)ptr - sizeof(blk_t));
    if(b->size >= n) return ptr;
    void *np = malloc(n);
    if(!np) return NULL;
    memcpy(np, ptr, b->size);
    free(ptr);
    return np;
}

size_t myos_heap_free(void) {
    if(!heap_ready) heap_init();
    size_t total = 0;
    for(uintptr_t p = heap_lo; p < heap_hi; ) {
        blk_t *b = (blk_t *)p;
        if(b->free) total += b->size;
        p += sizeof(blk_t) + b->size;
    }
    return total;
}

int atoi(const char *s) {
    int sign = 1, v = 0;
    while(isspace(*s)) s++;
    if(*s == '-') { sign = -1; s++; } else if(*s == '+') s++;
    while(isdigit(*s)) { v = v * 10 + (*s - '0'); s++; }
    return v * sign;
}
int abs(int v) { return v < 0 ? -v : v; }

static unsigned rand_state = 1;
void srand(unsigned seed) { rand_state = seed ? seed : 1; }
int rand(void) {
    rand_state = rand_state * 1103515245u + 12345u;
    return (int)((rand_state >> 1) & 0x7FFFFFFF);
}

void qsort(void *base, size_t count, size_t size, int (*cmp)(const void *, const void *)) {
    unsigned char *a = (unsigned char *)base;
    /* Insertion sort by swapping neighbours byte-by-byte: stable, needs no
     * scratch buffer (so any element size works) and is plenty fast for the
     * UI-sized lists apps sort. */
    for(size_t i = 1; i < count; i++) {
        for(size_t j = i; j > 0 && cmp(a + (j - 1) * size, a + j * size) > 0; j--) {
            unsigned char *p = a + (j - 1) * size, *q = a + j * size;
            for(size_t k = 0; k < size; k++) { unsigned char t = p[k]; p[k] = q[k]; q[k] = t; }
        }
    }
}

/* ======================================================================== */
/* snprintf                                                                  */
/* ======================================================================== */
typedef struct { char *buf; size_t size, len; } out_t;
static void out_char(out_t *o, char c) {
    if(o->len + 1 < o->size) o->buf[o->len] = c;
    o->len++;
}
static void out_pad(out_t *o, int n, char c) { while(n-- > 0) out_char(o, c); }

static void out_number(out_t *o, uint32_t v, int base, int upper, int neg, int width, int zero, int left) {
    char tmp[16]; int n = 0;
    if(v == 0) tmp[n++] = '0';
    while(v) { int d = (int)(v % (uint32_t)base); tmp[n++] = (char)(d < 10 ? '0' + d : (upper ? 'A' : 'a') + d - 10); v /= (uint32_t)base; }
    int total = n + (neg ? 1 : 0);
    if(!left && !zero) out_pad(o, width - total, ' ');
    if(neg) out_char(o, '-');
    if(!left && zero) out_pad(o, width - total, '0');
    while(n) out_char(o, tmp[--n]);
    if(left) out_pad(o, width - total, ' ');
}

int vsnprintf(char *buf, size_t size, const char *fmt, va_list ap) {
    out_t o = { buf, size, 0 };
    for(; *fmt; fmt++) {
        if(*fmt != '%') { out_char(&o, *fmt); continue; }
        fmt++;
        int zero = 0, left = 0, width = 0;
        for(;; fmt++) { if(*fmt == '0') zero = 1; else if(*fmt == '-') left = 1; else break; }
        if(*fmt == '*') { width = va_arg(ap, int); fmt++; }
        else while(*fmt >= '0' && *fmt <= '9') width = width * 10 + (*fmt++ - '0');
        while(*fmt == 'l' || *fmt == 'h') fmt++;
        switch(*fmt) {
            case 'd': case 'i': { int v = va_arg(ap, int); out_number(&o, v < 0 ? (uint32_t)(-(int64_t)v) : (uint32_t)v, 10, 0, v < 0, width, zero, left); break; }
            case 'u': out_number(&o, va_arg(ap, unsigned), 10, 0, 0, width, zero, left); break;
            case 'x': out_number(&o, va_arg(ap, unsigned), 16, 0, 0, width, zero, left); break;
            case 'X': out_number(&o, va_arg(ap, unsigned), 16, 1, 0, width, zero, left); break;
            case 'p': out_char(&o, '0'); out_char(&o, 'x'); out_number(&o, (uint32_t)(uintptr_t)va_arg(ap, void *), 16, 0, 0, 8, 1, 0); break;
            case 'c': out_char(&o, (char)va_arg(ap, int)); break;
            case 's': {
                const char *s = va_arg(ap, const char *);
                if(!s) s = "(null)";
                int len = (int)strlen(s);
                if(!left) out_pad(&o, width - len, ' ');
                while(*s) out_char(&o, *s++);
                if(left) out_pad(&o, width - len, ' ');
                break;
            }
            case '%': out_char(&o, '%'); break;
            case '\0': fmt--; break;
            default: out_char(&o, '%'); out_char(&o, *fmt); break;
        }
    }
    if(size) o.buf[o.len < size ? o.len : size - 1] = '\0';
    return (int)o.len;
}

int snprintf(char *buf, size_t size, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    int r = vsnprintf(buf, size, fmt, ap);
    va_end(ap);
    return r;
}

int myos_ftoa(char *buf, size_t size, double v, int decimals) {
    if(decimals < 0) decimals = 0;
    if(decimals > 6) decimals = 6;
    int neg = v < 0;
    if(neg) v = -v;
    double scale = 1.0;
    for(int i = 0; i < decimals; i++) scale *= 10.0;
    uint32_t whole = (uint32_t)v;
    uint32_t frac = (uint32_t)((v - (double)whole) * scale + 0.5);
    if(frac >= (uint32_t)scale) { whole++; frac -= (uint32_t)scale; }
    if(decimals == 0) return snprintf(buf, size, "%s%u", neg ? "-" : "", whole);
    return snprintf(buf, size, "%s%u.%0*u", neg ? "-" : "", whole, decimals, frac);
}

/* ======================================================================== */
/* math (x87)                                                                */
/* ======================================================================== */
double myos_sin(double x) { double r; __asm__("fsin" : "=t"(r) : "0"(x)); return r; }
double myos_cos(double x) { double r; __asm__("fcos" : "=t"(r) : "0"(x)); return r; }
double myos_sqrt(double x) { double r; __asm__("fsqrt" : "=t"(r) : "0"(x)); return r; }
double myos_atan2(double y, double x) { double r; __asm__("fpatan" : "=t"(r) : "0"(x), "u"(y) : "st(1)"); return r; }
