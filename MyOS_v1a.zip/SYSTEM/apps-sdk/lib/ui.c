/* Immediate-mode widgets (include/myos/ui.h). Pure user-space code on top of
 * the drawing syscalls -- the look matches the desktop's own apps. */
#include <myos/ui.h>

#define C_CARD      0xFF2A2A30
#define C_FILL      0xFF3A3A42
#define C_FILL_HOT  0xFF47474F
#define C_FILL_DOWN 0xFF2C2C32
#define C_STROKE    0x1CFFFFFF
#define C_ACCENT_HI 0xFF6FD0FF
#define C_ACCENT_LO 0xFF3A9FD0
#define C_ON_ACCENT 0xFF0E1620

/* value * w / range in 32-bit arithmetic (a 64-bit divide would need libgcc,
 * which a bare freestanding link does not have). Operands are scaled down
 * first so the product cannot overflow even for very large ranges. */
static int scale_to_width(int value, int range, int w) {
    if(range <= 0 || value <= 0) return 0;
    while(range > 400000) { range >>= 1; value >>= 1; }
    if(w > 4096) w = 4096;
    return (int)(((uint32_t)value * (uint32_t)w) / (uint32_t)range);
}

void myos_ui_init(myos_ui_t *ui, int win) {
    memset(ui, 0, sizeof(*ui));
    ui->win = win;
    ui->mx = ui->my = -1;
}

void myos_ui_event(myos_ui_t *ui, const myos_event_t *ev) {
    switch(ev->type) {
        case MYOS_EV_MOUSE_MOVE: ui->mx = ev->x; ui->my = ev->y; break;
        case MYOS_EV_MOUSE_DOWN:
            if(ev->button == MYOS_BTN_LEFT) {
                ui->mx = ev->x; ui->my = ev->y; ui->down = 1; ui->pressed = 1; ui->focus_claimed = 0;
            }
            break;
        case MYOS_EV_MOUSE_UP:
            ui->mx = ev->x; ui->my = ev->y; ui->down = 0; ui->released = 1;
            break;
        case MYOS_EV_KEY:
            ui->key = ev->key; ui->mods = ev->mods;
            if(ui->key_count < 16) ui->keys[ui->key_count++] = ev->key;
            break;
        case MYOS_EV_FOCUS: if(!ev->key) { ui->down = 0; ui->active = 0; } break;
        default: break;
    }
}

void myos_ui_end_frame(myos_ui_t *ui) {
    if(ui->pressed && !ui->focus_claimed) ui->focus = 0;      /* clicked outside every text box */
    if(ui->released) ui->active = 0;
    ui->pressed = ui->released = 0;
    ui->key = 0;
    ui->key_count = 0;
}

int myos_ui_hover(const myos_ui_t *ui, int x, int y, int w, int h) {
    return ui->mx >= x && ui->mx < x + w && ui->my >= y && ui->my < y + h;
}

static void text_center(const myos_ui_t *ui, int x, int y, int w, int h, const char *s, uint32_t color) {
    int tw = (int)strlen(s) * MYOS_CHAR_W;
    myos_text(ui->win, x + (w - tw) / 2, y + (h - MYOS_CHAR_H) / 2, s, color);
}

void myos_ui_panel(myos_ui_t *ui, int x, int y, int w, int h) {
    myos_round_rect(ui->win, x, y, w, h, 8, C_CARD);
    myos_outline(ui->win, x, y, w, h, 8, C_STROKE);
}

void myos_ui_label(myos_ui_t *ui, int x, int y, const char *text, uint32_t color) {
    myos_text(ui->win, x, y, text, color);
}

void myos_ui_label_centered(myos_ui_t *ui, int x, int y, int w, int h, const char *text, uint32_t color) {
    text_center(ui, x, y, w, h, text, color);
}

int myos_ui_button(myos_ui_t *ui, int id, int x, int y, int w, int h, const char *label, myos_ui_style_t style) {
    int hot = myos_ui_hover(ui, x, y, w, h);
    if(hot && ui->pressed) ui->active = id;
    int held = (ui->active == id && ui->down);
    int clicked = (ui->active == id && ui->released && hot);

    uint32_t fill, text = MYOS_COLOR_TEXT;
    switch(style) {
        case MYOS_UI_ACCENT: fill = held ? C_ACCENT_LO : hot ? C_ACCENT_HI : MYOS_COLOR_ACCENT; text = C_ON_ACCENT; break;
        case MYOS_UI_DANGER: fill = held ? 0xFFA32316 : hot ? 0xFFD6453A : MYOS_COLOR_DANGER; text = 0xFFFFFFFF; break;
        case MYOS_UI_FLAT:   fill = held ? C_CARD : hot ? 0xFF34343B : MYOS_COLOR_BG; break;
        default:             fill = held ? C_FILL_DOWN : hot ? C_FILL_HOT : C_FILL; break;
    }
    myos_round_rect(ui->win, x, y, w, h, 6, fill);
    if(style == MYOS_UI_NORMAL || style == MYOS_UI_FLAT) myos_outline(ui->win, x, y, w, h, 6, C_STROKE);
    text_center(ui, x, y + (held ? 1 : 0), w, h, label, text);
    return clicked;
}

int myos_ui_checkbox(myos_ui_t *ui, int id, int x, int y, const char *label, int *value) {
    int w = 24 + (int)strlen(label) * MYOS_CHAR_W + 4, h = 22;
    int hot = myos_ui_hover(ui, x, y, w, h);
    if(hot && ui->pressed) ui->active = id;
    int changed = 0;
    if(ui->active == id && ui->released && hot) { *value = !*value; changed = 1; }

    myos_round_rect(ui->win, x, y + 2, 18, 18, 5, *value ? MYOS_COLOR_ACCENT : (hot ? C_FILL_HOT : C_FILL));
    if(!*value) myos_outline(ui->win, x, y + 2, 18, 18, 5, C_STROKE);
    else {   /* check mark */
        myos_line_f(ui->win, (float)x + 4.5f, (float)y + 11.5f, (float)x + 7.5f, (float)y + 14.5f, 2.0f, C_ON_ACCENT);
        myos_line_f(ui->win, (float)x + 7.5f, (float)y + 14.5f, (float)x + 13.5f, (float)y + 7.5f, 2.0f, C_ON_ACCENT);
    }
    myos_text(ui->win, x + 26, y + 3, label, MYOS_COLOR_TEXT);
    return changed;
}

int myos_ui_slider(myos_ui_t *ui, int id, int x, int y, int w, int *value, int min, int max) {
    int h = 20;
    int hot = myos_ui_hover(ui, x, y, w, h);
    if(hot && ui->pressed) ui->active = id;
    int changed = 0;
    if(ui->active == id && ui->down && max > min) {
        /* position as a 12-bit fraction of the track, then scale to the range */
        int off = MYOS_CLAMP(ui->mx - x, 0, w > 4096 ? 4096 : w);
        uint32_t frac = (uint32_t)off * 4096u / (uint32_t)(w > 4096 ? 4096 : w);
        uint32_t span = (uint32_t)(max - min);
        if(span > 500000u) span = 500000u;                  /* keeps span * frac inside 32 bits */
        int v = min + (int)((span * frac + 2048u) / 4096u);
        v = MYOS_CLAMP(v, min, max);
        if(v != *value) { *value = v; changed = 1; }
    }
    int fill = scale_to_width(*value - min, max - min, w);
    myos_round_rect(ui->win, x, y + 8, w, 4, 2, C_FILL);
    if(fill > 0) myos_round_rect(ui->win, x, y + 8, fill, 4, 2, MYOS_COLOR_ACCENT);
    int held = (ui->active == id && ui->down);
    myos_circle(ui->win, x + fill, y + 10, held ? 9 : 8, 0xFFF2F2F5);
    myos_circle(ui->win, x + fill, y + 10, 4, MYOS_COLOR_ACCENT);
    return changed;
}

void myos_ui_progress(myos_ui_t *ui, int x, int y, int w, int h, int value, int max) {
    myos_round_rect(ui->win, x, y, w, h, h / 2, C_FILL);
    if(max <= 0 || value <= 0) return;
    if(value > max) value = max;
    int fill = scale_to_width(value, max, w);
    if(fill < h) fill = h;
    myos_round_rect(ui->win, x, y, fill, h, h / 2, MYOS_COLOR_ACCENT);
}

int myos_ui_textbox(myos_ui_t *ui, int id, int x, int y, int w, char *buffer, int capacity) {
    int h = 28;
    int hot = myos_ui_hover(ui, x, y, w, h);
    if(hot && ui->pressed) { ui->focus = id; ui->focus_claimed = 1; }
    int focused = (ui->focus == id);
    int submitted = 0;

    if(focused) {
        /* Apply every key typed since the last redraw, in order. */
        for(int i = 0; i < ui->key_count; i++) {
            int len = (int)strlen(buffer), k = ui->keys[i];
            if(k == '\n') submitted = 1;
            else if((k == 8 || k == 127) && len > 0) buffer[len - 1] = '\0';
            else if(k >= 32 && k < 127 && len < capacity - 1) { buffer[len] = (char)k; buffer[len + 1] = '\0'; }
        }
        ui->key_count = 0;
    }

    myos_round_rect(ui->win, x, y, w, h, 6, 0xFF1A1A1E);
    myos_outline(ui->win, x, y, w, h, 6, focused ? 0xC04CC2FF : C_STROKE);
    int max_chars = (w - 16) / MYOS_CHAR_W;
    const char *s = buffer;
    int len = (int)strlen(buffer);
    if(len > max_chars) s += len - max_chars;                 /* show the tail while typing */
    myos_text(ui->win, x + 8, y + (h - MYOS_CHAR_H) / 2, s, MYOS_COLOR_TEXT);
    if(focused && (myos_ticks_ms() / 500) % 2 == 0) {
        int shown = len > max_chars ? max_chars : len;
        myos_fill_rect(ui->win, x + 8 + shown * MYOS_CHAR_W, y + 6, 2, h - 12, MYOS_COLOR_ACCENT);
    }
    return submitted;
}
