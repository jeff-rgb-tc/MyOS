/* gfx3d.c -- software 3D rasteriser (see include/myos/gfx3d.h). */
#include <myos/gfx3d.h>
#include <myos/libc.h>

#define PI_F 3.14159265f

/* ---- trig without libm: range-reduce to [-pi, pi], then a polynomial ---- */
float myos_sinf(float x) {
    x -= (float)(int)(x / (2.0f * PI_F)) * 2.0f * PI_F;
    if(x > PI_F) x -= 2.0f * PI_F;
    if(x < -PI_F) x += 2.0f * PI_F;
    /* Bhaskara-style parabola refined with one correction term: max error ~0.001 */
    float y = (4.0f / PI_F) * x - (4.0f / (PI_F * PI_F)) * x * (x < 0 ? -x : x);
    float ay = y < 0 ? -y : y;
    return 0.225f * (y * ay - y) + y;
}
float myos_cosf(float x) { return myos_sinf(x + PI_F * 0.5f); }

static float f_sqrt(float v) { double r; __asm__("fsqrt" : "=t"(r) : "0"((double)v)); return (float)r; }

myos_vec3 myos_vec3_make(float x, float y, float z) { myos_vec3 v = { x, y, z }; return v; }
myos_vec3 myos_vec3_sub(myos_vec3 a, myos_vec3 b) { return myos_vec3_make(a.x - b.x, a.y - b.y, a.z - b.z); }
myos_vec3 myos_vec3_cross(myos_vec3 a, myos_vec3 b) { return myos_vec3_make(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }
float myos_vec3_dot(myos_vec3 a, myos_vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
myos_vec3 myos_vec3_normalize(myos_vec3 v) {
    float l = f_sqrt(myos_vec3_dot(v, v));
    if(l < 1e-8f) return v;
    return myos_vec3_make(v.x / l, v.y / l, v.z / l);
}

myos_mat4 myos_mat4_identity(void) { myos_mat4 r; for(int i = 0; i < 16; i++) r.m[i] = (i % 5 == 0) ? 1.0f : 0.0f; return r; }
myos_mat4 myos_mat4_mul(myos_mat4 a, myos_mat4 b) {
    myos_mat4 r;
    for(int i = 0; i < 4; i++) for(int j = 0; j < 4; j++) {
        float s = 0;
        for(int k = 0; k < 4; k++) s += a.m[i * 4 + k] * b.m[k * 4 + j];
        r.m[i * 4 + j] = s;
    }
    return r;
}
myos_mat4 myos_mat4_translate(float x, float y, float z) { myos_mat4 r = myos_mat4_identity(); r.m[3] = x; r.m[7] = y; r.m[11] = z; return r; }
myos_mat4 myos_mat4_scale(float x, float y, float z) { myos_mat4 r = myos_mat4_identity(); r.m[0] = x; r.m[5] = y; r.m[10] = z; return r; }
myos_mat4 myos_mat4_rotate_x(float a) { myos_mat4 r = myos_mat4_identity(); float c = myos_cosf(a), s = myos_sinf(a); r.m[5] = c; r.m[6] = -s; r.m[9] = s; r.m[10] = c; return r; }
myos_mat4 myos_mat4_rotate_y(float a) { myos_mat4 r = myos_mat4_identity(); float c = myos_cosf(a), s = myos_sinf(a); r.m[0] = c; r.m[2] = s; r.m[8] = -s; r.m[10] = c; return r; }
myos_mat4 myos_mat4_rotate_z(float a) { myos_mat4 r = myos_mat4_identity(); float c = myos_cosf(a), s = myos_sinf(a); r.m[0] = c; r.m[1] = -s; r.m[4] = s; r.m[5] = c; return r; }

myos_mat4 myos_mat4_perspective(float fov, float aspect, float zn, float zf) {
    float f = myos_cosf(fov * 0.5f) / myos_sinf(fov * 0.5f);          /* cot(fov/2) */
    myos_mat4 r;
    for(int i = 0; i < 16; i++) r.m[i] = 0;
    r.m[0] = f / aspect;
    r.m[5] = f;
    r.m[10] = zf / (zf - zn);
    r.m[11] = -zf * zn / (zf - zn);
    r.m[14] = 1.0f;                                                   /* w = z */
    return r;
}

/* ---- target ---- */
int myos_g3d_init(myos_g3d_t *g, int w, int h) {
    memset(g, 0, sizeof(*g));
    g->w = w; g->h = h;
    g->color = (uint32_t *)malloc((size_t)w * h * 4);
    g->depth = (float *)malloc((size_t)w * h * 4);
    if(!g->color || !g->depth) { myos_g3d_free(g); return -1; }
    g->light = myos_vec3_normalize(myos_vec3_make(-0.4f, 0.7f, -0.6f));
    g->ambient = 0.25f;
    g->base_color = 0xFF4CC2FF;
    return 0;
}
void myos_g3d_free(myos_g3d_t *g) { free(g->color); free(g->depth); g->color = 0; g->depth = 0; }

void myos_g3d_clear(myos_g3d_t *g, uint32_t color) {
    int n = g->w * g->h;
    for(int i = 0; i < n; i++) { g->color[i] = color; g->depth[i] = 1e30f; }
    g->tris_drawn = 0;
}

static uint32_t shade(uint32_t c, float k) {
    if(k < 0) k = 0;
    if(k > 1) k = 1;
    uint32_t r = (uint32_t)((float)((c >> 16) & 0xFF) * k), gg = (uint32_t)((float)((c >> 8) & 0xFF) * k), b = (uint32_t)((float)(c & 0xFF) * k);
    return 0xFF000000u | (r << 16) | (gg << 8) | b;
}

static void line_px(myos_g3d_t *g, int x0, int y0, int x1, int y1, uint32_t c) {
    int dx = x1 > x0 ? x1 - x0 : x0 - x1, dy = y1 > y0 ? y1 - y0 : y0 - y1;
    int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    int err = (dx > dy ? dx : -dy) / 2;
    for(int guard = 0; guard < 4096; guard++) {
        if(x0 >= 0 && y0 >= 0 && x0 < g->w && y0 < g->h) g->color[y0 * g->w + x0] = c;
        if(x0 == x1 && y0 == y1) break;
        int e2 = err;
        if(e2 > -dx) { err -= dy; x0 += sx; }
        if(e2 < dy) { err += dx; y0 += sy; }
    }
}

static void fill_tri(myos_g3d_t *g, float x0, float y0, float z0, float x1, float y1, float z1, float x2, float y2, float z2, uint32_t color) {
    float minx = x0 < x1 ? (x0 < x2 ? x0 : x2) : (x1 < x2 ? x1 : x2);
    float maxx = x0 > x1 ? (x0 > x2 ? x0 : x2) : (x1 > x2 ? x1 : x2);
    float miny = y0 < y1 ? (y0 < y2 ? y0 : y2) : (y1 < y2 ? y1 : y2);
    float maxy = y0 > y1 ? (y0 > y2 ? y0 : y2) : (y1 > y2 ? y1 : y2);
    int ix0 = (int)minx; if(ix0 < 0) ix0 = 0;
    int iy0 = (int)miny; if(iy0 < 0) iy0 = 0;
    int ix1 = (int)maxx + 1; if(ix1 > g->w) ix1 = g->w;
    int iy1 = (int)maxy + 1; if(iy1 > g->h) iy1 = g->h;
    float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
    if(area > -1e-6f && area < 1e-6f) return;
    float inv = 1.0f / area;
    for(int y = iy0; y < iy1; y++) {
        float py = (float)y + 0.5f;
        for(int x = ix0; x < ix1; x++) {
            float px = (float)x + 0.5f;
            float w0 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) * inv;
            float w1 = ((x2 - px) * (y0 - py) - (x0 - px) * (y2 - py)) * inv;
            float w2 = 1.0f - w0 - w1;
            if(w0 < 0 || w1 < 0 || w2 < 0) continue;
            float z = w0 * z0 + w1 * z1 + w2 * z2;
            int idx = y * g->w + x;
            if(z < g->depth[idx]) { g->depth[idx] = z; g->color[idx] = color; }
        }
    }
}

void myos_g3d_draw_mesh(myos_g3d_t *g, const myos_mesh_t *mesh, const myos_mat4 *model, const myos_mat4 *proj, int flags) {
    if(!g->color || mesh->vert_count > 512) return;
    myos_vec3 wv[512];                 /* world space */
    float sx[512], sy[512], sz[512]; char ok[512];
    const float *M = model->m, *P = proj->m;
    for(int i = 0; i < mesh->vert_count; i++) {
        myos_vec3 v = mesh->verts[i];
        float x = M[0] * v.x + M[1] * v.y + M[2] * v.z + M[3];
        float y = M[4] * v.x + M[5] * v.y + M[6] * v.z + M[7];
        float z = M[8] * v.x + M[9] * v.y + M[10] * v.z + M[11];
        wv[i] = myos_vec3_make(x, y, z);
        float cw = P[14] * z;                                    /* clip w (= z for our projection) */
        if(cw < 0.05f) { ok[i] = 0; continue; }                  /* behind / too close to the camera */
        float cx = P[0] * x + P[1] * y + P[2] * z + P[3];
        float cy = P[4] * x + P[5] * y + P[6] * z + P[7];
        float cz = P[8] * x + P[9] * y + P[10] * z + P[11];
        sx[i] = (cx / cw * 0.5f + 0.5f) * (float)g->w;
        sy[i] = (0.5f - cy / cw * 0.5f) * (float)g->h;            /* y grows downwards on screen */
        sz[i] = cz / cw;
        ok[i] = 1;
    }
    for(int t = 0; t < mesh->tri_count; t++) {
        int a = mesh->indices[t * 3], b = mesh->indices[t * 3 + 1], c = mesh->indices[t * 3 + 2];
        if(a >= mesh->vert_count || b >= mesh->vert_count || c >= mesh->vert_count) continue;
        if(!ok[a] || !ok[b] || !ok[c]) continue;
        myos_vec3 n = myos_vec3_cross(myos_vec3_sub(wv[b], wv[a]), myos_vec3_sub(wv[c], wv[a]));
        n = myos_vec3_normalize(n);
        if(flags & MYOS_G3D_CULL_BACK) {
            /* triangle faces the camera if its normal points back towards the origin */
            if(myos_vec3_dot(n, wv[a]) >= 0.0f) continue;
        }
        uint32_t base = mesh->tri_color ? mesh->tri_color[t] : g->base_color;
        uint32_t col = base;
        if(!(flags & MYOS_G3D_NO_LIGHT)) {
            float d = myos_vec3_dot(n, g->light);          /* light points TOWARDS the lamp */
            if(d < 0) d = -d * 0.35f;                                  /* a little light from behind for open meshes */
            col = shade(base, g->ambient + (1.0f - g->ambient) * d);
        }
        if(flags & MYOS_G3D_WIREFRAME) {
            line_px(g, (int)sx[a], (int)sy[a], (int)sx[b], (int)sy[b], col);
            line_px(g, (int)sx[b], (int)sy[b], (int)sx[c], (int)sy[c], col);
            line_px(g, (int)sx[c], (int)sy[c], (int)sx[a], (int)sy[a], col);
        } else {
            fill_tri(g, sx[a], sy[a], sz[a], sx[b], sy[b], sz[b], sx[c], sy[c], sz[c], col);
        }
        g->tris_drawn++;
    }
}

/* ---- meshes ---- */
static const myos_vec3 cube_v[8] = {
    { -0.5f, -0.5f, -0.5f }, { 0.5f, -0.5f, -0.5f }, { 0.5f, 0.5f, -0.5f }, { -0.5f, 0.5f, -0.5f },
    { -0.5f, -0.5f, 0.5f }, { 0.5f, -0.5f, 0.5f }, { 0.5f, 0.5f, 0.5f }, { -0.5f, 0.5f, 0.5f },
};
/* counter-clockwise when seen from outside (y up, z away from the camera) */
static const uint16_t cube_i[36] = {
    0, 3, 2,  0, 2, 1,      /* back  (-z) */
    4, 5, 6,  4, 6, 7,      /* front (+z) */
    0, 4, 7,  0, 7, 3,      /* left  (-x) */
    1, 2, 6,  1, 6, 5,      /* right (+x) */
    3, 7, 6,  3, 6, 2,      /* top   (+y) */
    0, 1, 5,  0, 5, 4,      /* bottom(-y) */
};
static const uint32_t cube_c[12] = {
    0xFFE5484D, 0xFFE5484D, 0xFF4CC2FF, 0xFF4CC2FF, 0xFF5FD38D, 0xFF5FD38D,
    0xFFFFB454, 0xFFFFB454, 0xFF9B8CFF, 0xFF9B8CFF, 0xFFF2F2F5, 0xFFF2F2F5,
};
static const myos_mesh_t cube_mesh = { cube_v, 8, cube_i, 12, cube_c };
const myos_mesh_t *myos_mesh_cube(void) { return &cube_mesh; }

static const myos_vec3 pyr_v[5] = {
    { -0.5f, -0.5f, -0.5f }, { 0.5f, -0.5f, -0.5f }, { 0.5f, -0.5f, 0.5f }, { -0.5f, -0.5f, 0.5f }, { 0.0f, 0.6f, 0.0f },
};
static const uint16_t pyr_i[18] = {
    0, 1, 2,  0, 2, 3,                   /* base */
    0, 4, 1,  1, 4, 2,  2, 4, 3,  3, 4, 0,
};
static const uint32_t pyr_c[6] = { 0xFF8A8A94, 0xFF8A8A94, 0xFFE5484D, 0xFF5FD38D, 0xFF4CC2FF, 0xFFFFB454 };
static const myos_mesh_t pyr_mesh = { pyr_v, 5, pyr_i, 6, pyr_c };
const myos_mesh_t *myos_mesh_pyramid(void) { return &pyr_mesh; }
