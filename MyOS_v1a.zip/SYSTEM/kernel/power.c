#include "power.h"
#include "port.h"
#include "kernio.h"

extern void halt(void);

void power_shutdown(void) {
    printf("Shutting down...\n");

    /* Try every "magic port" shutdown sequence known to work under an
     * emulator, in order of how likely we are to actually be running
     * under each. None of these do anything on real ACPI-only
     * hardware (the write is simply ignored), so trying them all in
     * sequence is safe -- whichever one the host understands takes
     * effect and the machine powers off; the rest never get a chance
     * to matter. */

    /* Newer QEMU (the isa-debug-exit / "qemu shutdown" port most
     * commonly used today, also honored by many QEMU-derived BIOSes,
     * which is why this works under VirtualBox in practice too). */
    outw(0x604, 0x2000);

    /* Older QEMU / Bochs. */
    outw(0xB004, 0x2000);

    /* Older Bochs still. */
    outw(0x8900, 0x2000);

    /* Nothing above worked -- most likely real hardware with no ACPI
     * shutdown support wired up here. Halting the CPU is not a true
     * power-off, but it stops execution safely; the user can cut power
     * manually from here. */
    printf("Could not power off automatically. It is now safe to turn "
           "off the computer manually.\n");
    halt();
}

void power_reboot(void) {
    printf("Restarting...\n");

    /* Pulse the CPU reset line via the 8042 keyboard controller's
     * command port. This is the standard, widely-portable way to
     * trigger a real CPU reset from software -- works on real
     * hardware and in every emulator, unlike the shutdown magic ports
     * above which are emulator-specific. */
    outb(0x64, 0xFE);

    /* If we're still executing, the controller didn't respond (some
     * emulators are slow to react, or something odd is going on).
     * Halting is the safe fallback rather than falling through into
     * whatever comes after this function. */
    halt();
}
