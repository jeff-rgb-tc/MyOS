#ifndef LOOPDEV_H
#define LOOPDEV_H

#include "stdint.h"

/* Loop devices: a byte range of another device presented as a read-only disk of 512-byte sectors, so that
 * a disk image stored INSIDE something else (the f32.disk inside the update ISO on a CD/DVD) can be mounted
 * by the ordinary FAT32 driver. Ids start at LOOP_BASE and are accepted by ata_dev_read()/ata_dev_read_stream(). */
#define LOOP_BASE 16
#define LOOP_MAX  2

/* Backing device: an ATA/AHCI disk or an ATAPI CD/DVD drive. Returns the new device id or -1. */
int  loop_attach(int backing_dev, uint64_t byte_offset, uint64_t byte_length);
void loop_detach(int dev);
int  loop_is(int dev);
uint64_t loop_sectors(int dev);
int  loop_read(int dev, uint64_t lba, uint32_t count, void *buf);       /* 0 = ok */

#endif
