#ifndef DRIVER_LOADER_H
#define DRIVER_LOADER_H

#include "stdint.h"

/* Driver descriptors: /Drivers/<category>/<id>.drv
 *
 * A .drv file is a small INI text file that describes one driver and
 * controls how the kernel uses it. Categories (the folder name) are
 * "sound", "input" and "display". Format (see Drivers/README.md for the
 * full reference):
 *
 *   [driver]  id, name, category, version, vendor, description
 *   [load]    enabled (0/1), priority (higher is probed first), required (0/1)
 *   [match]   pci = VVVV:DDDD   (informational: the PCI device it drives)
 *   [settings] driver-specific key=value pairs (see each driver's file)
 *
 * The driver *code* is built into the kernel (kernel/ac97.c, sb16.c, ...):
 * a .drv does not contain machine code, it binds to a built-in driver by
 * its `id`. That keeps drivers safe (a bad file can only mis-configure,
 * never run code in ring 0) and still lets users and distributors enable,
 * disable, reorder and tune drivers without rebuilding the kernel.
 *
 * Absent files mean "defaults": a built-in driver with no descriptor is
 * enabled with its built-in priority, exactly like before .drv existed,
 * so an empty /Drivers folder never breaks boot. */

typedef enum {
    DRV_STATUS_INSTALLED = 0,  /* descriptor read, driver not (yet) started  */
    DRV_STATUS_ACTIVE,         /* started and in use                         */
    DRV_STATUS_STANDBY,        /* enabled, but a higher-priority driver won  */
    DRV_STATUS_DISABLED,       /* enabled=0 in its descriptor                */
    DRV_STATUS_NOT_PRESENT,    /* enabled, but its hardware wasn't found     */
    DRV_STATUS_UNKNOWN_ID,     /* descriptor names a driver this kernel lacks */
} driver_status_t;

#define DRV_MAX_DRIVERS 24
#define DRV_MAX_SETTINGS 6

typedef struct {
    char id[24];
    char name[40];
    char category[12];
    char version[12];
    char vendor[32];
    char description[64];
    char pci[12];
    int enabled;
    int priority;
    int required;
    int setting_count;
    char setting_key[DRV_MAX_SETTINGS][24];
    char setting_val[DRV_MAX_SETTINGS][32];
    driver_status_t status;
    char path[64];            /* where the descriptor was read from */
} driver_info_t;

/* Scans every .drv file under /Drivers/<category>/. Call once after the filesystem is up
 * and before the drivers that consult it start. Safe if /Drivers is
 * missing or empty. */
void driver_loader_init(void);

int driver_count(void);
const driver_info_t *driver_get(int index);
const driver_info_t *driver_find(const char *id);   /* NULL if no descriptor */

/* Convenience lookups for built-in drivers: each falls back to the given
 * default when there is no descriptor / no such setting. */
int driver_is_enabled(const char *id);              /* 1 if no descriptor (default on) */
int driver_priority(const char *id, int default_priority);
int driver_setting_int(const char *id, const char *key, int default_value);

/* Called by the subsystem that owns a built-in driver so Task Manager and
 * diagnostics show what is really happening. Creates a runtime-only entry
 * if the driver has no descriptor file. */
void driver_report_status(const char *id, const char *category, const char *name, driver_status_t status);

const char *driver_status_name(driver_status_t status);

#endif
