#ifndef AHCI_H
#define AHCI_H

#include "stdint.h"
#include "ata_pio_drv.h"

/* AHCI (SATA) disks, polled, one command at a time. This is the controller VirtualBox gives a new VM's disk by
 * default (and most real PCs since ~2008 in "AHCI" BIOS mode). Each SATA disk shows up as an ordinary ata device
 * (ids 4..9), so everything above -- FAT32, the installer, My PC, the volume scanner -- works unchanged. */

#define AHCI_MAX_PORTS 6

/* Looks for an AHCI controller and its disks. Fills `out[0..n)` and returns n. */
int  ahci_probe(ata_info_t *out, int max);
int  ahci_read(int port_index, uint64_t lba, uint32_t count, void *buf);          /* 0 = ok */
int  ahci_write(int port_index, uint64_t lba, uint32_t count, const void *buf);   /* 0 = ok */

#endif
