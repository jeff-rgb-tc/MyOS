#include "app_loader.h"
#include "stdio.h"
#include "common.h"
#include "kernio.h"
#include "kheap.h"
#include "paging.h"
#include "frame.h"
#include "usermode.h"
#include "tss.h"
#include "syscall.h"
#include "setjmp.h"
#include "pit.h"
#include "fs_util.h"
#include "desktop.h"

extern struct page_directory *kernel_directory;

/* Set immediately before enter_usermode() and read back by
 * app_fault_return()/app_exit_return() to get back out of execute_app():
 * returning normally from a syscall or fault handler would resume the
 * app's ring-3 code, which is exactly what must NOT happen, so a
 * non-local jump (setjmp.h) is used. One app at a time, so one jmp_buf. */
static jmp_buf app_return_point;
static volatile uint8_t app_running = 0;
static volatile uint8_t app_crashed = 0;
static char app_crash_reason[64];
static char app_name[40];
static uint32_t app_perms = 0;
static int app_abi = 2;
static volatile uint32_t last_syscall_ms = 0;

/* Launch request waiting for the desktop loop to pick it up. */
static char pending_path[96];
static volatile uint8_t pending = 0;

int app_is_running(void) { return app_running; }
const char *app_loader_current_name(void) { return app_running ? app_name : NULL; }
uint32_t app_permissions(void) { return app_perms; }
int app_abi_level(void) { return app_abi; }

void app_note_syscall(void) { last_syscall_ms = pit_get_ms(); }

void app_fault_return(const char *reason) {
    app_crashed = 1;
    int i = 0;
    while(reason[i] && i < (int)sizeof(app_crash_reason) - 1) {
        app_crash_reason[i] = reason[i];
        i++;
    }
    app_crash_reason[i] = '\0';
    longjmp(app_return_point, 1);
}

void app_exit_return(void) {
    longjmp(app_return_point, 1);
}

/* Runs in interrupt context (IRQ0, EOI already sent) and only while the
 * timer interrupted RING-3 code -- see pit.c. If the app has not entered
 * the kernel for APP_WATCHDOG_MS it is stuck in a compute loop; the
 * desktop is frozen for as long as that lasts, so end it. */
void app_watchdog_check(void) {
    if(!app_running) return;
    if((uint32_t)(pit_get_ms() - last_syscall_ms) > APP_WATCHDOG_MS) {
        app_fault_return("not responding");
    }
}

/* Dedicated ring0 stack for the whole time an app runs. Bigger than the
 * old 16 KB because desktop_pump() -- a full desktop frame with window
 * painting -- runs on it from inside syscalls. */
#define APP_KERNEL_STACK_SIZE 65536
static uint8_t app_kernel_stack[APP_KERNEL_STACK_SIZE] __attribute__((aligned(16)));

static void map_user_region(uint32_t addr, uint32_t len) {
    uint32_t start = addr & 0xFFFFF000;
    uint32_t end = addr + len;
    for(uint32_t curr = start; curr < end; curr += 0x1000) {
        struct page *p = get_page(curr, 1, kernel_directory);
        alloc_frame(p, /*is_kernel=*/0, /*is_writeable=*/1);
    }
}

static void unmap_user_region(uint32_t addr, uint32_t len) {
    uint32_t start = addr & 0xFFFFF000;
    uint32_t end = addr + len;
    for(uint32_t curr = start; curr < end; curr += 0x1000) {
        struct page *p = get_page(curr, 0, kernel_directory);
        if(p && p->present) {
            free_frame(p);
            p->present = 0;
        }
    }
}

static void copy_cstr(char *dst, int max, const char *src) {
    int i = 0;
    while(src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

static const char *base_name(const char *path) {
    const char *b = path;
    for(const char *p = path; *p; p++) if(*p == '/') b = p + 1;
    return b;
}

static void toast_failure(const char *what, const char *why) {
    char msg[120];
    sprintf(msg, "%s: %s", what, why);
    desktop_toast(msg);
}

int app_loader_read_manifest(const char *path, app_manifest_t *m, uint8_t **icon_png, uint32_t *icon_len) {
    uint32_t size = 0;
    uint8_t *file = fsu_read_file(path, &size);
    if(!file) return 0;
    const char *err = app_format_parse(file, size, m);
    if(err) { kfree(file); return 0; }
    if(icon_png) {
        *icon_png = NULL;
        if(icon_len) *icon_len = 0;
        if(m->icon_size) {
            uint8_t *copy = (uint8_t *)kmalloc(m->icon_size);
            if(copy) {
                memcpy(copy, file + m->icon_offset, m->icon_size);
                *icon_png = copy;
                if(icon_len) *icon_len = m->icon_size;
            }
        }
    }
    kfree(file);
    return 1;
}

int app_loader_run(const char *path) {
    if(!path || !path[0]) return 0;
    const char *shown = base_name(path);
    if(app_running || pending) {
        toast_failure(shown, "another app is already running");
        return 0;
    }
    int is_dir = 0;
    if(!fsu_stat(path, &is_dir, NULL, NULL, NULL) || is_dir) {
        toast_failure(shown, "file not found");
        return 0;
    }
    copy_cstr(pending_path, sizeof(pending_path), path);
    pending = 1;
    desktop_working_for_ms(1500);    /* arrow + spinner until it is up */
    return 1;
}

static void execute_app(const char *path) {
    const char *shown = base_name(path);
    desktop_busy_begin();

    uint32_t size = 0;
    uint8_t *file = fsu_read_file(path, &size);
    if(!file) {
        desktop_busy_end();
        toast_failure(shown, "cannot read file");
        return;
    }

    app_manifest_t m;
    const char *err = app_format_parse(file, size, &m);
    if(err) {
        kfree(file);
        desktop_busy_end();
        toast_failure(shown, err);
        return;
    }

    /* Map and populate the image. Everything beyond the stored bytes
     * (the bss) is zero because the whole region is cleared first. */
    map_user_region(APP_LOAD_BASE, APP_CODE_SIZE);
    memset((void *)APP_LOAD_BASE, 0, APP_CODE_SIZE);
    memcpy((void *)APP_LOAD_BASE, file + m.image_offset, m.code_size);

    map_user_region(APP_STACK_BASE, APP_STACK_SIZE);
    memset((void *)APP_STACK_BASE, 0, APP_STACK_SIZE);

    uint32_t entry_eip = APP_LOAD_BASE + m.entry_offset;
    uint32_t user_esp = APP_STACK_BASE + APP_STACK_SIZE - 16;
    kfree(file);

    /* MYOS_PERM_SYSTEM lets a program partition and format disks. It is
     * honoured for exactly two files -- the system installer and the system
     * updater -- no matter what any other app's manifest claims. */
    uint32_t eff_perms = m.permissions;
    if((eff_perms & MYOS_PERM_SYSTEM) && strcasecmp(path, "/APPS/installer/installer.app") != 0
                                       && strcasecmp(path, "/APPS/update/update.app") != 0) {
        eff_perms &= ~MYOS_PERM_SYSTEM;
        printf("app_loader: %s asked for the system permission -- denied.\n", m.name);
    }

    copy_cstr(app_name, sizeof(app_name), m.name);
    app_perms = eff_perms;
    app_abi = (int)m.abi_level;
    syscall_reset_state((uint32_t)m.abi_level, eff_perms);
    app_crashed = 0;
    app_crash_reason[0] = '\0';
    app_note_syscall();
    app_running = 1;
    desktop_busy_end();

    tss_set_kernel_stack((uint32_t)(app_kernel_stack + APP_KERNEL_STACK_SIZE));

    if(setjmp(app_return_point) == 0) {
        /* Drops to ring 3; control only comes back through a longjmp from
         * the syscall dispatcher, a fault handler or the watchdog. */
        enter_usermode(entry_eip, user_esp);
    }

    /* The app has exited or crashed. A fault/watchdog jump arrives here
     * with interrupts disabled (it came through an interrupt gate), and
     * setjmp does not restore EFLAGS -- turn them back on. */
    __asm__ volatile("sti");
    app_running = 0;
    syscall_cleanup_app();
    unmap_user_region(APP_LOAD_BASE, APP_CODE_SIZE);
    unmap_user_region(APP_STACK_BASE, APP_STACK_SIZE);

    if(app_crashed) {
        printf("app_loader: %s stopped (%s)\n", m.name, app_crash_reason);
        toast_failure(m.name, app_crash_reason[0] ? app_crash_reason : "stopped unexpectedly");
    }
}

void app_loader_service(void) {
    if(!pending || app_running) return;
    char path[sizeof(pending_path)];
    copy_cstr(path, sizeof(path), pending_path);
    pending = 0;
    execute_app(path);
}
