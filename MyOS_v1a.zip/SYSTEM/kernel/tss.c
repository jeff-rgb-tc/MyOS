#include "tss.h"
#include "common.h"

static tss_entry_t tss_entry;

/* Writes the raw 8-byte GDT descriptor for the TSS at gdt_entries[index]
 * -- mirrors gdt_set_gate() in gdt.c, but duplicated here rather than
 * exported from there, since a TSS descriptor's access byte (0x89:
 * present, ring0, type 1001 = 32-bit available TSS) is a fixed constant
 * that has nothing to do with gdt_set_gate()'s general-purpose
 * code/data-segment access byte parameter -- keeping it local avoids
 * gdt.c needing to know anything about TSS specifics. */
extern void gdt_set_tss_gate(int32_t entry, uint32_t base, uint32_t limit);
extern void load_tss(void);

void init_tss(int32_t gdt_entry_index, uint16_t ss0, uint32_t esp0) {
    uint32_t base = (uint32_t)&tss_entry;
    /* A segment limit is the offset of the last valid byte, not a byte
     * count or an end address -- sizeof(tss_entry_t) - 1, not base +
     * sizeof(tss_entry_t) (which would encode a limit almost as large
     * as the base address itself, since gdt_set_tss_gate only takes the
     * low 16 bits of this as limit_low with byte granularity). */
    uint32_t limit = sizeof(tss_entry_t) - 1;

    gdt_set_tss_gate(gdt_entry_index, base, limit);

    memset(&tss_entry, 0, sizeof(tss_entry_t));
    tss_entry.ss0 = ss0;
    tss_entry.esp0 = esp0;

    /* Segment selectors the CPU loads into es/cs/ss/ds/fs/gs when a
     * ring3->ring0 switch happens via this TSS's fields (used only if
     * the TSS is entered via a hardware task switch, which this kernel
     * never does -- but harmless and conventional to set the data
     * segments to the kernel data selector | RPL 3 here regardless, as
     * every reference OSDev-style TSS setup does, in case anything ever
     * relies on it). Kernel data selector is GDT entry 2 (see gdt.c) ->
     * selector 0x10; | 3 sets the RPL bits some setups expect here. */
    tss_entry.cs = 0x0B;
    tss_entry.ss = tss_entry.ds = tss_entry.es = tss_entry.fs = tss_entry.gs = 0x13;

    load_tss();
}

void tss_set_kernel_stack(uint32_t esp0) {
    tss_entry.esp0 = esp0;
}
