#include "ata_pio_drv.h"
#include "ahci.h"
#include "loopdev.h"
#include "port.h"
#include "kheap.h"
#include "common.h"
#include "kernio.h"

#define ATA_PRIMARY_DATA         0x1F0
#define ATA_PRIMARY_ERR          0x1F1
#define ATA_PRIMARY_SECCOUNT     0x1F2
#define ATA_PRIMARY_LBA_LO       0x1F3
#define ATA_PRIMARY_LBA_MID      0x1F4
#define ATA_PRIMARY_LBA_HI       0x1F5
#define ATA_PRIMARY_DRIVE_HEAD   0x1F6
#define ATA_PRIMARY_COMM_REGSTAT 0x1F7
#define ATA_PRIMARY_ALTSTAT_DCR  0x3F6


#define STAT_ERR  (1 << 0) // Indicates an error occurred. Send a new command to clear it
#define STAT_DRQ  (1 << 3) // Set when the drive has PIO data to transfer, or is ready to accept PIO data.
#define STAT_SRV  (1 << 4) // Overlapped Mode Service Request.
#define STAT_DF   (1 << 5) // Drive Fault Error (does not set ERR).
#define STAT_RDY  (1 << 6) // Bit is clear when drive is spun down, or after an error. Set otherwise.
#define STAT_BSY  (1 << 7) // Indicates the drive is preparing to send/receive data (wait for it to clear).
                           // In case of 'hang' (it never clears), do a software reset.


/**
 * To use the IDENTIFY command, select a target drive by sending 0xA0 for the master drive,
 * or 0xB0 for the slave, to the "drive select" IO port. On the Primary bus, this would be port 0x1F6.
 * Then set the Sectorcount, LBAlo, LBAmid, and LBAhi IO ports to 0 (port 0x1F2 to 0x1F5). Then send
 * the IDENTIFY command (0xEC) to the Command IO port (0x1F7).
 *
 * Then read the Status port (0x1F7) again.
 * If the value read is 0, the drive does not exist.
 * For any other value: poll the Status port (0x1F7) until bit 7 (BSY, value = 0x80) clears.
 * Because of some ATAPI drives that do not follow spec, at this point you need to check the
 * LBAmid and LBAhi ports (0x1F4 and 0x1F5) to see if they are non-zero. If so, the drive is not ATA,
 * and you should stop polling. Otherwise, continue polling one of the Status
 * ports until bit 3 (DRQ, value = 8) sets, or until bit 0 (ERR, value = 1) sets.
 *
 * At that point, if ERR is clear, the data is ready to read from the Data port (0x1F0).
 * Read 256 16-bit values, and store them.
 */

/* Generous spin-count ceiling for the polling loops below, so a drive
 * that never responds correctly -- or real hardware with a controller
 * quirk this driver doesn't handle -- can't hang the boot forever. This
 * matters far more on real hardware than under QEMU: an emulated ATA
 * controller reliably answers or reliably doesn't, but real
 * controllers/no-drive-present states can leave status bits in
 * combinations these unbounded loops would spin on indefinitely.
 * There's no calibrated delay primitive available this early in boot
 * (no working timer yet at the point kernel.c calls identify()), so
 * this is a plain iteration count rather than a wall-clock timeout --
 * imprecise, but the actual value only needs to be "clearly more
 * iterations than any real drive ever takes to respond" for the
 * fallback to work correctly. */
#define ATA_POLL_TIMEOUT_ITERS 100000

uint8_t identify() {
    inb(ATA_PRIMARY_COMM_REGSTAT);
    outb(ATA_PRIMARY_DRIVE_HEAD, 0xA0);
    inb(ATA_PRIMARY_COMM_REGSTAT);
    outb(ATA_PRIMARY_SECCOUNT, 0);
    inb(ATA_PRIMARY_COMM_REGSTAT);
    outb(ATA_PRIMARY_LBA_LO, 0);
    inb(ATA_PRIMARY_COMM_REGSTAT);
    outb(ATA_PRIMARY_LBA_MID, 0);
    inb(ATA_PRIMARY_COMM_REGSTAT);
    outb(ATA_PRIMARY_LBA_HI, 0);
    inb(ATA_PRIMARY_COMM_REGSTAT);
    /* Send ONLY the IDENTIFY command (0xEC) here. This used to be
     * immediately followed by outb(..., 0xE7) (FLUSH CACHE) -- sending
     * a second, unrelated command right on top of IDENTIFY before the
     * drive had any chance to process it. QEMU's emulated controller
     * tolerated that, but it's not spec-compliant ATA sequencing, and
     * real hardware is exactly where a stray extra command like this is
     * likely to leave the drive in a state these polling loops never
     * recover from -- silently hanging the boot. FLUSH CACHE has its
     * own correct, separate call site after an actual write (see the
     * "Flush the cache" comment further down in this file). */
    outb(ATA_PRIMARY_COMM_REGSTAT, 0xEC);

    // Read the status port. If it's zero, the drive does not exist.
    uint8_t status = inb(ATA_PRIMARY_COMM_REGSTAT);
    if(status == 0) return 0;

    printf("Waiting for status.\n");
    /* Poll until BSY clears, bounded so a drive that never clears it
     * can't hang boot forever (see ATA_POLL_TIMEOUT_ITERS above). */
    for(uint32_t i = 0; (status & STAT_BSY) && i < ATA_POLL_TIMEOUT_ITERS; i++) {
        status = inb(ATA_PRIMARY_COMM_REGSTAT);
    }
    if(status & STAT_BSY) {
        printf("No response from drive (BSY never cleared) -- assuming none present.\n");
        return 0;
    }

    if(status == 0) return 0;

    uint8_t mid = inb(ATA_PRIMARY_LBA_MID);
    uint8_t hi = inb(ATA_PRIMARY_LBA_HI);
    if(mid || hi) {
        // The drive is not ATA. (Who knows what it is.)
        return 0;
    }

    printf("Waiting for ERR or DRQ.\n");
    // Wait for ERR or DRQ, bounded for the same reason as the BSY poll above.
    for(uint32_t i = 0; !(status & (STAT_ERR | STAT_DRQ)) && i < ATA_POLL_TIMEOUT_ITERS; i++) {
        status = inb(ATA_PRIMARY_COMM_REGSTAT);
    }
    if(!(status & (STAT_ERR | STAT_DRQ))) {
        printf("No response from drive (neither ERR nor DRQ set) -- assuming none present.\n");
        return 0;
    }

    if(status & STAT_ERR) {
        // There was an error on the drive. Forget about it.
        return 0;
    }

    printf("Reading IDENTIFY structure.\n");
    //uint8_t *buff = kmalloc(40960, 0, NULL);
    uint8_t buff[256 * 2];
    insw(ATA_PRIMARY_DATA, buff, 256);
    printf("Success. Disk is ready to go.\n");
    // We read it!
    return 1;
}


/* ===========================================================================
 * Device-aware ATA PIO layer
 *
 * The code above only ever talked to the primary-channel master. A VM often
 * has the hard disk on another channel/position (VirtualBox: IDE controller,
 * primary/secondary, master/slave), and the installer has to enumerate every
 * disk and write to the one the user picks, so every drive position gets a
 * slot: 0 = primary master, 1 = primary slave, 2 = secondary master,
 * 3 = secondary slave. ATAPI devices (the CD with the ISO) are detected and
 * skipped, never treated as disks.
 *
 * Every wait is bounded (ATA_POLL_TIMEOUT_ITERS) -- a drive that never
 * answers fails the call instead of freezing the machine.
 * =========================================================================== */

static ata_info_t ata_devs[ATA_MAX_DEVICES];
static int ata_probed = 0;
static int ata_default_dev = 0;

#define ATA_IO(d)   (ata_devs[d].io)
#define ATA_CTL(d)  (ata_devs[d].ctl)

static void ata_delay400(int d) {
    /* Reading the alternate status register four times costs ~400 ns. */
    inb(ATA_CTL(d)); inb(ATA_CTL(d)); inb(ATA_CTL(d)); inb(ATA_CTL(d));
}

/* Waits for BSY to clear. Returns the last status, or 0xFF-with-BSY on timeout. */
static uint8_t ata_wait_ready(int d, uint32_t iters, int *timed_out) {
    uint8_t st = inb(ATA_IO(d) + 7);
    uint32_t i = 0;
    while((st & STAT_BSY) && i++ < iters) st = inb(ATA_IO(d) + 7);
    if(timed_out) *timed_out = (st & STAT_BSY) ? 1 : 0;
    return st;
}

/* Waits for DRQ (or an error). Returns 0 when data can be transferred. */
static int ata_wait_drq(int d) {
    uint32_t i = 0;
    uint8_t st;
    ata_delay400(d);
    for(;;) {
        st = inb(ATA_IO(d) + 7);
        if(!(st & STAT_BSY)) {
            if(st & (STAT_ERR | STAT_DF)) return -1;
            if(st & STAT_DRQ) return 0;
        }
        if(++i > ATA_POLL_TIMEOUT_ITERS * 50) return -1;
    }
}

static void ata_select(int d, uint32_t lba_hi4) {
    outb(ATA_IO(d) + 6, (uint8_t)(0xE0 | (ata_devs[d].slave << 4) | (lba_hi4 & 0x0F)));
    ata_delay400(d);
}

static void ata_copy_model(const uint16_t *id, char *out) {
    int n = 0;
    for(int w = 27; w <= 46; w++) {
        out[n++] = (char)(id[w] >> 8);
        out[n++] = (char)(id[w] & 0xFF);
    }
    out[n] = 0;
    while(n > 0 && (out[n - 1] == ' ' || out[n - 1] == 0)) out[--n] = 0;
}

static void ata_probe_one(int d) {
    ata_info_t *a = &ata_devs[d];
    a->present = 0; a->atapi = 0; a->lba48 = 0; a->sectors = 0; a->model[0] = 0;

    uint16_t io = a->io;
    outb(io + 6, (uint8_t)(0xA0 | (a->slave << 4)));
    ata_delay400(d);

    uint8_t st = inb(io + 7);
    if(st == 0x00 || st == 0xFF) return;           /* nothing there / floating bus */

    outb(a->ctl, 0x02);                             /* nIEN: no IRQ14/15 from this drive */
    outb(io + 2, 0); outb(io + 3, 0); outb(io + 4, 0); outb(io + 5, 0);
    outb(io + 7, 0xEC);                             /* IDENTIFY DEVICE */
    ata_delay400(d);
    st = inb(io + 7);
    if(st == 0) return;

    int to = 0;
    st = ata_wait_ready(d, ATA_POLL_TIMEOUT_ITERS, &to);
    if(to) return;

    uint8_t mid = inb(io + 4), hi = inb(io + 5);
    if(mid == 0x14 && hi == 0xEB) {                             /* ATAPI: CD/DVD drive */
        a->atapi = 1;
        /* IDENTIFY PACKET DEVICE gives the drive's name for the My PC view. */
        outb(io + 7, 0xA1);
        ata_delay400(d);
        if(ata_wait_drq(d) == 0) {
            uint16_t id[256];
            insw(io, id, 256);
            ata_copy_model(id, a->model);
        }
        return;
    }
    if(mid || hi) return;                                      /* not ATA */

    if(ata_wait_drq(d) != 0) return;

    uint16_t id[256];
    insw(io, id, 256);

    if(!(id[49] & (1 << 9))) return;                /* no LBA support: not usable */
    uint64_t s28 = ((uint32_t)id[61] << 16) | id[60];
    uint64_t s48 = 0;
    if(id[83] & (1 << 10)) {
        s48 = ((uint64_t)id[103] << 48) | ((uint64_t)id[102] << 32) |
              ((uint64_t)id[101] << 16) | id[100];
        if(s48) a->lba48 = 1;
    }
    a->sectors = a->lba48 ? s48 : s28;
    if(a->sectors == 0) return;
    ata_copy_model(id, a->model);
    a->present = 1;
}

int ata_probe_all(void) {
    static const uint16_t io_base[2]  = { 0x1F0, 0x170 };
    static const uint16_t ctl_base[2] = { 0x3F6, 0x376 };
    int found = 0;
    for(int d = 0; d < ATA_IDE_DEVICES; d++) {
        ata_devs[d].io = io_base[d >> 1];
        ata_devs[d].ctl = ctl_base[d >> 1];
        ata_devs[d].slave = (uint8_t)(d & 1);
        ata_probe_one(d);
        /* Some controllers answer for an empty slave slot with the master's
         * registers ("ghost" device). Same channel + identical size and
         * model as the master means it is the master again -- drop it, or
         * the installer would list one physical disk twice. */
        if(ata_devs[d].present && (d & 1)) {
            const ata_info_t *m = &ata_devs[d - 1];
            if(m->present && m->sectors == ata_devs[d].sectors &&
               strcmp(m->model, ata_devs[d].model) == 0) {
                ata_devs[d].present = 0;
            }
        }
        if(ata_devs[d].present) found++;
    }
    /* SATA disks behind an AHCI controller: found once (the controller is initialised only the first time). */
    static int ahci_scanned = 0, ahci_count = 0;
    static ata_info_t ahci_info[ATA_MAX_DEVICES - ATA_IDE_DEVICES];
    if(!ahci_scanned) { ahci_scanned = 1; ahci_count = ahci_probe(ahci_info, ATA_MAX_DEVICES - ATA_IDE_DEVICES); }
    for(int i = 0; i < ATA_MAX_DEVICES - ATA_IDE_DEVICES; i++) {
        if(i < ahci_count) { ata_devs[ATA_IDE_DEVICES + i] = ahci_info[i]; found++; }
        else memset(&ata_devs[ATA_IDE_DEVICES + i], 0, sizeof(ata_info_t));
    }
    ata_probed = 1;
    return found;
}

const ata_info_t *ata_device_info(int d) {
    if(d < 0 || d >= ATA_MAX_DEVICES) return 0;
    if(!ata_probed) ata_probe_all();
    return &ata_devs[d];
}

void ata_set_default_device(int d) { if(d >= 0 && d < ATA_MAX_DEVICES) ata_default_dev = d; }
int ata_get_default_device(void) { return ata_default_dev; }

static int ata_check(int d, uint64_t lba, uint32_t count) {
    if(d < 0 || d >= ATA_MAX_DEVICES) return -1;
    if(!ata_probed) ata_probe_all();
    if(!ata_devs[d].present) return -1;
    if(lba + count > ata_devs[d].sectors) return -1;
    return 0;
}

/* Issues one transfer command of up to 128 sectors. Returns the opcode
 * family chosen, or -1 if this device cannot address that LBA. */
static int ata_issue(int d, uint64_t lba, uint32_t n, int write, int dma) {
    uint16_t io = ata_devs[d].io;
    int to = 0;
    /* Select the drive FIRST: the status register shows the status of the
     * currently selected device, so waiting before selecting can wait on the
     * wrong drive of the channel (real hardware, master + slave on one cable). */
    outb(io + 6, (uint8_t)(0xA0 | (ata_devs[d].slave << 4)));
    ata_delay400(d);
    uint8_t st0 = ata_wait_ready(d, ATA_POLL_TIMEOUT_ITERS, &to);
    if(to || (st0 & (STAT_DRQ | STAT_ERR | STAT_DF))) {
        /* Leftover DRQ/error from an earlier aborted command: clear it with a
         * soft reset of the channel, then wait again. */
        outb(ATA_CTL(d), 0x06);              /* SRST + nIEN */
        ata_delay400(d);
        outb(ATA_CTL(d), 0x02);              /* release reset, keep nIEN */
        ata_delay400(d);
        outb(io + 6, (uint8_t)(0xA0 | (ata_devs[d].slave << 4)));
        ata_delay400(d);
        ata_wait_ready(d, ATA_POLL_TIMEOUT_ITERS * 20, &to);
        if(to) return -1;
    }

    if(lba + n <= 0x0FFFFFFFull) {
        ata_select(d, (uint32_t)(lba >> 24));
        outb(io + 1, 0);
        outb(io + 2, (uint8_t)n);
        outb(io + 3, (uint8_t)(lba & 0xFF));
        outb(io + 4, (uint8_t)((lba >> 8) & 0xFF));
        outb(io + 5, (uint8_t)((lba >> 16) & 0xFF));
        outb(io + 7, dma ? (write ? 0xCA : 0xC8) : (write ? 0x30 : 0x20));
        return 28;
    }
    if(!ata_devs[d].lba48) return -1;
    outb(io + 6, (uint8_t)(0x40 | (ata_devs[d].slave << 4)));
    ata_delay400(d);
    outb(io + 2, 0);                                  /* sector count, high byte */
    outb(io + 3, (uint8_t)((lba >> 24) & 0xFF));
    outb(io + 4, (uint8_t)((lba >> 32) & 0xFF));
    outb(io + 5, (uint8_t)((lba >> 40) & 0xFF));
    outb(io + 2, (uint8_t)n);
    outb(io + 3, (uint8_t)(lba & 0xFF));
    outb(io + 4, (uint8_t)((lba >> 8) & 0xFF));
    outb(io + 5, (uint8_t)((lba >> 16) & 0xFF));
    outb(io + 7, dma ? (write ? 0x35 : 0x25) : (write ? 0x34 : 0x24));
    return 48;
}

/* ---- small-read cache ------------------------------------------------------
 * The desktop and Explorer re-read the same few directory clusters every
 * ~600 ms to notice changes. With PIO on a real/virtual IDE disk each of
 * those reads is dozens of slow port accesses, so the UI stalled
 * periodically. Reads of up to 16 sectors (one cluster) are cached
 * (direct-mapped, exact lba+count match, 256 lines = 2 MiB); a write
 * updates an exactly matching line and drops other overlapping ones.
 * File data and FAT blocks use ata_dev_read_stream() and bypass it. */
#define ATA_RC_ENTRIES 256
#define ATA_RC_MAXSEC  16          /* clusters up to 8 KiB (volumes up to 32 GiB) */
typedef struct { int8_t dev; uint8_t count; uint64_t lba; } ata_rc_tag_t;   /* count 0 = empty */
static ata_rc_tag_t *ata_rc_tags = 0;
static uint8_t *ata_rc_data = 0;
static int ata_rc_failed = 0;

static int ata_rc_ready(void) {
    if(ata_rc_tags) return 1;
    if(ata_rc_failed) return 0;
    ata_rc_tags = (ata_rc_tag_t *)kmalloc(sizeof(ata_rc_tag_t) * ATA_RC_ENTRIES);
    ata_rc_data = (uint8_t *)kmalloc((size_t)ATA_RC_ENTRIES * ATA_RC_MAXSEC * 512);
    if(!ata_rc_tags || !ata_rc_data) { ata_rc_tags = 0; ata_rc_failed = 1; return 0; }
    for(int i = 0; i < ATA_RC_ENTRIES; i++) ata_rc_tags[i].count = 0;
    return 1;
}

static uint32_t ata_rc_slot(int d, uint64_t lba) {
    uint32_t h = (uint32_t)lba * 2654435761u + (uint32_t)d * 40503u;
    return (h >> 20) % ATA_RC_ENTRIES;
}

/* Called with the data about to be written: an exactly matching line is
 * refreshed (so re-reading a directory after changing it stays a RAM hit),
 * any other overlapping line is dropped. */
static void ata_rc_on_write(int d, uint64_t lba, uint32_t count, const void *buf) {
    if(!ata_rc_tags) return;
    for(int i = 0; i < ATA_RC_ENTRIES; i++) {
        ata_rc_tag_t *t = &ata_rc_tags[i];
        if(!t->count || t->dev != d) continue;
        if(!(lba < t->lba + t->count && t->lba < lba + count)) continue;
        if(t->lba == lba && t->count == count)
            memcpy(ata_rc_data + (size_t)i * ATA_RC_MAXSEC * 512, buf, (size_t)count * 512);
        else
            t->count = 0;
    }
}

/* ---- deferred FLUSH CACHE ---------------------------------------------------
 * FLUSH CACHE forces the drive (and, in a VM, the host) to push everything
 * to the platter -- by far the slowest command there is. Callers that do many
 * writes in a row (installer, a whole file create) turn flushing off and do
 * ONE flush at the end. Nestable. */
static int ata_flush_defer_depth = 0;
static uint8_t ata_flush_pending[ATA_MAX_DEVICES];

/* ---- bus-master DMA (PIIX/ICH IDE) -------------------------------------------
 * PIO moves every 512-byte sector through the CPU with several port accesses;
 * in a VM each of those is a trap, which is what made the installed system so
 * slow. With bus-master DMA one command moves up to 64 KiB and the controller
 * does the copying. If anything about DMA fails it switches itself off and the
 * PIO code below takes over, so it can only make things faster, never break them.
 * The bounce buffer must be physically contiguous: a static array in the
 * identity-mapped kernel image is (the heap is not). */
#include "pci.h"
#include "pit.h"

typedef struct { uint32_t addr; uint16_t count; uint16_t flags; } __attribute__((packed)) ata_prd_t;
static uint8_t dma_buf[65536] __attribute__((aligned(65536)));
static ata_prd_t dma_prd[2] __attribute__((aligned(64)));
static uint16_t dma_bm = 0;
static int dma_state = -1;           /* -1 = off (default), 0 = enabled but not initialised yet, 1 = usable.
                                      * Off until the kernel reads /Drivers/system/ata.drv (dma=1): DMA could not
                                      * be tested on real VM/hardware here, so it must never be a boot risk. */

void ata_dma_set_enabled(int on) {
    if(on && dma_state < 0) dma_state = 0;
    else if(!on) dma_state = -1;
}

static void ata_dma_init(void) {
    dma_state = -1;
    pci_device_t dev;
    if(!pci_find_device_by_class(0x01, 0x01, &dev)) return;           /* mass storage / IDE */
    uint32_t raw = pci_config_read32(dev.bus, dev.device, dev.function, 0x20);
    if(!(raw & 1)) return;
    uint16_t bm = (uint16_t)(raw & 0xFFFC);
    if(bm == 0 || bm == 0xFFFC) return;
    uint32_t cmd = pci_config_read32(dev.bus, dev.device, dev.function, 0x04) & 0xFFFF;
    pci_config_write32(dev.bus, dev.device, dev.function, 0x04, cmd | 0x5);   /* I/O space + bus master */
    dma_bm = bm;
    dma_state = 1;
    printf("ATA: bus-master DMA enabled (BM base 0x%x).\n", bm);
}

static int ata_dma_usable(int d) {
    if(dma_state == 0) ata_dma_init();
    if(dma_state < 0) return 0;
    return ata_devs[d].io == 0x1F0 || ata_devs[d].io == 0x170;        /* compatibility-mode channels only */
}

/* One DMA transfer of 1..128 sectors. Returns 28/48 (command family) or -1. */
static int ata_dma_xfer(int d, uint64_t lba, uint32_t n, int write, void *buf) {
    uint16_t bm = (uint16_t)(dma_bm + (ata_devs[d].io == 0x170 ? 8 : 0));
    if(write) memcpy(dma_buf, buf, (size_t)n * 512);

    dma_prd[0].addr = (uint32_t)dma_buf;
    dma_prd[0].count = (n * 512 >= 65536) ? 0 : (uint16_t)(n * 512);
    dma_prd[0].flags = 0x8000;                                        /* end of table */

    outb(bm, 0);
    outb(bm + 2, (uint8_t)(inb(bm + 2) | 0x06));                      /* clear error + interrupt */
    outl(bm + 4, (uint32_t)dma_prd);
    int mode = ata_issue(d, lba, n, write, 1);
    if(mode < 0) return -1;
    outb(bm, (uint8_t)((write ? 0x00 : 0x08) | 0x01));                /* start (bit 3 = device -> memory) */

    /* Done when the engine goes inactive (bit 0) -- NOT when the IRQ-status bit
     * appears: that bit follows the drive's INTRQ line and never sets on some
     * controllers/VMs. The wait is bounded by both a loop count and the clock,
     * because the clock alone does not advance if interrupts are off. */
    uint32_t t0 = pit_get_ms();
    uint8_t st = 0;
    uint32_t spins = 0;
    for(;;) {
        st = inb(bm + 2);
        if(st & 0x02) break;                                          /* error */
        if(!(st & 0x01)) break;                                       /* finished */
        if(++spins > 3000000u || (uint32_t)(pit_get_ms() - t0) > 3000) { st |= 0x02; break; }
    }
    outb(bm, 0);
    outb(bm + 2, (uint8_t)(st | 0x06));
    int to = 0;
    uint8_t ds = ata_wait_ready(d, ATA_POLL_TIMEOUT_ITERS * 50, &to);
    if((st & 0x02) || to || (ds & (STAT_ERR | STAT_DF))) return -1;

    if(!write) memcpy(buf, dma_buf, (size_t)n * 512);
    return mode;
}

static void ata_dma_off(const char *why) {
    dma_state = -1;
    printf("ATA: DMA %s -- falling back to PIO.\n", why);
}

static int ata_dev_read_raw(int d, uint64_t lba, uint32_t count, void *buf) {
    if(ata_devs[d].backend) return ahci_read(ata_devs[d].port, lba, count, buf);
    uint8_t *p = (uint8_t *)buf;
    while(count) {
        uint32_t n = count > 128 ? 128 : count;
        if(ata_dma_usable(d)) {
            if(ata_dma_xfer(d, lba, n, 0, p) >= 0) { p += (size_t)n * 512; lba += n; count -= n; continue; }
            ata_dma_off("read failed");
        }
        if(ata_issue(d, lba, n, 0, 0) < 0) return -1;
        for(uint32_t i = 0; i < n; i++) {
            if(i == 0) { if(ata_wait_drq(d) != 0) return -1; }
            else {
                /* Burst continues: one alt-status read is enough settle time
                 * (the 400 ns delay is only required right after a command). */
                inb(ATA_CTL(d));
                uint32_t spin = 0; uint8_t st;
                for(;;) {
                    st = inb(ATA_IO(d) + 7);
                    if(!(st & STAT_BSY)) {
                        if(st & (STAT_ERR | STAT_DF)) return -1;
                        if(st & STAT_DRQ) break;
                    }
                    if(++spin > ATA_POLL_TIMEOUT_ITERS * 50) return -1;
                }
            }
            insw(ATA_IO(d), p, 256);
            p += 512;
        }
        lba += n; count -= n;
    }
    return 0;
}

int ata_dev_read_stream(int d, uint64_t lba, uint32_t count, void *buf) {
    if(d >= LOOP_BASE) return loop_read(d, lba, count, buf);
    if(ata_check(d, lba, count) != 0) return -1;
    return ata_dev_read_raw(d, lba, count, buf);
}

int ata_dev_read(int d, uint64_t lba, uint32_t count, void *buf) {
    if(d >= LOOP_BASE) return loop_read(d, lba, count, buf);
    if(ata_check(d, lba, count) != 0) return -1;
    if(count == 0 || count > ATA_RC_MAXSEC || !ata_rc_ready())
        return ata_dev_read_raw(d, lba, count, buf);

    uint32_t slot = ata_rc_slot(d, lba);
    ata_rc_tag_t *t = &ata_rc_tags[slot];
    uint8_t *data = ata_rc_data + (size_t)slot * ATA_RC_MAXSEC * 512;
    if(t->count == count && t->dev == d && t->lba == lba) {
        memcpy(buf, data, (size_t)count * 512);
        return 0;
    }
    if(ata_dev_read_raw(d, lba, count, data) != 0) { t->count = 0; return -1; }
    t->dev = (int8_t)d; t->lba = lba; t->count = (uint8_t)count;
    memcpy(buf, data, (size_t)count * 512);
    return 0;
}

int ata_flush_now(int d, int lba48);

int ata_dev_write(int d, uint64_t lba, uint32_t count, const void *buf) {
    if(d >= LOOP_BASE) return -1;                        /* loop devices are read-only */
    if(ata_check(d, lba, count) != 0) return -1;
    ata_rc_on_write(d, lba, count, buf);
    if(ata_devs[d].backend) return ahci_write(ata_devs[d].port, lba, count, buf);
    const uint8_t *p = (const uint8_t *)buf;
    int mode = 28;
    while(count) {
        uint32_t n = count > 128 ? 128 : count;
        if(ata_dma_usable(d)) {
            int m = ata_dma_xfer(d, lba, n, 1, (void *)p);
            if(m >= 0) { mode = m; p += (size_t)n * 512; lba += n; count -= n; continue; }
            ata_dma_off("write failed");
        }
        mode = ata_issue(d, lba, n, 1, 0);
        if(mode < 0) return -1;
        for(uint32_t i = 0; i < n; i++) {
            if(ata_wait_drq(d) != 0) return -1;
            outsw(ATA_IO(d), (void *)p, 256);
            p += 512;
        }
        /* Wait until the drive has really finished this chunk before the
         * next command (a command written while BSY is ignored by real
         * drives). The expensive FLUSH CACHE is NOT done per 64 KiB chunk
         * any more -- once per call, below. */
        ata_delay400(d);
        int to = 0;
        uint8_t st = ata_wait_ready(d, ATA_POLL_TIMEOUT_ITERS * 50, &to);
        if(to || (st & (STAT_ERR | STAT_DF))) return -1;
        lba += n; count -= n;
    }
    if(ata_flush_defer_depth > 0) { ata_flush_pending[d] = 1; return 0; }
    return ata_flush_now(d, mode == 48);
}

int ata_flush_now(int d, int lba48) {
    if(ata_devs[d].backend) return 0;                    /* AHCI writes are synchronous DMA */
    ata_flush_pending[d] = 0;
    outb(ATA_IO(d) + 7, lba48 ? 0xEA : 0xE7);
    ata_delay400(d);
    int to = 0;
    uint8_t st = ata_wait_ready(d, ATA_POLL_TIMEOUT_ITERS * 200, &to);   /* flush can take a while */
    if(to || (st & (STAT_ERR | STAT_DF))) return -1;
    return 0;
}

void ata_defer_flush(int on) {
    if(on) { ata_flush_defer_depth++; return; }
    if(ata_flush_defer_depth > 0) ata_flush_defer_depth--;
    if(ata_flush_defer_depth == 0) {
        for(int d = 0; d < ATA_MAX_DEVICES; d++)
            if(ata_flush_pending[d]) ata_flush_now(d, ata_devs[d].lba48);
    }
}

/* ---- legacy entry points (default device) -------------------------------- */

void ata_pio_read28(uint32_t LBA, uint8_t sectorcount, uint8_t *target) {
    ata_dev_read(ata_default_dev, LBA, sectorcount ? sectorcount : 256, target);
}

void ata_pio_read48(uint64_t LBA, uint16_t sectorcount, uint8_t *target) {
    if(ata_dev_read(ata_default_dev, LBA, sectorcount, target) != 0) {
        printf("ATA: read error at LBA %d\n", (uint32_t)LBA);
        memset(target, 0, (uint32_t)sectorcount * 512);
    }
}

void ata_pio_write48(uint64_t LBA, uint16_t sectorcount, uint8_t *target) {
    if(ata_dev_write(ata_default_dev, LBA, sectorcount, target) != 0) {
        printf("ATA: write error at LBA %d\n", (uint32_t)LBA);
    }
}


/* ---------------------------------------------------------------------------
 * ATAPI (CD / DVD) -- PIO READ(10) / READ CAPACITY(10)
 * ------------------------------------------------------------------------ */
static int atapi_packet(int d, const uint8_t pkt[12], void *buf, uint32_t max_bytes, uint32_t *got) {
    uint16_t io = ata_devs[d].io;
    int to = 0;
    if(got) *got = 0;

    outb(io + 6, (uint8_t)(0xA0 | (ata_devs[d].slave << 4)));
    ata_delay400(d);
    uint8_t st = ata_wait_ready(d, ATA_POLL_TIMEOUT_ITERS, &to);
    if(to || (st & (STAT_DRQ | STAT_ERR | STAT_DF))) return -1;

    outb(io + 1, 0);                    /* PIO, no DMA */
    outb(io + 4, (uint8_t)(max_bytes > 0xFFFE ? 0xFE : (max_bytes & 0xFF)));
    outb(io + 5, (uint8_t)(max_bytes > 0xFFFE ? 0xFF : ((max_bytes >> 8) & 0xFF)));
    outb(io + 7, 0xA0);                 /* PACKET */
    if(ata_wait_drq(d) != 0) return -1;
    outsw(io, (void *)pkt, 6);

    uint32_t total = 0;
    uint8_t *out = (uint8_t *)buf;
    for(;;) {
        ata_delay400(d);
        uint32_t spin = 0;
        for(;;) {
            st = inb(io + 7);
            if(!(st & STAT_BSY)) break;
            if(++spin > ATA_POLL_TIMEOUT_ITERS * 50) return -1;
        }
        if(st & (STAT_ERR | STAT_DF)) return -1;
        if(!(st & STAT_DRQ)) break;                     /* command finished */
        uint32_t n = (uint32_t)inb(io + 4) | ((uint32_t)inb(io + 5) << 8);
        if(n == 0 || (n & 1)) return -1;
        if(total + n > max_bytes) return -1;
        insw(io, out + total, n / 2);
        total += n;
    }
    if(got) *got = total;
    return 0;
}

int ata_atapi_read(int d, uint32_t lba, uint32_t count, void *buf) {
    if(d < 0 || d >= ATA_MAX_DEVICES) return -1;
    if(!ata_probed) ata_probe_all();
    if(!ata_devs[d].atapi || count == 0) return -1;
    uint8_t *out = (uint8_t *)buf;
    while(count) {
        uint32_t n = count > 16 ? 16 : count;
        uint8_t pkt[12] = { 0x28, 0, (uint8_t)(lba >> 24), (uint8_t)(lba >> 16), (uint8_t)(lba >> 8), (uint8_t)lba,
                            0, (uint8_t)(n >> 8), (uint8_t)n, 0, 0, 0 };
        uint32_t got = 0;
        int rc = -1;
        for(int attempt = 0; attempt < 3 && rc != 0; attempt++)      /* first command often reports "unit attention" */
            rc = atapi_packet(d, pkt, out, n * 2048, &got);
        if(rc != 0 || got != n * 2048) return -1;
        out += n * 2048; lba += n; count -= n;
    }
    return 0;
}

uint32_t ata_atapi_capacity(int d) {
    if(d < 0 || d >= ATA_MAX_DEVICES) return 0;
    if(!ata_probed) ata_probe_all();
    if(!ata_devs[d].atapi) return 0;
    uint8_t pkt[12] = { 0x25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    uint8_t r[8];
    uint32_t got = 0;
    int rc = -1;
    for(int attempt = 0; attempt < 3 && rc != 0; attempt++) rc = atapi_packet(d, pkt, r, 8, &got);
    if(rc != 0 || got < 8) return 0;
    uint32_t last = ((uint32_t)r[0] << 24) | ((uint32_t)r[1] << 16) | ((uint32_t)r[2] << 8) | r[3];
    uint32_t bs = ((uint32_t)r[4] << 24) | ((uint32_t)r[5] << 16) | ((uint32_t)r[6] << 8) | r[7];
    if(bs != 2048) return 0;
    return last + 1;
}
