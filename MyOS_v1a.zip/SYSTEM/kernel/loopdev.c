#include "loopdev.h"
#include "ata_pio_drv.h"
#include "kheap.h"
#include "common.h"

typedef struct { int used, backing, optical; uint64_t off, len; uint8_t *tmp; } loop_t;
static loop_t loops[LOOP_MAX];

int loop_attach(int backing, uint64_t off, uint64_t len) {
    const ata_info_t *ai = ata_device_info(backing);
    if(!ai || (!ai->present && !ai->atapi) || len < 512) return -1;
    for(int i = 0; i < LOOP_MAX; i++) {
        if(loops[i].used) continue;
        uint8_t *tmp = (uint8_t *)kmalloc(2048);
        if(!tmp) return -1;
        loops[i].used = 1; loops[i].backing = backing; loops[i].optical = ai->atapi ? 1 : 0;
        loops[i].off = off; loops[i].len = len; loops[i].tmp = tmp;
        return LOOP_BASE + i;
    }
    return -1;
}

void loop_detach(int dev) {
    if(!loop_is(dev)) return;
    loop_t *l = &loops[dev - LOOP_BASE];
    kfree(l->tmp);
    memset(l, 0, sizeof(*l));
}

int loop_is(int dev) { return dev >= LOOP_BASE && dev < LOOP_BASE + LOOP_MAX && loops[dev - LOOP_BASE].used; }
uint64_t loop_sectors(int dev) { return loop_is(dev) ? loops[dev - LOOP_BASE].len >> 9 : 0; }

/* Reads `len` bytes at absolute byte offset `pos` of the backing device. */
static int backing_read(loop_t *l, uint64_t pos, uint8_t *out, uint32_t len) {
    uint32_t ss = l->optical ? 2048 : 512, shift = l->optical ? 11 : 9;
    while(len) {
        uint64_t sec = pos >> shift;
        uint32_t inoff = (uint32_t)(pos & (ss - 1));
        if(inoff == 0 && len >= ss) {
            uint32_t n = len / ss, maxn = l->optical ? 32u : 128u;
            if(n > maxn) n = maxn;
            int rc = l->optical ? ata_atapi_read(l->backing, (uint32_t)sec, n, out) : ata_dev_read_stream(l->backing, sec, n, out);
            if(rc != 0) return -1;
            out += (size_t)n * ss; pos += (uint64_t)n * ss; len -= n * ss;
        } else {
            int rc = l->optical ? ata_atapi_read(l->backing, (uint32_t)sec, 1, l->tmp) : ata_dev_read(l->backing, sec, 1, l->tmp);
            if(rc != 0) return -1;
            uint32_t take = ss - inoff;
            if(take > len) take = len;
            memcpy(out, l->tmp + inoff, take);
            out += take; pos += take; len -= take;
        }
    }
    return 0;
}

int loop_read(int dev, uint64_t lba, uint32_t count, void *buf) {
    if(!loop_is(dev)) return -1;
    loop_t *l = &loops[dev - LOOP_BASE];
    if(((lba + count) << 9) > l->len) return -1;
    return backing_read(l, l->off + (lba << 9), (uint8_t *)buf, count << 9);
}
