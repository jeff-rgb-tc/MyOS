#ifndef SYSCALL_H
#define SYSCALL_H

#include "stdint.h"
#include "myos/abi.h"

/* The syscall numbers, argument structs and event layout all live in
 * apps-sdk/include/myos/abi.h (shared with the SDK). This header only
 * declares the kernel-side entry points. */

/* Called by the int 0x80 gate (idt_asm). */
uint32_t syscall_dispatch(uint32_t num, uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4);

/* Per-launch bookkeeping, called by app_loader.c. */
void syscall_reset_state(uint32_t abi_level, uint32_t permissions);
/* Destroys every window the app still owns and releases its buffers. */
void syscall_cleanup_app(void);

#endif
