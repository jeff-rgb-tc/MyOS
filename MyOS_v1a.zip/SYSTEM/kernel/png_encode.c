/*
 * PNG encoder using uncompressed ("stored") DEFLATE blocks. See the
 * header comment in png_encode.h for why we don't bother with a real
 * Huffman compressor here -- the output is fully spec-compliant PNG,
 * just not size-optimized, which is a fine tradeoff for saving small
 * user drawings from Paint.
 *
 * A stored DEFLATE block is: 1 bit (BFINAL) + 2 bits (BTYPE=00), padded
 * to the next byte boundary, then a 4-byte header (LEN + ~LEN as two
 * little-endian uint16s) followed by LEN raw bytes. Stored blocks are
 * capped at 65535 bytes each, so a large image needs to be split across
 * multiple blocks -- we do that here rather than assume one block fits.
 */

#include "stdint.h"
#include "stddef.h"
#include "png_encode.h"
#include "kheap.h"
#include "common.h"
#include "kernio.h"
#include "stdio.h"

/* --- CRC32 (PNG chunk checksums), standard IEEE polynomial ------------ */

static uint32_t crc32_table[256];
static int crc32_table_ready = 0;

static void crc32_init_table() {
    for(uint32_t n = 0; n < 256; n++) {
        uint32_t c = n;
        for(int k = 0; k < 8; k++) {
            c = (c & 1) ? (0xEDB88320 ^ (c >> 1)) : (c >> 1);
        }
        crc32_table[n] = c;
    }
    crc32_table_ready = 1;
}

static uint32_t crc32(const uint8_t *data, uint32_t length) {
    if(!crc32_table_ready) crc32_init_table();

    uint32_t c = 0xFFFFFFFF;
    for(uint32_t i = 0; i < length; i++) {
        c = crc32_table[(c ^ data[i]) & 0xFF] ^ (c >> 8);
    }
    return c ^ 0xFFFFFFFF;
}

/* --- Adler32 (zlib stream checksum) ------------------------------------ */

static uint32_t adler32(const uint8_t *data, uint32_t length) {
    uint32_t a = 1, b = 0;
    const uint32_t MOD_ADLER = 65521;

    for(uint32_t i = 0; i < length; i++) {
        a = (a + data[i]) % MOD_ADLER;
        b = (b + a) % MOD_ADLER;
    }

    return (b << 16) | a;
}

/* --- little/big-endian helpers ---------------------------------------- */

static void write_u32be(uint8_t *p, uint32_t v) {
    p[0] = (v >> 24) & 0xFF;
    p[1] = (v >> 16) & 0xFF;
    p[2] = (v >> 8) & 0xFF;
    p[3] = v & 0xFF;
}

static void write_u16le(uint8_t *p, uint16_t v) {
    p[0] = v & 0xFF;
    p[1] = (v >> 8) & 0xFF;
}

/* --- growable output buffer -------------------------------------------- */

typedef struct {
    uint8_t *data;
    uint32_t length;
    uint32_t capacity;
} buffer_t;

static void buf_init(buffer_t *b, uint32_t initial_capacity) {
    b->data = (uint8_t *)kmalloc(initial_capacity);
    b->length = 0;
    b->capacity = initial_capacity;
}

static void buf_ensure(buffer_t *b, uint32_t additional) {
    if(b->length + additional <= b->capacity) return;

    uint32_t new_capacity = b->capacity * 2;
    while(new_capacity < b->length + additional) new_capacity *= 2;

    uint8_t *new_data = (uint8_t *)kmalloc(new_capacity);
    fastcp((char *)new_data, (char *)b->data, b->length);
    kfree(b->data);
    b->data = new_data;
    b->capacity = new_capacity;
}

static void buf_append(buffer_t *b, const uint8_t *data, uint32_t length) {
    buf_ensure(b, length);
    fastcp((char *)(b->data + b->length), (char *)data, length);
    b->length += length;
}

static void buf_append_u8(buffer_t *b, uint8_t v) {
    buf_append(b, &v, 1);
}

/* --- PNG chunk writing --------------------------------------------------- */

static void write_chunk(buffer_t *out, const char *type, const uint8_t *data, uint32_t length) {
    uint8_t len_bytes[4];
    write_u32be(len_bytes, length);
    buf_append(out, len_bytes, 4);

    /* CRC covers the chunk type + data, not the length field. */
    buffer_t crc_input;
    buf_init(&crc_input, length + 4);
    buf_append(&crc_input, (const uint8_t *)type, 4);
    if(length > 0) buf_append(&crc_input, data, length);

    buf_append(out, (const uint8_t *)type, 4);
    if(length > 0) buf_append(out, data, length);

    uint32_t crc = crc32(crc_input.data, crc_input.length);
    kfree(crc_input.data);

    uint8_t crc_bytes[4];
    write_u32be(crc_bytes, crc);
    buf_append(out, crc_bytes, 4);
}

/* --- stored-DEFLATE + zlib wrapping -------------------------------------- */

#define STORED_BLOCK_MAX 65535

static buffer_t deflate_stored(const uint8_t *raw, uint32_t raw_len) {
    buffer_t out;
    /* Worst case: each 65535-byte block costs 5 bytes of overhead. */
    buf_init(&out, raw_len + (raw_len / STORED_BLOCK_MAX + 1) * 5 + 16);

    uint32_t pos = 0;
    do {
        uint32_t remaining = raw_len - pos;
        uint32_t block_len = remaining > STORED_BLOCK_MAX ? STORED_BLOCK_MAX : remaining;
        uint8_t is_final = (pos + block_len >= raw_len) ? 1 : 0;

        /* BFINAL (1 bit) + BTYPE=00 (2 bits), then pad to byte boundary.
         * Since both fields fit in the low 3 bits of one byte and we
         * always emit whole bytes, this is just one byte: bit 0 = BFINAL,
         * bits 1-2 = 00 (stored), bits 3-7 = 0 padding. */
        buf_append_u8(&out, is_final ? 0x01 : 0x00);

        uint8_t len_bytes[4];
        write_u16le(len_bytes, (uint16_t)block_len);
        write_u16le(len_bytes + 2, (uint16_t)(~block_len & 0xFFFF));
        buf_append(&out, len_bytes, 4);

        buf_append(&out, raw + pos, block_len);

        pos += block_len;
    } while(pos < raw_len);

    return out;
}

static buffer_t zlib_deflate_stored(const uint8_t *raw, uint32_t raw_len) {
    buffer_t deflate_data = deflate_stored(raw, raw_len);

    buffer_t out;
    buf_init(&out, deflate_data.length + 6);

    /* zlib header: CMF=0x78 (deflate, 32K window), FLG chosen so that
     * (CMF*256 + FLG) % 31 == 0, per RFC 1950 -- 0x78 0x01 is a common
     * valid "no dictionary, fastest compression" pair. */
    buf_append_u8(&out, 0x78);
    buf_append_u8(&out, 0x01);

    buf_append(&out, deflate_data.data, deflate_data.length);
    kfree(deflate_data.data);

    uint32_t adler = adler32(raw, raw_len);
    uint8_t adler_bytes[4];
    write_u32be(adler_bytes, adler);
    buf_append(&out, adler_bytes, 4);

    return out;
}

/* --- top-level PNG encoding ---------------------------------------------- */

uint8_t *png_encode(const uint32_t *pixels, uint16_t width, uint16_t height, uint32_t *out_length) {
    if(!pixels || width == 0 || height == 0) {
        return NULL;
    }

    /* Build the raw (pre-DEFLATE) scanline stream: one filter-type byte
     * (always 0 = None, since we're not compressing anyway, filtering
     * would only add complexity without a compressor to exploit it)
     * followed by width*4 bytes of RGBA per row. */
    uint32_t bytes_per_row = (uint32_t)width * 4;
    uint32_t raw_size = (bytes_per_row + 1) * height;

    uint8_t *raw = (uint8_t *)kmalloc(raw_size);
    if(!raw) {
        printf("png_encode: out of memory for raw buffer (%d bytes)\n", raw_size);
        return NULL;
    }

    for(int y = 0; y < height; y++) {
        uint8_t *row = raw + y * (bytes_per_row + 1);
        row[0] = 0; /* filter type: None */

        const uint32_t *src_row = pixels + y * width;
        uint8_t *dst = row + 1;

        for(int x = 0; x < width; x++) {
            uint32_t px = src_row[x];
            uint8_t a = (px >> 24) & 0xFF;
            uint8_t r = (px >> 16) & 0xFF;
            uint8_t g = (px >> 8) & 0xFF;
            uint8_t b = px & 0xFF;

            dst[x * 4 + 0] = r;
            dst[x * 4 + 1] = g;
            dst[x * 4 + 2] = b;
            dst[x * 4 + 3] = a;
        }
    }

    buffer_t idat = zlib_deflate_stored(raw, raw_size);
    kfree(raw);

    buffer_t out;
    buf_init(&out, idat.length + 128);

    static const uint8_t PNG_SIGNATURE[8] = {0x89, 'P', 'N', 'G', '\r', '\n', 0x1A, '\n'};
    buf_append(&out, PNG_SIGNATURE, 8);

    uint8_t ihdr[13];
    write_u32be(ihdr + 0, width);
    write_u32be(ihdr + 4, height);
    ihdr[8] = 8;  /* bit depth */
    ihdr[9] = 6;  /* color type: truecolor + alpha */
    ihdr[10] = 0; /* compression method */
    ihdr[11] = 0; /* filter method */
    ihdr[12] = 0; /* interlace: none */
    write_chunk(&out, "IHDR", ihdr, 13);

    write_chunk(&out, "IDAT", idat.data, idat.length);
    kfree(idat.data);

    write_chunk(&out, "IEND", NULL, 0);

    *out_length = out.length;
    return out.data;
}

int png_save_to_file(const uint32_t *pixels, uint16_t width, uint16_t height,
                      f32 *fs, struct directory *dir, char *filename) {
    uint32_t length;
    uint8_t *data = png_encode(pixels, width, height, &length);
    if(!data) {
        return 0;
    }

    writeFile(fs, dir, data, filename, length);
    kfree(data);
    return 1;
}
