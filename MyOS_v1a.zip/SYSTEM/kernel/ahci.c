#include "ahci.h"
#include "pci.h"
#include "paging.h"
#include "common.h"
#include "kernio.h"

#ifdef AHCI_HOST_TEST
extern void ahci_test_hook(void);                  /* the host model advances the "hardware" while we poll */
#define POLL_HOOK() ahci_test_hook()
#else
#define POLL_HOOK() ((void)0)
#endif

/* ---- registers ---- */
#define HBA_CAP  0x00
#define HBA_GHC  0x04
#define HBA_IS   0x08
#define HBA_PI   0x0C
#define PORT(n, r) (0x100u + (n) * 0x80u + (r))
#define P_CLB 0x00
#define P_CLBU 0x04
#define P_FB  0x08
#define P_FBU 0x0C
#define P_IS  0x10
#define P_IE  0x14
#define P_CMD 0x18
#define P_TFD 0x20
#define P_SIG 0x24
#define P_SSTS 0x28
#define P_SERR 0x30
#define P_SACT 0x34
#define P_CI  0x38
#define CMD_ST  (1u << 0)
#define CMD_FRE (1u << 4)
#define CMD_FR  (1u << 14)
#define CMD_CR  (1u << 15)
#define TFD_ERR 0x01
#define TFD_DRQ 0x08
#define TFD_BSY 0x80
#define IS_TFES (1u << 30)

extern struct page_directory *kernel_directory;

typedef struct { uint8_t port; uint8_t ok; } ahci_port_t;

static volatile uint8_t *abar = 0;
static ahci_port_t ports[AHCI_MAX_PORTS];
static int nports = 0;

/* DMA structures live in the (identity-mapped) kernel image, so virtual == physical. */
static uint8_t cmd_list[AHCI_MAX_PORTS][1024] __attribute__((aligned(1024)));
static uint8_t fis_rx[AHCI_MAX_PORTS][256] __attribute__((aligned(256)));
static uint8_t cmd_tbl[AHCI_MAX_PORTS][256] __attribute__((aligned(128)));
static uint8_t bounce[65536] __attribute__((aligned(4096)));

static uint32_t rd(uint32_t off) { return *(volatile uint32_t *)(abar + off); }
static void wr(uint32_t off, uint32_t v) { *(volatile uint32_t *)(abar + off) = v; }

/* Uncached identity mapping for the controller registers. (struct page's "accessed"/"dirty" fields sit on the
 * hardware PWT/PCD bits 3/4, so setting them makes the page write-through + cache-disabled.) */
static void map_mmio(uint32_t phys, uint32_t len) {
    uint32_t cur = phys & 0xFFFFF000u;
    while(cur < phys + len) {
        struct page *p = get_page(cur, 1, kernel_directory);
        if(p) { p->present = 1; p->rw = 1; p->user = 0; p->accessed = 1; p->dirty = 1; p->frame = cur >> 12; }
#ifndef AHCI_HOST_TEST
        __asm__ volatile("invlpg (%0)" : : "r"(cur) : "memory");
#endif
        cur += 0x1000;
    }
}

static int wait_clear(uint32_t off, uint32_t mask, uint32_t spins) {
    while(spins--) { if(!(rd(off) & mask)) return 0; POLL_HOOK(); }
    return -1;
}

static int port_stop(int n) {
    uint32_t cmd = rd(PORT(n, P_CMD));
    if(cmd & (CMD_ST | CMD_CR)) { wr(PORT(n, P_CMD), cmd & ~CMD_ST); if(wait_clear(PORT(n, P_CMD), CMD_CR, 2000000) != 0) return -1; }
    cmd = rd(PORT(n, P_CMD));
    if(cmd & (CMD_FRE | CMD_FR)) { wr(PORT(n, P_CMD), cmd & ~CMD_FRE); if(wait_clear(PORT(n, P_CMD), CMD_FR, 2000000) != 0) return -1; }
    return 0;
}

static int port_start(int slot_idx, int n) {
    if(port_stop(n) != 0) return -1;
    memset(cmd_list[slot_idx], 0, sizeof(cmd_list[slot_idx]));
    memset(fis_rx[slot_idx], 0, sizeof(fis_rx[slot_idx]));
    wr(PORT(n, P_CLB), (uint32_t)cmd_list[slot_idx]); wr(PORT(n, P_CLBU), 0);
    wr(PORT(n, P_FB), (uint32_t)fis_rx[slot_idx]);    wr(PORT(n, P_FBU), 0);
    wr(PORT(n, P_SERR), 0xFFFFFFFFu);
    wr(PORT(n, P_IS), 0xFFFFFFFFu);
    wr(PORT(n, P_IE), 0);                                 /* polled: no interrupts */
    wr(PORT(n, P_CMD), rd(PORT(n, P_CMD)) | CMD_FRE);
    wr(PORT(n, P_CMD), rd(PORT(n, P_CMD)) | CMD_ST);
    return 0;
}

/* One command. `lba48` selects the 48-bit form of read/write. 0 = ok. */
static int issue(int idx, uint8_t command, uint64_t lba, uint32_t count, int write, void *buf, uint32_t bytes) {
    int n = ports[idx].port;
    if(wait_clear(PORT(n, P_TFD), TFD_BSY | TFD_DRQ, 2000000) != 0) return -1;

    uint8_t *hdr = cmd_list[idx];
    uint8_t *tbl = cmd_tbl[idx];
    memset(tbl, 0, 256);
    /* H2D register FIS */
    tbl[0] = 0x27; tbl[1] = 0x80; tbl[2] = command;
    tbl[4] = (uint8_t)lba; tbl[5] = (uint8_t)(lba >> 8); tbl[6] = (uint8_t)(lba >> 16);
    tbl[7] = 0x40;                                               /* LBA mode */
    tbl[8] = (uint8_t)(lba >> 24); tbl[9] = (uint8_t)(lba >> 32); tbl[10] = (uint8_t)(lba >> 40);
    tbl[12] = (uint8_t)count; tbl[13] = (uint8_t)(count >> 8);
    /* one PRD entry */
    uint32_t *prd = (uint32_t *)(tbl + 0x80);
    prd[0] = (uint32_t)buf; prd[1] = 0; prd[2] = 0; prd[3] = (bytes - 1) & 0x3FFFFF;

    uint32_t dw0 = 5u | (write ? (1u << 6) : 0u) | (1u << 16);   /* CFL=5 dwords, W, PRDTL=1 */
    memset(hdr, 0, 32);
    *(uint32_t *)(hdr + 0) = dw0;
    *(uint32_t *)(hdr + 8) = (uint32_t)tbl;

    wr(PORT(n, P_IS), 0xFFFFFFFFu);
    wr(PORT(n, P_CI), 1);
    uint32_t spins = 8000000;
    for(;;) {
        POLL_HOOK();
        if(!(rd(PORT(n, P_CI)) & 1)) break;
        if(rd(PORT(n, P_IS)) & IS_TFES) return -1;
        if(--spins == 0) return -1;
    }
    if(rd(PORT(n, P_IS)) & IS_TFES) return -1;
    if(rd(PORT(n, P_TFD)) & TFD_ERR) return -1;
    return 0;
}

static void copy_model(const uint16_t *id, char *out) {
    int n = 0;
    for(int w = 27; w < 47; w++) { out[n++] = (char)(id[w] >> 8); out[n++] = (char)(id[w] & 0xFF); }
    while(n > 0 && (out[n - 1] == ' ' || out[n - 1] == 0)) n--;
    out[n] = 0;
}

int ahci_probe(ata_info_t *out, int max) {
    pci_device_t dev;
    nports = 0;
    if(!pci_find_device_by_class(0x01, 0x06, &dev) || dev.prog_if != 0x01) return 0;     /* SATA controller in AHCI mode */
    uint32_t cmd = pci_config_read32(dev.bus, dev.device, dev.function, 0x04) & 0xFFFF;
    pci_config_write32(dev.bus, dev.device, dev.function, 0x04, cmd | 0x6);              /* memory space + bus master */
    uint32_t base = pci_get_bar(&dev, 5);
    if(!base) return 0;
    map_mmio(base, 0x2000);
    abar = (volatile uint8_t *)base;
    wr(HBA_GHC, rd(HBA_GHC) | (1u << 31));                                               /* AHCI enable */
    uint32_t pi = rd(HBA_PI);
    printf("AHCI: controller at %x, ports implemented %x\n", base, pi);

    for(int p = 0; p < 32 && nports < AHCI_MAX_PORTS && nports < max; p++) {
        if(!(pi & (1u << p))) continue;
        uint32_t ssts = rd(PORT(p, P_SSTS));
        if((ssts & 0xF) != 3 || ((ssts >> 8) & 0xF) != 1) continue;                    /* no device / link down */
        if(rd(PORT(p, P_SIG)) != 0x00000101u) continue;                                  /* SATA disk only (not ATAPI/PM) */
        int idx = nports;
        ports[idx].port = (uint8_t)p;
        if(port_start(idx, p) != 0) { printf("AHCI: port %d would not start\n", p); continue; }
        static uint16_t id[256];
        memset(id, 0, sizeof(id));
        if(issue(idx, 0xEC, 0, 0, 0, id, 512) != 0) { printf("AHCI: port %d IDENTIFY failed\n", p); continue; }
        uint64_t sectors = ((uint64_t)id[103] << 48) | ((uint64_t)id[102] << 32) | ((uint64_t)id[101] << 16) | id[100];
        if(!(id[83] & (1 << 10)) || !sectors) sectors = ((uint32_t)id[61] << 16) | id[60];
        if(!sectors) continue;
        ata_info_t *a = &out[nports];
        memset(a, 0, sizeof(*a));
        a->present = 1; a->lba48 = 1; a->sectors = sectors; a->backend = 1; a->port = (uint8_t)idx;
        copy_model(id, a->model);
        ports[idx].ok = 1;
        nports++;
        printf("AHCI: port %d: %s\n", p, a->model);
    }
    return nports;
}

static int transfer(int idx, uint64_t lba, uint32_t count, void *buf, int write) {
    if(idx < 0 || idx >= nports || !ports[idx].ok) return -1;
    uint8_t *p = (uint8_t *)buf;
    while(count) {
        uint32_t n = count > 128 ? 128 : count;                  /* 64 KiB bounce buffer */
        if(write) memcpy(bounce, p, (size_t)n * 512);
        if(issue(idx, write ? 0x35 : 0x25, lba, n, write, bounce, n * 512) != 0) return -1;
        if(!write) memcpy(p, bounce, (size_t)n * 512);
        p += (size_t)n * 512; lba += n; count -= n;
    }
    return 0;
}

int ahci_read(int idx, uint64_t lba, uint32_t count, void *buf) { return transfer(idx, lba, count, buf, 0); }
int ahci_write(int idx, uint64_t lba, uint32_t count, const void *buf) { return transfer(idx, lba, count, (void *)buf, 1); }
