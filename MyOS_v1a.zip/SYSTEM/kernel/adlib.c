#include "adlib.h"
#include "port.h"
#include "kernio.h"
#include "stddef.h"

#define OPL2_STATUS_PORT 0x388
#define OPL2_ADDR_PORT   0x388
#define OPL2_DATA_PORT   0x389

static uint8_t adlib_present = 0;

/* Standard OPL2 detection sequence (documented in every AdLib
 * programming reference): reset both timers, unmask them, start timer
 * 1, then check that its "expired" status bit actually set itself after
 * a short wait -- real silicon (or an emulator faithfully reproducing
 * it) will do this; nothing will on a port with no OPL2 chip behind it. */
static int adlib_probe_and_init(void) {
    outb(OPL2_ADDR_PORT, 0x04);
    outb(OPL2_DATA_PORT, 0x60); /* mask both timers */
    outb(OPL2_ADDR_PORT, 0x04);
    outb(OPL2_DATA_PORT, 0x80); /* reset IRQ */

    uint8_t status1 = inb(OPL2_STATUS_PORT);
    if((status1 & 0xE0) != 0) return 0; /* busy/timer bits should be clear right after reset */

    outb(OPL2_ADDR_PORT, 0x02);
    outb(OPL2_DATA_PORT, 0xFF); /* timer 1 count = max */
    outb(OPL2_ADDR_PORT, 0x04);
    outb(OPL2_DATA_PORT, 0x21); /* unmask + start timer 1 */

    for(volatile int i = 0; i < 10000; i++) { } /* let timer 1 actually expire */

    uint8_t status2 = inb(OPL2_STATUS_PORT);

    /* Clean up regardless of the result. */
    outb(OPL2_ADDR_PORT, 0x04);
    outb(OPL2_DATA_PORT, 0x60);
    outb(OPL2_ADDR_PORT, 0x04);
    outb(OPL2_DATA_PORT, 0x80);

    if((status2 & 0xC0) != 0xC0) return 0; /* timer 1 expired + overall status bits should both be set now */

    adlib_present = 1;
    printf("adlib: OPL2 chip detected at %x (FM synthesis only -- no PCM playback support)\n", OPL2_STATUS_PORT);
    return 1;
}

/* No-ops: see adlib.h's top comment for why PCM playback is not
 * something this hardware can do at all, not just something this
 * driver hasn't implemented yet. */
static void adlib_set_format(uint32_t sample_rate, uint8_t channels) {
    (void)sample_rate; (void)channels;
}

static void adlib_write(const int16_t *samples, uint32_t sample_count) {
    (void)samples; (void)sample_count;
}

static int adlib_ready_for_more(void) {
    /* Always "ready" (nothing to ever be behind on) rather than 0, so a
     * caller polling this in a loop waiting for space doesn't spin
     * forever if AdLib somehow ends up the active driver. */
    return adlib_present;
}

const audio_driver_t adlib_driver = {
    .name = "AdLib (FM synthesis only, no PCM playback)",
    .probe_and_init = adlib_probe_and_init,
    .set_format = adlib_set_format,
    .write = adlib_write,
    .ready_for_more = adlib_ready_for_more,
    .set_volume = NULL,
};
