#include "installer.h"
#include "fsx.h"
#include "volumes.h"
#include "loopdev.h"
#include "ata_pio_drv.h"
#include "fat32.h"
#include "kheap.h"
#include "common.h"
#include "kernio.h"
#include "pit.h"

/* See installer.h for the big picture. Everything here is plain C on top of
 * the ATA and FAT32 drivers; the only interaction with the desktop is that
 * every call is short, so the installer window keeps repainting between
 * steps. */

#define SECTOR 512u

/* Directories on the running system that are copied to the new one. */
static const char *const copy_roots[] = { "/SYSTEM", "/APPS", "/Drivers", "/Users", "/boot" };
#define NUM_ROOTS ((int)(sizeof(copy_roots) / sizeof(copy_roots[0])))
/* Never copied: the boot loader payload is only needed to write the MBR. */
/* /APPS/installer: the installer is only for the live ISO; an installed system must not carry it. */
static const char *const skip_paths[] = { "/SYSTEM/install", "/APPS/installer" };

#define PATH_MAX_LEN 160

typedef struct {
    char path[PATH_MAX_LEN];
    uint32_t size;
    uint8_t is_dir;
} item_t;

enum {
    ST_IDLE = 0, ST_UCHECK, ST_CHECK, ST_BACKUP, ST_RESTORE, ST_BOOT, ST_FMT_META, ST_FMT_FAT, ST_SCAN, ST_COPY, ST_FINISH, ST_DONE, ST_FAILED
};

static struct {
    int stage;
    /* optional backup of the old /Users before the disk is formatted, restored at the end */
    int backup;
    int bk_started;
    struct bk_item *bk; uint32_t bk_n, bk_cap, bk_skipped, rs_cursor;
    uint64_t bk_bytes;
    f32 *bk_fs;
    struct directory bk_dir; int bk_dir_open; uint32_t bk_pos;
    char bk_path[160];
    char bk_queue[48][160]; int bk_qn;
    f32 *src;                /* where the files come from: NULL = the running system (Live); else the disc's image */
    f32 *src_iso; int src_loop;
    int self_update;         /* 1 = the target is the running system itself (update from a disc) */
    int update;              /* 1 = update an installed system in place (no partitioning/formatting) */
    uint32_t part_lba;       /* first sector of the target FAT32 partition */
    int dev;                 /* ATA device being installed to */
    uint32_t disk_sectors;
    uint32_t part_sectors;
    uint32_t spf;            /* sectors per FAT */
    uint32_t spc;            /* sectors per cluster */
    uint32_t finish_off;     /* FAT mirror progress (sectors) */
    uint32_t clusters;
    uint32_t cursor;         /* progress inside the current stage */
    uint32_t total_files;    /* kept after the worklist is freed, for the final status */
    uint32_t items_done;
    item_t *items;
    uint32_t item_count, item_cap;
    uint64_t bytes_total, bytes_done;
    f32 *tfs;                /* target filesystem, once mounted */
    int32_t error;
    char stage_text[48];
    char detail[64];
} S;

static f32 *srcfs(void) { return S.src ? S.src : master_fs; }   /* where the files to copy are read from */


/* ------------------------------------------------------------------ */
/* small helpers                                                       */
/* ------------------------------------------------------------------ */
static void put_le16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put_le32(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
}
static void copy_str(char *dst, int max, const char *src) {
    int i = 0;
    while(src && src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

static void set_stage(const char *text) { copy_str(S.stage_text, sizeof(S.stage_text), text); }

/* The whole install writes thousands of small blocks; FLUSH CACHE after each
 * one is what made it so slow. Flushing is postponed for the duration of the
 * install and done once at the end (or when it fails / is cancelled). */
static int flush_deferred = 0;
static void io_defer_begin(void) { if(!flush_deferred) { ata_defer_flush(1); flush_deferred = 1; } }
static void io_defer_end(void)   { if(flush_deferred)  { flush_deferred = 0; ata_defer_flush(0); } }

static int fail(int32_t err, const char *why) {
    io_defer_end();
    S.error = err;
    S.stage = ST_FAILED;
    copy_str(S.detail, sizeof(S.detail), why);
    if(S.tfs) { S.tfs->defer_flush = 0; }
    return err;
}

/* ------------------------------------------------------------------ */
/* disk enumeration                                                    */
/* ------------------------------------------------------------------ */
static int nth_disk(int index) {
    int seen = 0;
    for(int d = 0; d < ATA_MAX_DEVICES; d++) {
        const ata_info_t *ai = ata_device_info(d);
        if(ai && ai->present) {
            if(seen == index) return d;
            seen++;
        }
    }
    return -1;
}

int installer_disk_count(void) {
    int n = 0;
    ata_probe_all();
    for(int d = 0; d < ATA_MAX_DEVICES; d++) {
        const ata_info_t *ai = ata_device_info(d);
        if(ai && ai->present) n++;
    }
    return n;
}

static uint32_t part_sectors_for(uint64_t disk_sectors) {
    uint64_t avail = disk_sectors > INST_PART_START ? disk_sectors - INST_PART_START : 0;
    if(avail > INST_MAX_PART_SECTORS) avail = INST_MAX_PART_SECTORS;
    return (uint32_t)avail;
}

int installer_disk_info(int index, myos_diskinfo_t *out) {
    int d = nth_disk(index);
    if(d < 0) return MYOS_E_ARG;
    const ata_info_t *ai = ata_device_info(d);
    memset(out, 0, sizeof(*out));
    copy_str(out->model, sizeof(out->model), ai->model[0] ? ai->model : "Hard disk");
    out->size_mb = (uint32_t)(ai->sectors / 2048u);
    out->part_mb = part_sectors_for(ai->sectors) / 2048u;
    out->usable = 1;

    if(ai->sectors < INST_MIN_DISK_SECTORS) { out->usable = 0; out->reason = 1; }

    /* Never offer the disk the running system lives on. */
    if(master_fs && master_fs->dev == d) { out->usable = 0; out->reason = 2; }

    uint32_t part;
    out->has_filesystem = fat32_probe_volume(d, &part) ? 1u : 0u;
    return MYOS_OK;
}

/* ------------------------------------------------------------------ */
/* path helpers on an explicit filesystem                              */
/* ------------------------------------------------------------------ */
static int find_entry(const struct directory *d, const char *name) {
    for(uint32_t i = 0; i < d->num_entries; i++) {
        if(!d->entries[i].name || (d->entries[i].dir_attrs & LFN) == LFN) continue;   /* copy read-only/hidden/system files too */
        if(strcasecmp(d->entries[i].name, name) == 0) return (int)i;
    }
    return -1;
}

static int open_dir(f32 *fs, const char *path, struct directory *out) {
    populate_root_dir(fs, out);
    int i = 0;
    while(path[i]) {
        while(path[i] == '/') i++;
        if(!path[i]) break;
        char name[64]; int n = 0;
        while(path[i] && path[i] != '/') { if(n < 63) name[n++] = path[i]; i++; }
        name[n] = '\0';
        int idx = find_entry(out, name);
        if(idx < 0 || !(out->entries[idx].dir_attrs & DIRECTORY)) { free_directory(fs, out); return 0; }
        uint32_t cluster = out->entries[idx].first_cluster;
        free_directory(fs, out);
        populate_dir(fs, out, cluster ? cluster : 2);
    }
    return 1;
}

static void split_path(const char *path, char *parent, int pmax, char *name, int nmax) {
    int len = (int)strlen(path), last = -1;
    for(int i = 0; i < len; i++) if(path[i] == '/') last = i;
    if(last <= 0) { parent[0] = '/'; parent[1] = '\0'; }
    else { int n = last < pmax - 1 ? last : pmax - 1; for(int i = 0; i < n; i++) parent[i] = path[i]; parent[n] = '\0'; }
    int nn = 0;
    for(int i = last + 1; i < len && nn < nmax - 1; i++) name[nn++] = path[i];
    name[nn] = '\0';
}

static int path_is(const char *a, const char *b) { return strcasecmp(a, b) == 0; }

/* ------------------------------------------------------------------ */
/* worklist                                                            */
/* ------------------------------------------------------------------ */
static int add_item(const char *path, int is_dir, uint32_t size) {
    if(S.item_count == S.item_cap) {
        uint32_t ncap = S.item_cap ? S.item_cap * 2 : 128;
        item_t *n = (item_t *)krealloc(S.items, ncap * sizeof(item_t));
        if(!n) return 0;
        S.items = n; S.item_cap = ncap;
    }
    item_t *it = &S.items[S.item_count++];
    copy_str(it->path, sizeof(it->path), path);
    it->is_dir = (uint8_t)is_dir;
    it->size = size;
    return 1;
}

static void free_items(void) {
    if(S.items) kfree(S.items);
    S.items = 0; S.item_count = S.item_cap = 0;
}

/* Breadth-first walk of the running system: parents are always listed
 * before their children, so the copy stage can create them in order. */
static int scan_source(void) {
    free_items();
    S.bytes_total = 0;
    for(int r = 0; r < NUM_ROOTS; r++) {
        if(S.update && path_is(copy_roots[r], "/Users")) continue;
        struct directory d;
        if(open_dir(srcfs(), copy_roots[r], &d)) {
            free_directory(srcfs(), &d);
            if(!add_item(copy_roots[r], 1, 0)) return 0;
        }
    }
    for(uint32_t i = 0; i < S.item_count; i++) {
        if(!S.items[i].is_dir) continue;
        char dirpath[PATH_MAX_LEN];
        copy_str(dirpath, sizeof(dirpath), S.items[i].path);

        struct directory d;
        if(!open_dir(srcfs(), dirpath, &d)) continue;
        for(uint32_t k = 0; k < d.num_entries; k++) {
            struct dir_entry *e = &d.entries[k];
            if(!e->name || (e->dir_attrs & (LFN | VolumeID))) continue;
            if(strcmp(e->name, ".") == 0 || strcmp(e->name, "..") == 0) continue;
            char child[PATH_MAX_LEN];
            int len = (int)strlen(dirpath);
            if(len + 1 + (int)strlen(e->name) >= PATH_MAX_LEN) continue;   /* too long: skipped */
            copy_str(child, sizeof(child), dirpath);
            if(len > 1) { child[len] = '/'; child[len + 1] = '\0'; }
            int cl = (int)strlen(child);
            copy_str(child + cl, (int)sizeof(child) - cl, e->name);

            int skip = 0;
            for(unsigned s = 0; s < sizeof(skip_paths) / sizeof(skip_paths[0]); s++)
                if(path_is(child, skip_paths[s])) skip = 1;
            if(skip) continue;

            int is_dir = (e->dir_attrs & DIRECTORY) ? 1 : 0;
            if(!add_item(child, is_dir, is_dir ? 0 : e->file_size)) { free_directory(srcfs(), &d); return 0; }
            if(!is_dir) S.bytes_total += e->file_size;
        }
        free_directory(srcfs(), &d);
    }
    return 1;
}

/* ------------------------------------------------------------------ */
/* stage: check                                                        */
/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/* optional backup of /Users (kept in RAM while the disk is rebuilt)   */
/* ------------------------------------------------------------------ */
struct bk_item { char *path; uint8_t *data; uint32_t size; uint8_t is_dir; };
#define BK_CAP_BYTES (48u * 1024u * 1024u)       /* total kept in memory */
#define BK_FILE_MAX  (12u * 1024u * 1024u)       /* larger single files are skipped (and counted) */

static void bk_free(void) {
    for(uint32_t i = 0; i < S.bk_n; i++) { kfree(S.bk[i].path); if(S.bk[i].data) kfree(S.bk[i].data); }
    if(S.bk) kfree(S.bk);
    S.bk = 0; S.bk_n = S.bk_cap = 0;
    if(S.bk_dir_open) { free_directory(S.bk_fs, &S.bk_dir); S.bk_dir_open = 0; }
    if(S.bk_fs) { destroyFilesystem(S.bk_fs); S.bk_fs = 0; }
}

static int bk_add(const char *path, uint8_t *data, uint32_t size, int is_dir) {
    if(S.bk_n == S.bk_cap) {
        uint32_t ncap = S.bk_cap ? S.bk_cap * 2 : 64;
        struct bk_item *n = (struct bk_item *)krealloc(S.bk, ncap * sizeof(struct bk_item));
        if(!n) return 0;
        S.bk = n; S.bk_cap = ncap;
    }
    uint32_t len = (uint32_t)strlen(path);
    char *p = (char *)kmalloc(len + 1);
    if(!p) return 0;
    memcpy(p, path, len + 1);
    S.bk[S.bk_n].path = p; S.bk[S.bk_n].data = data; S.bk[S.bk_n].size = size; S.bk[S.bk_n].is_dir = (uint8_t)is_dir;
    S.bk_n++;
    return 1;
}

static int stage_backup(void) {
    uint32_t t0 = pit_get_ms();
    if(!S.bk_started) {
        S.bk_started = 1;
        uint32_t part = 0;
        if(fat32_probe_volume(S.dev, &part)) S.bk_fs = makeFilesystemOn(S.dev, part);
        if(S.bk_fs) {
            struct directory d;
            if(open_dir(S.bk_fs, "/Users", &d)) {
                free_directory(S.bk_fs, &d);
                copy_str(S.bk_queue[0], 160, "/Users"); S.bk_qn = 1;
                bk_add("/Users", 0, 0, 1);
            }
        }
    }
    while(S.bk_fs && (uint32_t)(pit_get_ms() - t0) < 300) {
        if(!S.bk_dir_open) {
            if(S.bk_qn == 0) break;
            copy_str(S.bk_path, sizeof(S.bk_path), S.bk_queue[--S.bk_qn]);
            if(!open_dir(S.bk_fs, S.bk_path, &S.bk_dir)) continue;
            S.bk_dir_open = 1; S.bk_pos = 0;
            copy_str(S.detail, sizeof(S.detail), S.bk_path);
        }
        if(S.bk_pos >= S.bk_dir.num_entries) { free_directory(S.bk_fs, &S.bk_dir); S.bk_dir_open = 0; continue; }
        struct dir_entry *e = &S.bk_dir.entries[S.bk_pos++];
        if(!e->name || (e->dir_attrs & LFN) == LFN || e->name[0] == '.') continue;
        char child[160];
        int n = 0;
        for(const char *c = S.bk_path; *c && n < 150; c++) child[n++] = *c;
        child[n++] = '/';
        for(const char *c = e->name; *c && n < 159; c++) child[n++] = *c;
        child[n] = 0;
        if(e->dir_attrs & DIRECTORY) {
            if(S.bk_qn < 48 && bk_add(child, 0, 0, 1)) copy_str(S.bk_queue[S.bk_qn++], 160, child);
            else S.bk_skipped++;
        } else {
            uint32_t size = e->file_size;
            if(size > BK_FILE_MAX || S.bk_bytes + size > BK_CAP_BYTES) { S.bk_skipped++; continue; }
            uint8_t *data = size ? readFile(S.bk_fs, e) : (uint8_t *)kmalloc(1);
            if(!data || !bk_add(child, data, size, 0)) { if(data) kfree(data); S.bk_skipped++; continue; }
            S.bk_bytes += size;
        }
    }
    if(!S.bk_fs || (S.bk_qn == 0 && !S.bk_dir_open)) {
        if(S.bk_fs) { destroyFilesystem(S.bk_fs); S.bk_fs = 0; }
        S.stage = ST_BOOT;
        set_stage("Preparing the disk");
    }
    return MYOS_OK;
}

static int stage_restore(void) {
    uint32_t t0 = pit_get_ms();
    while(S.rs_cursor < S.bk_n && (uint32_t)(pit_get_ms() - t0) < 300) {
        struct bk_item *it = &S.bk[S.rs_cursor++];
        char parent[PATH_MAX_LEN], name[64];
        split_path(it->path, parent, sizeof(parent), name, sizeof(name));
        copy_str(S.detail, sizeof(S.detail), it->path);
        if(!name[0]) continue;
        struct directory d;
        if(!open_dir(S.tfs, parent, &d)) continue;            /* parent missing: skip, never abort the install */
        if(it->is_dir) { if(find_entry(&d, name) < 0) mkdir(S.tfs, &d, name); }
        else writeFile(S.tfs, &d, it->data, name, it->size);
        free_directory(S.tfs, &d);
        if(it->data) { kfree(it->data); it->data = 0; }
    }
    if(S.rs_cursor >= S.bk_n) {
        bk_free();
        S.stage = ST_FINISH;
        set_stage("Finishing");
    }
    return MYOS_OK;
}

static void src_release(void) {
    if(S.src) { destroyFilesystem(S.src); S.src = 0; }
    if(S.src_loop >= LOOP_BASE) { loop_detach(S.src_loop); S.src_loop = 0; }
    if(S.src_iso) { destroyFilesystem(S.src_iso); S.src_iso = 0; }
}

/* Running from the hard disk: the new version has to come from an update disc. Looks for a CD/DVD (ISO 9660)
 * that carries /boot/f32.disk -- the FAT32 image with the new SYSTEM/APPS/Drivers -- and mounts that image
 * through a loop device. */
static f32 *find_update_source(void) {
    volumes_scan();
    for(int i = 0; i < volumes_count(); i++) {
        const volume_t *v = volumes_get(i);
        if(!v || !v->optical || v->fs != FS_ISO9660) continue;
        f32 *iso = fsx_mount(v);
        if(!iso) continue;
        struct directory d;
        if(open_dir(iso, "/boot", &d)) {
            int idx = find_entry(&d, "f32.disk");
            if(idx >= 0) {
                uint32_t lba = d.entries[idx].first_cluster, size = d.entries[idx].file_size;
                free_directory(iso, &d);
                int ld = loop_attach(v->dev, (uint64_t)lba * 2048u, size);
                if(ld >= 0) {
                    f32 *fs = makeFilesystemOn(ld, 0);
                    if(fs) {
                        struct directory t;
                        if(open_dir(fs, "/SYSTEM", &t)) { free_directory(fs, &t); S.src_iso = iso; S.src_loop = ld; return fs; }
                        destroyFilesystem(fs);
                    }
                    loop_detach(ld);
                }
            }
            else free_directory(iso, &d);
        }
        destroyFilesystem(iso);
    }
    return 0;
}

static int stage_check(void) {
    const ata_info_t *ai = ata_device_info(S.dev);
    if(!ai || !ai->present) return fail(MYOS_E_INST_DISK, "disk not found");
    if(ai->sectors < INST_MIN_DISK_SECTORS) return fail(MYOS_E_INST_DISK, "disk is smaller than 256 MB");
    if(master_fs && master_fs->dev == S.dev) return fail(MYOS_E_INST_DISK, "this is the disk MyOS is running from");
    if(!master_fs) return fail(MYOS_E_FAIL, "system disk not mounted");
    S.disk_sectors = ai->sectors > 0xFFFFFFFFull ? 0xFFFFFFFFu : (uint32_t)ai->sectors;
    S.part_sectors = part_sectors_for(ai->sectors);

    /* geometry: 32 reserved sectors, 2 FATs; the cluster size grows with the
     * partition so that the FAT stays small enough to live in RAM. */
    uint32_t reserved = 32, spc = INST_MIN_SECTORS_PER_CLUSTER, spf = 1;
    while(spc < 64 && (S.part_sectors / spc) > INST_MAX_CLUSTERS_TARGET) spc *= 2;
    for(int it = 0; it < 32; it++) {
        uint32_t data = S.part_sectors - reserved - 2 * spf;
        uint32_t clusters = data / spc;
        uint32_t need = ((clusters + 2) * 4 + SECTOR - 1) / SECTOR;
        if(need == spf) break;
        spf = need;
    }
    S.spc = spc;
    S.spf = spf;
    S.clusters = (S.part_sectors - reserved - 2 * spf) / spc;
    if(S.clusters < 65525) return fail(MYOS_E_INST_DISK, "partition too small for FAT32");

    /* the boot loader payload must exist before we touch the disk */
    struct directory d;
    if(!open_dir(master_fs, "/SYSTEM/install", &d)) return fail(MYOS_E_INST_PAYLOAD, "boot loader files missing");
    int idx = find_entry(&d, "bootsect.bin");
    int ok = idx >= 0 && d.entries[idx].file_size >= INST_PART_START * SECTOR / 2;
    free_directory(master_fs, &d);
    if(!ok) return fail(MYOS_E_INST_PAYLOAD, "bootsect.bin missing or too short");

    S.cursor = 0;
    S.stage = S.backup ? ST_BACKUP : ST_BOOT;
    set_stage(S.backup ? "Backing up your files" : "Preparing the disk");
    return MYOS_OK;
}

/* ------------------------------------------------------------------ */
/* stage: boot loader (MBR + GRUB core.img in the gap before part. 1)  */
/* ------------------------------------------------------------------ */
static int stage_boot(void) {
    io_defer_begin();
    struct directory d;
    if(!open_dir(master_fs, "/SYSTEM/install", &d)) return fail(MYOS_E_INST_PAYLOAD, "boot loader files missing");
    int idx = find_entry(&d, "bootsect.bin");
    if(idx < 0) { free_directory(master_fs, &d); return fail(MYOS_E_INST_PAYLOAD, "bootsect.bin missing"); }
    uint32_t size = d.entries[idx].file_size;
    uint8_t *data = readFile(master_fs, &d.entries[idx]);
    free_directory(master_fs, &d);
    if(!data) return fail(MYOS_E_NOMEM, "out of memory");

    uint32_t gap = INST_PART_START * SECTOR;
    uint8_t *buf = (uint8_t *)kmalloc(gap);
    if(!buf) { kfree(data); return fail(MYOS_E_NOMEM, "out of memory"); }
    memset(buf, 0, gap);
    memcpy(buf, data, size < gap ? size : gap);
    kfree(data);

    /* The payload's MBR carries GRUB's boot code and a partition table for
     * a scratch disk; rewrite partition entry 1 for THIS disk. */
    uint8_t *e = buf + 446;
    memset(e, 0, 64);
    e[0] = 0x80;                       /* bootable */
    e[1] = 0xFE; e[2] = 0xFF; e[3] = 0xFF;   /* CHS "use LBA" */
    e[4] = 0x0C;                       /* FAT32 (LBA) */
    e[5] = 0xFE; e[6] = 0xFF; e[7] = 0xFF;
    put_le32(e + 8, INST_PART_START);
    put_le32(e + 12, S.part_sectors);
    uint32_t sig = pit_get_ms() * 2654435761u ^ S.disk_sectors;
    put_le32(buf + 440, sig);          /* disk signature */
    buf[510] = 0x55; buf[511] = 0xAA;

    int rc = ata_dev_write(S.dev, 0, INST_PART_START, buf);
    kfree(buf);
    if(rc != 0) return fail(MYOS_E_INST_IO, "cannot write the boot sector");

    S.stage = ST_FMT_META;
    set_stage("Creating the partition");
    return MYOS_OK;
}

/* ------------------------------------------------------------------ */
/* stage: FAT32 format                                                 */
/* ------------------------------------------------------------------ */
static int stage_fmt_meta(void) {
    const uint32_t base = INST_PART_START;
    const uint32_t reserved = 32;
    uint8_t s[SECTOR];

    /* boot sector (+ backup at sector 6) */
    memset(s, 0, sizeof(s));
    s[0] = 0xEB; s[1] = 0x58; s[2] = 0x90;
    memcpy(s + 3, "MYOS    ", 8);
    put_le16(s + 11, SECTOR);
    s[13] = (uint8_t)S.spc;
    put_le16(s + 14, (uint16_t)reserved);
    s[16] = 2;                         /* FAT count */
    put_le16(s + 17, 0);               /* root entries (FAT32: 0) */
    put_le16(s + 19, 0);
    s[21] = 0xF8;
    put_le16(s + 22, 0);
    put_le16(s + 24, 63);
    put_le16(s + 26, 255);
    put_le32(s + 28, base);            /* hidden sectors = partition start */
    put_le32(s + 32, S.part_sectors);
    put_le32(s + 36, S.spf);
    put_le16(s + 40, 0);
    put_le16(s + 42, 0);
    put_le32(s + 44, 2);               /* root directory cluster */
    put_le16(s + 48, 1);               /* FSInfo sector */
    put_le16(s + 50, 6);               /* backup boot sector */
    s[64] = 0x80;
    s[66] = 0x29;
    put_le32(s + 67, pit_get_ms() ^ 0x4D594F53u);
    memcpy(s + 71, "MYOS       ", 11);
    memcpy(s + 82, "FAT32   ", 8);
    s[510] = 0x55; s[511] = 0xAA;
    if(ata_dev_write(S.dev, base + 0, 1, s) != 0) return fail(MYOS_E_INST_IO, "write error");
    if(ata_dev_write(S.dev, base + 6, 1, s) != 0) return fail(MYOS_E_INST_IO, "write error");

    /* FSInfo (+ backup at sector 7) */
    memset(s, 0, sizeof(s));
    put_le32(s + 0, 0x41615252);
    put_le32(s + 484, 0x61417272);
    put_le32(s + 488, 0xFFFFFFFF);     /* free cluster count: "unknown" (the driver doesn't maintain it) */
    put_le32(s + 492, 0xFFFFFFFF);     /* next free cluster: unknown */
    put_le32(s + 508, 0xAA550000);
    if(ata_dev_write(S.dev, base + 1, 1, s) != 0) return fail(MYOS_E_INST_IO, "write error");
    if(ata_dev_write(S.dev, base + 7, 1, s) != 0) return fail(MYOS_E_INST_IO, "write error");

    /* sectors 2..5 and 8..31 of the reserved area: zero */
    memset(s, 0, sizeof(s));
    for(uint32_t r = 2; r < reserved; r++) {
        if(r == 6 || r == 7) continue;
        if(ata_dev_write(S.dev, base + r, 1, s) != 0) return fail(MYOS_E_INST_IO, "write error");
    }

    /* root directory cluster (cluster 2) */
    uint32_t data_start = reserved + 2 * S.spf;
    for(uint32_t i = 0; i < S.spc; i++) {
        if(ata_dev_write(S.dev, base + data_start + i, 1, s) != 0) return fail(MYOS_E_INST_IO, "write error");
    }

    S.cursor = 0;
    S.stage = ST_FMT_FAT;
    set_stage("Formatting");
    return MYOS_OK;
}

/* Writes both FAT copies, a chunk per call. */
static int stage_fmt_fat(void) {
    const uint32_t base = INST_PART_START + 32;
    const uint32_t total = S.spf;     /* FAT #1 only; #2 is mirrored from it at the end */
    const uint32_t chunk = 256;
    uint8_t *buf = (uint8_t *)kmalloc(chunk * SECTOR);
    if(!buf) return fail(MYOS_E_NOMEM, "out of memory");

    uint32_t n = total - S.cursor;
    if(n > chunk) n = chunk;
    for(uint32_t i = 0; i < n; i++) {
        uint32_t sec_in_fat = (S.cursor + i) % S.spf;     /* position inside its FAT copy */
        uint8_t *p = buf + i * SECTOR;
        memset(p, 0, SECTOR);
        /* entries that exist only because the FAT is rounded up to whole
         * sectors are marked "bad cluster" so they can never be allocated */
        for(uint32_t e = 0; e < SECTOR / 4; e++) {
            uint32_t cl = sec_in_fat * (SECTOR / 4) + e;
            uint32_t v = 0;
            if(cl == 0) v = 0x0FFFFFF8;
            else if(cl == 1) v = 0x0FFFFFFF;
            else if(cl == 2) v = 0x0FFFFFFF;           /* root directory: one cluster */
            else if(cl >= S.clusters + 2) v = 0x0FFFFFF7;
            if(v) put_le32(p + e * 4, v);
        }
    }
    int rc = ata_dev_write(S.dev, base + S.cursor, n, buf);
    kfree(buf);
    if(rc != 0) return fail(MYOS_E_INST_IO, "write error while formatting");

    S.cursor += n;
    if(S.cursor >= total) {
        S.stage = ST_SCAN;
        set_stage("Reading the system files");
    }
    return MYOS_OK;
}

/* ------------------------------------------------------------------ */
/* stage: scan + copy                                                  */
/* ------------------------------------------------------------------ */
static int stage_scan(void) {
    if(!S.update) {
        S.tfs = makeFilesystemOn(S.dev, S.part_lba);
        if(!S.tfs) return fail(MYOS_E_INST_IO, "new filesystem does not mount");
        S.tfs->defer_flush = 1;
    }

    if(!scan_source()) return fail(MYOS_E_NOMEM, "out of memory while listing files");
    S.cursor = 0;
    S.items_done = 0;
    S.bytes_done = 0;
    S.total_files = S.item_count;
    S.stage = ST_COPY;
    set_stage(S.update ? "Updating system files" : "Copying system files");
    return MYOS_OK;
}

static int copy_one(item_t *it) {
    char parent[PATH_MAX_LEN], name[64];
    split_path(it->path, parent, sizeof(parent), name, sizeof(name));
    if(!name[0]) return 1;

    if(it->is_dir) {
        struct directory d;
        if(!open_dir(S.tfs, parent, &d)) return 0;
        if(find_entry(&d, name) < 0) mkdir(S.tfs, &d, name);
        free_directory(S.tfs, &d);
        return 1;
    }

    /* Update: a driver descriptor that already exists carries the user's own
     * settings (sensitivity, volume...) -- leave it alone. */
    if(S.update && strncmp(it->path, "/Drivers/", 9) == 0) {
        struct directory ed;
        if(open_dir(S.tfs, parent, &ed)) {
            int have = find_entry(&ed, name) >= 0;
            free_directory(S.tfs, &ed);
            if(have) return 1;
        }
    }

    /* read from the running system */
    struct directory sd;
    if(!open_dir(srcfs(), parent, &sd)) return 0;
    int idx = find_entry(&sd, name);
    if(idx < 0 || (sd.entries[idx].dir_attrs & DIRECTORY)) { free_directory(srcfs(), &sd); return 0; }
    uint32_t size = sd.entries[idx].file_size;
    uint8_t *data = size ? readFile(srcfs(), &sd.entries[idx]) : (uint8_t *)kmalloc(1);
    char exact[64];
    copy_str(exact, sizeof(exact), sd.entries[idx].name);
    free_directory(srcfs(), &sd);
    if(!data) return 0;

    /* write to the new disk */
    struct directory td;
    if(!open_dir(S.tfs, parent, &td)) { kfree(data); return 0; }
    writeFile(S.tfs, &td, data, exact, size);
    free_directory(S.tfs, &td);
    kfree(data);
    return 1;
}

static int stage_copy(void) {
    uint32_t start_ms = pit_get_ms();
    uint64_t budget = 1024 * 1024;           /* bytes per call */
    uint64_t done_now = 0;

    while(S.cursor < S.item_count) {
        item_t *it = &S.items[S.cursor];
        copy_str(S.detail, sizeof(S.detail), it->path);
        if(!copy_one(it)) {
            return fail(MYOS_E_INST_IO, it->path);
        }
        S.cursor++;
        S.items_done++;
        if(!it->is_dir) { S.bytes_done += it->size; done_now += it->size; }
        if(done_now >= budget || (uint32_t)(pit_get_ms() - start_ms) > 300) break;
    }

    if(S.cursor >= S.item_count) {
        if(S.backup && S.bk_n) { S.stage = ST_RESTORE; set_stage("Restoring your files"); }
        else { S.stage = ST_FINISH; set_stage("Finishing"); }
    }
    return MYOS_OK;
}

/* ------------------------------------------------------------------ */
/* stage: finish -- flush the FAT, mirror it into the 2nd copy         */
/* ------------------------------------------------------------------ */
static int stage_finish(void) {
    const uint32_t fat1 = S.part_lba + (S.update ? S.tfs->fat_begin_sector : 32u);
    const uint32_t fat2 = fat1 + S.spf;

    if(S.finish_off == 0) {
        fat32_flush(S.tfs);                    /* only the modified FAT sectors */
        set_stage("Finishing");
    }

    /* Mirror FAT #1 into FAT #2, 512 sectors (256 KiB) per call so the
     * installer window stays responsive even for a 16 MiB FAT. */
    if(S.finish_off < S.spf && (!S.update || S.tfs->bpb.FAT_count >= 2)) {
        uint32_t n = S.spf - S.finish_off; if(n > 512) n = 512;
        uint8_t *buf = (uint8_t *)kmalloc(n * SECTOR);
        if(!buf) return fail(MYOS_E_NOMEM, "out of memory");
        if(ata_dev_read_stream(S.dev, fat1 + S.finish_off, n, buf) != 0 ||
           ata_dev_write(S.dev, fat2 + S.finish_off, n, buf) != 0) {
            kfree(buf);
            return fail(MYOS_E_INST_IO, "cannot mirror the FAT");
        }
        kfree(buf);
        S.finish_off += n;
        if(S.finish_off < S.spf) return MYOS_OK;
    }

    io_defer_end();                            /* the one real FLUSH CACHE */
    if(S.self_update) { S.tfs->defer_flush = 0; S.tfs = 0; }     /* the running system stays mounted */
    else { destroyFilesystem(S.tfs); S.tfs = 0; }                /* frees it; the FAT was just written */
    src_release();
    free_items();
    S.stage = ST_DONE;
    set_stage(S.update ? "Update complete" : "Installation complete");
    S.detail[0] = '\0';
    return MYOS_OK;
}

/* ------------------------------------------------------------------ */
/* stage: update check -- find the installed system, mount it           */
/* ------------------------------------------------------------------ */
static int stage_ucheck(void) {
    if(!master_fs) return fail(MYOS_E_FAIL, "system disk not mounted");
    if(master_fs->dev >= 0) {
        /* Running from the installed disk: update this very system from a disc in the CD/DVD drive. */
        S.src = find_update_source();
        if(!S.src) return fail(MYOS_E_INST_DISK, "no update disc: put the new MyOS ISO in the CD/DVD drive");
        S.self_update = 1;
        S.dev = master_fs->dev; S.part_lba = master_fs->part_lba; S.tfs = master_fs;
        master_fs->defer_flush = 1;
        S.spf = master_fs->bpb.count_sectors_per_FAT32;
        io_defer_begin();
        S.stage = ST_SCAN;
        set_stage("Reading the update disc");
        return MYOS_OK;
    }

    ata_probe_all();
    for(int d = 0; d < ATA_MAX_DEVICES; d++) {
        const ata_info_t *ai = ata_device_info(d);
        if(!ai || !ai->present) continue;
        uint32_t part = 0;
        if(!fat32_probe_volume(d, &part)) continue;
        f32 *fs = makeFilesystemOn(d, part);
        if(!fs) continue;
        struct directory dd;
        int ok = open_dir(fs, "/SYSTEM", &dd);
        if(ok) free_directory(fs, &dd);
        if(ok && open_dir(fs, "/boot", &dd)) {            /* looks like an installed MyOS */
            free_directory(fs, &dd);
            S.dev = d; S.part_lba = part; S.tfs = fs;
            fs->defer_flush = 1;
            S.spf = fs->bpb.count_sectors_per_FAT32;
            io_defer_begin();
            S.stage = ST_SCAN;
            set_stage("Reading the update");
            return MYOS_OK;
        }
        destroyFilesystem(fs);
    }
    return fail(MYOS_E_INST_DISK, "no installed MyOS found on any hard disk");
}

/* ------------------------------------------------------------------ */
/* public API                                                          */
/* ------------------------------------------------------------------ */
int installer_begin(int index, uint32_t flags) {
    if(S.stage != ST_IDLE && S.stage != ST_DONE && S.stage != ST_FAILED) return MYOS_E_INST_BUSY;
    int d = nth_disk(index);
    installer_cancel();                /* drop leftovers of an earlier failed run */
    memset(&S, 0, sizeof(S));
    if(d < 0) return MYOS_E_ARG;
    if(flags & INST_FLAG_X64) return MYOS_E_ARG;      /* no 64-bit build exists yet */
    S.backup = (flags & INST_FLAG_BACKUP) ? 1 : 0;
    S.dev = d;
    S.part_lba = INST_PART_START;
    S.stage = ST_CHECK;
    set_stage("Checking the disk");
    return MYOS_OK;
}

/* Update an installed system from the running (live) one: the files of /SYSTEM,
 * /APPS, /Drivers and /boot are overwritten, nothing is partitioned or
 * formatted, /Users is left alone. */
int installer_begin_update(void) {
    if(S.stage != ST_IDLE && S.stage != ST_DONE && S.stage != ST_FAILED) return MYOS_E_INST_BUSY;
    installer_cancel();
    memset(&S, 0, sizeof(S));
    S.update = 1;
    S.dev = -1;
    S.stage = ST_UCHECK;
    set_stage("Looking for the installed system");
    return MYOS_OK;
}

void installer_cancel(void) {
    io_defer_end();
    bk_free();
    if(S.tfs) { S.tfs->defer_flush = 0; if(!S.self_update) destroyFilesystem(S.tfs); S.tfs = 0; }
    src_release();
    free_items();
    S.stage = ST_IDLE;
}

int installer_step(myos_install_status_t *st) {
    int rc = MYOS_OK;
    switch(S.stage) {
        case ST_UCHECK:   rc = stage_ucheck();   break;
        case ST_CHECK:    rc = stage_check();    break;
        case ST_BACKUP:   rc = stage_backup();   break;
        case ST_RESTORE:  rc = stage_restore();  break;
        case ST_BOOT:     rc = stage_boot();     break;
        case ST_FMT_META: rc = stage_fmt_meta(); break;
        case ST_FMT_FAT:  rc = stage_fmt_fat();  break;
        case ST_SCAN:     rc = stage_scan();     break;
        case ST_COPY:     rc = stage_copy();     break;
        case ST_FINISH:   rc = stage_finish();   break;
        default: break;
    }

    memset(st, 0, sizeof(*st));
    copy_str(st->stage, sizeof(st->stage), S.stage_text);
    copy_str(st->detail, sizeof(st->detail), S.detail);
    st->files_done = S.items_done;
    st->files_total = S.total_files;

    uint32_t pct = 0;
    switch(S.stage) {
        case ST_UCHECK: case ST_CHECK: case ST_BOOT: pct = 2; break;
        case ST_BACKUP: pct = 3; break;
        case ST_RESTORE: pct = 94; break;
        case ST_FMT_META: pct = 6; break;
        case ST_FMT_FAT: pct = S.spf ? 6 + (S.cursor * 9) / S.spf : 6; break;
        case ST_SCAN: pct = 15; break;
        case ST_COPY:
            pct = 15 + (S.bytes_total ? (uint32_t)((S.bytes_done * 80) / S.bytes_total)
                                      : (S.item_count ? (S.cursor * 80) / S.item_count : 0));
            break;
        case ST_FINISH: pct = 97; break;
        case ST_DONE: pct = 100; break;
        default: break;
    }
    if(pct > 100) pct = 100;
    st->percent = pct;

    if(S.stage == ST_DONE) st->state = MYOS_INST_DONE;
    else if(S.stage == ST_FAILED) { st->state = MYOS_INST_FAILED; st->error = S.error; }
    else st->state = MYOS_INST_RUNNING;
    return rc < 0 && S.stage != ST_FAILED ? rc : MYOS_OK;
}
