/*
 * Minimal INI-style parser for desktop.ini. Deliberately narrow in
 * scope: [section] headers, key=value lines, and whole-line comments
 * starting with ; or # (no trailing comments, no quoting, no escaping, no multi-line values). This keeps it small
 * and predictable for the one format it actually needs to read.
 */

#include "stdint.h"
#include "stddef.h"
#include "ini.h"
#include "common.h"
#include "kernio.h"

static void copy_trimmed(char *dest, uint32_t dest_size, const char *src, uint32_t src_len) {
    /* Trim leading/trailing spaces so "name = Command Prompt" and
     * "name=Command Prompt" both parse the same way. */
    while(src_len > 0 && (*src == ' ' || *src == '\t')) { src++; src_len--; }
    while(src_len > 0 && (src[src_len - 1] == ' ' || src[src_len - 1] == '\t' ||
                           src[src_len - 1] == '\r')) {
        src_len--;
    }

    uint32_t n = src_len < dest_size - 1 ? src_len : dest_size - 1;
    for(uint32_t i = 0; i < n; i++) dest[i] = src[i];
    dest[n] = '\0';
}

int ini_parse(const char *text, uint32_t length, ini_document_t *out) {
    memset(out, 0, sizeof(ini_document_t));

    ini_section_t *current = NULL;
    uint32_t line_start = 0;

    for(uint32_t pos = 0; pos <= length; pos++) {
        int at_end = (pos == length);
        int at_newline = !at_end && (text[pos] == '\n');

        if(!at_end && !at_newline) continue;

        uint32_t line_len = pos - line_start;
        const char *line = text + line_start;

        /* Skip blank lines (including a trailing lone \r). */
        uint32_t trimmed_len = line_len;
        while(trimmed_len > 0 && (line[trimmed_len - 1] == '\r')) trimmed_len--;

        if(trimmed_len == 0) {
            line_start = pos + 1;
            continue;
        }

        /* Comment lines (";" or "#" first) are skipped, so config files
         * such as /Drivers/<category>/<id>.drv can document themselves. */
        if(line[0] == ';' || line[0] == '#') {
            line_start = pos + 1;
            continue;
        }

        if(line[0] == '[') {
            /* Section header: [name] -- find the closing bracket. */
            uint32_t close = 0;
            for(uint32_t i = 1; i < trimmed_len; i++) {
                if(line[i] == ']') { close = i; break; }
            }

            if(close > 0 && out->section_count < INI_MAX_SECTIONS) {
                current = &out->sections[out->section_count++];
                memset(current, 0, sizeof(ini_section_t));
                copy_trimmed(current->name, sizeof(current->name), line + 1, close - 1);
            }
            else {
                current = NULL; /* malformed header or out of section slots */
            }
        }
        else if(current && current->kv_count < INI_MAX_KEYS_PER_SECTION) {
            /* key=value line within the current section. */
            uint32_t eq = 0;
            uint8_t found_eq = 0;
            for(uint32_t i = 0; i < trimmed_len; i++) {
                if(line[i] == '=') { eq = i; found_eq = 1; break; }
            }

            if(found_eq) {
                ini_kv_t *kv = &current->kv[current->kv_count++];
                copy_trimmed(kv->key, sizeof(kv->key), line, eq);
                copy_trimmed(kv->value, sizeof(kv->value), line + eq + 1, trimmed_len - eq - 1);
            }
            /* Lines without '=' inside a section are silently ignored
             * rather than treated as an error -- forwards-compatible
             * with any future desktop.ini fields we don't understand
             * yet, and tolerant of stray blank-ish lines. */
        }

        line_start = pos + 1;
    }

    return 1;
}

const char *ini_get(const ini_document_t *doc, const char *section, const char *key) {
    for(int i = 0; i < doc->section_count; i++) {
        if(strcmp(doc->sections[i].name, section) == 0) {
            const ini_section_t *s = &doc->sections[i];
            for(int j = 0; j < s->kv_count; j++) {
                if(strcmp(s->kv[j].key, key) == 0) {
                    return s->kv[j].value;
                }
            }
            return NULL;
        }
    }
    return NULL;
}

int ini_get_int(const ini_document_t *doc, const char *section, const char *key, int *out) {
    const char *value = ini_get(doc, section, key);
    if(!value) return 0;

    uint32_t parsed;
    if(!coerce_int((char *)value, &parsed)) return 0;

    *out = (int)parsed;
    return 1;
}
