#include "cursor_ani.h"
#include "kheap.h"
#include "common.h"

/* Little-endian readers that never run past the buffer. */
static int rd32(const uint8_t *d, uint32_t len, uint32_t off, uint32_t *out) {
    if(off > len || len - off < 4) return 0;
    *out = (uint32_t)d[off] | ((uint32_t)d[off + 1] << 8) | ((uint32_t)d[off + 2] << 16) | ((uint32_t)d[off + 3] << 24);
    return 1;
}

#define FOURCC(a,b,c,d) ((uint32_t)(a) | ((uint32_t)(b) << 8) | ((uint32_t)(c) << 16) | ((uint32_t)(d) << 24))

void cursor_ani_free(cursor_anim_t *a) {
    if(!a) return;
    if(a->frames) {
        for(int i = 0; i < a->frame_count; i++) cursor_free(&a->frames[i]);
        kfree(a->frames);
    }
    if(a->step_frame) kfree(a->step_frame);
    if(a->step_ms) kfree(a->step_ms);
    memset(a, 0, sizeof(*a));
}

static uint16_t jiffies_to_ms(uint32_t j) {
    if(j == 0) j = 1;
    uint32_t ms = j * 50 / 3;          /* 1 jiffy = 1/60 s = 16.67 ms */
    if(ms < 16) ms = 16;
    if(ms > 60000) ms = 60000;
    return (uint16_t)ms;
}

int cursor_ani_load_from_memory(const uint8_t *d, uint32_t len, cursor_anim_t *out) {
    memset(out, 0, sizeof(*out));
    uint32_t v;
    if(len < 12) return 0;
    if(!rd32(d, len, 0, &v) || v != FOURCC('R','I','F','F')) return 0;
    if(!rd32(d, len, 8, &v) || v != FOURCC('A','C','O','N')) return 0;

    uint32_t riff_size;
    rd32(d, len, 4, &riff_size);
    uint32_t end = riff_size + 8 < len ? riff_size + 8 : len;

    uint32_t n_frames = 0, n_steps = 0, default_rate = 6, flags = 0;
    int have_anih = 0;
    uint32_t rate_off = 0, rate_len = 0, seq_off = 0, seq_len = 0;
    uint32_t frame_off[CURSOR_ANI_MAX_FRAMES], frame_len[CURSOR_ANI_MAX_FRAMES];
    int frames_found = 0;

    uint32_t pos = 12;
    while(pos + 8 <= end) {
        uint32_t id, sz;
        rd32(d, len, pos, &id); rd32(d, len, pos + 4, &sz);
        uint32_t body = pos + 8;
        if(sz > end - body) sz = end - body;     /* tolerate a truncated last chunk */

        if(id == FOURCC('a','n','i','h')) {
            uint32_t cb, nf, ns, w, h, bc, pl, rate, fl;
            if(sz >= 36 &&
               rd32(d, len, body, &cb) && rd32(d, len, body + 4, &nf) && rd32(d, len, body + 8, &ns) &&
               rd32(d, len, body + 12, &w) && rd32(d, len, body + 16, &h) && rd32(d, len, body + 20, &bc) &&
               rd32(d, len, body + 24, &pl) && rd32(d, len, body + 28, &rate) && rd32(d, len, body + 32, &fl)) {
                n_frames = nf; n_steps = ns; default_rate = rate; flags = fl; have_anih = 1;
            }
        }
        else if(id == FOURCC('r','a','t','e')) { rate_off = body; rate_len = sz; }
        else if(id == FOURCC('s','e','q',' ')) { seq_off = body; seq_len = sz; }
        else if(id == FOURCC('L','I','S','T')) {
            uint32_t form;
            if(sz >= 4 && rd32(d, len, body, &form) && form == FOURCC('f','r','a','m')) {
                uint32_t p2 = body + 4, e2 = body + sz;
                while(p2 + 8 <= e2 && frames_found < CURSOR_ANI_MAX_FRAMES) {
                    uint32_t id2, sz2;
                    rd32(d, len, p2, &id2); rd32(d, len, p2 + 4, &sz2);
                    uint32_t b2 = p2 + 8;
                    if(sz2 > e2 - b2) sz2 = e2 - b2;
                    if(id2 == FOURCC('i','c','o','n')) {
                        frame_off[frames_found] = b2; frame_len[frames_found] = sz2; frames_found++;
                    }
                    p2 = b2 + sz2 + (sz2 & 1);
                }
            }
        }
        pos = body + sz + (sz & 1);                /* chunks are word-aligned */
    }

    if(!have_anih || !(flags & 1) || frames_found == 0) return 0;   /* raw-bitmap frames unsupported */
    if(n_frames == 0 || n_frames > (uint32_t)frames_found) n_frames = (uint32_t)frames_found;
    if(n_steps == 0) n_steps = n_frames;
    if(n_steps > CURSOR_ANI_MAX_STEPS) return 0;

    out->frames = (cursor_image_t *)kmalloc(sizeof(cursor_image_t) * n_frames);
    out->step_frame = (uint8_t *)kmalloc(n_steps);
    out->step_ms = (uint16_t *)kmalloc(sizeof(uint16_t) * n_steps);
    if(!out->frames || !out->step_frame || !out->step_ms) {
        if(out->frames) kfree(out->frames);
        if(out->step_frame) kfree(out->step_frame);
        if(out->step_ms) kfree(out->step_ms);
        memset(out, 0, sizeof(*out));
        return 0;
    }
    memset(out->frames, 0, sizeof(cursor_image_t) * n_frames);

    for(uint32_t i = 0; i < n_frames; i++) {
        if(!cursor_load_from_memory(d + frame_off[i], frame_len[i], &out->frames[i])) {
            out->frame_count = (int)i;       /* free only what was decoded */
            cursor_ani_free(out);
            return 0;
        }
    }
    out->frame_count = (int)n_frames;
    out->step_count = (int)n_steps;

    uint32_t total = 0;
    for(uint32_t s = 0; s < n_steps; s++) {
        uint32_t fr = s, j = default_rate;
        if(seq_off && (s + 1) * 4 <= seq_len) rd32(d, len, seq_off + s * 4, &fr);
        if(rate_off && (s + 1) * 4 <= rate_len) rd32(d, len, rate_off + s * 4, &j);
        if(fr >= n_frames) fr = 0;                    /* out-of-range index: fall back, never read OOB */
        out->step_frame[s] = (uint8_t)fr;
        out->step_ms[s] = jiffies_to_ms(j);
        total += out->step_ms[s];
    }
    out->total_ms = total ? total : 1;
    return 1;
}

int cursor_ani_step_at(const cursor_anim_t *a, uint32_t ms) {
    if(!a || a->step_count == 0) return 0;
    uint32_t t = ms % a->total_ms;
    for(int s = 0; s < a->step_count; s++) {
        if(t < a->step_ms[s]) return s;
        t -= a->step_ms[s];
    }
    return a->step_count - 1;
}

const cursor_image_t *cursor_ani_image_at(const cursor_anim_t *a, uint32_t ms) {
    if(!a || a->frame_count == 0) return NULL;
    return &a->frames[a->step_frame[cursor_ani_step_at(a, ms)]];
}
