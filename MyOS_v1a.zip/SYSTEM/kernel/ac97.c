#include "ac97.h"
#include "pci.h"
#include "port.h"
#include "kernio.h"
#include "kheap.h"
#include "common.h"
#include "pit.h"

/* --- NAM (mixer) registers, offsets from BAR0 --- */
#define NAM_RESET           0x00
#define NAM_MASTER_VOLUME   0x02
#define NAM_PCM_OUT_VOLUME  0x18
#define NAM_EXT_AUDIO       0x28
#define NAM_EXT_AUDIO_CTRL  0x2A
#define NAM_PCM_FRONT_RATE  0x2C

/* --- NABM (bus master) registers, offsets from BAR1 --- */
/* PCM OUT channel register block starts at 0x10 within NABM. */
#define NABM_PO_BDBAR  0x10 /* Buffer Descriptor Base Address Register (physical address of the BDL) */
#define NABM_PO_CIV    0x14 /* Current Index Value (which BDL entry the hardware is on) */
#define NABM_PO_LVI    0x15 /* Last Valid Index (software tells hardware how far the BDL is populated) */
#define NABM_PO_SR     0x16 /* Status Register */
#define NABM_PO_PICB   0x18 /* Position In Current Buffer (samples remaining in the entry CIV points to) */
#define NABM_PO_CR     0x1B /* Control Register */
#define NABM_GLOB_CNT  0x2C /* Global Control */
#define NABM_GLOB_STA  0x30 /* Global Status */

#define PO_CR_RPBM   0x01 /* Run/Pause Bus Master -- 1 starts DMA */
#define PO_CR_RESET  0x02
#define PO_CR_IOCE   0x04 /* Interrupt On Completion Enable */

#define PO_SR_DCH    0x01 /* DMA Controller Halted */
#define PO_SR_BCIS   0x08 /* Buffer Completion Interrupt Status -- an entry finished */

/* Buffer Descriptor List: 32 entries max per the AC97 spec, each
 * describing one physically-contiguous buffer for the hardware to play.
 * BDL_ENTRY_COUNT smaller than the max (8) keeps the ring short enough
 * that audio_queue() callers see their data actually start playing
 * soon, while still giving the hardware several buffers of lead time so
 * a brief delay in refilling doesn't cause an audible gap. */
#define BDL_ENTRY_COUNT 16
#define BDL_BUFFER_SAMPLES 4096 /* samples (not bytes) per buffer -- ~93ms at 44100Hz stereo */

typedef struct {
    uint32_t buffer_phys_addr;
    uint16_t sample_count; /* -1 from the real count, per AC97 spec (see the BDL fill code) -- kept raw here, adjusted at write time */
    uint16_t flags;
} __attribute__((packed)) bdl_entry_t;

#define BDL_FLAG_IOC 0x8000 /* Interrupt On Completion for this entry */
#define BDL_FLAG_BUP 0x4000 /* Buffer Underrun Policy -- play last sample instead of garbage if we fall behind */

static uint16_t nam_base = 0;
static uint16_t nabm_base = 0;
static uint8_t ac97_present = 0;

/* BDL and its backing sample buffers -- identity-mapped kernel heap
 * memory (see audio.h's top comment: this kernel's heap is always
 * identity-mapped, so a kmalloc'd pointer's value IS its physical
 * address, no special DMA-safe allocator needed). Static rather than
 * heap-allocated at probe time purely so the BDL itself (which must be
 * contiguous) doesn't compete with anything else for a single
 * kmalloc -- these arrays are already contiguous by construction. */
static bdl_entry_t bdl[BDL_ENTRY_COUNT] __attribute__((aligned(8)));
static int16_t sample_buffers[BDL_ENTRY_COUNT][BDL_BUFFER_SAMPLES] __attribute__((aligned(4)));

static int next_fill_index = 0;
static uint8_t slot_filled[BDL_ENTRY_COUNT];
static int last_civ = 0;
static uint8_t po_running = 0;
static uint8_t po_paused = 0;
 /* next BDL slot audio_queue() will write into */

static void ac97_irq_poll(void);

static int ac97_probe_and_init(void) {
    pci_device_t dev;
    if(!pci_find_device_by_class(PCI_CLASS_MULTIMEDIA, PCI_SUBCLASS_AUDIO, &dev)) {
        return 0;
    }

    uint32_t bar0 = pci_get_bar(&dev, 0);
    uint32_t bar1 = pci_get_bar(&dev, 1);
    if(!pci_bar_is_io(pci_config_read32(dev.bus, dev.device, dev.function, 0x10))
       || !pci_bar_is_io(pci_config_read32(dev.bus, dev.device, dev.function, 0x14))) {
        /* AC97's NAM/NABM are always I/O-space BARs per spec -- if
         * either came back as memory-space, this isn't a device this
         * driver knows how to talk to (or the BAR read went wrong).
         * Fail safe rather than send port I/O to a memory address. */
        printf("ac97: found PCI audio device but BARs aren't I/O space, skipping\n");
        return 0;
    }
    nam_base = (uint16_t)bar0;
    nabm_base = (uint16_t)bar1;

    /* Enable PCI bus mastering (needed for the device's DMA engine to
     * actually access memory) and I/O space access, via the PCI command
     * register (offset 0x04): bit 0 = I/O space enable, bit 2 = bus
     * master enable. */
    uint32_t command = pci_config_read32(dev.bus, dev.device, dev.function, 0x04);
    command |= (1 << 0) | (1 << 2);
    pci_config_write32(dev.bus, dev.device, dev.function, 0x04, command);

    /* Cold reset the mixer, then give it a moment (AC97 codecs need a
     * short settle time after reset before registers are reliable) --
     * busy-wait loop rather than a real timer since this runs during
     * audio_init(), before this kernel's own timer is necessarily a
     * meaningful wait-source this early (and the actual delay needed is
     * on the order of microseconds, far below this timer's 100ms tick
     * granularity anyway). */
    outw(nam_base + NAM_RESET, 0);
    for(volatile int i = 0; i < 100000; i++) { }

    /* Unmute and set master + PCM-out volume to a reasonable default
     * (mid-volume, not max -- see set_volume() for the actual
     * user-controllable path via Settings). Volume registers are 6-bit
     * attenuation per channel (0 = loudest, 63 = quietest), packed as
     * left<<8 | right, with bit 15 as a mute flag. */
    outw(nam_base + NAM_MASTER_VOLUME, 0x0000);
    outw(nam_base + NAM_PCM_OUT_VOLUME, 0x0000);

    /* Reset the PCM OUT DMA engine, then build and register the BDL. */
    outb(nabm_base + NABM_PO_CR, PO_CR_RESET);
    for(volatile int i = 0; i < 100000; i++) { }

    memset(bdl, 0, sizeof(bdl));
    memset(sample_buffers, 0, sizeof(sample_buffers));
    for(int i = 0; i < BDL_ENTRY_COUNT; i++) {
        bdl[i].buffer_phys_addr = (uint32_t)&sample_buffers[i][0];
        bdl[i].sample_count = BDL_BUFFER_SAMPLES;
        bdl[i].flags = BDL_FLAG_BUP;
    }
    next_fill_index = 0;

    outl(nabm_base + NABM_PO_BDBAR, (uint32_t)&bdl[0]);
    outb(nabm_base + NABM_PO_LVI, BDL_ENTRY_COUNT - 1);

    for(int i = 0; i < BDL_ENTRY_COUNT; i++) slot_filled[i] = 0;
    po_running = 0; po_paused = 0; last_civ = 0;
    ac97_present = 1;
    pit_set_hook_slot(1, ac97_irq_poll);
    printf("ac97: found at PCI %d:%d.%d, NAM=%x NABM=%x\n",
           dev.bus, dev.device, dev.function, nam_base, nabm_base);
    return 1;
}

/* The codec is left at its power-on rate of 48000 Hz for good; any other
 * source rate is resampled to it in software (ac97_write below).
 *
 * Why: every write to the codec's DAC-rate register makes an emulated
 * AC97 (QEMU) close and re-open its host audio stream -- on some hosts
 * (WSL with PulseAudio especially) that takes whole seconds, and it
 * happened at the start of EVERY track, freezing the whole machine while
 * it ran. With a constant hardware rate the stream is opened once. */
#define HW_RATE 48000u
static uint32_t src_rate = HW_RATE;
static uint32_t rs_pos = 0;             /* 16.16 position inside the current input block (may be "negative": see below) */
static int16_t rs_prev_l = 0, rs_prev_r = 0;

static void ac97_set_format(uint32_t sample_rate, uint8_t channels) {
    if(!ac97_present) return;
    (void)channels; /* AC97's PCM OUT is always interleaved stereo at the hardware level; a mono source is duplicated to both channels by the caller before reaching audio_queue() -- see wav.c/mp3.c's decode paths */
    if(sample_rate < 4000) sample_rate = 4000;
    if(sample_rate > 192000) sample_rate = 192000;
    src_rate = sample_rate;
    rs_pos = 0; rs_prev_l = rs_prev_r = 0;
}

/* ---- Playback ring ----
 * The hardware plays the BDL circularly. To keep it from ever halting at
 * the "last valid index" we continuously move LVI to the entry just
 * BEHIND the one being played (the way Linux's snd-intel8x0 does), and
 * we silence every buffer the hardware has finished with -- so if the
 * player ever falls behind, the DAC plays silence instead of looping
 * stale audio. (The previous version compared CIV to its own write
 * index, which is equal at start-up, so the very first write spun
 * forever.) */

/* The ring bookkeeping runs from two places: the normal player path
 * (ac97_poll) and a 50 ms timer-interrupt keep-alive (ac97_irq_poll). The keep-alive
 * matters: if the desktop is busy for a few hundred ms (slow frame, disk read)
 * nothing else would move LVI, the DMA engine would run into the "last valid
 * index" and halt -- the audible stutter on VirtualBox. `in_poll` stops the
 * interrupt from re-entering while the main path is in the middle of it. */
static volatile uint8_t in_poll = 0;

static void ac97_poll_core(void) {
    int civ = inb(nabm_base + NABM_PO_CIV) % BDL_ENTRY_COUNT;
    while(last_civ != civ) {
        /* hardware finished this buffer: free it and silence it (only if it
         * actually held audio -- an already silent one needs no memset) */
        if(slot_filled[last_civ]) {
            slot_filled[last_civ] = 0;
            memset(sample_buffers[last_civ], 0, sizeof(sample_buffers[0]));
        }
        last_civ = (last_civ + 1) % BDL_ENTRY_COUNT;
    }
    outb(nabm_base + NABM_PO_LVI, (uint8_t)((civ + BDL_ENTRY_COUNT - 1) % BDL_ENTRY_COUNT));
    /* clear completion/LVBCI/FIFO status bits so they don't latch */
    outw(nabm_base + NABM_PO_SR, 0x1C);
}

static void ac97_irq_poll(void) {
    if(!po_running || in_poll) return;
    in_poll = 1;
    ac97_poll_core();
    in_poll = 0;
}

static void ac97_poll(void) {
    if(!po_running) return;
    in_poll = 1;
    ac97_poll_core();
    in_poll = 0;

    /* Underrun recovery. If the player fell behind, every slot is empty and the
     * write position is somewhere behind the play head: new audio would have to
     * wait for the hardware to go all the way round the ring first (a lag that
     * grew with every stall). Restart the write position right after the slot
     * that is playing now. */
    int any = 0;
    for(int i = 0; i < BDL_ENTRY_COUNT; i++) if(slot_filled[i]) { any = 1; break; }
    if(!any) next_fill_index = (last_civ + 1) % BDL_ENTRY_COUNT;
}

static int ac97_slot_writable(void) {
    if(slot_filled[next_fill_index]) return 0;
    if(po_running) {
        int civ = inb(nabm_base + NABM_PO_CIV) % BDL_ENTRY_COUNT;
        if(civ == next_fill_index) return 0; /* that one is playing right now */
    }
    return 1;
}

/* How many consecutive slots, starting at the next one to fill, can be
 * written right now. */
static int ac97_free_slots(void) {
    int civ = po_running ? (inb(nabm_base + NABM_PO_CIV) % BDL_ENTRY_COUNT) : -1;
    int n = 0;
    for(int k = 0; k < BDL_ENTRY_COUNT; k++) {
        int idx = (next_fill_index + k) % BDL_ENTRY_COUNT;
        if(slot_filled[idx] || idx == civ) break;
        n++;
    }
    return n;
}

static int ac97_ready_for_more(void) {
    if(!ac97_present) return 0;
    ac97_poll();
    /* A chunk of source audio can expand to several slots once resampled
     * up to 48 kHz, so require room for the worst case: callers write one
     * chunk per "ready" and must never find the ring full half-way. */
    int need = (src_rate == HW_RATE) ? 1 : 3;
    return ac97_free_slots() >= need;
}

/* Starts DMA from entry 0. Interrupts stay OFF (no IOCE): this driver polls
 * the ring, and with the interrupt enabled the controller held its IRQ line
 * asserted after every completed buffer until the next poll cleared it --
 * an unhandled level-triggered IRQ that the CPU re-took in a tight loop. */
static void ac97_engine_start(void) {
    outb(nabm_base + NABM_PO_CR, PO_CR_RESET);
    for(volatile int i = 0; i < 20000; i++) { }
    outl(nabm_base + NABM_PO_BDBAR, (uint32_t)&bdl[0]);
    last_civ = 0;
    outb(nabm_base + NABM_PO_LVI, (uint8_t)(BDL_ENTRY_COUNT - 1));
    outw(nabm_base + NABM_PO_SR, 0x1C);
    po_running = 1;
    if(!po_paused) outb(nabm_base + NABM_PO_CR, PO_CR_RPBM);
}

static void ac97_write_raw(const int16_t *samples, uint32_t sample_count) {
    if(!ac97_present) return;

    uint32_t written = 0;
    while(written < sample_count) {
        ac97_poll();
        if(!ac97_slot_writable()) {
            /* Ring full (callers normally check ready_for_more() first, so
             * this is the rare case): wait briefly for a slot, then give up
             * and drop the rest rather than stall the desktop. Bounded by
             * TIME -- the old 2,000,000-poll loop could run for seconds,
             * every poll being a trapped port access under emulation. */
            uint32_t t0 = pit_get_ms();
            while(!ac97_slot_writable() && (uint32_t)(pit_get_ms() - t0) < 4) ac97_poll();
            if(!ac97_slot_writable()) return;
        }

        uint32_t chunk = sample_count - written;
        if(chunk > BDL_BUFFER_SAMPLES) chunk = BDL_BUFFER_SAMPLES;

        fastcp((char *)sample_buffers[next_fill_index], (char *)(samples + written), chunk * sizeof(int16_t));
        if(chunk < BDL_BUFFER_SAMPLES) {
            memset(&sample_buffers[next_fill_index][chunk], 0, (BDL_BUFFER_SAMPLES - chunk) * sizeof(int16_t));
        }
        slot_filled[next_fill_index] = 1;
        int filled = next_fill_index;
        next_fill_index = (next_fill_index + 1) % BDL_ENTRY_COUNT;
        written += chunk;

        (void)filled;
        if(!po_running) ac97_engine_start();
    }
}

/* Linear-interpolating resampler from src_rate to the codec's fixed 48 kHz.
 * Stereo interleaved in and out; state (position + last frame) carries across
 * calls so block boundaries are seamless. Returns output SAMPLES written
 * (at most out_max). The position runs in 16.16 input frames: frame -1 is the
 * previous block's last frame, so the first output of a new block can
 * interpolate between it and frame 0. */
static uint32_t ac97_resample(const int16_t *in, uint32_t in_samples, int16_t *out, uint32_t out_max) {
    int32_t n = (int32_t)(in_samples / 2);
    if(n <= 0) return 0;
    uint32_t step = (uint32_t)(((uint64_t)src_rate << 16) / HW_RATE);
    int32_t pos = (int32_t)rs_pos;
    uint32_t o = 0;
    while((pos >> 16) <= n - 2 && o + 2 <= out_max) {
        int32_t idx = pos >> 16;
        int32_t frac = pos & 0xFFFF;
        int32_t al, ar, bl, br;
        if(idx < 0) { al = rs_prev_l; ar = rs_prev_r; }
        else { al = in[idx * 2]; ar = in[idx * 2 + 1]; }
        bl = in[(idx + 1) * 2]; br = in[(idx + 1) * 2 + 1];
        out[o++] = (int16_t)(al + (((bl - al) * frac) >> 16));
        out[o++] = (int16_t)(ar + (((br - ar) * frac) >> 16));
        pos += (int32_t)step;
    }
    rs_pos = (uint32_t)(pos - (n << 16));
    rs_prev_l = in[(n - 1) * 2]; rs_prev_r = in[(n - 1) * 2 + 1];
    return o;
}

#define RS_IN_BLOCK 2048u          /* input samples per block: bounds the output size */
#define RS_OUT_MAX  16384u         /* 2048 samples * 6 (8 kHz -> 48 kHz) is 12288 */
static int16_t rs_stage[RS_OUT_MAX];

static void ac97_write(const int16_t *samples, uint32_t sample_count) {
    if(!ac97_present) return;
    if(src_rate == HW_RATE) { ac97_write_raw(samples, sample_count); return; }
    uint32_t done = 0;
    while(done < sample_count) {
        uint32_t n = sample_count - done;
        if(n > RS_IN_BLOCK) n = RS_IN_BLOCK;
        n &= ~1u;
        if(n == 0) break;
        uint32_t produced = ac97_resample(samples + done, n, rs_stage, RS_OUT_MAX);
        ac97_write_raw(rs_stage, produced);
        done += n;
    }
}

static void ac97_flush(void) {
    if(!ac97_present) return;
    outb(nabm_base + NABM_PO_CR, PO_CR_RESET);
    for(volatile int i = 0; i < 20000; i++) { }
    memset(sample_buffers, 0, sizeof(sample_buffers));
    for(int i = 0; i < BDL_ENTRY_COUNT; i++) slot_filled[i] = 0;
    next_fill_index = 0;
    last_civ = 0;
    po_running = 0;
    po_paused = 0;
    rs_pos = 0; rs_prev_l = rs_prev_r = 0;
}

static void ac97_pause(int paused) {
    if(!ac97_present) return;
    po_paused = paused ? 1 : 0;
    if(!po_running) return;
    uint8_t cr = inb(nabm_base + NABM_PO_CR);
    if(paused) outb(nabm_base + NABM_PO_CR, cr & (uint8_t)~PO_CR_RPBM);
    else outb(nabm_base + NABM_PO_CR, cr | PO_CR_RPBM);
}

static void ac97_set_volume(uint8_t volume_percent) {
    if(!ac97_present) return;
    if(volume_percent > 100) volume_percent = 100;

    /* AC97 volume is 6 bits of ATTENUATION (0 = loudest, 63 = silent) --
     * inverted from the usual "bigger number = louder" a volume_percent
     * API implies, so this maps 100% -> attenuation 0, 0% -> attenuation
     * 63, linearly in between. Same attenuation value written to both
     * the left (bits 8-14) and right (bits 0-6) channel fields for a
     * centered mix -- this kernel doesn't currently expose a balance
     * control, only master volume. */
    uint8_t attenuation = (uint8_t)(63 - (volume_percent * 63 / 100));
    uint16_t reg_value = ((uint16_t)attenuation << 8) | attenuation;
    outw(nam_base + NAM_MASTER_VOLUME, reg_value);
    outw(nam_base + NAM_PCM_OUT_VOLUME, reg_value);
}

const audio_driver_t ac97_driver = {
    .name = "AC97",
    .probe_and_init = ac97_probe_and_init,
    .set_format = ac97_set_format,
    .write = ac97_write,
    .ready_for_more = ac97_ready_for_more,
    .set_volume = ac97_set_volume,
    .flush = ac97_flush,
    .pause = ac97_pause,
};
