#include "rtc.h"
#include "port.h"

#define CMOS_ADDRESS 0x70
#define CMOS_DATA    0x71

#define CMOS_REG_SECONDS      0x00
#define CMOS_REG_MINUTES      0x02
#define CMOS_REG_HOURS        0x04
#define CMOS_REG_STATUS_A     0x0A
#define CMOS_REG_STATUS_B     0x0B

#define STATUS_A_UPDATE_IN_PROGRESS 0x80
#define STATUS_B_24_HOUR   0x02
#define STATUS_B_BINARY    0x04

static uint8_t cmos_read(uint8_t reg) {
    outb(CMOS_ADDRESS, reg);
    return inb(CMOS_DATA);
}

static int rtc_update_in_progress(void) {
    return (cmos_read(CMOS_REG_STATUS_A) & STATUS_A_UPDATE_IN_PROGRESS) != 0;
}

static uint8_t bcd_to_bin(uint8_t val) {
    return (uint8_t)(((val & 0xF0) >> 1) + ((val & 0xF0) >> 3) + (val & 0x0F));
}

static void rtc_read_raw(uint8_t *sec, uint8_t *min, uint8_t *hour, uint8_t *reg_b) {
    /* Wait for any in-progress update to finish before reading, so we
     * don't catch the RTC mid-tick. */
    while(rtc_update_in_progress());

    *sec = cmos_read(CMOS_REG_SECONDS);
    *min = cmos_read(CMOS_REG_MINUTES);
    *hour = cmos_read(CMOS_REG_HOURS);
    *reg_b = cmos_read(CMOS_REG_STATUS_B);
}

void rtc_read_time(rtc_time_t *out) {
    uint8_t sec, min, hour, reg_b;
    uint8_t last_sec, last_min, last_hour;

    /* A read can still land exactly as the RTC ticks over even after
     * waiting out UIP (the UIP window and the actual register update
     * don't perfectly coincide on every chipset), so read twice and
     * retry if the two reads disagree -- standard CMOS RTC practice. */
    rtc_read_raw(&sec, &min, &hour, &reg_b);
    do {
        last_sec = sec;
        last_min = min;
        last_hour = hour;
        rtc_read_raw(&sec, &min, &hour, &reg_b);
    } while(sec != last_sec || min != last_min || hour != last_hour);

    uint8_t pm = hour & 0x80; /* bit 7 of the hours register = PM flag, only meaningful in 12-hour mode */
    hour &= 0x7F;

    if(!(reg_b & STATUS_B_BINARY)) {
        sec = bcd_to_bin(sec);
        min = bcd_to_bin(min);
        hour = bcd_to_bin(hour);
    }

    if(!(reg_b & STATUS_B_24_HOUR)) {
        /* 12-hour mode: convert to 24-hour. Midnight (12 AM) -> 0,
         * noon (12 PM) stays 12, other PM hours get +12. */
        if(hour == 12) {
            hour = pm ? 12 : 0;
        }
        else if(pm) {
            hour = (uint8_t)(hour + 12);
        }
    }

    out->seconds = sec;
    out->minutes = min;
    out->hours = hour;
}

#define CMOS_REG_DAY    0x07
#define CMOS_REG_MONTH  0x08
#define CMOS_REG_YEAR   0x09
#define CMOS_REG_CENTURY 0x32

void rtc_read_date(rtc_date_t *out) {
    uint8_t day, month, year, century, reg_b;
    uint8_t ld, lm, ly;

    while(rtc_update_in_progress());
    day = cmos_read(CMOS_REG_DAY); month = cmos_read(CMOS_REG_MONTH); year = cmos_read(CMOS_REG_YEAR);
    do {
        ld = day; lm = month; ly = year;
        while(rtc_update_in_progress());
        day = cmos_read(CMOS_REG_DAY); month = cmos_read(CMOS_REG_MONTH); year = cmos_read(CMOS_REG_YEAR);
    } while(day != ld || month != lm || year != ly);
    century = cmos_read(CMOS_REG_CENTURY);
    reg_b = cmos_read(CMOS_REG_STATUS_B);

    if(!(reg_b & STATUS_B_BINARY)) {
        day = bcd_to_bin(day); month = bcd_to_bin(month); year = bcd_to_bin(year); century = bcd_to_bin(century);
    }
    uint16_t full_year = (century >= 19 && century <= 30) ? (uint16_t)(century * 100 + year) : (uint16_t)(2000 + year);
    out->day = day; out->month = month; out->year = full_year;
}
