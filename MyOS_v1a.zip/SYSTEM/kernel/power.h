#ifndef POWER_H
#define POWER_H

/* Attempts to power off the machine. Tries the "magic port" shutdown
 * sequences understood by QEMU, Bochs, and older QEMU/Bochs versions in
 * turn, which covers every common emulator this OS is actually run
 * under (and is what VirtualBox's own OSE BIOS/QEMU-derived core also
 * honors). None of these exist on real ACPI-only hardware, so as a
 * last resort this halts the CPU in a loop -- not a real shutdown, but
 * safe, and better than falling through into undefined behavior.
 * Never returns. */
void power_shutdown(void);

/* Reboots the machine via the 8042 keyboard controller's pulse-reset
 * line (port 0x64, command 0xFE) -- the standard, widely-supported way
 * to trigger a CPU reset from software, working on real hardware and
 * in every emulator. Never returns (successfully). */
void power_reboot(void);

/* "Sleep" is a software-only screen-blank/wait state, NOT real ACPI S3
 * suspend-to-RAM -- actual hardware sleep needs full ACPI table
 * parsing (finding the FADT, programming the PM1 control register with
 * the right SLP_TYP value, etc.), which this kernel doesn't implement.
 * This is implemented in desktop.c (not here -- see
 * taskbar.c's Sleep menu item and desktop_enter_sleep()) rather than in
 * this kernel-level power module, since it needs to drive the
 * graphical desktop's own render loop (dim the screen, wait for input)
 * rather than anything actually kernel/hardware-level the way shutdown/
 * reboot are. Declared here only as a placeholder comment pointing at
 * the real implementation, so anyone looking at power.h for "what can
 * this OS do with power state" finds this note rather than nothing. */

#endif
