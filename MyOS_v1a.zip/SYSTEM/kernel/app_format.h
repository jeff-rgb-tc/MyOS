#ifndef APP_FORMAT_H
#define APP_FORMAT_H

#include "stdint.h"
#include "myos/abi.h"

/* Parsing and validation of .app files, kept free of any kernel services
 * so it can be tested on its own (and reused by the Start-menu scanner
 * that only wants the name and icon, not to run the program). */

typedef struct {
    int      version;                 /* 1 or 2 */
    uint32_t image_offset;            /* where the image starts in the file */
    uint32_t entry_offset;            /* relative to the image */
    uint32_t code_size;               /* bytes of image stored in the file */
    uint32_t mem_size;                /* bytes of image in memory (>= code_size) */
    uint32_t abi_level;
    uint32_t permissions;
    uint32_t icon_offset;             /* 0 = none */
    uint32_t icon_size;
    char name[33];
    char version_str[17];
    char author[33];
    char description[65];
} app_manifest_t;

/* CRC-32 (IEEE 802.3), the same polynomial zlib/PNG use. */
uint32_t app_crc32(const uint8_t *data, uint32_t length);

/* Validates `file` (length `length`) and fills `out`. Returns NULL when the
 * file is a well-formed .app this kernel can run, or a short human-readable
 * reason otherwise ("bad magic", "needs a newer kernel", ...). Every offset
 * and size is range-checked against `length`; nothing in the file can make
 * this read out of bounds. */
const char *app_format_parse(const uint8_t *file, uint32_t length, app_manifest_t *out);

#endif
