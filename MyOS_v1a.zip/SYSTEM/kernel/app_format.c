#include "app_format.h"

static uint32_t rd32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

uint32_t app_crc32(const uint8_t *data, uint32_t length) {
    uint32_t crc = 0xFFFFFFFFu;
    for(uint32_t i = 0; i < length; i++) {
        crc ^= data[i];
        for(int b = 0; b < 8; b++) crc = (crc >> 1) ^ (0xEDB88320u & (uint32_t)-(int32_t)(crc & 1));
    }
    return ~crc;
}

/* Copies a fixed-size, possibly unterminated header string into a buffer
 * that is always NUL-terminated, keeping only printable characters. */
static void copy_field(char *dst, int dst_size, const uint8_t *src, int src_size) {
    int n = 0;
    for(int i = 0; i < src_size && n < dst_size - 1; i++) {
        uint8_t c = src[i];
        if(c == 0) break;
        dst[n++] = (c >= 32 && c < 127) ? (char)c : '?';
    }
    dst[n] = '\0';
}

const char *app_format_parse(const uint8_t *f, uint32_t len, app_manifest_t *out) {
    for(unsigned i = 0; i < sizeof(*out); i++) ((uint8_t *)out)[i] = 0;

    if(len < 8) return "file too small";
    if(f[0] != 'M' || f[1] != 'Y' || f[2] != 'A' || f[3] != 'P') return "not a .app file (bad magic)";
    uint32_t version = rd32(f + 4);

    if(version == 1) {
        /* Legacy 16-byte header: magic, version, entry_offset, code_size. */
        if(len < 16) return "file too small";
        out->version = 1;
        out->image_offset = 16;
        out->entry_offset = rd32(f + 8);
        out->code_size = rd32(f + 12);
        out->mem_size = out->code_size;
        out->abi_level = 1;
        out->permissions = MYOS_PERM_FILE_WRITE | MYOS_PERM_AUDIO | MYOS_PERM_CLIPBOARD; /* v1 had no sandbox model */
        copy_field(out->name, sizeof(out->name), (const uint8_t *)"App", 4);
    }
    else if(version == 2) {
        if(len < MYOS_APP_HEADER_SIZE) return "file too small";
        uint32_t header_size = rd32(f + 8);
        if(header_size != MYOS_APP_HEADER_SIZE) return "unsupported header size";
        out->version = 2;
        out->image_offset = header_size;
        out->entry_offset = rd32(f + 12);
        out->code_size = rd32(f + 16);
        out->mem_size = rd32(f + 20);
        out->abi_level = rd32(f + 24);
        out->permissions = rd32(f + 28);
        /* f + 32: flags, reserved */
        out->icon_offset = rd32(f + 36);
        out->icon_size = rd32(f + 40);
        uint32_t crc = rd32(f + 44);
        copy_field(out->name, sizeof(out->name), f + 48, 32);
        copy_field(out->version_str, sizeof(out->version_str), f + 80, 16);
        copy_field(out->author, sizeof(out->author), f + 96, 32);
        copy_field(out->description, sizeof(out->description), f + 128, 64);

        if(out->abi_level > MYOS_ABI_LEVEL) return "needs a newer MyOS (ABI level too high)";
        if(out->abi_level < 1) return "invalid ABI level";
        if(out->code_size <= len && len - out->code_size >= header_size) {
            if(app_crc32(f + header_size, out->code_size) != crc) return "checksum mismatch (file damaged?)";
        }
    }
    else {
        return "unsupported .app version";
    }

    if(out->code_size == 0) return "empty program";
    if(out->mem_size < out->code_size) return "memory size smaller than code size";
    if(out->mem_size > MYOS_APP_IMAGE_MAX) return "program too large (over 8 MB)";
    if(out->image_offset > len || len - out->image_offset < out->code_size) return "file is truncated";
    if(out->entry_offset >= out->code_size) return "entry point outside the program";

    if(out->icon_size) {
        if(out->icon_offset < out->image_offset + out->code_size ||
           out->icon_offset > len || len - out->icon_offset < out->icon_size) {
            out->icon_offset = out->icon_size = 0;      /* bad icon: ignore it, still runnable */
        }
    }
    if(!out->name[0]) copy_field(out->name, sizeof(out->name), (const uint8_t *)"App", 4);
    return 0;
}
