#ifndef PIT_H
#define PIT_H

#include "stdint.h"

void init_timer(uint32_t frequency); //frequency in Hz

/* Enables/disables the periodic text-mode status line the timer used to
 * draw over the framebuffer. The graphical desktop disables this once it
 * takes over rendering, since it owns the whole frame itself. */
void pit_set_status_line_enabled(uint8_t enabled);

/* Ticks since init_timer() was called, incrementing at a fixed 10 Hz
 * (100ms per tick) regardless of init_timer()'s frequency argument or
 * how fast the host/emulator actually runs -- this is real wall-clock
 * time from the PIT hardware, not a frame count. Use this (not a
 * render-loop frame counter) for anything that needs to measure actual
 * elapsed time, such as double-click detection: a frame-count-based
 * timing window means the same "N frames" is a wildly different amount
 * of real time on a fast host/KVM build versus a slow software-rendered
 * emulator, which is why double-click used to work inconsistently
 * across VirtualBox/QEMU/Bochs. */
long long pit_get_ticks(void);

/* Registers a function called from the timer IRQ every 50 ms (pass 0 to
 * remove it). It runs in interrupt context: it must be short, must not
 * allocate and must not take locks. Used by the boot splash to keep its
 * spinner turning even while the main code is stuck in a long disk read. */
void pit_set_hook(void (*fn)(void));          /* slot 0: boot splash */
void pit_set_hook_slot(int slot, void (*fn)(void));   /* slot 1: audio keep-alive (ac97.c), slot 2: not-responding cursor (desktop.c); 0..2 */

/* Milliseconds since boot (10 ms resolution, wraps after ~49 days). */
uint32_t pit_get_ms(void);

#endif
