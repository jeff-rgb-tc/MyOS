#ifndef MOUSE_H
#define MOUSE_H

#include "stdint.h"

/* Button bit masks, matching the PS/2 mouse packet byte 0 layout. */
#define MOUSE_BUTTON_LEFT   0x01
#define MOUSE_BUTTON_RIGHT  0x02
#define MOUSE_BUTTON_MIDDLE 0x04

typedef struct {
    int32_t x;          /* absolute screen x, clamped to [0, screen_width-1]  */
    int32_t y;          /* absolute screen y, clamped to [0, screen_height-1] */
    uint8_t buttons;     /* bitmask of MOUSE_BUTTON_* currently held down     */
    uint8_t prev_buttons; /* bitmask from the previous packet, for edge detection */
    int8_t  dx;          /* raw delta from the most recent packet (debug use) */
    int8_t  dy;
    int16_t wheel;        /* wheel notches since the desktop last took them: + = scroll down (toward you) */
    uint8_t updated;      /* set to 1 whenever new mouse state is available; the
                            * desktop loop should clear it after consuming state */
} mouse_state_t;

/* Initializes the PS/2 auxiliary (mouse) device and installs the IRQ12
 * handler. Must be called after remap_pic()/init_idt(), and after
 * set_vmode() so the driver knows the screen bounds to clamp against. */
void initialize_mouse();

/* Returns a pointer to the live mouse state. Treat as read-only outside
 * of the mouse driver itself. */
mouse_state_t *mouse_get_state();

/* Called from the mouse interrupt after every decoded packet with the new position. */
void mouse_set_move_hook(void (*fn)(int x, int y));

/* Convenience helpers */
int mouse_button_down(uint8_t button);
int mouse_button_pressed(uint8_t button);  /* transitioned from up -> down since last check */
int mouse_button_released(uint8_t button); /* transitioned from down -> up since last check */

/* Pointer speed multiplier in percent (25..400, default 100). */
void mouse_set_sensitivity(int percent);

#endif
