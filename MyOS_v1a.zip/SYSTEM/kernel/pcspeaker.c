#include "pcspeaker.h"
#include "port.h"
#include "pit.h"

void speaker_tone(uint32_t freq) {
    if(freq < 20 || freq > 20000) { speaker_off(); return; }
    uint32_t div = 1193182u / freq;
    outb(0x43, 0xB6);                         /* channel 2, lobyte/hibyte, square wave */
    outb(0x42, (uint8_t)(div & 0xFF));
    outb(0x42, (uint8_t)((div >> 8) & 0xFF));
    outb(0x61, (uint8_t)(inb(0x61) | 0x03));  /* gate + speaker on */
}

void speaker_off(void) { outb(0x61, (uint8_t)(inb(0x61) & ~0x03)); }

void speaker_beep(uint32_t freq, uint32_t ms) {
    if(ms > 1000) ms = 1000;
    speaker_tone(freq);
    uint32_t t0 = pit_get_ms();
    while((uint32_t)(pit_get_ms() - t0) < ms) { __asm__ volatile("sti; hlt"); }
    speaker_off();
}
