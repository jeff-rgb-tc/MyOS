#ifndef VESA_H
#define VESA_H

/* Requested resolutions, in order of preference. set_vmode() will try each
 * in turn and fall back to the next if the BIOS/emulator doesn't report a
 * matching VBE mode. This lets MyOS boot on real VESA-capable hardware or
 * emulators at 1920x1080 when available, while still working on more
 * constrained setups down to 800x600. */
typedef struct {
    uint16_t width;
    uint16_t height;
    uint8_t  bpp;
} vesa_mode_pref_t;

void set_vmode();

/* Returns nonzero if VESA video mode was set up successfully. */
int vesa_is_ready();

uint32_t make_vesa_color(uint8_t r, uint8_t g, uint8_t b);

void draw_pixel_at(int x, int y, uint32_t color);

void draw_character_at(int x, int y, int c, uint32_t fg, uint32_t bg);

uint32_t get_framebuffer_addr();
uint32_t get_framebuffer_length();

/* Actual negotiated screen geometry, valid after set_vmode() returns. */
uint32_t get_screen_width();
uint32_t get_screen_height();
uint32_t get_screen_pitch();
uint32_t get_screen_bpp();

void set_vesa_color(uint32_t color);
void set_vesa_background(uint32_t color);

uint32_t get_vesa_color();
uint32_t get_vesa_background();

/* Enables/disables drawing printf() boot-log text to the screen --
 * called with 0 right before the graphical boot splash (and later, the
 * desktop) starts drawing to the same physical framebuffer, so log
 * characters and splash/desktop graphics don't overwrite each other on
 * screen. Doesn't affect printf() itself (the "log" as a sequence of
 * calls still happens exactly as before), only whether those calls draw
 * anything visible. */
void vesa_set_text_output_enabled(uint8_t enabled);

#endif
