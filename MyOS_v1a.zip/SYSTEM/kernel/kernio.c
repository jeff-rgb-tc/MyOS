#include "kernio.h"
#include "terminal.h"
#include "common.h"
#include <stdarg.h>

int BOOTED;

// Potential base for stdarg. Doesn't work.
// We need to know more about how gcc handles the stack.
//typedef char *va_list;
//#define va_start(ap,parmn) (void)((ap) = (char*)(&(parmn) + 1))
//#define va_end(ap) (void)((ap) = 0)
//#define va_arg(ap, type)                          \
//    (((type*)((ap) = ((ap) + sizeof(type))))[-1])

int printf(char *fmt, ...) {
    //return;
    va_list argp;
    va_start(argp, fmt);

    char *p;
    for(p = fmt; *p != 0; p++) {
        if(*p != '%') {
            terminal_putchar(*p);
            continue;
        }
        p++; // Skip the %
        int i;
        char *s;
        /* Minimal zero-padded width support: only "%0Nd" (a literal '0'
         * flag followed by a single decimal digit width, e.g. "%02d")
         * -- that's the one case anything in this kernel actually needs
         * (HH:MM:SS-style zero-padded numbers). Anything fancier
         * (multi-digit width, '-' flag, non-zero pad char, applying
         * width to %x/%s) isn't parsed; unrecognized combinations fall
         * through to the default case below exactly as before. */
        int zero_pad_width = 0;
        if(p[0] == '0' && p[1] >= '1' && p[1] <= '9' && p[2] == 'd') {
            zero_pad_width = p[1] - '0';
            p += 2;
        }
        switch(*p) {
        case 'c':
            i = va_arg(argp, int);
            terminal_putchar(i);
            break;
        case 's':
            s = va_arg(argp, char *);
            terminal_writestring(s);
            break;
        case 'd':
            i = va_arg(argp, int);
            if(zero_pad_width > 0) {
                char decbuff[13];
                char *dec = itos((uint32_t)i, decbuff, 13);
                int len = strlen(dec);
                for(int pad = len; pad < zero_pad_width; pad++) {
                    terminal_putchar('0');
                }
                terminal_writestring(dec);
            }
            else {
                terminal_write_dec(i);
            }
            break;
        case 'x':
            i = va_arg(argp, int);
            terminal_write_hex(i);
            break;
        case '%':
            terminal_putchar('%');
            break;
        default:
            terminal_putchar('%');
            terminal_putchar(*p);
            break;
        }
    }
    return 0;
}

int sprintf(char *str, char *fmt, ...) {
    va_list argp;
    va_start(argp, fmt);

    char *p;
    for(p = fmt; *p != 0; p++) {
        if(*p != '%') {
            *str++ = *p;
            continue;
        }
        p++; // Skip the %
        int i;
        char *s;
        /* Same minimal "%0Nd" zero-pad support as printf() above -- see
         * that comment for scope/limits. */
        int zero_pad_width = 0;
        if(p[0] == '0' && p[1] >= '1' && p[1] <= '9' && p[2] == 'd') {
            zero_pad_width = p[1] - '0';
            p += 2;
        }
        switch(*p) {
        case 'c':
            i = va_arg(argp, int);
            *str++ = i;
            break;
        case 's':
            s = va_arg(argp, char *);
            while(*s) {
                *str++ = *s++;
            }
            break;
        case 'd':
            i = va_arg(argp, int);
            char decbuff[13]; // At most 12 decimal places for 32 bit int.
            char *dec = itos((uint32_t)i, decbuff, 13);
            if(zero_pad_width > 0) {
                int len = strlen(dec);
                for(int pad = len; pad < zero_pad_width; pad++) {
                    *str++ = '0';
                }
            }
            while(*dec) {
                *str++ = *dec++;
            }
            break;
        case 'x':
            i = va_arg(argp, int);
            for(int j = 28; j >= 0; j-=4)
            {
                *str++ = hex_char(i>>j);
            }
            break;
        case '%':
            *str++ = '%';
            break;
        default:
            *str++ = '%';
            *str++ = *p;
            break;
        }
    }
    *str++ = 0;
    return 0;
}

void set_status(char *str) {
    if(terminal_set_status) {
        terminal_set_status(str);
    }
}
