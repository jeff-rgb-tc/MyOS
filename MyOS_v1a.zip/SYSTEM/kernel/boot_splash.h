#ifndef BOOT_SPLASH_H
#define BOOT_SPLASH_H

/* Graphical boot screen: black background, a large white "MyOS" title
 * slightly above the centre and a small ring-of-dots spinner under it.
 *
 * The spinner is driven by the timer interrupt (see pit_set_hook()), NOT by
 * the boot code calling a tick function at checkpoints -- so it keeps turning
 * however long a single boot step (disk probe, FAT mount, driver init) takes,
 * even on a slow installed disk. While the splash is active the spinner is
 * drawn straight into the visible framebuffer; nothing else may call
 * gfx_present() until boot_splash_stop() has been called.
 *
 * gfx_init() must already have succeeded (kernel.c calls it right after
 * initialize_paging()). */

/* Draws the splash and starts the animation. */
void boot_splash_show(void);

/* Kept for compatibility with older callers: the animation is timer driven
 * now, so this does nothing. */
void boot_splash_tick(void);

/* Shows one line of text under the spinner ("Loading apps...") with the seconds
 * since boot started, so a slow or stuck start-up shows WHERE it is waiting.
 * Also written to the kernel log / serial port. Safe to call at any time. */
void boot_splash_status(const char *msg);

/* Stops the animation (call before the desktop takes over the screen). */
void boot_splash_stop(void);

#endif
