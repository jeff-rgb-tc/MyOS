#!/bin/sh
# populate_disk.sh <disk_path> <size_mb> <reserved_sectors>
#
# Creates a fresh FAT32 disk image at <disk_path> of <size_mb>, with
# <reserved_sectors> reserved sectors (mkfs.fat -R), and writes in the
# same SYSTEM/APPS/Users tree both populate_disk (the ISO's f32.disk,
# reserved_sectors=default via -s 1) and img (the single bootable+
# writable disk, which needs a larger reserved-sectors gap so GRUB's
# core.img -- embedded separately, see the top-level Makefile's img
# target -- has somewhere to live before the FAT32 filesystem itself
# begins) both need identically populated.
#
# Uses mtools (mmd/mcopy) throughout -- no mounting, no loop device, no
# root required, consistent with how this project has always written to
# its FAT32 images.
set -e

DISK_PATH="$1"
SIZE_MB="$2"
RESERVED_SECTORS="$3"

if [ -z "$DISK_PATH" ] || [ -z "$SIZE_MB" ] || [ -z "$RESERVED_SECTORS" ]; then
    echo "usage: populate_disk.sh <disk_path> <size_mb> <reserved_sectors>" >&2
    exit 1
fi

rm -f "$DISK_PATH"
dd if=/dev/zero of="$DISK_PATH" bs=1M count="$SIZE_MB"
mkfs.fat -F32 "$DISK_PATH" -s 1 -R "$RESERVED_SECTORS"

mmd -i "$DISK_PATH" ::/SYSTEM
mmd -i "$DISK_PATH" ::/SYSTEM/res
mmd -i "$DISK_PATH" ::/SYSTEM/res/cursors
mmd -i "$DISK_PATH" ::/SYSTEM/res/backgrounds
mmd -i "$DISK_PATH" ::/SYSTEM/res/icons
mmd -i "$DISK_PATH" ::/APPS
mmd -i "$DISK_PATH" ::/Users
mmd -i "$DISK_PATH" ::/Users/User
mmd -i "$DISK_PATH" ::/Users/User/Desktop
mmd -i "$DISK_PATH" ::/Users/User/Music
mmd -i "$DISK_PATH" ::/Drivers

mcopy -o -i "$DISK_PATH" ../res/cursors/*.cur ::/SYSTEM/res/cursors/
if ls ../res/cursors/*.ani >/dev/null 2>&1; then
    mcopy -o -i "$DISK_PATH" ../res/cursors/*.ani ::/SYSTEM/res/cursors/
fi
mcopy -o -i "$DISK_PATH" ../res/omys.ico ::/SYSTEM/res/
mcopy -o -i "$DISK_PATH" ../res/backgrounds/*.png ::/SYSTEM/res/backgrounds/
mcopy -o -i "$DISK_PATH" ../res/icons/*.png ::/SYSTEM/res/icons/

for app_dir in ../../APPS/*/; do
    app=$(basename "$app_dir")
    mmd -i "$DISK_PATH" ::/APPS/"$app"
    if ls ../../APPS/"$app"/*.png >/dev/null 2>&1; then
        mcopy -o -i "$DISK_PATH" ../../APPS/"$app"/*.png ::/APPS/"$app"/
    fi
    # Third-party / SDK-built programs: <name>.app (plus optional data files)
    if ls ../../APPS/"$app"/*.app >/dev/null 2>&1; then
        mcopy -o -i "$DISK_PATH" ../../APPS/"$app"/*.app ::/APPS/"$app"/
    fi
done

# Music -- any files in MyOS/Users/User/Music on the source tree are
# copied to /Users/User/Music on the disk (handy for testing playback).
if ls ../../Users/User/Music/* >/dev/null 2>&1; then
    mcopy -o -i "$DISK_PATH" ../../Users/User/Music/* ::/Users/User/Music/
fi

# Drivers -- see MyOS/Drivers/<category>/ on the source tree
# (e.g. MyOS/Drivers/sound/ac97.drv) mirrored onto the disk at
# /Drivers/<category>/. Copies whatever categories/driver files
# actually exist rather than a fixed list, same reasoning as the app
# loop above (a category or driver added later should never need this
# script updated to match).
if [ -d ../../Drivers ]; then
    for category_dir in ../../Drivers/*/; do
        [ -d "$category_dir" ] || continue
        category=$(basename "$category_dir")
        mmd -i "$DISK_PATH" ::/Drivers/"$category"
        if ls "$category_dir"*.drv >/dev/null 2>&1; then
            mcopy -o -i "$DISK_PATH" "$category_dir"*.drv ::/Drivers/"$category"/
        fi
    done
fi

# ---------------------------------------------------------------------
# Files the INSTALLER copies onto a new disk. The running system can only
# copy what it can read from its own filesystem, so everything an installed
# system needs has to be on this image:
#   /boot/myos.bin          the kernel (GRUB loads it on the installed disk)
#   /boot/grub/grub.cfg     menu for the installed system (no "module" line)
#   /SYSTEM/apps-sdk/       the app SDK, so users can build their own apps
#   /SYSTEM/install/        boot loader payload (MBR + GRUB core.img); only
#                           used to write the MBR, never copied to the target
# ---------------------------------------------------------------------
mmd -i "$DISK_PATH" ::/boot
mmd -i "$DISK_PATH" ::/boot/grub
if [ -f ./myos.bin ]; then
    mcopy -o -i "$DISK_PATH" ./myos.bin ::/boot/myos.bin
else
    echo "populate_disk: WARNING ./myos.bin missing -- installed systems will not boot" >&2
fi
mcopy -o -i "$DISK_PATH" ../../BOOT/grub/grub-installed.cfg ::/boot/grub/grub.cfg

if [ -d ../apps-sdk ]; then
    # Source + docs + examples; skip build output and editor leftovers.
    tmp_sdk=$(mktemp -d)
    cp -R ../apps-sdk "$tmp_sdk/apps-sdk"
    find "$tmp_sdk/apps-sdk" \( -name build -o -name '*.o' -o -name '*.elf' -o -name '__pycache__' \) -prune -exec rm -rf {} + 2>/dev/null || true
    mcopy -s -o -i "$DISK_PATH" "$tmp_sdk/apps-sdk" ::/SYSTEM/
    rm -rf "$tmp_sdk"
fi

if [ -f ./bootsect.bin ]; then
    mmd -i "$DISK_PATH" ::/SYSTEM/install
    mcopy -o -i "$DISK_PATH" ./bootsect.bin ::/SYSTEM/install/bootsect.bin
else
    echo "populate_disk: note: ./bootsect.bin missing -- installer.app will report 'boot loader files missing' (run: make bootsect)" >&2
fi

echo "Populated $DISK_PATH (${SIZE_MB}MB, ${RESERVED_SECTORS} reserved sectors)."
