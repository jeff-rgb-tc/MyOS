#ifndef BMP_H
#define BMP_H

#include "stdint.h"
#include "fat32.h"

/* Encodes an ARGB8888 buffer (top-down, row-major, same layout as every
 * other image type in the desktop) into a classic uncompressed 32bpp BMP
 * file in memory. BMP was chosen alongside PNG as a save format because
 * it needs no compression step at all -- just a header and byte
 * reordering -- which keeps this encoder tiny and dependency-free.
 *
 * Returns a heap-allocated buffer containing the complete .bmp file
 * (caller must kfree() it) and writes its length to *out_length, or
 * returns NULL on allocation failure. */
uint8_t *bmp_encode(const uint32_t *pixels, uint16_t width, uint16_t height, uint32_t *out_length);

/* Convenience wrapper: encodes and writes directly to a file inside the
 * given FAT32 directory. Returns 1 on success, 0 on failure. */
int bmp_save_to_file(const uint32_t *pixels, uint16_t width, uint16_t height,
                      f32 *fs, struct directory *dir, char *filename);

#endif
