[bits 32]
section .text
global enter_usermode

; void enter_usermode(uint32_t entry_eip, uint32_t user_esp)
;
; Builds the iret frame by hand and drops to ring3. Segment selectors:
; user data = GDT entry 4 -> 4*8=0x20, | 3 for RPL 3 -> 0x23
; user code = GDT entry 3 -> 3*8=0x18, | 3 for RPL 3 -> 0x1B
; (see gdt.c: entries 0=null,1=kernel code,2=kernel data,3=user code,
; 4=user data,5=TSS)
;
; iret pops, in order: eip, cs, eflags, [esp, ss] -- the last two only
; when cs's RPL differs from the RPL the interrupt/call was made from,
; which is exactly the case here (we're in ring0 now, cs.RPL=0, and the
; cs we're loading has RPL=3) -- so iret DOES expect esp/ss on the
; stack for this specific transition, unlike a same-ring iret.
enter_usermode:
    mov     eax, [esp + 4]      ; entry_eip
    mov     ecx, [esp + 8]      ; user_esp

    mov     dx, 0x23            ; user data selector (RPL 3)
    mov     ds, dx
    mov     es, dx
    mov     fs, dx
    mov     gs, dx
    ; ss is NOT loaded here -- it's set by iret itself below, since
    ; loading ss directly while still on the ring0 stack/segment and
    ; then trying to push more values would corrupt the frame we're
    ; still building. iret's own ss pop (final step) is what actually
    ; switches ss to ring3.

    push    0x23                ; ss (user data selector, RPL 3)
    push    ecx                 ; esp (user stack pointer)
    pushfd                      ; eflags
    pop     edx
    or      edx, 0x200          ; ensure IF (interrupts enabled) is set in the eflags we're dropping into --
                                 ; ring3 code must run with interrupts on, or the timer/keyboard/mouse IRQs
                                 ; (and this app's own ability to ever be preempted back to the desktop) stop firing.
    push    edx                 ; eflags
    push    0x1B                ; cs (user code selector, RPL 3)
    push    eax                 ; eip (entry point)

    iret
