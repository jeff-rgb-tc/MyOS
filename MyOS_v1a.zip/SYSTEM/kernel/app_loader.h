#ifndef APP_LOADER_H
#define APP_LOADER_H

#include "stdint.h"
#include "myos/abi.h"
#include "app_format.h"

/* Loads and runs .app programs in ring 3 (see apps-sdk/docs/FORMAT.md for
 * the file format and apps-sdk/include/myos/abi.h for the syscall ABI).
 *
 * How an app coexists with the desktop (there is no scheduler in this
 * kernel): the app runs in ring 3 on top of the desktop loop. Whenever it
 * waits (SYS_WAIT_EVENT / SYS_SLEEP_MS / SYS_YIELD / SYS_PRESENT, or while
 * blocked on audio) the syscall handler runs one desktop frame by calling
 * desktop_pump() on the app's kernel stack. So the whole desktop -- window
 * dragging, the taskbar, other windows, cursor animation -- stays alive
 * while an app runs, and the app's windows are ordinary desktop windows
 * whose pixels come from a per-window surface the app draws into.
 *
 * Consequences, all documented in the SDK: one .app runs at a time; an app
 * that computes for more than ~10 s without making any syscall is stopped
 * by a watchdog; closing the app's window sends it MYOS_EV_CLOSE, ending
 * the task from Task Manager terminates it immediately. */

/* Memory layout (kept under the old names too). */
#define APP_MAGIC "MYAP"
#define APP_LOAD_BASE  MYOS_APP_BASE
#define APP_CODE_SIZE  MYOS_APP_IMAGE_MAX
#define APP_STACK_BASE (APP_LOAD_BASE + APP_CODE_SIZE)
#define APP_STACK_SIZE MYOS_APP_STACK_SIZE

#define APP_WATCHDOG_MS 10000

/* Queues `path` to be launched. Safe to call from any UI handler: the
 * program is actually started by app_loader_service() at the top of the
 * desktop loop, never from inside the handler that asked for it (so no
 * half-finished UI code is left suspended underneath a running app).
 * Returns 1 if the request was accepted, 0 if the file doesn't exist or
 * another app is already running/pending (the user gets an on-screen
 * message either way it fails). */
int app_loader_run(const char *path);

/* Starts a queued launch, if any, and returns when that app has exited.
 * Called only from desktop_run()'s loop. */
void app_loader_service(void);

int app_is_running(void);
const char *app_loader_current_name(void);      /* manifest name of the running app, or NULL */
uint32_t app_permissions(void);                 /* MYOS_PERM_* of the running app */
int app_abi_level(void);                        /* ABI level the running app was built for */

/* Reads just the manifest (and optionally a copy of the embedded icon PNG,
 * kmalloc'd; caller kfree()s) of an app file. Returns 1 on success. Used
 * by the Start menu to list installed apps without running them. */
int app_loader_read_manifest(const char *path, app_manifest_t *manifest,
                             uint8_t **icon_png, uint32_t *icon_len);

/* Called from every syscall: feeds the watchdog. */
void app_note_syscall(void);
/* Called from the timer interrupt while ring-3 code is running: stops an
 * app that hasn't entered the kernel for APP_WATCHDOG_MS. */
void app_watchdog_check(void);

/* Non-local exits back to the loader. Never return. */
void app_fault_return(const char *reason) __attribute__((noreturn));
void app_exit_return(void) __attribute__((noreturn));

#endif
