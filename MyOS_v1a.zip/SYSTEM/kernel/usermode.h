#ifndef USERMODE_H
#define USERMODE_H

#include "stdint.h"

/* Drops the CPU from ring0 to ring3 and begins executing at
 * entry_eip, with esp initialized to user_esp (both are virtual
 * addresses in pages the caller must have already mapped as
 * present+user+writeable -- see app_loader.c). This function does not
 * return in the usual sense: control passes to entry_eip via iret, and
 * the only way back into this same kernel call stack is a later
 * interrupt/exception/syscall trapping through the TSS's ss0:esp0 (see
 * tss_set_kernel_stack(), which the caller must set to a valid,
 * currently-unused kernel stack before calling this -- see
 * app_loader.c's run_app() for the actual sequencing). */
void enter_usermode(uint32_t entry_eip, uint32_t user_esp);

#endif
