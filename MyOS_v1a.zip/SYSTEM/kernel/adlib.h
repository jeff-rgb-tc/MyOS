#ifndef ADLIB_H
#define ADLIB_H

#include "audio.h"

/* AdLib (Yamaha OPL2 FM synthesis chip, fixed ISA I/O port 388h). Unlike
 * every other driver in this OS, AdLib hardware has NO PCM sample
 * playback capability at all -- it only generates sound by combining FM
 * synthesis operators (sine-wave oscillators modulating each other),
 * driven by writing instrument/note parameters to its registers, not by
 * streaming audio samples. Properly "supporting" AdLib for this OS's
 * purposes (playing WAV/MP3/OGG files) is not actually possible on real
 * AdLib hardware -- there's no PCM input to send it.
 *
 * This driver implements real hardware DETECTION only (the standard
 * OPL2 status-register probe), so audio_active_driver_name() reports
 * accurately if AdLib is the only thing present, and Drivers/sound/
 * adlib.drv is a real, meaningful file rather than a placeholder that
 * claims capability it doesn't have. Its write()/set_format() are
 * deliberately no-ops -- see adlib.c's comments at each -- rather than
 * silently pretending to play audio that never actually sounds. */
extern const audio_driver_t adlib_driver;

#endif
