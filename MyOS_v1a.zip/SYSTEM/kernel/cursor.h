#ifndef CURSOR_H
#define CURSOR_H

#include "stdint.h"

/* A cursor decoded from a Windows .cur file into a simple ARGB8888 buffer
 * ready for blitting. Pixels are stored top-to-bottom, left-to-right
 * (already un-flipped from the bottom-up DIB layout .cur files use on
 * disk), and alpha == 0 means "fully transparent, don't touch the
 * framebuffer here". */
typedef struct {
    uint16_t width;
    uint16_t height;
    uint16_t hotspot_x; /* pixel within the image that represents the actual
                            pointer location (e.g. the tip of an arrow) */
    uint16_t hotspot_y;
    uint32_t *pixels;   /* width * height ARGB8888 values, 0xAARRGGBB, heap-allocated */
} cursor_image_t;

/* Parses raw .cur file bytes already loaded into memory (e.g. read from
 * the FAT32 filesystem via fread) into a cursor_image_t. Returns 1 on
 * success, 0 on failure (malformed file, unsupported bit depth, etc).
 * On success, out->pixels is heap-allocated via kmalloc and the caller
 * owns it. If the .cur file contains multiple images (multiple
 * resolutions), the first/largest entry is used. */
int cursor_load_from_memory(const uint8_t *data, uint32_t length, cursor_image_t *out);

/* Builds a simple built-in default arrow cursor (32x32) without needing
 * any file at all. Useful as a fallback if no .cur resource is found on
 * disk, so the desktop always has *some* usable pointer. */
void cursor_build_default_arrow(cursor_image_t *out);

/* Frees the pixel buffer owned by a cursor_image_t. Safe to call on an
 * already-freed/zeroed image. */
void cursor_free(cursor_image_t *img);

#endif
