#include "wav.h"
#include "stdio.h"
#include "kernio.h"
#include "kheap.h"
#include "common.h"

static uint32_t read_u32le(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static uint16_t read_u16le(const uint8_t *p) {
    return (uint16_t)(p[0] | (p[1] << 8));
}

int wav_load_from_file(const char *path, wav_audio_t *out) {
    memset(out, 0, sizeof(wav_audio_t));

    FILE *f = fopen(path, NULL);
    if(!f) return 0;

    /* Read the whole file -- same growable-buffer approach every other
     * loader in this kernel uses (png.c, app_loader.c, ...). WAV files
     * for short system sounds/music are a few MB at most; reading the
     * whole thing up front keeps this decoder simple (no need to
     * seek/re-fread around a streaming parse) at the cost of that much
     * heap for the duration of the load. */
    uint32_t capacity = 65536;
    uint32_t total = 0;
    uint8_t *buffer = (uint8_t *)kmalloc(capacity);
    if(!buffer) { fclose(f); return 0; }

    size_t chunk;
    while((chunk = fread(buffer + total, 1, capacity - total, f)) > 0) {
        total += chunk;
        if(total >= capacity) {
            uint32_t new_capacity = capacity * 2;
            uint8_t *new_buffer = (uint8_t *)kmalloc(new_capacity);
            if(!new_buffer) { kfree(buffer); fclose(f); return 0; }
            fastcp((char *)new_buffer, (char *)buffer, total);
            kfree(buffer);
            buffer = new_buffer;
            capacity = new_capacity;
        }
    }
    fclose(f);

    if(total < 44 || memcmp(buffer, "RIFF", 4) != 0 || memcmp(buffer + 8, "WAVE", 4) != 0) {
        printf("wav: %s is not a valid RIFF/WAVE file\n", path);
        kfree(buffer);
        return 0;
    }

    /* Walk chunks looking for "fmt " and "data" -- WAV allows other
     * chunks (metadata, cue points, ...) in between/around these, and
     * doesn't guarantee "fmt " comes immediately before "data" (though
     * it almost always does in practice), so this doesn't assume a
     * fixed layout past the 12-byte RIFF/WAVE header. */
    uint32_t pos = 12;
    uint16_t format_tag = 0, channels = 0, bits_per_sample = 0;
    uint32_t sample_rate = 0;
    const uint8_t *data_chunk = NULL;
    uint32_t data_chunk_size = 0;

    while(pos + 8 <= total) {
        const uint8_t *chunk_id = buffer + pos;
        uint32_t chunk_size = read_u32le(buffer + pos + 4);
        const uint8_t *chunk_data = buffer + pos + 8;

        if(pos + 8 + chunk_size > total) {
            /* Chunk claims to run past the end of the file -- truncated/
             * corrupt file. Stop parsing rather than read out of
             * bounds. */
            break;
        }

        if(memcmp(chunk_id, "fmt ", 4) == 0 && chunk_size >= 16) {
            format_tag = read_u16le(chunk_data + 0);
            channels = read_u16le(chunk_data + 2);
            sample_rate = read_u32le(chunk_data + 4);
            bits_per_sample = read_u16le(chunk_data + 14);
        }
        else if(memcmp(chunk_id, "data", 4) == 0) {
            data_chunk = chunk_data;
            data_chunk_size = chunk_size;
        }

        pos += 8 + chunk_size + (chunk_size & 1); /* chunks are word-aligned -- a trailing pad byte on odd sizes */
    }

    if(!data_chunk || format_tag != 1 /* WAVE_FORMAT_PCM */
       || (bits_per_sample != 8 && bits_per_sample != 16)
       || (channels != 1 && channels != 2)) {
        printf("wav: %s isn't uncompressed 8/16-bit mono/stereo PCM (format=%d bits=%d channels=%d) -- unsupported\n",
               path, format_tag, bits_per_sample, channels);
        kfree(buffer);
        return 0;
    }

    uint32_t sample_count;
    int16_t *samples;

    if(bits_per_sample == 16) {
        sample_count = data_chunk_size / 2;
        samples = (int16_t *)kmalloc(sample_count * sizeof(int16_t));
        if(!samples) { kfree(buffer); return 0; }
        for(uint32_t i = 0; i < sample_count; i++) {
            samples[i] = (int16_t)read_u16le(data_chunk + i * 2);
        }
    }
    else {
        /* 8-bit WAV samples are UNSIGNED, centered at 128 -- convert to
         * signed 16-bit centered at 0, scaled up by 256 so the dynamic
         * range roughly matches what a genuine 16-bit source would use
         * (audio.h's API is always 16-bit, see its top comment). */
        sample_count = data_chunk_size;
        samples = (int16_t *)kmalloc(sample_count * sizeof(int16_t));
        if(!samples) { kfree(buffer); return 0; }
        for(uint32_t i = 0; i < sample_count; i++) {
            int16_t centered = (int16_t)((int32_t)data_chunk[i] - 128);
            samples[i] = (int16_t)(centered * 256);
        }
    }

    kfree(buffer);

    out->sample_rate = sample_rate;
    out->channels = (uint8_t)channels;
    out->bits_per_sample = 16; /* always -- see the header comment */
    out->samples = samples;
    out->sample_count = sample_count;
    return 1;
}

void wav_free(wav_audio_t *audio) {
    if(audio && audio->samples) {
        kfree(audio->samples);
        audio->samples = NULL;
    }
}
