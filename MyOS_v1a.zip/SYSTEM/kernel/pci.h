#ifndef PCI_H
#define PCI_H

#include "stdint.h"

/* Minimal PCI configuration-space access via the legacy I/O ports
 * 0xCF8 (CONFIG_ADDRESS)/0xCFC (CONFIG_DATA) -- the mechanism every x86
 * PC (real or emulated) with a PCI bus supports, predating the newer
 * memory-mapped (MMCONFIG/PCIe ECAM) access method this kernel doesn't
 * need since it only targets 32-bit PCI, not PCIe-specific features.
 * Needed here specifically to find the AC97 sound device (see
 * ac97.c/ac97.h) -- unlike SB16/AdLib/GUS, which are legacy ISA
 * devices at fixed, well-known I/O ports, AC97 lives on the PCI bus at
 * whatever bus/device/function the BIOS/firmware assigned it, which can
 * only be discovered by scanning. */

typedef struct {
    uint8_t bus;
    uint8_t device;
    uint8_t function;
    uint16_t vendor_id;
    uint16_t device_id;
    uint8_t class_code;
    uint8_t subclass;
    uint8_t prog_if;
} pci_device_t;

/* Reads a 32-bit value from PCI configuration space at
 * (bus, device, function, offset). offset must be 4-byte aligned (the
 * low 2 bits are ignored by the hardware mechanism itself). */
uint32_t pci_config_read32(uint8_t bus, uint8_t device, uint8_t function, uint8_t offset);
void pci_config_write32(uint8_t bus, uint8_t device, uint8_t function, uint8_t offset, uint32_t value);

/* Convenience 16-bit accessor -- reads the containing 32-bit dword and
 * extracts the requested half, since the underlying I/O port mechanism
 * only ever transfers 32 bits at a time. */
uint16_t pci_config_read16(uint8_t bus, uint8_t device, uint8_t function, uint8_t offset);

/* Scans every bus/device/function (0-255/0-31/0-7) for a device
 * matching the given class/subclass (PCI_CLASS_MULTIMEDIA/
 * PCI_SUBCLASS_AUDIO for AC97 -- see below), filling *out and returning
 * 1 on the first match found, 0 if none exists. This kernel only ever
 * needs to find one sound device, so "first match" is sufficient --
 * a machine with multiple sound cards would only ever see the first one
 * enumerated, which is an acceptable limitation for this OS's scope. */
int pci_find_device_by_class(uint8_t class_code, uint8_t subclass, pci_device_t *out);

#define PCI_CLASS_MULTIMEDIA 0x04
#define PCI_SUBCLASS_AUDIO   0x01

/* Reads one of a device's 6 possible Base Address Registers (BARs),
 * masking off the low flag bits (BAR & 1 tells I/O-space vs memory-space;
 * see pci_bar_is_io()) so the caller gets a clean base address. */
uint32_t pci_get_bar(pci_device_t *dev, int bar_index);
int pci_bar_is_io(uint32_t raw_bar);

#endif
