#ifndef SB16_H
#define SB16_H

#include "audio.h"

/* Sound Blaster 16 -- legacy ISA device at a fixed I/O base (220h by
 * far the most common default, which is all this driver probes; a real
 * SB16 can be configured to other bases via jumpers/software, but
 * there's no standard way to auto-detect that without a full ISA PnP
 * scan, out of scope here). Uses 8-bit DMA channel 1 for playback.
 * Included as a fallback for older real hardware/emulators without
 * AC97 -- see audio.c's priority list, which only ever tries this after
 * AC97 fails to probe. */
extern const audio_driver_t sb16_driver;

#endif
