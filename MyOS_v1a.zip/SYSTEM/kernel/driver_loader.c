#include "driver_loader.h"
#include "ini.h"
#include "fat32.h"
#include "fs_util.h"
#include "kheap.h"
#include "kernio.h"
#include "common.h"

static driver_info_t drivers[DRV_MAX_DRIVERS];
static int driver_total = 0;

static void copy_str(char *dst, int max, const char *src) {
    int i = 0;
    if(src) while(src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

static int streq_nocase(const char *a, const char *b) {
    while(*a && *b) {
        char x = *a, y = *b;
        if(x >= 'A' && x <= 'Z') x = (char)(x + 32);
        if(y >= 'A' && y <= 'Z') y = (char)(y + 32);
        if(x != y) return 0;
        a++; b++;
    }
    return *a == *b;
}

const char *driver_status_name(driver_status_t s) {
    switch(s) {
        case DRV_STATUS_ACTIVE: return "Active";
        case DRV_STATUS_STANDBY: return "Standby";
        case DRV_STATUS_DISABLED: return "Disabled";
        case DRV_STATUS_NOT_PRESENT: return "No hardware";
        case DRV_STATUS_UNKNOWN_ID: return "Unknown driver";
        default: return "Installed";
    }
}

int driver_count(void) { return driver_total; }

const driver_info_t *driver_get(int i) {
    return (i >= 0 && i < driver_total) ? &drivers[i] : NULL;
}

const driver_info_t *driver_find(const char *id) {
    for(int i = 0; i < driver_total; i++) {
        if(streq_nocase(drivers[i].id, id)) return &drivers[i];
    }
    return NULL;
}

static driver_info_t *find_mut(const char *id) {
    return (driver_info_t *)driver_find(id);
}

/* Parses one descriptor's text into a slot. Returns 1 if it had a usable
 * [driver] id. Every string is length-limited by copy_str(), and the INI
 * parser itself caps sections/keys, so hostile files can't overflow. */
static int parse_descriptor(const char *text, uint32_t len, const char *category_from_dir,
                            const char *path, driver_info_t *out) {
    static ini_document_t doc;   /* ~14 KB: keep it off the kernel stack */
    if(!ini_parse(text, len, &doc)) return 0;

    memset(out, 0, sizeof(*out));
    const char *id = ini_get(&doc, "driver", "id");
    if(!id || !id[0]) return 0;

    copy_str(out->id, sizeof(out->id), id);
    copy_str(out->name, sizeof(out->name), ini_get(&doc, "driver", "name"));
    if(!out->name[0]) copy_str(out->name, sizeof(out->name), id);
    const char *cat = ini_get(&doc, "driver", "category");
    copy_str(out->category, sizeof(out->category), cat && cat[0] ? cat : category_from_dir);
    copy_str(out->version, sizeof(out->version), ini_get(&doc, "driver", "version"));
    copy_str(out->vendor, sizeof(out->vendor), ini_get(&doc, "driver", "vendor"));
    copy_str(out->description, sizeof(out->description), ini_get(&doc, "driver", "description"));
    copy_str(out->pci, sizeof(out->pci), ini_get(&doc, "match", "pci"));
    copy_str(out->path, sizeof(out->path), path);

    int v;
    out->enabled = 1;
    out->priority = 50;
    out->required = 0;
    if(ini_get_int(&doc, "load", "enabled", &v)) out->enabled = v != 0;
    if(ini_get_int(&doc, "load", "priority", &v)) out->priority = v;
    if(ini_get_int(&doc, "load", "required", &v)) out->required = v != 0;
    if(out->required) out->enabled = 1;      /* a required driver can't be switched off */

    for(int s = 0; s < doc.section_count; s++) {
        if(!streq_nocase(doc.sections[s].name, "settings")) continue;
        for(int k = 0; k < doc.sections[s].kv_count && out->setting_count < DRV_MAX_SETTINGS; k++) {
            copy_str(out->setting_key[out->setting_count], sizeof(out->setting_key[0]), doc.sections[s].kv[k].key);
            copy_str(out->setting_val[out->setting_count], sizeof(out->setting_val[0]), doc.sections[s].kv[k].value);
            out->setting_count++;
        }
    }

    out->status = out->enabled ? DRV_STATUS_INSTALLED : DRV_STATUS_DISABLED;
    return 1;
}

void driver_loader_init(void) {
    driver_total = 0;
    static const char *categories[] = { "sound", "input", "display", "system" };

    for(int c = 0; c < 4; c++) {
        char dirpath[32] = "/Drivers/";
        int n = 9;
        for(const char *p = categories[c]; *p && n < 30; p++) dirpath[n++] = *p;
        dirpath[n] = '\0';

        struct directory d;
        if(!fsu_open_dir(dirpath, &d)) continue;

        for(uint32_t i = 0; i < d.num_entries && driver_total < DRV_MAX_DRIVERS; i++) {
            struct dir_entry *e = &d.entries[i];
            if(e->dir_attrs & DIRECTORY) continue;
            const char *ext = fsu_ext(e->name);
            if(!ext || !streq_nocase(ext, ".drv")) continue;
            if(e->file_size == 0 || e->file_size > 8192) continue;   /* descriptors are tiny */

            char path[64]; int pn = 0;
            for(const char *p = dirpath; *p && pn < 40; p++) path[pn++] = *p;
            path[pn++] = '/';
            for(const char *p = e->name; *p && pn < 63; p++) path[pn++] = *p;
            path[pn] = '\0';

            uint32_t size = 0;
            uint8_t *data = fsu_read_file(path, &size);
            if(!data) continue;
            driver_info_t info;
            if(parse_descriptor((const char *)data, size, categories[c], path, &info)) {
                if(find_mut(info.id)) printf("drivers: duplicate id %s in %s ignored\n", info.id, path);
                else drivers[driver_total++] = info;
            }
            else {
                printf("drivers: %s is not a valid driver descriptor\n", path);
            }
            kfree(data);
        }
        free_directory(master_fs, &d);
    }
    printf("drivers: %d descriptor(s) loaded\n", driver_total);
}

int driver_is_enabled(const char *id) {
    const driver_info_t *d = driver_find(id);
    return d ? d->enabled : 1;
}

int driver_priority(const char *id, int default_priority) {
    const driver_info_t *d = driver_find(id);
    return d ? d->priority : default_priority;
}

int driver_setting_int(const char *id, const char *key, int default_value) {
    const driver_info_t *d = driver_find(id);
    if(!d) return default_value;
    for(int i = 0; i < d->setting_count; i++) {
        if(!streq_nocase(d->setting_key[i], key)) continue;
        const char *s = d->setting_val[i];
        int neg = 0, v = 0, any = 0;
        if(*s == '-') { neg = 1; s++; }
        while(*s >= '0' && *s <= '9') { v = v * 10 + (*s - '0'); s++; any = 1; }
        return any ? (neg ? -v : v) : default_value;
    }
    return default_value;
}

void driver_report_status(const char *id, const char *category, const char *name, driver_status_t status) {
    driver_info_t *d = find_mut(id);
    if(!d) {
        if(driver_total >= DRV_MAX_DRIVERS) return;
        d = &drivers[driver_total++];
        memset(d, 0, sizeof(*d));
        copy_str(d->id, sizeof(d->id), id);
        copy_str(d->name, sizeof(d->name), name ? name : id);
        copy_str(d->category, sizeof(d->category), category);
        copy_str(d->description, sizeof(d->description), "Built-in driver (no descriptor file)");
        d->enabled = 1;
        d->priority = 50;
    }
    d->status = status;
}
