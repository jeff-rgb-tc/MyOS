#ifndef TSS_H
#define TSS_H

#include "stdint.h"

/* A minimal Task State Segment. This kernel doesn't use x86 hardware
 * task-switching (each "task" isn't a separate TSS) -- there is exactly
 * one TSS, loaded once with ltr and never task-switched to directly.
 * Its only real job is telling the CPU which ring0 stack (ss0:esp0) to
 * switch to automatically whenever an interrupt or exception fires while
 * the CPU is in ring3. Without this, any interrupt during ring3 code
 * (including the timer IRQ, which fires constantly) has nowhere valid to
 * put its return frame and the machine triple-faults/reboots instead of
 * cleanly trapping back into the kernel. */
struct tss_entry_struct {
    uint32_t prev_tss;
    uint32_t esp0;      // ring0 stack pointer, loaded on a ring3->ring0 privilege change
    uint32_t ss0;        // ring0 stack segment, likewise
    uint32_t esp1;
    uint32_t ss1;
    uint32_t esp2;
    uint32_t ss2;
    uint32_t cr3;
    uint32_t eip;
    uint32_t eflags;
    uint32_t eax, ecx, edx, ebx, esp, ebp, esi, edi;
    uint32_t es, cs, ss, ds, fs, gs;
    uint32_t ldt;
    uint16_t trap;
    uint16_t iomap_base;
} __attribute__((packed));
typedef struct tss_entry_struct tss_entry_t;

/* Sets up the TSS (in the given GDT entry slot -- see gdt.c, which
 * reserves entry 5 for it), points ss0:esp0 at a dedicated static
 * kernel stack, and loads it with ltr. Must run after init_gdt() (it
 * writes into the already-installed GDT) and before the first ring3
 * entry (see enter_usermode() in usermode.h). */
void init_tss(int32_t gdt_entry_index, uint16_t ss0, uint32_t esp0);

/* Updates just esp0 in the already-installed TSS -- called whenever the
 * kernel is about to drop into ring3 for a new app, so a fault/syscall
 * from that app returns onto the correct current kernel stack rather
 * than whatever esp0 happened to be set to at boot. */
void tss_set_kernel_stack(uint32_t esp0);

#endif
