#include "syscall.h"
#include "common.h"
#include "kernio.h"
#include "kheap.h"
#include "gfx.h"
#include "window.h"
#include "mouse.h"
#include "keyboard.h"
#include "pit.h"
#include "isr.h"
#include "rtc.h"
#include "audio.h"
#include "app_loader.h"
#include "desktop.h"
#include "fs_util.h"
#include "clipboard.h"
#include "datetime_util.h"
#include "cursor_set.h"
#include "installer.h"
#include "power.h"
#include "pcspeaker.h"
#include "driver_loader.h"

/* ===========================================================================
 * Syscall layer for .app programs (ABI level 2 -- apps-sdk/include/myos/abi.h)
 *
 * Window model: an app window is a normal desktop window (window_t). Its
 * pixels live in a per-window SURFACE (kernel memory) that the app draws
 * into through the SYS_DRAW_* calls; the window's on_paint just copies the
 * surface to the screen. So window content persists between frames, and
 * all of the desktop's own primitives (rounded rects, AA lines, scaled
 * text...) are available to apps by pointing gfx at the surface for the
 * duration of one call (gfx_target_push).
 *
 * Input model: the desktop already calls each window's on_key / on_click /
 * on_drag / ... hooks; those just append to the window's event queue, which
 * SYS_POLL_EVENT / SYS_WAIT_EVENT drain.
 *
 * Time model: every blocking call runs desktop_pump() in a loop (see
 * app_loader.h), so the desktop stays interactive while the app waits.
 * =========================================================================== */

#if defined(SYSCALL_HOST_SIM) && !defined(SYSCALL_TEST_REALPTR)
/* Host test build: "app memory" is ordinary host memory, so only reject
 * null; the range check below is for the real ring-3 address window. */
static int app_ptr_valid(uint32_t ptr, uint32_t len) { (void)len; return ptr != 0; }
#else
#define APP_MEM_SIZE (MYOS_APP_IMAGE_MAX + MYOS_APP_STACK_SIZE)
static int app_ptr_valid(uint32_t ptr, uint32_t len) {
    if(ptr < MYOS_APP_BASE) return 0;
    if(len > APP_MEM_SIZE) return 0;                       /* guards the subtraction below */
    if(ptr - MYOS_APP_BASE > APP_MEM_SIZE - len) return 0; /* would run past the app's memory */
    return 1;
}
#endif

static int copy_in(void *dst, uint32_t src, uint32_t len) {
    if(!app_ptr_valid(src, len)) return 0;
    memcpy(dst, (const void *)src, len);
    return 1;
}

/* Copies a NUL-terminated app string, reading no further than the app's own
 * memory allows. Returns 1 only if a terminator was found within max_len. */
static int copy_string(uint32_t ptr, char *out, int max_len) {
    if(!app_ptr_valid(ptr, 1)) return 0;
    const char *src = (const char *)ptr;
    for(int i = 0; i < max_len - 1; i++) {
        if(!app_ptr_valid(ptr + (uint32_t)i, 1)) return 0;
        out[i] = src[i];
        if(out[i] == '\0') return 1;
    }
    return 0;
}

/* ---------------------------------------------------------------------- */
/* State of the running app                                               */
/* ---------------------------------------------------------------------- */
#define APP_MAX_WINDOWS 8
#define EVQ_SIZE 64
#define APP_MAX_TIMERS 4
#define SURFACE_BUDGET (32u * 1024u * 1024u)

typedef struct {
    window_t *win;
    uint8_t alive;
    uint8_t closed_by_app;      /* the app itself asked for the close */
    uint8_t focused_seen;
    int cursor;                 /* MYOS_CURSOR_* over the client area */
    uint32_t *surface;
    int sw, sh;
    uint32_t bg;
    int last_mx, last_my;
    myos_event_t q[EVQ_SIZE];
    int q_head, q_tail;
    struct { uint8_t active; uint32_t interval, next; } timers[APP_MAX_TIMERS];
} app_win_t;

static app_win_t aw[APP_MAX_WINDOWS];
static uint32_t surface_bytes = 0;
static uint32_t abi_level = MYOS_ABI_LEVEL;
static uint32_t perms = 0;
static volatile int kill_requested = 0;
static int busy_on = 0;
static int ev_scan_start = 0;
static uint32_t rng_state = 2463534242u;
static uint32_t last_audio_rate = 0, last_audio_channels = 0;

static void cache_invalidate_all(void);

void syscall_reset_state(uint32_t level, uint32_t permissions) {
    memset(aw, 0, sizeof(aw));
    surface_bytes = 0;
    abi_level = level;
    perms = permissions;
    kill_requested = 0;
    busy_on = 0;
    ev_scan_start = 0;
    last_audio_rate = last_audio_channels = 0;
    rng_state ^= pit_get_ms() * 2654435761u;
    if(rng_state == 0) rng_state = 2463534242u;
    cache_invalidate_all();
}

/* One desktop frame, then honour a forced termination (Task Manager's
 * "End task", or the user closing a window the app never answered). */
static void app_pump(void) {
    desktop_pump();
    if(kill_requested) app_exit_return();
}

/* ---------------------------------------------------------------------- */
/* Events                                                                 */
/* ---------------------------------------------------------------------- */
static void push_event(app_win_t *a, int type, int x, int y, int key, int button) {
    int next = (a->q_head + 1) % EVQ_SIZE;
    if(type == MYOS_EV_MOUSE_MOVE && a->q_tail != a->q_head) {
        /* Coalesce: only the latest pointer position matters. */
        int last = (a->q_head + EVQ_SIZE - 1) % EVQ_SIZE;
        if(a->q[last].type == MYOS_EV_MOUSE_MOVE && a->q[last].button == button) {
            a->q[last].x = x; a->q[last].y = y; a->q[last].time_ms = (int32_t)pit_get_ms();
            return;
        }
    }
    if(next == a->q_tail) a->q_tail = (a->q_tail + 1) % EVQ_SIZE;   /* full: drop the oldest */
    myos_event_t *e = &a->q[a->q_head];
    e->type = type;
    e->window = (int32_t)(a - aw);
    e->x = x; e->y = y; e->key = key; e->button = button;
    e->mods = (int32_t)(keyboard_get_modifiers() & 0x0F);
    e->time_ms = (int32_t)pit_get_ms();
    a->q_head = next;
}

static int pop_from(app_win_t *a, myos_event_t *out) {
    if(a->q_tail == a->q_head) return 0;
    *out = a->q[a->q_tail];
    a->q_tail = (a->q_tail + 1) % EVQ_SIZE;
    return 1;
}

static app_win_t *win_arg(uint32_t handle) {
    if(handle >= APP_MAX_WINDOWS || !aw[handle].alive) return NULL;
    return &aw[handle];
}

/* Writes an event to the app in the layout its ABI level expects. */
static int deliver(uint32_t dst, const myos_event_t *e) {
    if(abi_level < 2) {
        myos_event_v1_t v = { e->type, e->x, e->y, e->key };
        if(!app_ptr_valid(dst, sizeof(v))) return 0;
        memcpy((void *)dst, &v, sizeof(v));
        return 1;
    }
    if(!app_ptr_valid(dst, sizeof(*e))) return 0;
    memcpy((void *)dst, e, sizeof(*e));
    return 1;
}

static int next_event(int handle, myos_event_t *out) {
    if(handle == MYOS_ANY_WINDOW) {
        for(int n = 0; n < APP_MAX_WINDOWS; n++) {
            int i = (ev_scan_start + n) % APP_MAX_WINDOWS;
            if(aw[i].alive && pop_from(&aw[i], out)) { ev_scan_start = (i + 1) % APP_MAX_WINDOWS; return 1; }
        }
        return 0;
    }
    app_win_t *a = win_arg((uint32_t)handle);
    return a ? pop_from(a, out) : 0;
}

/* ---------------------------------------------------------------------- */
/* Window hooks (called by the desktop)                                   */
/* ---------------------------------------------------------------------- */
static void surface_fill(uint32_t *p, int n, uint32_t color) {
    for(int i = 0; i < n; i++) p[i] = color;
}

static void aw_paint(window_t *self, int cx, int cy, int cw, int ch) {
    app_win_t *a = (app_win_t *)self->user_data;
    if(!a || !a->alive || cw <= 0 || ch <= 0) return;

    if(cw != a->sw || ch != a->sh) {
        /* The user resized the window: give the app a surface of the new
         * size (keeping what it already drew in the overlapping corner so
         * nothing flashes blank) and tell it to redraw. */
        uint32_t need = (uint32_t)cw * (uint32_t)ch * 4u;
        uint32_t after = surface_bytes - (uint32_t)(a->sw * a->sh * 4) + need;
        if(after <= SURFACE_BUDGET) {
            uint32_t *np = (uint32_t *)kmalloc(need);
            if(np) {
                surface_fill(np, cw * ch, a->bg);
                int ow = a->sw < cw ? a->sw : cw, oh = a->sh < ch ? a->sh : ch;
                for(int y = 0; y < oh; y++) memcpy(np + y * cw, a->surface + y * a->sw, (uint32_t)ow * 4u);
                kfree(a->surface);
                a->surface = np;
                surface_bytes = after;
                a->sw = cw; a->sh = ch;
                push_event(a, MYOS_EV_RESIZE, cw, ch, 0, 0);
            }
        }
    }
    int w = cw < a->sw ? cw : a->sw, h = ch < a->sh ? ch : a->sh;
    gfx_copy_pixels(cx, cy, a->surface, w, h, a->sw);
}

static void aw_key(window_t *self, char c) {
    app_win_t *a = (app_win_t *)self->user_data;
    if(a && a->alive) push_event(a, MYOS_EV_KEY, 0, 0, (int)(uint8_t)c, 0);
}
static void aw_click(window_t *self, int x, int y) {
    app_win_t *a = (app_win_t *)self->user_data;
    if(a && a->alive) { a->last_mx = x; a->last_my = y; push_event(a, MYOS_EV_MOUSE_DOWN, x, y, 0, MYOS_BTN_LEFT); }
}
static void aw_right_click(window_t *self, int x, int y) {
    app_win_t *a = (app_win_t *)self->user_data;
    if(a && a->alive) push_event(a, MYOS_EV_MOUSE_DOWN, x, y, 0, MYOS_BTN_RIGHT);
}
static void aw_drag(window_t *self, int x, int y) {
    app_win_t *a = (app_win_t *)self->user_data;
    if(a && a->alive) { a->last_mx = x; a->last_my = y; push_event(a, MYOS_EV_MOUSE_MOVE, x, y, 0, MYOS_BTN_LEFT); }
}
static void aw_mouse_up(window_t *self, int x, int y) {
    app_win_t *a = (app_win_t *)self->user_data;
    if(a && a->alive) push_event(a, MYOS_EV_MOUSE_UP, x, y, 0, MYOS_BTN_LEFT);
}

static void aw_scroll(window_t *self, int x, int y, int notches) {
    app_win_t *a = (app_win_t *)self->user_data;
    if(a && a->alive) push_event(a, MYOS_EV_WHEEL, x, y, notches, 0);
}

/* The desktop asks this every frame while the pointer hovers the client
 * area, which makes it the natural place to report plain (no-button) mouse
 * movement as well as to say which cursor to show. */
static int aw_cursor_at(window_t *self, int x, int y) {
    app_win_t *a = (app_win_t *)self->user_data;
    if(!a || !a->alive) return 0;
    if(x != a->last_mx || y != a->last_my) {
        a->last_mx = x; a->last_my = y;
        push_event(a, MYOS_EV_MOUSE_MOVE, x, y, 0, 0);
    }
    return a->cursor;
}

/* Per-frame: focus changes and timers. */
static void aw_tick(window_t *self) {
    app_win_t *a = (app_win_t *)self->user_data;
    if(!a || !a->alive) return;

    int focused = (wm_focused_window() == self);
    if(focused != a->focused_seen) {
        a->focused_seen = (uint8_t)focused;
        push_event(a, MYOS_EV_FOCUS, 0, 0, focused, 0);
    }

    uint32_t now = pit_get_ms();
    for(int i = 0; i < APP_MAX_TIMERS; i++) {
        if(!a->timers[i].active) continue;
        if((int32_t)(now - a->timers[i].next) >= 0) {
            push_event(a, MYOS_EV_TIMER, 0, 0, i, 0);
            a->timers[i].next += a->timers[i].interval;
            /* If the app fell far behind, don't fire a burst to catch up. */
            if((int32_t)(now - a->timers[i].next) > (int32_t)(a->timers[i].interval * 4u)) a->timers[i].next = now + a->timers[i].interval;
        }
    }
}

/* The close box is pressed: ask the app (it may want to save first). */
static void aw_close_request(window_t *self) {
    app_win_t *a = (app_win_t *)self->user_data;
    if(a && a->alive) push_event(a, MYOS_EV_CLOSE, 0, 0, 0, 0);
    else wm_destroy_window(self);
}

static void aw_destroy(window_t *self) {
    app_win_t *a = (app_win_t *)self->user_data;
    if(!a || !a->alive) return;
    a->alive = 0;
    if(a->surface) { kfree(a->surface); surface_bytes -= (uint32_t)(a->sw * a->sh * 4); a->surface = NULL; }
    a->win = NULL;
    /* Destroyed by someone else (Task Manager "End task", shutdown...)
     * rather than by the app: the program can no longer do its job, so
     * end it at the next opportunity. */
    if(!a->closed_by_app && app_is_running()) kill_requested = 1;
}

/* ---------------------------------------------------------------------- */
/* Window syscalls                                                        */
/* ---------------------------------------------------------------------- */
static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

static int create_window(const char *title, int x, int y, int cw, int ch, uint32_t flags, uint32_t bg) {
    int slot = -1;
    for(int i = 0; i < APP_MAX_WINDOWS; i++) if(!aw[i].alive) { slot = i; break; }
    if(slot < 0) return MYOS_E_FAIL;

    int sw = (int)gfx_width(), sh = (int)gfx_height();
    cw = clampi(cw, 64, sw - 40);
    ch = clampi(ch, 48, sh - 80);
    uint32_t bytes = (uint32_t)cw * (uint32_t)ch * 4u;
    if(surface_bytes + bytes > SURFACE_BUDGET) return MYOS_E_NOMEM;

    uint32_t *surface = (uint32_t *)kmalloc(bytes);
    if(!surface) return MYOS_E_NOMEM;
    if(bg == 0) bg = 0xFF1E1E22;
    bg |= 0xFF000000u;
    surface_fill(surface, cw * ch, bg);

    int total_w = cw + WM_BORDER * 2;
    int total_h = ch + WM_TITLEBAR_HEIGHT + WM_BORDER;
    int count = 0;
    for(int i = 0; i < APP_MAX_WINDOWS; i++) if(aw[i].alive) count++;
    if((flags & MYOS_WIN_CENTER) || x < 0 || y < 0) {
        x = (sw - total_w) / 2 + count * 28;
        y = (sh - WM_TASKBAR_RESERVED_HEIGHT - total_h) / 2 + count * 28;
        if(x < 0) x = 0;
        if(y < 0) y = 0;
    }

    window_t *win = wm_create_window(title, x, y, total_w, total_h, bg);
    if(!win) { kfree(surface); return MYOS_E_FAIL; }

    app_win_t *a = &aw[slot];
    memset(a, 0, sizeof(*a));
    a->win = win;
    a->alive = 1;
    a->surface = surface;
    a->sw = cw; a->sh = ch;
    a->bg = bg;
    a->last_mx = a->last_my = -1;
    surface_bytes += bytes;

    win->user_data = a;
    win->on_paint = aw_paint;
    win->on_key = aw_key;
    win->on_click = aw_click;
    win->on_right_click = aw_right_click;
    win->on_drag = aw_drag;
    win->on_mouse_up = aw_mouse_up;
    win->on_scroll = aw_scroll;
    win->cursor_at = aw_cursor_at;
    win->on_tick = aw_tick;
    win->on_close_request = aw_close_request;
    win->on_destroy = aw_destroy;
    wm_focus(win);
    return slot;
}

static int sys_window_create_ex(uint32_t desc_ptr) {
    myos_window_desc_t d;
    if(!copy_in(&d, desc_ptr, sizeof(d))) return MYOS_E_ARG;
    char title[64];
    if(!copy_string(d.title, title, sizeof(title))) memcpy(title, "App", 4);
    return create_window(title, d.x, d.y, d.w, d.h, d.flags, d.bg_color);
}

static int sys_create_window_v1(uint32_t title_ptr, uint32_t w, uint32_t h) {
    char title[64];
    if(!copy_string(title_ptr, title, sizeof(title))) memcpy(title, "App", 4);
    /* v1 passed the TOTAL window size; convert to a client size. */
    return create_window(title, -1, -1, (int)w - WM_BORDER * 2, (int)h - WM_TITLEBAR_HEIGHT - WM_BORDER, 0, 0xFFC0C0C0);
}

static int sys_window_close(uint32_t handle) {
    app_win_t *a = win_arg(handle);
    if(!a) return MYOS_E_FAIL;
    a->closed_by_app = 1;
    wm_destroy_window(a->win);      /* aw_destroy frees the surface */
    return MYOS_OK;
}

static int sys_window_set_title(uint32_t handle, uint32_t str) {
    app_win_t *a = win_arg(handle);
    char title[64];
    if(!a) return MYOS_E_FAIL;
    if(!copy_string(str, title, sizeof(title))) return MYOS_E_ARG;
    memcpy(a->win->title, title, sizeof(title));
    return MYOS_OK;
}

static int sys_window_get_size(uint32_t handle, uint32_t out) {
    app_win_t *a = win_arg(handle);
    if(!a) return MYOS_E_FAIL;
    myos_size_t s = { a->sw, a->sh };
    if(!app_ptr_valid(out, sizeof(s))) return MYOS_E_ARG;
    memcpy((void *)out, &s, sizeof(s));
    return MYOS_OK;
}

static int sys_window_set_cursor(uint32_t handle, uint32_t kind) {
    app_win_t *a = win_arg(handle);
    if(!a) return MYOS_E_FAIL;
    if(kind >= CURSOR_COUNT || kind == CURSOR_BUSY || kind == CURSOR_WORKING) kind = 0;
    a->cursor = (int)kind;
    return MYOS_OK;
}

static int sys_window_set_timer(uint32_t handle, uint32_t id, uint32_t interval) {
    app_win_t *a = win_arg(handle);
    if(!a || id >= APP_MAX_TIMERS) return MYOS_E_ARG;
    if(interval == 0) { a->timers[id].active = 0; return MYOS_OK; }
    if(interval < 10) interval = 10;                    /* the clock only ticks every 10 ms */
    a->timers[id].active = 1;
    a->timers[id].interval = interval;
    a->timers[id].next = pit_get_ms() + interval;
    return MYOS_OK;
}

/* ---------------------------------------------------------------------- */
/* Drawing -- always into the window's surface, clipped to it             */
/* ---------------------------------------------------------------------- */
#define BEGIN_DRAW(a) gfx_target_push((a)->surface, (a)->sw, (a)->sh)
#define END_DRAW() gfx_target_pop()

static int sys_draw_clear(uint32_t handle, uint32_t color) {
    app_win_t *a = win_arg(handle);
    if(!a) return MYOS_E_FAIL;
    BEGIN_DRAW(a); gfx_fill_rect(0, 0, a->sw, a->sh, color | 0xFF000000u); END_DRAW();
    return MYOS_OK;
}

static int sys_fill_rect(uint32_t handle, uint32_t ptr, uint32_t color) {
    app_win_t *a = win_arg(handle);
    myos_rect_t r;
    if(!a) return MYOS_E_FAIL;
    if(!copy_in(&r, ptr, sizeof(r))) return MYOS_E_ARG;
    BEGIN_DRAW(a);
    if((color >> 24) == 0xFF || (color >> 24) == 0) gfx_fill_rect(r.x, r.y, r.w, r.h, color);
    else gfx_blend_rounded_rect(r.x, r.y, r.w, r.h, 0, color);
    END_DRAW();
    return MYOS_OK;
}

static int sys_draw_string(uint32_t handle, uint32_t point_ptr, uint32_t str, uint32_t color) {
    app_win_t *a = win_arg(handle);
    myos_point_t p;
    char text[256];
    if(!a) return MYOS_E_FAIL;
    if(!copy_in(&p, point_ptr, sizeof(p)) || !copy_string(str, text, sizeof(text))) return MYOS_E_ARG;
    BEGIN_DRAW(a); gfx_draw_string(p.x, p.y, text, color); END_DRAW();
    return MYOS_OK;
}

static int sys_draw_round_rect(uint32_t handle, uint32_t ptr) {
    app_win_t *a = win_arg(handle);
    myos_round_rect_t r;
    if(!a) return MYOS_E_FAIL;
    if(!copy_in(&r, ptr, sizeof(r))) return MYOS_E_ARG;
    BEGIN_DRAW(a);
    gfx_blend_rounded_rect_ex(r.x, r.y, r.w, r.h, r.radius, r.color, r.corners ? r.corners : MYOS_CORNER_ALL);
    END_DRAW();
    return MYOS_OK;
}

static int sys_draw_outline(uint32_t handle, uint32_t ptr) {
    app_win_t *a = win_arg(handle);
    myos_outline_t o;
    if(!a) return MYOS_E_FAIL;
    if(!copy_in(&o, ptr, sizeof(o))) return MYOS_E_ARG;
    BEGIN_DRAW(a);
    if(o.radius > 0) gfx_draw_rounded_outline(o.x, o.y, o.w, o.h, o.radius, o.color);
    else gfx_draw_rect(o.x, o.y, o.w, o.h, o.color);
    END_DRAW();
    return MYOS_OK;
}

static int sys_draw_line(uint32_t handle, uint32_t ptr) {
    app_win_t *a = win_arg(handle);
    myos_line_t l;
    if(!a) return MYOS_E_FAIL;
    if(!copy_in(&l, ptr, sizeof(l))) return MYOS_E_ARG;
    if(l.width < 1) l.width = 1;
    BEGIN_DRAW(a);
    gfx_draw_line_thick(l.x0 / 16.0, l.y0 / 16.0, l.x1 / 16.0, l.y1 / 16.0, l.width / 16.0, l.color);
    END_DRAW();
    return MYOS_OK;
}

static int sys_draw_circle(uint32_t handle, uint32_t ptr) {
    app_win_t *a = win_arg(handle);
    myos_circle_t c;
    if(!a) return MYOS_E_FAIL;
    if(!copy_in(&c, ptr, sizeof(c))) return MYOS_E_ARG;
    if(c.r > 2048) return MYOS_E_ARG;
    BEGIN_DRAW(a); gfx_fill_circle(c.cx, c.cy, c.r, c.color); END_DRAW();
    return MYOS_OK;
}

static int sys_draw_text(uint32_t handle, uint32_t ptr) {
    app_win_t *a = win_arg(handle);
    myos_text_t t;
    char text[256];
    if(!a) return MYOS_E_FAIL;
    if(!copy_in(&t, ptr, sizeof(t)) || !copy_string(t.text, text, sizeof(text))) return MYOS_E_ARG;
    int scale = clampi(t.scale, 1, 8);
    BEGIN_DRAW(a);
    if(scale == 1) gfx_draw_string(t.x, t.y, text, t.color);
    else gfx_draw_string_scaled(t.x, t.y, text, t.color, scale);
    END_DRAW();
    return MYOS_OK;
}

static int sys_draw_blit(uint32_t handle, uint32_t ptr) {
    app_win_t *a = win_arg(handle);
    myos_blit_t b;
    if(!a) return MYOS_E_FAIL;
    if(!copy_in(&b, ptr, sizeof(b))) return MYOS_E_ARG;
    if(b.w <= 0 || b.h <= 0 || b.w > 4096 || b.h > 4096) return MYOS_E_ARG;
    if(b.stride < b.w) b.stride = b.w;
    uint32_t bytes = (uint32_t)b.stride * (uint32_t)b.h * 4u;
    if(!app_ptr_valid(b.pixels, bytes)) return MYOS_E_ARG;
    const uint32_t *src = (const uint32_t *)b.pixels;
    BEGIN_DRAW(a);
    if(b.flags & MYOS_BLIT_ALPHA) {
        for(int row = 0; row < b.h; row++) gfx_blit_argb(b.x, b.y + row, src + row * b.stride, b.w, 1, 0, 0);
    }
    else {
        gfx_copy_pixels(b.x, b.y, src, b.w, b.h, b.stride);
    }
    END_DRAW();
    return MYOS_OK;
}

static int sys_draw_blit_scaled(uint32_t handle, uint32_t ptr) {
    app_win_t *a = win_arg(handle);
    myos_blit_scaled_t b;
    if(!a) return MYOS_E_FAIL;
    if(!copy_in(&b, ptr, sizeof(b))) return MYOS_E_ARG;
    if(b.dst_w <= 0 || b.dst_h <= 0 || b.dst_w > 4096 || b.dst_h > 4096) return MYOS_E_ARG;
    if(b.src_w <= 0 || b.src_h <= 0 || b.src_w > 4096 || b.src_h > 4096) return MYOS_E_ARG;
    if(b.stride != b.src_w) return MYOS_E_ARG;                 /* tightly packed source */
    uint32_t bytes = (uint32_t)b.src_w * (uint32_t)b.src_h * 4u;
    if(!app_ptr_valid(b.pixels, bytes)) return MYOS_E_ARG;
    const uint32_t *src = (const uint32_t *)b.pixels;
    BEGIN_DRAW(a);
    if(b.flags & MYOS_BLIT_ALPHA) gfx_blit_scaled_argb_alpha(b.dst_x, b.dst_y, b.dst_w, b.dst_h, src, b.src_w, b.src_h);
    else gfx_blit_scaled_argb(b.dst_x, b.dst_y, b.dst_w, b.dst_h, src, b.src_w, b.src_h);
    END_DRAW();
    return MYOS_OK;
}

static uint32_t sys_beep(uint32_t freq, uint32_t ms) {
    if(!(perms & MYOS_PERM_AUDIO)) return (uint32_t)MYOS_E_PERM;
    if(freq < 20 || freq > 20000 || ms == 0 || ms > 1000) return (uint32_t)MYOS_E_ARG;
    if(!driver_is_enabled("pcspeaker")) return (uint32_t)MYOS_E_FAIL;
    speaker_beep(freq, ms);
    return MYOS_OK;
}

static uint32_t sys_toast(uint32_t str) {
    char text[80];
    if(!copy_string(str, text, sizeof(text))) return (uint32_t)MYOS_E_ARG;
    desktop_toast(text);
    return MYOS_OK;
}

static int sys_draw_gradient(uint32_t handle, uint32_t ptr) {
    app_win_t *a = win_arg(handle);
    myos_gradient_t g;
    if(!a) return MYOS_E_FAIL;
    if(!copy_in(&g, ptr, sizeof(g))) return MYOS_E_ARG;
    BEGIN_DRAW(a);
    gfx_fill_rounded_gradient(g.x, g.y, g.w, g.h, g.radius, g.top, g.bottom, g.corners ? g.corners : MYOS_CORNER_ALL);
    END_DRAW();
    return MYOS_OK;
}

/* ---------------------------------------------------------------------- */
/* Waiting                                                                */
/* ---------------------------------------------------------------------- */
static uint32_t sys_poll_event(uint32_t handle, uint32_t ev_ptr) {
    myos_event_t e;
    if(next_event((int)handle, &e)) return (uint32_t)deliver(ev_ptr, &e);
    return 0;
}

static uint32_t sys_wait_event(uint32_t handle, uint32_t ev_ptr, uint32_t timeout) {
    uint32_t start = pit_get_ms();
    for(;;) {
        myos_event_t e;
        if(next_event((int)handle, &e)) return (uint32_t)deliver(ev_ptr, &e);
        if(timeout == 0) return 0;
        if(timeout != 0xFFFFFFFFu && (uint32_t)(pit_get_ms() - start) >= timeout) return 0;
        app_pump();
    }
}

static uint32_t sys_sleep_ms(uint32_t ms) {
    uint32_t start = pit_get_ms();
    while((uint32_t)(pit_get_ms() - start) < ms) app_pump();
    app_pump();                           /* always show at least one frame */
    return 1;
}

/* ---------------------------------------------------------------------- */
/* Files -- small caches so byte-range reads and directory walks don't    */
/* re-read the FAT every call                                             */
/* ---------------------------------------------------------------------- */
#define PATH_MAX_LEN 120
#define DIR_CACHE_MAX 128

static struct { char path[PATH_MAX_LEN]; uint8_t *data; uint32_t size; } fcache;
static struct {
    char path[PATH_MAX_LEN]; int count; int valid;
    struct { char name[64]; uint32_t size; uint32_t is_dir; } e[DIR_CACHE_MAX];
} dcache;

static void cache_invalidate_all(void) {
    if(fcache.data) kfree(fcache.data);
    fcache.data = NULL; fcache.path[0] = 0; fcache.size = 0;
    dcache.valid = 0; dcache.count = 0; dcache.path[0] = 0;
}

static int paths_equal(const char *a, const char *b) {
    while(*a && *b) {
        char x = *a++, y = *b++;
        if(x >= 'A' && x <= 'Z') x = (char)(x + 32);
        if(y >= 'A' && y <= 'Z') y = (char)(y + 32);
        if(x != y) return 0;
    }
    return *a == *b;
}

static int starts_with_nocase(const char *s, const char *prefix) {
    while(*prefix) {
        char x = *s++, y = *prefix++;
        if(x >= 'A' && x <= 'Z') x = (char)(x + 32);
        if(y >= 'A' && y <= 'Z') y = (char)(y + 32);
        if(x != y) return 0;
    }
    return 1;
}

/* Absolute paths only, no "." / ".." components (so a path can't walk out
 * of the area a permission grants). */
static int path_ok(const char *p) {
    if(p[0] != '/') return 0;
    for(int i = 0; p[i]; i++) {
        if(p[i] == '.' && p[i + 1] == '.' && (i == 0 || p[i - 1] == '/') && (p[i + 2] == '/' || p[i + 2] == '\0')) return 0;
    }
    return 1;
}

static int write_path_ok(const char *p) {
    return (perms & MYOS_PERM_FILE_WRITE) && path_ok(p) && starts_with_nocase(p, "/Users/");
}

static int read_path_arg(uint32_t ptr, char *out) {
    if(!copy_string(ptr, out, PATH_MAX_LEN)) return 0;
    return path_ok(out);
}

static uint32_t sys_file_read(uint32_t io_ptr) {
    myos_file_io_t io;
    char path[PATH_MAX_LEN];
    if(!copy_in(&io, io_ptr, sizeof(io))) return (uint32_t)MYOS_E_ARG;
    if(!read_path_arg(io.path, path)) return (uint32_t)MYOS_E_ARG;
    if(!app_ptr_valid(io.buffer, io.length)) return (uint32_t)MYOS_E_ARG;

    if(!fcache.data || !paths_equal(fcache.path, path)) {
        if(fcache.data) kfree(fcache.data);
        fcache.data = NULL; fcache.path[0] = 0;
        uint32_t size = 0;
        uint8_t *d = fsu_read_file(path, &size);
        if(!d) return (uint32_t)MYOS_E_NOENT;
        fcache.data = d; fcache.size = size;
        memcpy(fcache.path, path, PATH_MAX_LEN);
    }
    if(io.offset >= fcache.size) return 0;
    uint32_t n = fcache.size - io.offset;
    if(n > io.length) n = io.length;
    memcpy((void *)io.buffer, fcache.data + io.offset, n);
    return n;
}

static uint32_t sys_file_write(uint32_t io_ptr) {
    myos_file_io_t io;
    char path[PATH_MAX_LEN];
    if(!copy_in(&io, io_ptr, sizeof(io))) return (uint32_t)MYOS_E_ARG;
    if(!copy_string(io.path, path, sizeof(path))) return (uint32_t)MYOS_E_ARG;
    if(!write_path_ok(path)) return (uint32_t)((perms & MYOS_PERM_FILE_WRITE) ? MYOS_E_ARG : MYOS_E_PERM);
    if(io.length > 4u * 1024u * 1024u || !app_ptr_valid(io.buffer, io.length)) return (uint32_t)MYOS_E_ARG;

    int ok;
    if(io.flags & MYOS_FILE_APPEND) {
        uint32_t old_size = 0;
        uint8_t *old = fsu_read_file(path, &old_size);
        uint8_t *all = (uint8_t *)kmalloc(old_size + io.length + 1);
        if(!all) { if(old) kfree(old); return (uint32_t)MYOS_E_NOMEM; }
        if(old) { memcpy(all, old, old_size); kfree(old); } else old_size = 0;
        memcpy(all + old_size, (const void *)io.buffer, io.length);
        ok = fsu_write_file(path, all, old_size + io.length);
        kfree(all);
    }
    else {
        ok = fsu_write_file(path, (const uint8_t *)io.buffer, io.length);
    }
    cache_invalidate_all();
    return ok ? io.length : (uint32_t)MYOS_E_FAIL;
}

static uint32_t sys_file_stat(uint32_t path_ptr, uint32_t out_ptr) {
    char path[PATH_MAX_LEN];
    myos_stat_t st;
    int is_dir = 0; uint32_t size = 0; uint16_t d = 0, t = 0;
    if(!read_path_arg(path_ptr, path) || !app_ptr_valid(out_ptr, sizeof(st))) return (uint32_t)MYOS_E_ARG;
    if(!fsu_stat(path, &is_dir, &size, &d, &t)) return (uint32_t)MYOS_E_NOENT;
    st.size = size; st.is_dir = (uint32_t)is_dir; st.date = d; st.time = t;
    memcpy((void *)out_ptr, &st, sizeof(st));
    return MYOS_OK;
}

static int dcache_load(const char *path) {
    if(dcache.valid && paths_equal(dcache.path, path)) return 1;
    struct directory d;
    if(!fsu_open_dir(path, &d)) return 0;
    dcache.count = 0;
    for(uint32_t i = 0; i < d.num_entries && dcache.count < DIR_CACHE_MAX; i++) {
        struct dir_entry *e = &d.entries[i];
        if(!e->name || e->name[0] == '\0') continue;
        if(e->name[0] == '.' && (e->name[1] == '\0' || (e->name[1] == '.' && e->name[2] == '\0'))) continue;
        int n = 0;
        while(e->name[n] && n < 63) { dcache.e[dcache.count].name[n] = e->name[n]; n++; }
        dcache.e[dcache.count].name[n] = '\0';
        dcache.e[dcache.count].size = e->file_size;
        dcache.e[dcache.count].is_dir = (e->dir_attrs & DIRECTORY) ? 1 : 0;
        dcache.count++;
    }
    free_directory(master_fs, &d);
    memcpy(dcache.path, path, PATH_MAX_LEN);
    dcache.valid = 1;
    return 1;
}

static uint32_t sys_dir_read(uint32_t path_ptr, uint32_t index, uint32_t out_ptr) {
    char path[PATH_MAX_LEN];
    if(!read_path_arg(path_ptr, path) || !app_ptr_valid(out_ptr, sizeof(myos_dirent_t))) return (uint32_t)MYOS_E_ARG;
    if(!dcache_load(path)) return (uint32_t)MYOS_E_NOENT;
    if((int)index >= dcache.count) return 0;
    myos_dirent_t ent;
    memset(&ent, 0, sizeof(ent));
    memcpy(ent.name, dcache.e[index].name, 64);
    ent.size = dcache.e[index].size;
    ent.is_dir = dcache.e[index].is_dir;
    memcpy((void *)out_ptr, &ent, sizeof(ent));
    return 1;
}

static uint32_t sys_file_delete(uint32_t path_ptr) {
    char path[PATH_MAX_LEN];
    if(!copy_string(path_ptr, path, sizeof(path))) return (uint32_t)MYOS_E_ARG;
    if(!write_path_ok(path)) return (uint32_t)((perms & MYOS_PERM_FILE_WRITE) ? MYOS_E_ARG : MYOS_E_PERM);
    int r = fsu_delete_file(path);
    cache_invalidate_all();
    return r ? MYOS_OK : (uint32_t)MYOS_E_FAIL;
}

static uint32_t sys_dir_create(uint32_t path_ptr) {
    char path[PATH_MAX_LEN];
    if(!copy_string(path_ptr, path, sizeof(path))) return (uint32_t)MYOS_E_ARG;
    if(!write_path_ok(path)) return (uint32_t)((perms & MYOS_PERM_FILE_WRITE) ? MYOS_E_ARG : MYOS_E_PERM);
    int r = fsu_mkdir(path);
    cache_invalidate_all();
    return r ? MYOS_OK : (uint32_t)MYOS_E_FAIL;
}

/* ---------------------------------------------------------------------- */
/* Audio, clipboard, system information                                   */
/* ---------------------------------------------------------------------- */
#define AUDIO_CHUNK 2048
static uint32_t sys_audio_play(uint32_t ptr) {
    myos_audio_t a;
    if(!(perms & MYOS_PERM_AUDIO)) return (uint32_t)MYOS_E_PERM;
    if(!copy_in(&a, ptr, sizeof(a))) return (uint32_t)MYOS_E_ARG;
    if(a.channels < 1 || a.channels > 2 || a.sample_rate < 4000 || a.sample_rate > 96000) return (uint32_t)MYOS_E_ARG;
    if(a.count > 16u * 1024u * 1024u || !app_ptr_valid(a.samples, a.count * 2u)) return (uint32_t)MYOS_E_ARG;
    if(!audio_is_available()) return (uint32_t)MYOS_E_FAIL;

    if(a.sample_rate != last_audio_rate || a.channels != last_audio_channels) {
        audio_set_format(a.sample_rate, (uint8_t)a.channels);
        last_audio_rate = a.sample_rate; last_audio_channels = a.channels;
    }
    static int16_t chunk[AUDIO_CHUNK];
    const int16_t *src = (const int16_t *)a.samples;
    uint32_t done = 0;
    while(done < a.count) {
        /* Wait for room in the card's queue without freezing the desktop. */
        while(!audio_ready_for_more()) app_pump();
        uint32_t n = a.count - done;
        if(n > AUDIO_CHUNK) n = AUDIO_CHUNK;
        n -= n % a.channels;
        if(n == 0) break;
        memcpy(chunk, src + done, n * 2u);
        audio_queue(chunk, n);
        done += n;
    }
    return done;
}

static uint32_t sys_clip_set(uint32_t str) {
    char text[512];
    if(!(perms & MYOS_PERM_CLIPBOARD)) return (uint32_t)MYOS_E_PERM;
    if(!copy_string(str, text, sizeof(text))) return (uint32_t)MYOS_E_ARG;
    clipboard_set_text(text);
    return MYOS_OK;
}

static uint32_t sys_clip_get(uint32_t buf, uint32_t max) {
    if(!(perms & MYOS_PERM_CLIPBOARD)) return (uint32_t)MYOS_E_PERM;
    if(max == 0 || !app_ptr_valid(buf, max)) return (uint32_t)MYOS_E_ARG;
    const char *t = clipboard_get_text();
    uint32_t n = 0;
    while(t[n] && n < max - 1) { ((char *)buf)[n] = t[n]; n++; }
    ((char *)buf)[n] = '\0';
    return n;
}

static uint32_t sys_sysinfo(uint32_t out) {
    myos_sysinfo_t s;
    if(!app_ptr_valid(out, sizeof(s))) return (uint32_t)MYOS_E_ARG;
    memset(&s, 0, sizeof(s));
    uint32_t total = 0, freeb = 0;
    kheap_get_stats(&total, &freeb, NULL);
    s.abi_level = MYOS_ABI_LEVEL;
    s.screen_w = gfx_width(); s.screen_h = gfx_height();
    s.uptime_ms = pit_get_ms();
    s.heap_total_kb = total >> 10; s.heap_free_kb = freeb >> 10;
    s.cpu_percent = (uint32_t)desktop_cpu_usage();
    s.audio_available = (uint32_t)audio_is_available();
    s.window_count = (uint32_t)wm_window_count();
    memcpy(s.os_version, "MyOS 5.0", 9);
    const char *drv = audio_active_driver_name();
    for(int i = 0; drv && drv[i] && i < 23; i++) s.audio_driver[i] = drv[i];
    memcpy((void *)out, &s, sizeof(s));
    return MYOS_OK;
}

static uint32_t sys_datetime(uint32_t out) {
    myos_datetime_t d;
    rtc_time_t t; rtc_date_t dt;
    if(!app_ptr_valid(out, sizeof(d))) return (uint32_t)MYOS_E_ARG;
    rtc_read_time(&t); rtc_read_date(&dt);
    d.year = dt.year; d.month = dt.month; d.day = dt.day;
    d.hour = t.hours; d.minute = t.minutes; d.second = t.seconds;
    d.weekday = dt_weekday(dt.year, dt.month, dt.day);
    d.reserved = 0;
    memcpy((void *)out, &d, sizeof(d));
    return MYOS_OK;
}

static uint32_t sys_random(void) {
    rng_state ^= rng_state << 13;
    rng_state ^= rng_state >> 17;
    rng_state ^= rng_state << 5;
    return rng_state;
}

static uint32_t sys_log(uint32_t str) {
    char text[160];
    if(!copy_string(str, text, sizeof(text))) return (uint32_t)MYOS_E_ARG;
    const char *n = app_loader_current_name();
    printf("[%s] %s\n", n ? n : "app", text);
    return MYOS_OK;
}

static uint32_t sys_set_busy(uint32_t on) {
    if(on && !busy_on) { busy_on = 1; desktop_busy_begin(); }
    else if(!on && busy_on) { busy_on = 0; desktop_busy_end(); }
    return MYOS_OK;
}

void syscall_cleanup_app(void) {
    for(int i = 0; i < APP_MAX_WINDOWS; i++) {
        if(aw[i].alive) {
            aw[i].closed_by_app = 1;        /* we are tearing it down, not a user kill */
            wm_destroy_window(aw[i].win);
        }
    }
    if(busy_on) { busy_on = 0; desktop_busy_end(); }
    audio_flush();
    cache_invalidate_all();
    kill_requested = 0;
}


/* ---------------------------------------------------------------------- */
/* System installer (ABI level 3) -- only for /APPS/installer/installer.app */
/* ---------------------------------------------------------------------- */
static uint32_t sys_disk_count(void) {
    if(!(perms & MYOS_PERM_SYSTEM)) return (uint32_t)MYOS_E_PERM;
    return (uint32_t)installer_disk_count();
}

static uint32_t sys_disk_info(uint32_t index, uint32_t out) {
    myos_diskinfo_t d;
    if(!(perms & MYOS_PERM_SYSTEM)) return (uint32_t)MYOS_E_PERM;
    if(!app_ptr_valid(out, sizeof(d))) return (uint32_t)MYOS_E_ARG;
    int rc = installer_disk_info((int)index, &d);
    if(rc != MYOS_OK) return (uint32_t)rc;
    memcpy((void *)out, &d, sizeof(d));
    return MYOS_OK;
}

static uint32_t sys_install_begin(uint32_t index, uint32_t flags) {
    if(!(perms & MYOS_PERM_SYSTEM)) return (uint32_t)MYOS_E_PERM;
    return (uint32_t)installer_begin((int)index, flags);
}

static uint32_t sys_update_begin(void) {
    if(!(perms & MYOS_PERM_SYSTEM)) return (uint32_t)MYOS_E_PERM;
    return (uint32_t)installer_begin_update();
}

static uint32_t sys_install_step(uint32_t out) {
    myos_install_status_t st;
    if(!(perms & MYOS_PERM_SYSTEM)) return (uint32_t)MYOS_E_PERM;
    if(!app_ptr_valid(out, sizeof(st))) return (uint32_t)MYOS_E_ARG;
    int rc = installer_step(&st);
    memcpy((void *)out, &st, sizeof(st));
    return (uint32_t)rc;
}

/* ---------------------------------------------------------------------- */
/* Dispatcher                                                             */
/* ---------------------------------------------------------------------- */
static uint32_t dispatch_inner(uint32_t num, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t a4) {
    switch(num) {
        case SYS_CREATE_WINDOW:     return (uint32_t)sys_create_window_v1(a1, a2, a3);
        case SYS_FILL_RECT:         return (uint32_t)sys_fill_rect(a1, a2, a3);
        case SYS_DRAW_STRING:       return (uint32_t)sys_draw_string(a1, a2, a3, a4);
        case SYS_PRESENT:
        case SYS_YIELD:             app_pump(); return MYOS_OK;
        case SYS_POLL_EVENT:        return sys_poll_event(a1, a2);
        case SYS_SLEEP_MS:          return sys_sleep_ms(a1);
        case SYS_TICKS_MS:          return pit_get_ms();
        case SYS_SYSINFO:           return sys_sysinfo(a1);
        case SYS_DATETIME:          return sys_datetime(a1);
        case SYS_RANDOM:            return sys_random();
        case SYS_LOG:               return sys_log(a1);
        case SYS_SET_BUSY:          return sys_set_busy(a1);

        case SYS_WINDOW_CREATE_EX:  return (uint32_t)sys_window_create_ex(a1);
        case SYS_WINDOW_CLOSE:      return (uint32_t)sys_window_close(a1);
        case SYS_WINDOW_SET_TITLE:  return (uint32_t)sys_window_set_title(a1, a2);
        case SYS_WINDOW_GET_SIZE:   return (uint32_t)sys_window_get_size(a1, a2);
        case SYS_WINDOW_SET_CURSOR: return (uint32_t)sys_window_set_cursor(a1, a2);
        case SYS_WINDOW_SET_TIMER:  return (uint32_t)sys_window_set_timer(a1, a2, a3);

        case SYS_DRAW_CLEAR:        return (uint32_t)sys_draw_clear(a1, a2);
        case SYS_DRAW_ROUND_RECT:   return (uint32_t)sys_draw_round_rect(a1, a2);
        case SYS_DRAW_OUTLINE:      return (uint32_t)sys_draw_outline(a1, a2);
        case SYS_DRAW_LINE:         return (uint32_t)sys_draw_line(a1, a2);
        case SYS_DRAW_CIRCLE:       return (uint32_t)sys_draw_circle(a1, a2);
        case SYS_DRAW_TEXT:         return (uint32_t)sys_draw_text(a1, a2);
        case SYS_DRAW_BLIT:         return (uint32_t)sys_draw_blit(a1, a2);
        case SYS_DRAW_GRADIENT:     return (uint32_t)sys_draw_gradient(a1, a2);
        case SYS_DRAW_BLIT_SCALED:  return (uint32_t)sys_draw_blit_scaled(a1, a2);
        case SYS_TOAST:             return sys_toast(a1);
        case SYS_BEEP:              return sys_beep(a1, a2);

        case SYS_WAIT_EVENT:        return sys_wait_event(a1, a2, a3);

        case SYS_FILE_READ:         return sys_file_read(a1);
        case SYS_FILE_WRITE:        return sys_file_write(a1);
        case SYS_FILE_STAT:         return sys_file_stat(a1, a2);
        case SYS_DIR_READ:          return sys_dir_read(a1, a2, a3);
        case SYS_FILE_DELETE:       return sys_file_delete(a1);
        case SYS_DIR_CREATE:        return sys_dir_create(a1);

        case SYS_AUDIO_PLAY:        return sys_audio_play(a1);
        case SYS_AUDIO_STOP:        audio_flush(); return MYOS_OK;

        case SYS_CLIP_SET:          return sys_clip_set(a1);
        case SYS_CLIP_GET:          return sys_clip_get(a1, a2);

        case SYS_DISK_COUNT:        return sys_disk_count();
        case SYS_DISK_INFO:         return sys_disk_info(a1, a2);
        case SYS_INSTALL_BEGIN:     return sys_install_begin(a1, a2);
        case SYS_UPDATE_BEGIN:      return sys_update_begin();
        case SYS_INSTALL_STEP:      return sys_install_step(a1);
        case SYS_INSTALL_CANCEL:    if(!(perms & MYOS_PERM_SYSTEM)) return (uint32_t)MYOS_E_PERM;
                                    installer_cancel(); return MYOS_OK;
        case SYS_REBOOT:            if(!(perms & MYOS_PERM_SYSTEM)) return (uint32_t)MYOS_E_PERM;
                                    power_reboot(); return MYOS_OK;
        default:                    return (uint32_t)MYOS_E_ARG;
    }
}

uint32_t syscall_dispatch(uint32_t num, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t a4) {
#ifndef SYSCALL_HOST_SIM
    /* The int 0x80 gate is an interrupt gate (type 0x8E/0xEE), so the CPU
     * enters with IF cleared. Blocking calls run the desktop and wait for
     * timer interrupts, so interrupts must be on for the whole call. */
    __asm__ volatile("sti");
#endif
    app_note_syscall();
    if(num == SYS_EXIT) app_exit_return();

    /* The kernel itself uses the x87 FPU (antialiased lines, circles).
     * Save and restore the app's FPU state around every call so kernel
     * code can never clobber a value the app has in flight. fnsave leaves
     * the FPU initialised, so kernel code starts from a clean stack. */
    uint8_t fpu[108] __attribute__((aligned(16)));
    __asm__ volatile("fnsave %0" : "=m"(fpu));
    uint32_t r = dispatch_inner(num, a1, a2, a3, a4);
    __asm__ volatile("frstor %0" : : "m"(fpu));
    app_note_syscall();
    return r;
}
