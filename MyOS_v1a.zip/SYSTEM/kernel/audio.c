#include "audio.h"
#include "kernio.h"
#include "stddef.h"
#include "ac97.h"
#include "sb16.h"
#include "adlib.h"
#include "gus.h"
#include "driver_loader.h"

static const audio_driver_t *active_driver = NULL;

/* Priority order: AC97 (PCI, the most likely to actually be present
 * under QEMU/VirtualBox/real hardware from the 2000s on -- see
 * ac97.c's own comment on why it was implemented first and most fully),
 * then the legacy ISA devices in roughly their real-world prevalence
 * order for pre-AC97 hardware. */
typedef struct {
    const audio_driver_t *drv;
    const char *id;            /* matches /Drivers/sound/<id>.drv */
    int default_priority;
} builtin_audio_t;

static const builtin_audio_t builtin_audio[] = {
    { &ac97_driver,  "ac97",  100 },
    { &sb16_driver,  "sb16",   80 },
    { &adlib_driver, "adlib",  60 },
    { &gus_driver,   "gus",    40 },
};
#define DRIVER_COUNT (int)(sizeof(builtin_audio) / sizeof(builtin_audio[0]))

/* Picks the sound driver. The built-in order above is only the default:
 * each driver's /Drivers/sound/<id>.drv (see driver_loader.h) can switch
 * it off or change its priority, and a driver with no descriptor behaves
 * exactly as it did before descriptors existed. The first enabled driver
 * (highest priority first) whose hardware answers becomes active; the
 * rest are reported as standby / no hardware / disabled for Task Manager. */
void audio_init(void) {
    int order[DRIVER_COUNT];
    int prio[DRIVER_COUNT];
    int n = 0;

    for(int i = 0; i < DRIVER_COUNT; i++) {
        const builtin_audio_t *b = &builtin_audio[i];
        if(!driver_is_enabled(b->id)) {
            driver_report_status(b->id, "sound", b->drv->name, DRV_STATUS_DISABLED);
            continue;
        }
        int p = driver_priority(b->id, b->default_priority);
        int pos = n;
        while(pos > 0 && prio[pos - 1] < p) {   /* stable insertion sort, high priority first */
            order[pos] = order[pos - 1];
            prio[pos] = prio[pos - 1];
            pos--;
        }
        order[pos] = i;
        prio[pos] = p;
        n++;
    }

    for(int k = 0; k < n; k++) {
        const builtin_audio_t *b = &builtin_audio[order[k]];
        if(active_driver) {
            driver_report_status(b->id, "sound", b->drv->name, DRV_STATUS_STANDBY);
            continue;
        }
        if(b->drv->probe_and_init()) {
            active_driver = b->drv;
            driver_report_status(b->id, "sound", b->drv->name, DRV_STATUS_ACTIVE);
            printf("audio: using %s\n", b->drv->name);
        }
        else {
            driver_report_status(b->id, "sound", b->drv->name, DRV_STATUS_NOT_PRESENT);
        }
    }
    if(!active_driver) printf("audio: no sound hardware found\n");
}

int audio_is_available(void) {
    return active_driver != NULL;
}

const char *audio_active_driver_name(void) {
    return active_driver ? active_driver->name : NULL;
}

void audio_set_format(uint32_t sample_rate, uint8_t channels) {
    if(active_driver) active_driver->set_format(sample_rate, channels);
}

/* Software master volume -- applied to every sample here so volume
 * control works identically on every driver (AC97, SB16, AdLib, GUS),
 * including the legacy ones that have no hardware mixer at all. The
 * hardware mixer (if any) is left at its default level. */
static uint8_t master_volume = 70; /* 0-100 */
static uint8_t master_muted = 0;

#define AUDIO_SCRATCH_SAMPLES 4096
static int16_t audio_scratch[AUDIO_SCRATCH_SAMPLES];

void audio_queue(const int16_t *samples, uint32_t sample_count) {
    if(!active_driver) return;

    if(!master_muted && master_volume >= 100) {
        active_driver->write(samples, sample_count);
        return;
    }

    /* Quadratic-ish curve so the slider feels natural (human loudness
     * perception is roughly logarithmic; a purely linear 0-100 gain
     * sounds like nothing happens in the upper half of the slider). */
    int32_t gain = master_muted ? 0 : ((int32_t)master_volume * (int32_t)master_volume * 256) / 10000; /* 0..256 */

    uint32_t done = 0;
    while(done < sample_count) {
        uint32_t n = sample_count - done;
        if(n > AUDIO_SCRATCH_SAMPLES) n = AUDIO_SCRATCH_SAMPLES;
        for(uint32_t i = 0; i < n; i++) {
            audio_scratch[i] = (int16_t)(((int32_t)samples[done + i] * gain) >> 8);
        }
        active_driver->write(audio_scratch, n);
        done += n;
    }
}

int audio_ready_for_more(void) {
    return active_driver ? active_driver->ready_for_more() : 0;
}

void audio_set_volume(uint8_t volume_percent) {
    if(volume_percent > 100) volume_percent = 100;
    master_volume = volume_percent;
}

uint8_t audio_get_volume(void) {
    return master_volume;
}

void audio_set_muted(int muted) {
    master_muted = muted ? 1 : 0;
}

int audio_is_muted(void) {
    return master_muted;
}

void audio_flush(void) {
    if(active_driver && active_driver->flush) active_driver->flush();
}

void audio_pause(int paused) {
    if(active_driver && active_driver->pause) active_driver->pause(paused);
}
