#ifndef FPU_H
#define FPU_H

/* This kernel had no x87/SSE floating-point support at all before the
 * MP3 decoder (mp3.c, ported from minimp3 -- see that file's own
 * comment) needed real `float` math for the first time anywhere in this
 * codebase. Every floating-point instruction faults with #NM (device
 * not available) until the CPU's FPU state is explicitly initialized --
 * this must run before anything (mp3.c, or anything else added later)
 * executes so much as a single float operation. */
void fpu_init(void);

#endif
