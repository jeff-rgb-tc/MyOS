#ifndef MYOS_SETJMP_H
#define MYOS_SETJMP_H

#include "stdint.h"

/* Minimal x86 setjmp/longjmp, hand-rolled since this freestanding
 * kernel has no libc to provide one. Used by app_loader.c to get back
 * out of run_app() from a completely different call context (a syscall
 * handler running on the TSS's ring0 stack, or a page-fault/GP-fault
 * handler) without unwinding through a normal C return chain -- there
 * is no such chain once control has passed to ring3 via enter_usermode
 * (that's an iret, not a call, so there's nothing for the app to
 * "return" through even if it wanted to). Saves/restores only the
 * callee-saved registers + esp + return eip, which is all a
 * cdecl-conforming non-local jump needs (matches every standard libc
 * jmp_buf implementation for x86 System V / cdecl). */
typedef struct {
    uint32_t ebx, esi, edi, ebp, esp, eip;
} jmp_buf[1];

/* Returns 0 from the direct call; returns whatever value longjmp() was
 * given when control comes back via the non-local jump (never 0 in
 * that case -- longjmp coerces a 0 argument to 1, matching standard
 * setjmp/longjmp semantics, though app_loader.c doesn't rely on that
 * distinction currently). */
int setjmp(jmp_buf env);

/* Never returns to its caller -- control resumes at the setjmp() call
 * site instead, as if setjmp() had just returned `val`. */
void longjmp(jmp_buf env, int val) __attribute__((noreturn));

#endif
