#include "gdt.h"
#include "stdint.h"
#include "tss.h"

// This structure contains the value of one GDT entry.
// We use the attribute 'packed' to tell GCC not to change
// any of the alignment in the structure.
struct gdt_entry_struct
{
    uint16_t limit_low;           // The lower 16 bits of the limit.
    uint16_t base_low;            // The lower 16 bits of the base.
    uint8_t  base_middle;         // The next 8 bits of the base.
    uint8_t  access;              // Access flags, determine what ring this segment can be used in.
    uint8_t  granularity;         // low 4 bits are high 4 bits of limit
    uint8_t  base_high;           // The last 8 bits of the base.
} __attribute__((packed));
typedef struct gdt_entry_struct gdt_entry_t;

struct gdt_ptr_struct
{
    uint16_t limit;               // The upper 16 bits of all selector limits.
    uint32_t base;                // The address of the first gdt_entry_t struct.
}
    __attribute__((packed));
typedef struct gdt_ptr_struct gdt_ptr_t;

// Lets us access our ASM functions from our C code.
//extern void load_gdt(uint32_t);
extern void load_gdt(gdt_ptr_t * gdt_ptr);

// Internal function prototypes.
static void gdt_set_gate(int32_t,uint32_t,uint32_t,uint8_t,uint8_t);

/* 6 entries: null, kernel code, kernel data, user code, user data, TSS.
 * gdt_asm.nasm's gdt_set_tss_gate writes directly into this array from
 * assembly (by symbol name, at entry*8 byte offset), so its size here
 * and TSS_GDT_ENTRY below must stay in sync with what tss.c passes to
 * init_tss(). */
#define TSS_GDT_ENTRY 5
#define GDT_ENTRY_COUNT 6

gdt_entry_t gdt_entries[GDT_ENTRY_COUNT];
gdt_ptr_t   gdt_ptr;
//idt_entry_t idt_entries[256];
//idt_ptr_t   idt_ptr;

/* Dedicated ring0 stack the CPU switches to automatically on any
 * interrupt/exception taken while running ring3 code (see tss.h's
 * comment on why this can't just be the boot stack: the boot stack is
 * still in active use by the kernel's own C call frames whenever a
 * ring3 app is running, since entering ring3 doesn't return from
 * kernel_main -- it's a nested call several frames deep). 16KB is
 * generous for what's just an interrupt entry stack (it only needs to
 * hold whatever the kernel's interrupt handlers use before they either
 * return to ring3 or hand off to the rest of the kernel's normal call
 * stack). */
#define KERNEL_STACK_SIZE 16384
static uint8_t kernel_stack[KERNEL_STACK_SIZE] __attribute__((aligned(16)));

void init_gdt()
{
    gdt_ptr.limit = (sizeof(gdt_entry_t)*GDT_ENTRY_COUNT) - 1;
    gdt_ptr.base = (uint32_t)&gdt_entries;

    /*
      Pr  Priv  1   Ex  DC   RW   Ac
      0x9A == 1001 1010  == 1   00    1   1   0    1    0
      0x92 == 1001 0010  == 1   00    1   0   0    1    0
      0xFA == 1111 1010  == 1   11    1   1   0    1    0
      0xF2 == 1111 0010  == 1   11    1   0   0    1    0

      We have page-granularity and 32-bit mode
      G   D   0   Av
      0xCF == 1100 1111  == 1   1   0   0  ~
    */

    gdt_set_gate(0,0,0,0,0);                    //Null segment
    gdt_set_gate(1, 0, 0xFFFFFFFF, 0x9A, 0xCF); //Code segment
    gdt_set_gate(2, 0, 0xFFFFFFFF, 0x92, 0xCF); //Data segment
    gdt_set_gate(3, 0, 0xFFFFFFFF, 0xFA, 0xCF); //User mode code segment
    gdt_set_gate(4, 0, 0xFFFFFFFF, 0xF2, 0xCF); //User mode data segment
    // Entry 5 (TSS) is written by init_tss() -> gdt_set_tss_gate(), not here --
    // it needs the kernel stack set up below first.

    //terminal_writestring("Flushing GDT.\n");
    load_gdt(&gdt_ptr);

    // ss0 = kernel data selector (0x10); esp0 = top of kernel_stack
    // (stacks grow down, so the initial esp0 is the highest address in
    // the buffer).
    init_tss(TSS_GDT_ENTRY, 0x10, (uint32_t)(kernel_stack + KERNEL_STACK_SIZE));
}

static void gdt_set_gate(int32_t entry, uint32_t base, uint32_t limit, uint8_t access, uint8_t gran)
{
    gdt_entries[entry].base_low = (base & 0xFFFF);
    gdt_entries[entry].base_middle = (base >> 16) & 0xFF;
    gdt_entries[entry].base_high = (base >> 24) & 0xFF;

    gdt_entries[entry].limit_low = (limit & 0xFFFF);
    gdt_entries[entry].granularity = (limit >> 16) & 0x0F;

    gdt_entries[entry].granularity |= gran & 0xF0;
    gdt_entries[entry].access = access;
}
