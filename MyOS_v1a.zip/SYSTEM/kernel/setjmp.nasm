[bits 32]
section .text

; int setjmp(jmp_buf env)
; env is a uint32_t[6] = {ebx, esi, edi, ebp, esp, eip}. esp/eip saved
; here are the values *at the point setjmp was called* -- i.e. the
; caller's own stack pointer and its return address (the instruction
; right after the `call setjmp`), so a later longjmp() resumes execution
; there, in the caller's own frame, exactly as if setjmp() had returned
; again (this time with longjmp's val).
global setjmp
setjmp:
    mov     eax, [esp + 4]      ; env
    mov     [eax + 0], ebx
    mov     [eax + 4], esi
    mov     [eax + 8], edi
    mov     [eax + 12], ebp
    ; caller's esp = our esp right now PLUS the return address slot
    ; (4 bytes) that's about to be popped by our own `ret` -- i.e. what
    ; esp will be in the CALLER's frame immediately after this function
    ; returns.
    lea     ecx, [esp + 4]
    mov     [eax + 16], ecx
    mov     ecx, [esp]          ; return address pushed by `call setjmp`
    mov     [eax + 20], ecx
    xor     eax, eax            ; direct call always returns 0
    ret

; void longjmp(jmp_buf env, int val)
; Restores the saved registers/esp, then jumps to the saved eip -- NOT
; via `ret` (there is no return address to pop; we're jumping into the
; middle of the setjmp() caller's frame, not returning from a call), but
; via an explicit `jmp` to the saved address, after manually placing
; `val` in eax (the register setjmp's caller will see as its "return
; value" the moment execution resumes there).
global longjmp
longjmp:
    mov     eax, [esp + 4]      ; env
    mov     ecx, [esp + 8]      ; val
    test    ecx, ecx
    jnz     .valok
    mov     ecx, 1              ; longjmp(env, 0) behaves as longjmp(env, 1) -- standard semantics
.valok:
    mov     ebx, [eax + 0]
    mov     esi, [eax + 4]
    mov     edi, [eax + 8]
    mov     ebp, [eax + 12]
    mov     esp, [eax + 16]
    mov     edx, [eax + 20]     ; saved eip
    mov     eax, ecx            ; the return-value-to-be, i.e. what ends up in eax at the resume point
    jmp     edx
