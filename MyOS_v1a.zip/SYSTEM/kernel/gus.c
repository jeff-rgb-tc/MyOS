#include "gus.h"
#include "port.h"
#include "kernio.h"
#include "stddef.h"

#define GUS_BASE 0x240
#define GUS_MIX_CTRL       (GUS_BASE + 0x0)
#define GUS_IRQ_STATUS     (GUS_BASE + 0x0E)
#define GUS_TIMER_CTRL     (GUS_BASE + 0x8)
#define GUS_TIMER_DATA     (GUS_BASE + 0x9)
#define GUS_RESET_REG      (GUS_BASE + 0x4C)

static uint8_t gus_present = 0;

/* Standard GUS detection: write the reset register, wait, read it back
 * -- a card that's actually there will latch and return the bits we
 * just set (specifically the master reset + DAC/IRQ enable bits);
 * nothing responds on a port with no GUS behind it. */
static int gus_probe_and_init(void) {
    outb(GUS_RESET_REG, 0x00); /* master reset */
    for(volatile int i = 0; i < 10000; i++) { }
    outb(GUS_RESET_REG, 0x01); /* take out of reset */
    for(volatile int i = 0; i < 10000; i++) { }

    uint8_t status = inb(GUS_RESET_REG);
    if((status & 0x01) == 0) return 0; /* didn't latch -- nothing there */

    outb(GUS_RESET_REG, 0x07); /* out of reset, DAC enabled, IRQ enabled */

    gus_present = 1;
    printf("gus: Gravis UltraSound detected at %x (sample upload/playback not yet implemented)\n", GUS_BASE);
    return 1;
}

/* Not yet implemented -- see gus.h's top comment for the real
 * architectural reason (onboard-RAM sample upload + voice triggering,
 * not a DMA stream). Documented no-ops rather than a silent pretend
 * success, same policy as adlib.c. */
static void gus_set_format(uint32_t sample_rate, uint8_t channels) {
    (void)sample_rate; (void)channels;
}

static void gus_write(const int16_t *samples, uint32_t sample_count) {
    (void)samples; (void)sample_count;
}

static int gus_ready_for_more(void) {
    return gus_present;
}

const audio_driver_t gus_driver = {
    .name = "Gravis UltraSound (detected, playback not yet implemented)",
    .probe_and_init = gus_probe_and_init,
    .set_format = gus_set_format,
    .write = gus_write,
    .ready_for_more = gus_ready_for_more,
    .set_volume = NULL,
};
