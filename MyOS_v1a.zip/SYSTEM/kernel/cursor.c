/*
 * Minimal Windows .cur (cursor) file parser.
 *
 * A .cur file is structurally almost identical to a .ico file:
 *
 *   ICONDIR header (6 bytes):
 *     uint16 reserved (must be 0)
 *     uint16 type (2 == cursor, 1 == icon)
 *     uint16 count (number of images in the file)
 *
 *   Followed by `count` ICONDIRENTRY records (16 bytes each):
 *     uint8  width  (0 means 256)
 *     uint8  height (0 means 256)
 *     uint8  color_count (0 if >= 8bpp)
 *     uint8  reserved
 *     uint16 hotspot_x   (cursor-only; for icons this is "planes")
 *     uint16 hotspot_y   (cursor-only; for icons this is "bit count")
 *     uint32 data_size   (size in bytes of the image data)
 *     uint32 data_offset (offset from start of file to the image data)
 *
 *   The image data itself is a BITMAPINFOHEADER followed by the color
 *   table (if any), the XOR (color) bitmap, and the AND (mask) bitmap.
 *   Note the BITMAPINFOHEADER's biHeight field is DOUBLED versus the
 *   actual image height, because it covers both the XOR and AND masks
 *   stacked together.
 *
 * We support the common cases you'll actually find in the wild:
 *   - 32bpp BGRA with a real per-pixel alpha channel (modern cursors)
 *   - 24bpp BGR plus a 1bpp AND mask (classic cursors)
 *   - 8bpp / 4bpp / 1bpp palettized plus a 1bpp AND mask (legacy cursors)
 *
 * Anything else is rejected gracefully (returns 0) rather than
 * crashing -- callers should fall back to cursor_build_default_arrow().
 */

#include "stdint.h"
#include "stddef.h"
#include "cursor.h"
#include "kheap.h"
#include "common.h"
#include "kernio.h"

#pragma pack(push, 1)
typedef struct {
    uint16_t reserved;
    uint16_t type;
    uint16_t count;
} icondir_t;

typedef struct {
    uint8_t  width;
    uint8_t  height;
    uint8_t  color_count;
    uint8_t  reserved;
    uint16_t hotspot_x;
    uint16_t hotspot_y;
    uint32_t data_size;
    uint32_t data_offset;
} icondirentry_t;

typedef struct {
    uint32_t header_size;
    int32_t  width;
    int32_t  height; /* doubled: XOR + AND masks stacked */
    uint16_t planes;
    uint16_t bpp;
    uint32_t compression;
    uint32_t image_size;
    int32_t  x_ppm;
    int32_t  y_ppm;
    uint32_t colors_used;
    uint32_t colors_important;
} bitmapinfoheader_t;
#pragma pack(pop)

static uint16_t read_u16(const uint8_t *p) {
    return (uint16_t)(p[0] | (p[1] << 8));
}

static uint32_t read_u32(const uint8_t *p) {
    return (uint32_t)(p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24));
}

/* Reads a little-endian struct field-by-field so we don't depend on the
 * compiler's struct layout/endianness for on-disk data, beyond using the
 * packed structs above purely as convenient offset maps. */

int cursor_load_from_memory(const uint8_t *data, uint32_t length, cursor_image_t *out) {
    if(!data || !out || length < sizeof(icondir_t)) {
        return 0;
    }

    memset(out, 0, sizeof(cursor_image_t));

    uint16_t reserved = read_u16(data + 0);
    uint16_t type = read_u16(data + 2);
    uint16_t count = read_u16(data + 4);

    if(reserved != 0 || type != 2 || count == 0) {
        printf("cursor: not a valid .cur file (reserved=%d type=%d count=%d)\n", reserved, type, count);
        return 0;
    }

    if(length < sizeof(icondir_t) + sizeof(icondirentry_t) * (uint32_t)count) {
        printf("cursor: truncated .cur directory\n");
        return 0;
    }

    /* Pick the largest image in the file. Most .cur files made for a
     * single resolution will just have one entry anyway. */
    uint32_t best_index = 0;
    uint32_t best_area = 0;
    for(uint32_t i = 0; i < count; i++) {
        const uint8_t *entry = data + sizeof(icondir_t) + i * sizeof(icondirentry_t);
        uint32_t w = entry[0] == 0 ? 256 : entry[0];
        uint32_t h = entry[1] == 0 ? 256 : entry[1];
        uint32_t area = w * h;
        if(area > best_area) {
            best_area = area;
            best_index = i;
        }
    }

    const uint8_t *entry = data + sizeof(icondir_t) + best_index * sizeof(icondirentry_t);
    uint32_t img_w = entry[0] == 0 ? 256 : entry[0];
    uint32_t img_h = entry[1] == 0 ? 256 : entry[1];
    uint16_t hotspot_x = read_u16(entry + 4);
    uint16_t hotspot_y = read_u16(entry + 6);
    uint32_t data_size = read_u32(entry + 8);
    uint32_t data_offset = read_u32(entry + 12);

    if((uint64_t)data_offset + data_size > length) {
        printf("cursor: image data out of bounds\n");
        return 0;
    }

    const uint8_t *img = data + data_offset;
    if(data_size < 40) {
        printf("cursor: image data too small for BITMAPINFOHEADER\n");
        return 0;
    }

    uint32_t header_size = read_u32(img + 0);
    if(header_size < 40) {
        printf("cursor: unsupported bitmap header size %d\n", header_size);
        return 0;
    }

    int32_t bmp_width = (int32_t)read_u32(img + 4);
    int32_t bmp_height = (int32_t)read_u32(img + 8); /* doubled height */
    uint16_t bpp = read_u16(img + 14);
    uint32_t compression = read_u32(img + 16);

    if(compression != 0 /* BI_RGB */) {
        printf("cursor: compressed cursor bitmaps are not supported\n");
        return 0;
    }

    uint32_t real_height = (uint32_t)(bmp_height / 2);
    uint32_t real_width = (uint32_t)bmp_width;

    if(real_width != img_w || real_height != img_h) {
        /* Trust the bitmap header over the directory entry; some tools
         * write inconsistent width/height bytes in the ICONDIRENTRY. */
        img_w = real_width;
        img_h = real_height;
    }

    if(img_w == 0 || img_h == 0 || img_w > 512 || img_h > 512) {
        printf("cursor: implausible cursor dimensions %dx%d\n", img_w, img_h);
        return 0;
    }

    const uint8_t *pixel_data = img + header_size;

    /* Palette, if present, sits between the header and the pixel data for
     * bpp <= 8. Each entry is 4 bytes (BGRA, alpha unused/0). */
    uint32_t palette_count = 0;
    if(bpp <= 8) {
        palette_count = read_u32(img + 32); /* colors_used */
        if(palette_count == 0) {
            palette_count = 1u << bpp;
        }
        pixel_data = img + header_size + palette_count * 4;
    }
    const uint8_t *palette = img + header_size;

    uint32_t *out_pixels = (uint32_t *)kmalloc(img_w * img_h * sizeof(uint32_t));
    if(!out_pixels) {
        printf("cursor: out of memory allocating %dx%d cursor\n", img_w, img_h);
        return 0;
    }

    /* XOR (color) mask row stride, padded to 4-byte boundary as required
     * by the BMP format. */
    uint32_t xor_row_bytes;
    if(bpp == 32) xor_row_bytes = img_w * 4;
    else if(bpp == 24) xor_row_bytes = img_w * 3;
    else if(bpp == 8) xor_row_bytes = img_w;
    else if(bpp == 4) xor_row_bytes = (img_w + 1) / 2;
    else if(bpp == 1) xor_row_bytes = (img_w + 7) / 8;
    else {
        printf("cursor: unsupported bit depth %d\n", bpp);
        kfree(out_pixels);
        return 0;
    }
    xor_row_bytes = (xor_row_bytes + 3) & ~3u;

    uint32_t xor_size = xor_row_bytes * img_h;
    const uint8_t *and_data = pixel_data + xor_size;
    uint32_t and_row_bytes = ((img_w + 7) / 8 + 3) & ~3u;

    int has_alpha_channel = (bpp == 32);

    /* .cur/.ico bitmaps are stored bottom-up: the first row in the file
     * is the *bottom* row of the image. We write into out_pixels in
     * normal top-down order by flipping the source row index. */
    for(uint32_t y = 0; y < img_h; y++) {
        uint32_t src_row = img_h - 1 - y;
        const uint8_t *xor_row = pixel_data + src_row * xor_row_bytes;
        const uint8_t *and_row = and_data + src_row * and_row_bytes;

        for(uint32_t x = 0; x < img_w; x++) {
            uint8_t r = 0, g = 0, b = 0, a = 255;

            if(bpp == 32) {
                const uint8_t *px = xor_row + x * 4;
                b = px[0]; g = px[1]; r = px[2]; a = px[3];
            }
            else if(bpp == 24) {
                const uint8_t *px = xor_row + x * 3;
                b = px[0]; g = px[1]; r = px[2];
            }
            else if(bpp == 8) {
                uint8_t idx = xor_row[x];
                const uint8_t *pal = palette + idx * 4;
                b = pal[0]; g = pal[1]; r = pal[2];
            }
            else if(bpp == 4) {
                uint8_t byte = xor_row[x / 2];
                uint8_t idx = (x % 2 == 0) ? (byte >> 4) : (byte & 0x0F);
                const uint8_t *pal = palette + idx * 4;
                b = pal[0]; g = pal[1]; r = pal[2];
            }
            else if(bpp == 1) {
                uint8_t byte = xor_row[x / 8];
                uint8_t bit = (byte >> (7 - (x % 8))) & 1;
                const uint8_t *pal = palette + bit * 4;
                b = pal[0]; g = pal[1]; r = pal[2];
            }

            if(!has_alpha_channel) {
                /* Fall back to the AND mask: 1 means "transparent",
                 * 0 means "opaque, use the XOR color". */
                uint8_t and_byte = and_row[x / 8];
                uint8_t and_bit = (and_byte >> (7 - (x % 8))) & 1;
                a = and_bit ? 0 : 255;
            }

            out_pixels[y * img_w + x] = ((uint32_t)a << 24) | ((uint32_t)r << 16) | ((uint32_t)g << 8) | b;
        }
    }

    out->width = (uint16_t)img_w;
    out->height = (uint16_t)img_h;
    out->hotspot_x = hotspot_x;
    out->hotspot_y = hotspot_y;
    out->pixels = out_pixels;

    return 1;
}

void cursor_build_default_arrow(cursor_image_t *out) {
    /* A classic 12x19 arrow glyph, scaled into a 32x32 canvas so it lines
     * up with the resolution most real .cur arrow cursors ship at. '#' is
     * solid black outline, '.' is white fill, ' ' is transparent. This is
     * intentionally similar in silhouette to the standard Windows arrow
     * so swapping in a real .cur later doesn't feel jarring. */
    static const char *glyph[19] = {
        "#                ",
        "##               ",
        "#.#              ",
        "#..#             ",
        "#...#            ",
        "#....#           ",
        "#.....#          ",
        "#......#         ",
        "#.......#        ",
        "#........#       ",
        "#.........#      ",
        "#......#####     ",
        "#...#..#         ",
        "#..# #..#        ",
        "#.#   #..#       ",
        "##     #..#      ",
        "#       #..#     ",
        "         #..#    ",
        "          ##     ",
    };

    const uint32_t w = 17;
    const uint32_t h = 19;

    uint32_t *pixels = (uint32_t *)kmalloc(w * h * sizeof(uint32_t));
    memset(pixels, 0, w * h * sizeof(uint32_t));

    for(uint32_t y = 0; y < h; y++) {
        for(uint32_t x = 0; x < w && glyph[y][x] != '\0'; x++) {
            char c = glyph[y][x];
            uint32_t color;
            if(c == '#') color = 0xFF000000; /* opaque black */
            else if(c == '.') color = 0xFFFFFFFF; /* opaque white */
            else continue; /* leave transparent (0) */
            pixels[y * w + x] = color;
        }
    }

    out->width = (uint16_t)w;
    out->height = (uint16_t)h;
    out->hotspot_x = 0;
    out->hotspot_y = 0;
    out->pixels = pixels;
}

void cursor_free(cursor_image_t *img) {
    if(img && img->pixels) {
        kfree(img->pixels);
        img->pixels = NULL;
    }
}
