/*
 * PS/2 mouse driver.
 *
 * Talks to the "auxiliary device" side of the 8042 PS/2 controller. This is
 * the same controller the keyboard driver (keyboard.c) already initializes
 * partially, but the mouse needs its own enable sequence and its own IRQ
 * (IRQ12, vector 44 once remapped).
 *
 * Packet format (3 bytes/packet in standard PS/2 mode, no scroll wheel):
 *
 *   byte 0: Y-overflow | X-overflow | Y-sign | X-sign | 1 | Middle | Right | Left
 *   byte 1: X movement (signed, relative)
 *   byte 2: Y movement (signed, relative; positive means UP on the wire,
 *           so we negate it to match screen-space where +Y is down)
 */

#include "stdint.h"
#include "mouse.h"
#include "isr.h"
#include "port.h"
#include "kernio.h"
#include "vesa.h"

#define PS2_DATA_PORT    0x60
#define PS2_STATUS_PORT  0x64
#define PS2_COMMAND_PORT 0x64

#define PS2_CMD_ENABLE_AUX       0xA8
#define PS2_CMD_READ_CONFIG      0x20
#define PS2_CMD_WRITE_CONFIG     0x60
#define PS2_CMD_WRITE_TO_AUX     0xD4

#define MOUSE_CMD_SET_DEFAULTS   0xF6
#define MOUSE_CMD_ENABLE_PACKETS 0xF4
#define MOUSE_ACK                0xFA

static mouse_state_t state;

static uint8_t packet[4];
static uint8_t packet_index = 0;
static uint8_t packet_len = 3;      /* 4 once the mouse has agreed to report the wheel */

/* Wait for the controller's input buffer to be clear (safe to write). Real
 * controllers are far slower than emulated ones, hence the generous limits. */
static int ps2_wait_input_clear() {
    for(int timeout = 200000; timeout > 0; timeout--) {
        if((inb(PS2_STATUS_PORT) & 0x02) == 0) {
            return 1;
        }
    }
    return 0;
}

/* Wait for the controller's output buffer to be full (safe to read). */
static int ps2_wait_output_full() {
    for(int timeout = 400000; timeout > 0; timeout--) {
        if(inb(PS2_STATUS_PORT) & 0x01) {
            return 1;
        }
    }
    return 0;
}

static void ps2_write_command(uint8_t cmd) {
    ps2_wait_input_clear();
    outb(PS2_COMMAND_PORT, cmd);
}

static void ps2_write_data(uint8_t data) {
    ps2_wait_input_clear();
    outb(PS2_DATA_PORT, data);
}

/* Returns 1 and stores the byte, or 0 on timeout (the old version returned
 * whatever stale byte was on the port, which made the init sequence lie). */
static int ps2_read_data_t(uint8_t *out) {
    if(!ps2_wait_output_full()) return 0;
    *out = inb(PS2_DATA_PORT);
    return 1;
}

/* An unread byte in the 8042's output buffer stops ALL further interrupts
 * (keyboard and mouse), so nothing may be left behind after initialization. */
static void ps2_flush_output() {
    for(int i = 0; i < 64 && (inb(PS2_STATUS_PORT) & 0x01); i++) {
        (void)inb(PS2_DATA_PORT);
    }
}

/* Sends a byte to the mouse itself (as opposed to the PS/2 controller).
 * Returns 1 if the mouse ACKed (0xFA); retries on "resend" (0xFE). */
static int mouse_write(uint8_t data) {
    for(int attempt = 0; attempt < 3; attempt++) {
        ps2_write_command(PS2_CMD_WRITE_TO_AUX);
        ps2_write_data(data);
        uint8_t r;
        if(!ps2_read_data_t(&r)) return 0;       /* no mouse answered */
        if(r == MOUSE_ACK) return 1;
        if(r != 0xFE) return 0;
    }
    return 0;
}

static void clamp_position() {
    int32_t max_x = (int32_t)get_screen_width() - 1;
    int32_t max_y = (int32_t)get_screen_height() - 1;
    if(max_x < 0) max_x = 0;
    if(max_y < 0) max_y = 0;

    if(state.x < 0) state.x = 0;
    if(state.y < 0) state.y = 0;
    if(state.x > max_x) state.x = max_x;
    if(state.y > max_y) state.y = max_y;
}

/* Pointer speed, in percent (set from the mouse driver's descriptor:
 * /Drivers/input/ps2-mouse.drv, [settings] sensitivity=). The fractional
 * remainder is carried between packets so slow speeds like 50% still
 * move the pointer smoothly instead of dropping odd pixels. */
static int sensitivity_percent = 100;
static int sens_rem_x = 0, sens_rem_y = 0;

void mouse_set_sensitivity(int percent) {
    if(percent < 25) percent = 25;
    if(percent > 400) percent = 400;
    sensitivity_percent = percent;
    sens_rem_x = sens_rem_y = 0;
}

static int scale_delta(int raw, int *rem) {
    if(sensitivity_percent == 100) return raw;
    int total = raw * sensitivity_percent + *rem;
    int out = total / 100;                  /* truncates toward zero, symmetric for +/- */
    *rem = total - out * 100;
    return out;
}

static void process_packet() {
    uint8_t flags = packet[0];

    /* Bit 3 of byte 0 must always be 1 in a well-formed packet. If it's
     * not, we've lost synchronization with the byte stream (e.g. we missed
     * an interrupt) -- drop this packet and resync on the next byte. */
    if((flags & 0x08) == 0) {
        packet_index = 0;
        return;
    }

    int16_t raw_dx = (int16_t)(uint16_t)packet[1];
    int16_t raw_dy = (int16_t)(uint16_t)packet[2];

    if(flags & 0x10) raw_dx -= 256; /* X sign bit */
    if(flags & 0x20) raw_dy -= 256; /* Y sign bit */

    /* X/Y overflow bits: if set, the movement value is garbage. Discard it
     * by zeroing the delta rather than letting the cursor jump wildly. */
    if(flags & 0x40) raw_dx = 0; /* X overflow */
    if(flags & 0x80) raw_dy = 0; /* Y overflow */

    /* Fourth byte (IntelliMouse): low 4 bits are the wheel, signed.
     * Positive = wheel rolled toward the user = scroll down. */
    if(packet_len == 4) {
        int w = packet[3] & 0x0F;
        if(w & 0x08) w -= 16;
        state.wheel = (int16_t)(state.wheel + w);
    }

    state.dx = (int8_t)raw_dx;
    state.dy = (int8_t)raw_dy;

    state.x += scale_delta(raw_dx, &sens_rem_x);
    state.y -= scale_delta(raw_dy, &sens_rem_y); /* PS/2 Y is inverted relative to screen coordinates */

    clamp_position();

    state.prev_buttons = state.buttons;
    state.buttons = flags & 0x07;
    state.updated = 1;
}

static void (*volatile mouse_move_hook)(int x, int y) = 0;
void mouse_set_move_hook(void (*fn)(int x, int y)) { mouse_move_hook = fn; }

static void mouse_consume_byte(uint8_t byte) {
    packet[packet_index++] = byte;
    if(packet_index >= packet_len) {
        packet_index = 0;
        process_packet();
        if(mouse_move_hook) mouse_move_hook(state.x, state.y);   /* pointer follows the hand even if the desktop is stuck */
    }
}

static void mouse_handler(registers_t regs) {
    (void)regs;
    /* Only take the byte if it is really a mouse byte (OBF + AUX set).
     * Otherwise it is a keyboard byte this IRQ must leave alone, or
     * that keypress would be silently eaten and fed into the packet
     * decoder as garbage. */
    for(int i = 0; i < 8 && (inb(PS2_STATUS_PORT) & 0x21) == 0x21; i++) {
        mouse_consume_byte(inb(PS2_DATA_PORT));
    }
}

/* Polled fallback, called whenever the desktop asks for the mouse state: if
 * an IRQ12 was lost (the 8042 raises no new IRQ while a byte is still
 * unread) or never arrives at all (some real machines / USB-legacy
 * emulation), the pointer still moves. Interrupts are off while polling so
 * this cannot race the IRQ handler. */
static void mouse_poll(void) {
    uint32_t flags;
    __asm__ volatile("pushf; pop %0; cli" : "=r"(flags) : : "memory");
    for(int i = 0; i < 16 && (inb(PS2_STATUS_PORT) & 0x21) == 0x21; i++) {
        mouse_consume_byte(inb(PS2_DATA_PORT));
    }
    if(flags & 0x200) __asm__ volatile("sti" : : : "memory");
}

void initialize_mouse() {
    printf("Initializing PS/2 mouse.\n");

    ps2_flush_output();

    /* Enable the auxiliary (mouse) port on the 8042 controller. */
    ps2_write_command(PS2_CMD_ENABLE_AUX);

    /* Enable IRQ12 by setting bit 1 of the controller configuration byte. */
    ps2_write_command(PS2_CMD_READ_CONFIG);
    uint8_t config = 0x47;
    if(!ps2_read_data_t(&config)) printf("PS/2: no answer to 'read config' (mouse)\n");
    config |= 0x02;  /* enable IRQ12 (mouse interrupt) */
    config &= ~0x20; /* ensure mouse clock is enabled (bit 5 = disable when set) */
    ps2_write_command(PS2_CMD_WRITE_CONFIG);
    ps2_write_data(config);
    ps2_flush_output();

    /* Reset the mouse to defaults and enable data reporting (streaming). */
    int have_mouse = mouse_write(MOUSE_CMD_SET_DEFAULTS);
    if(!have_mouse) printf("PS/2 mouse did not ACK 'set defaults' -- no PS/2 mouse (USB mouse without legacy support?)\n");

    /* Ask for the scroll wheel: the "magic" sample-rate sequence 200, 100, 80
     * switches an IntelliMouse-compatible device to ID 3 (4-byte packets).
     * Anything that does not answer with ID 3/4 keeps the plain 3-byte
     * protocol, so this is safe on every mouse. */
    uint8_t mouse_id = 0;
    if(have_mouse) {
        mouse_write(0xF3); mouse_write(200);
        mouse_write(0xF3); mouse_write(100);
        mouse_write(0xF3); mouse_write(80);
        if(mouse_write(0xF2)) {                 /* get device ID (ACK, then the ID byte) */
            ps2_read_data_t(&mouse_id);
        }
        if(mouse_id == 3 || mouse_id == 4) packet_len = 4;
    }
    printf("Mouse ID %d (%s)\n", (int)mouse_id, packet_len == 4 ? "scroll wheel" : "no wheel");

    mouse_write(MOUSE_CMD_ENABLE_PACKETS);

    /* Start the cursor in the middle of the screen if we know the
     * resolution already (set_vmode() should have run before this). */
    uint32_t w = get_screen_width();
    uint32_t h = get_screen_height();
    state.x = (w > 0) ? (int32_t)(w / 2) : 0;
    state.y = (h > 0) ? (int32_t)(h / 2) : 0;
    state.buttons = 0;
    state.prev_buttons = 0;
    state.updated = 1;

    packet_index = 0;

    /* Anything still in the output buffer (late ACK, first movement packet)
     * would block every further interrupt. */
    ps2_flush_output();

    register_interrupt_handler(IRQ12, mouse_handler);

    printf("Mouse ready to go!\n\n");
}

mouse_state_t *mouse_get_state() {
    mouse_poll();
    return &state;
}

int mouse_button_down(uint8_t button) {
    return (state.buttons & button) != 0;
}

int mouse_button_pressed(uint8_t button) {
    return ((state.buttons & button) != 0) && ((state.prev_buttons & button) == 0);
}

int mouse_button_released(uint8_t button) {
    return ((state.buttons & button) == 0) && ((state.prev_buttons & button) != 0);
}
