#ifndef INFLATE_H
#define INFLATE_H

#include "stdint.h"

/* Minimal DEFLATE (RFC 1951) decompressor, written from scratch since the
 * kernel has no libz and PNG (and therefore .ico files with PNG-encoded
 * layers) needs it. Supports stored, fixed-Huffman, and dynamic-Huffman
 * blocks -- i.e. the full DEFLATE format, since real-world PNG encoders
 * use all three depending on content.
 *
 * This does NOT implement the 2-byte zlib header/Adler32 trailer (RFC
 * 1950) -- that's handled separately in zlib_inflate() below, since PNG's
 * IDAT stream is zlib-wrapped DEFLATE data.
 */

/* Decompresses raw DEFLATE data (no zlib wrapper). `out` must be
 * pre-allocated with at least `out_capacity` bytes; the caller is
 * expected to know (or over-estimate) the decompressed size in advance,
 * which for PNG is derivable from width/height/bit-depth/color-type.
 * Returns the number of bytes actually written to `out`, or 0 on any
 * malformed-stream error. */
uint32_t inflate_raw(const uint8_t *in, uint32_t in_len, uint8_t *out, uint32_t out_capacity);

/* Decompresses a zlib-wrapped DEFLATE stream (2-byte header + deflate
 * data + 4-byte Adler32, per RFC 1950) -- this is the format PNG's IDAT
 * chunks actually use. Adler32 is parsed but not verified (we trust the
 * file rather than reject otherwise-decodable images over a checksum
 * mismatch, matching how most lenient decoders behave for icons/assets
 * shipped by the OS itself rather than untrusted network input).
 * Returns bytes written, or 0 on error. */
uint32_t zlib_inflate(const uint8_t *in, uint32_t in_len, uint8_t *out, uint32_t out_capacity);

#endif
