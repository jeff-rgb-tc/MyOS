#include "cpuinfo.h"
#include "stdint.h"

static void cpuid(uint32_t leaf, uint32_t *a, uint32_t *b, uint32_t *c, uint32_t *d) {
    __asm__ volatile("cpuid" : "=a"(*a), "=b"(*b), "=c"(*c), "=d"(*d) : "0"(leaf), "2"(0));
}

int cpu_has_cpuid(void) {
    uint32_t f1, f2;
    __asm__ volatile("pushfl; pushfl; popl %0; movl %0, %1; xorl $0x200000, %0; pushl %0; popfl; pushfl; popl %0; popfl"
                     : "=&r"(f1), "=&r"(f2) : : "cc");
    return ((f1 ^ f2) & 0x200000) != 0;
}

int cpu_has_long_mode(void) {
    if(!cpu_has_cpuid()) return 0;
    uint32_t a, b, c, d;
    cpuid(0x80000000u, &a, &b, &c, &d);
    if(a < 0x80000001u) return 0;
    cpuid(0x80000001u, &a, &b, &c, &d);
    return (d >> 29) & 1;
}

void cpu_brand(char out[49]) {
    out[0] = 0;
    if(cpu_has_cpuid()) {
        uint32_t a, b, c, d;
        cpuid(0x80000000u, &a, &b, &c, &d);
        if(a >= 0x80000004u) {
            uint32_t *p = (uint32_t *)out;
            for(uint32_t leaf = 0x80000002u; leaf <= 0x80000004u; leaf++) {
                cpuid(leaf, &a, &b, &c, &d);
                *p++ = a; *p++ = b; *p++ = c; *p++ = d;
            }
            out[48] = 0;
            int s = 0; while(out[s] == ' ') s++;               /* trim leading blanks */
            if(s) { int i = 0; while(out[s + i]) { out[i] = out[s + i]; i++; } out[i] = 0; }
            if(out[0]) return;
        }
    }
    const char *u = "Unknown processor"; int i = 0;
    while(u[i]) { out[i] = u[i]; i++; }
    out[i] = 0;
}
