#include "serial.h"
#include "port.h"
#include "terminal.h"
#include "stdint.h"

#define COM1 0x3F8

static int serial_ok = 0;
static void (*real_putchar)(char c) = 0;

int serial_init(void) {
    outb(COM1 + 1, 0x00);          /* no interrupts: we only poll */
    outb(COM1 + 3, 0x80);          /* DLAB on */
    outb(COM1 + 0, 0x01);          /* divisor 1 = 115200 baud */
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x03);          /* 8 bits, no parity, one stop bit */
    outb(COM1 + 2, 0xC7);          /* enable + clear FIFOs */
    outb(COM1 + 4, 0x1E);          /* loopback self-test */
    outb(COM1 + 0, 0xAE);
    if(inb(COM1 + 0) != 0xAE) { serial_ok = 0; return 0; }
    outb(COM1 + 4, 0x0F);          /* normal operation, RTS/DTR set */
    serial_ok = 1;
    return 1;
}

void serial_write_char(char c) {
    if(!serial_ok) return;
    if(c == '\n') serial_write_char('\r');
    for(int i = 0; i < 20000; i++) if(inb(COM1 + 5) & 0x20) break;     /* transmitter empty (bounded wait) */
    outb(COM1, (uint8_t)c);
}

void serial_write(const char *s) { while(*s) serial_write_char(*s++); }

static void tee_putchar(char c) {
    serial_write_char(c);
    if(real_putchar) real_putchar(c);
}

void serial_install_tee(void) {
    if(!serial_ok || terminal_putchar == tee_putchar) return;
    real_putchar = terminal_putchar;
    terminal_putchar = tee_putchar;
}

void serial_disable(void) { serial_ok = 0; }
int serial_present(void) { return serial_ok; }
