#include "common.h"
#include "kernio.h"
#include "terminal.h"
#include "vesa.h"
#include "kheap.h"

extern void halt();

void *memset(void *p, int c, size_t count)
{
    /* rep stosl for the bulk (4 bytes/iteration), rep stosb for the tail --
     * several times faster than a byte loop, especially under QEMU's
     * software CPU emulation where every loop iteration costs real time. */
    void *orig = p;
    uint32_t v = (uint8_t)c;
    v |= v << 8; v |= v << 16;
    size_t dwords = count >> 2;
    size_t tail = count & 3;
    __asm__ volatile("rep stosl" : "+D"(p), "+c"(dwords) : "a"(v) : "memory");
    __asm__ volatile("rep stosb" : "+D"(p), "+c"(tail) : "a"(v) : "memory");
    return orig;
}

void *memcpy(void *dest, const void *src, size_t n) {
    void *orig = dest;
    size_t dwords = n >> 2;
    size_t tail = n & 3;
    __asm__ volatile("rep movsl" : "+D"(dest), "+S"(src), "+c"(dwords) : : "memory");
    __asm__ volatile("rep movsb" : "+D"(dest), "+S"(src), "+c"(tail) : : "memory");
    return orig;
}

int memcmp(const void *s1, const void *s2, size_t n) {
    const unsigned char *a = s1;
    const unsigned char *b = s2;

    for(size_t i = 0; i < n; i++) {
        if(a[i] != b[i]) {
            return (int)a[i] - (int)b[i];
        }
    }

    return 0;
}

int k_toupper(int c) {
    if(c >= 97 && c <= 122) {
        return c - 32;
    }
    return c;
}
int k_tolower(int c) {
    if(c >=65 && c <= 90) {
        return c + 32;
    }
    return c;
}

char * itos(uint32_t myint, char buffer[], int bufflen)
{
    int i = bufflen - 2;
    buffer[bufflen-1] = 0;

    if(myint == 0) {
        buffer[i--] = '0';
    }

    while(myint > 0 && i >= 0)
    {
        buffer[i--] = (myint % 10) + '0';
        myint/=10;
    }

    return &buffer[i+1];
}

size_t strlen(const char* str) {
    size_t ret = 0;
    while ( str[ret] != 0 )
        ret++;
    return ret;
}

int strcmp(const char *s1, const char *s2) {
    while(*s1 && *s2) {
        if(*s1 != *s2) {
            return s1 - s2;
        }
        s1++;
        s2++;
    }
    if(*s1) return 1;
    if(*s2) return -1;
    return 0;
}

/* Case-insensitive compare. FAT32 short (8.3) directory entries are
 * always stored upper-case regardless of the case mtools/mcopy was
 * given on the host side, and are only backed by a long-filename
 * entry (which preserves case) when the name doesn't fit 8.3. That
 * means a path lookup using plain strcmp() will silently fail to find
 * any short-name-only file whose on-disk path was typed in lowercase
 * (e.g. "/SYSTEM/res/cursors/default.cur" written by mcopy comes back
 * as "DEFAULT.CUR" from read_dir_entry()) -- fopen() returns NULL,
 * and callers fall back to their "resource not found" defaults with
 * no other symptom. Path/filename matching should always be
 * case-insensitive to match real FAT32 semantics. */
int strcasecmp(const char *s1, const char *s2) {
    while(*s1 && *s2) {
        int c1 = k_toupper((unsigned char)*s1);
        int c2 = k_toupper((unsigned char)*s2);
        if(c1 != c2) {
            return c1 - c2;
        }
        s1++;
        s2++;
    }
    if(*s1) return 1;
    if(*s2) return -1;
    return 0;
}

int strncmp(const char *s1, const char *s2, size_t n) {
    while(n > 0 && *s1 && *s2) {
        if(*s1 != *s2) {
            return (unsigned char)*s1 - (unsigned char)*s2;
        }
        s1++;
        s2++;
        n--;
    }
    if(n == 0) return 0;
    return (unsigned char)*s1 - (unsigned char)*s2;
}

char *strdup(const char *s) {
    char *news = kmalloc(strlen(s) + 1);
    char *temp = news;
    while(*temp++ = *s++);
    return news;
}

char *strchr(const char *s, int c) {
    while(*s) {
        if(*s == c) return s;
        s++;
    }
    return NULL;
}

char *strtok_r(char *str, const char *delim, char **saveptr) {
    char *begin;
    if(str) {
        begin = str;
    }
    else if (*saveptr) {
        begin = *saveptr;
    }
    else {
        return NULL;
    }

    while(strchr(delim, begin[0])) {
        begin++;
    }


    char *next = NULL;
    for(int i = 0; i < strlen(delim); i++) {
        char *temp = strchr(begin, delim[i]);
        if(temp < next || next == NULL) {
            next = temp;
        }
    }
    if(!next) {
        *saveptr = NULL;
        return begin;
    }
    *next = 0;
    *saveptr=next+1;
    return begin;
}

int coerce_int(char *s, uint32_t *val) {
    uint32_t result = 0;

    while(*s && *s != '\n') {
        if(*s >= 48 && *s <= 57) {
            result *= 10;
            result = result + (*s - 48);
        }
        else {
            return 0;
        }
        s++;
    }
    *val = result;
    return 1;
}

uint8_t hex_char(uint8_t byte)
{
    byte = byte & 0x0F;
    if(byte < 0xA)
    {
        char buff[2];
        itos(byte, buff, 2);
        return buff[0];
    }
    else
    {
        switch(byte)
        {
        case 0x0A:
            return 'A';
            break;
        case 0x0B:
            return 'B';
            break;
        case 0x0C:
            return 'C';
            break;
        case 0x0D:
            return 'D';
            break;
        case 0x0E:
            return 'E';
            break;
        case 0x0F:
            return 'F';
            break;
        }
    }
    return 0;
}

void PANIC(char *err) {
    terminal_set_cursor(0, 1);
    set_vesa_color(make_vesa_color(0, 0, 0));
    set_vesa_background(make_vesa_color(255, 0, 0));
//    terminal_setcolor(make_color(COLOR_DARK_GREY, COLOR_BLACK));
//    terminal_settextcolor(make_color(COLOR_RED, COLOR_BLACK));
    printf("PANIC: %s", err);
    halt();
}
