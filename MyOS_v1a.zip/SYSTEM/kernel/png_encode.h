#ifndef PNG_ENCODE_H
#define PNG_ENCODE_H

#include "stdint.h"
#include "fat32.h"

/* Encodes an ARGB8888 buffer (top-down, row-major) into a valid PNG file
 * in memory. Uses uncompressed ("stored") DEFLATE blocks rather than a
 * real Huffman compressor -- the kernel already has a full DEFLATE
 * *decoder* (inflate.c) for reading PNGs, but writing compressed data
 * needs a separate encoder, which is unnecessary complexity for saving
 * small user drawings. The output is still 100% valid, standard PNG:
 * any PNG reader (including our own png.c) can open it, it's just not
 * space-optimal. Color type is always RGBA (truecolor + alpha), 8 bits
 * per channel.
 *
 * Returns a heap-allocated buffer containing the complete .png file
 * (caller must kfree() it) and writes its length to *out_length, or
 * NULL on failure. */
uint8_t *png_encode(const uint32_t *pixels, uint16_t width, uint16_t height, uint32_t *out_length);

/* Convenience wrapper: encodes and writes directly to a file inside the
 * given FAT32 directory. Returns 1 on success, 0 on failure. */
int png_save_to_file(const uint32_t *pixels, uint16_t width, uint16_t height,
                      f32 *fs, struct directory *dir, char *filename);

#endif
