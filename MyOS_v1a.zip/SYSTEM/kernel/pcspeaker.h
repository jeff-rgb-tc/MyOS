#ifndef PCSPEAKER_H
#define PCSPEAKER_H

#include "stdint.h"

/* PC speaker (PIT channel 2). A square-wave beeper that needs no sound card:
 * the fallback when no AC97/SB16 device exists. Emulators that model it
 * (QEMU -audiodev ... -machine pcspk-audiodev=) play it; VirtualBox has none. */
void speaker_tone(uint32_t freq_hz);     /* starts a tone (0 = off) */
void speaker_off(void);
void speaker_beep(uint32_t freq_hz, uint32_t ms);   /* blocking, capped at 1000 ms */

#endif
