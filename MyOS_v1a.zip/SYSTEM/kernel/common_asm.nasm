[bits 32]

section .text
global fastcp

fastcp:
    push    esi
    push    edi
    mov     edi, DWORD [esp + 12]
    mov     esi, DWORD [esp + 16]
    mov     ecx, DWORD [esp + 20]
    mov     edx, ecx
    shr     ecx, 2
    rep     movsd
    mov     ecx, edx
    and     ecx, 3
    rep     movsb
    pop     edi
    pop     esi
    ret
