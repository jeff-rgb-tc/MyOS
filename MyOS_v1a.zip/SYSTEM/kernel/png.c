/*
 * Minimal PNG decoder built on top of inflate.c's DEFLATE implementation.
 *
 * Supports the PNG feature set that real-world icon/asset export tools
 * actually produce: 8-bit-per-channel color types 0 (grayscale), 2
 * (truecolor), 3 (palette), 4 (grayscale+alpha), and 6 (truecolor+alpha),
 * all non-interlaced. Adam7 interlacing and 16-bit-per-channel samples
 * are not implemented -- both are rare for UI assets and would roughly
 * double this file's size for a case we don't expect to hit.
 */

#include "stdint.h"
#include "stddef.h"
#include "png.h"
#include "inflate.h"
#include "kheap.h"
#include "common.h"
#include "kernio.h"
#include "stdio.h"

static uint32_t read_u32be(const uint8_t *p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3];
}

#define PNG_COLOR_GRAY       0
#define PNG_COLOR_TRUECOLOR  2
#define PNG_COLOR_PALETTE    3
#define PNG_COLOR_GRAY_ALPHA 4
#define PNG_COLOR_TRUECOLOR_ALPHA 6

static int channels_for_color_type(uint8_t color_type) {
    switch(color_type) {
        case PNG_COLOR_GRAY: return 1;
        case PNG_COLOR_TRUECOLOR: return 3;
        case PNG_COLOR_PALETTE: return 1;
        case PNG_COLOR_GRAY_ALPHA: return 2;
        case PNG_COLOR_TRUECOLOR_ALPHA: return 4;
        default: return 0;
    }
}

static uint8_t paeth_predictor(uint8_t a, uint8_t b, uint8_t c) {
    int p = (int)a + (int)b - (int)c;
    int pa = p > a ? p - a : a - p;
    int pb = p > b ? p - b : b - p;
    int pc = p > c ? p - c : c - p;
    if(pa <= pb && pa <= pc) return a;
    if(pb <= pc) return b;
    return c;
}

/* Un-filters PNG scanlines in place. `raw` is the inflated IDAT stream:
 * for each of `height` rows, one filter-type byte followed by
 * `bytes_per_row` bytes of filtered sample data. bpp is bytes-per-pixel
 * (used for the filter's "left"/"upper-left" neighbor distance, which is
 * in whole pixels, not sub-byte samples). */
static int unfilter(uint8_t *raw, uint32_t width, uint32_t height, int bytes_per_row, int bpp) {
    int stride = bytes_per_row + 1; /* +1 for the filter-type byte prefix */
    uint8_t *prev_row = NULL;

    for(uint32_t y = 0; y < height; y++) {
        uint8_t *row_with_filter = raw + y * stride;
        uint8_t filter_type = row_with_filter[0];
        uint8_t *row = row_with_filter + 1;

        for(int x = 0; x < bytes_per_row; x++) {
            uint8_t a = (x >= bpp) ? row[x - bpp] : 0;             /* left */
            uint8_t b = prev_row ? prev_row[x] : 0;                 /* up */
            uint8_t c = (prev_row && x >= bpp) ? prev_row[x - bpp] : 0; /* upper-left */

            switch(filter_type) {
                case 0: /* None */
                    break;
                case 1: /* Sub */
                    row[x] = (uint8_t)(row[x] + a);
                    break;
                case 2: /* Up */
                    row[x] = (uint8_t)(row[x] + b);
                    break;
                case 3: /* Average */
                    row[x] = (uint8_t)(row[x] + ((a + b) / 2));
                    break;
                case 4: /* Paeth */
                    row[x] = (uint8_t)(row[x] + paeth_predictor(a, b, c));
                    break;
                default:
                    printf("png: invalid filter type %d on row %d\n", filter_type, y);
                    return 0;
            }
        }

        prev_row = row;
    }

    (void)width;
    return 1;
}

int png_load_from_memory(const uint8_t *data, uint32_t length, png_image_t *out) {
    static const uint8_t PNG_SIGNATURE[8] = {0x89, 'P', 'N', 'G', '\r', '\n', 0x1A, '\n'};

    if(!data || !out || length < 8 || memcmp(data, PNG_SIGNATURE, 8) != 0) {
        printf("png: bad signature\n");
        return 0;
    }

    memset(out, 0, sizeof(png_image_t));

    uint32_t width = 0, height = 0;
    uint8_t bit_depth = 0, color_type = 0, interlace = 0;
    int have_ihdr = 0;

    /* Palette (color type 3): up to 256 RGB entries, plus an optional
     * tRNS chunk of per-entry alpha values. */
    uint8_t palette[256 * 3];
    uint8_t palette_alpha[256];
    int palette_count = 0;
    int has_trns = 0;
    memset(palette_alpha, 255, sizeof(palette_alpha));

    /* IDAT chunks can be split across multiple chunks; concatenate them
     * into one buffer before inflating, per the PNG spec. We don't know
     * the total compressed size up front, so accumulate with a
     * doubling buffer. */
    uint32_t idat_capacity = 65536;
    uint32_t idat_len = 0;
    uint8_t *idat = (uint8_t *)kmalloc(idat_capacity);
    if(!idat) {
        printf("png: out of memory for IDAT buffer\n");
        return 0;
    }

    uint32_t pos = 8;
    while(pos + 8 <= length) {
        uint32_t chunk_len = read_u32be(data + pos);
        const uint8_t *chunk_type = data + pos + 4;
        const uint8_t *chunk_data = data + pos + 8;

        if((uint64_t)pos + 8 + (uint64_t)chunk_len + 4 > length) {
            printf("png: chunk out of bounds\n");
            kfree(idat);
            return 0;
        }

        if(memcmp(chunk_type, "IHDR", 4) == 0) {
            if(chunk_len < 13) { kfree(idat); return 0; }
            width = read_u32be(chunk_data + 0);
            height = read_u32be(chunk_data + 4);
            bit_depth = chunk_data[8];
            color_type = chunk_data[9];
            /* chunk_data[10] = compression method, always 0 */
            /* chunk_data[11] = filter method, always 0 */
            interlace = chunk_data[12];
            have_ihdr = 1;
        }
        else if(memcmp(chunk_type, "PLTE", 4) == 0) {
            palette_count = chunk_len / 3;
            if(palette_count > 256) palette_count = 256;
            fastcp((char *)palette, (char *)chunk_data, palette_count * 3);
        }
        else if(memcmp(chunk_type, "tRNS", 4) == 0) {
            has_trns = 1;
            uint32_t n = chunk_len > 256 ? 256 : chunk_len;
            fastcp((char *)palette_alpha, (char *)chunk_data, n);
        }
        else if(memcmp(chunk_type, "IDAT", 4) == 0) {
            if(idat_len + chunk_len > idat_capacity) {
                uint32_t new_capacity = idat_capacity * 2;
                while(new_capacity < idat_len + chunk_len) new_capacity *= 2;
                uint8_t *new_idat = (uint8_t *)kmalloc(new_capacity);
                if(!new_idat) {
                    printf("png: out of memory growing IDAT buffer\n");
                    kfree(idat);
                    return 0;
                }
                fastcp((char *)new_idat, (char *)idat, idat_len);
                kfree(idat);
                idat = new_idat;
                idat_capacity = new_capacity;
            }
            fastcp((char *)(idat + idat_len), (char *)chunk_data, chunk_len);
            idat_len += chunk_len;
        }
        else if(memcmp(chunk_type, "IEND", 4) == 0) {
            break;
        }
        /* Ancillary chunks (gAMA, sRGB, pHYs, etc) are safely ignored. */

        pos += 8 + chunk_len + 4;
    }

    if(!have_ihdr) {
        printf("png: missing IHDR\n");
        kfree(idat);
        return 0;
    }

    if(bit_depth != 8) {
        printf("png: unsupported bit depth %d (only 8-bit supported)\n", bit_depth);
        kfree(idat);
        return 0;
    }

    if(interlace != 0) {
        printf("png: interlaced PNGs are not supported\n");
        kfree(idat);
        return 0;
    }

    int channels = channels_for_color_type(color_type);
    if(channels == 0) {
        printf("png: unsupported color type %d\n", color_type);
        kfree(idat);
        return 0;
    }

    if(width == 0 || height == 0 || width > 4096 || height > 4096) {
        printf("png: implausible dimensions %dx%d\n", width, height);
        kfree(idat);
        return 0;
    }

    int bytes_per_row = (int)(width * channels); /* 8-bit samples only, so channels == bytes/pixel */
    uint32_t raw_size = (uint32_t)(bytes_per_row + 1) * height;

    uint8_t *raw = (uint8_t *)kmalloc(raw_size);
    if(!raw) {
        printf("png: out of memory for raw scanline buffer (%d bytes)\n", raw_size);
        kfree(idat);
        return 0;
    }

    uint32_t written = zlib_inflate(idat, idat_len, raw, raw_size);
    kfree(idat);

    if(written != raw_size) {
        printf("png: inflate produced %d bytes, expected %d\n", written, raw_size);
        kfree(raw);
        return 0;
    }

    if(!unfilter(raw, width, height, bytes_per_row, channels)) {
        kfree(raw);
        return 0;
    }

    uint32_t *pixels = (uint32_t *)kmalloc(width * height * sizeof(uint32_t));
    if(!pixels) {
        printf("png: out of memory for pixel buffer\n");
        kfree(raw);
        return 0;
    }

    int stride = bytes_per_row + 1;
    for(uint32_t y = 0; y < height; y++) {
        uint8_t *row = raw + y * stride + 1;

        for(uint32_t x = 0; x < width; x++) {
            uint8_t r = 0, g = 0, b = 0, a = 255;

            switch(color_type) {
                case PNG_COLOR_GRAY: {
                    uint8_t v = row[x];
                    r = g = b = v;
                    break;
                }
                case PNG_COLOR_GRAY_ALPHA: {
                    uint8_t v = row[x * 2 + 0];
                    a = row[x * 2 + 1];
                    r = g = b = v;
                    break;
                }
                case PNG_COLOR_TRUECOLOR: {
                    r = row[x * 3 + 0];
                    g = row[x * 3 + 1];
                    b = row[x * 3 + 2];
                    break;
                }
                case PNG_COLOR_TRUECOLOR_ALPHA: {
                    r = row[x * 4 + 0];
                    g = row[x * 4 + 1];
                    b = row[x * 4 + 2];
                    a = row[x * 4 + 3];
                    break;
                }
                case PNG_COLOR_PALETTE: {
                    uint8_t idx = row[x];
                    if(idx < palette_count) {
                        r = palette[idx * 3 + 0];
                        g = palette[idx * 3 + 1];
                        b = palette[idx * 3 + 2];
                    }
                    if(has_trns) {
                        a = palette_alpha[idx];
                    }
                    break;
                }
            }

            pixels[y * width + x] = ((uint32_t)a << 24) | ((uint32_t)r << 16) | ((uint32_t)g << 8) | b;
        }
    }

    kfree(raw);

    out->width = (uint16_t)width;
    out->height = (uint16_t)height;
    out->pixels = pixels;

    return 1;
}

int png_load_from_file(const char *path, png_image_t *out) {
    memset(out, 0, sizeof(png_image_t));

    FILE *f = fopen(path, NULL);
    if(!f) {
        return 0;
    }

    uint32_t capacity = 65536;
    uint32_t total = 0;
    uint8_t *buffer = (uint8_t *)kmalloc(capacity);
    if(!buffer) {
        fclose(f);
        return 0;
    }

    size_t chunk;
    while((chunk = fread(buffer + total, 1, capacity - total, f)) > 0) {
        total += chunk;
        if(total >= capacity) {
            uint32_t new_capacity = capacity * 2;
            uint8_t *new_buffer = (uint8_t *)kmalloc(new_capacity);
            if(!new_buffer) {
                kfree(buffer);
                fclose(f);
                return 0;
            }
            fastcp((char *)new_buffer, (char *)buffer, total);
            kfree(buffer);
            buffer = new_buffer;
            capacity = new_capacity;
        }
    }
    fclose(f);

    int ok = png_load_from_memory(buffer, total, out);
    kfree(buffer);
    return ok;
}

void png_free(png_image_t *img) {
    if(img && img->pixels) {
        kfree(img->pixels);
        img->pixels = NULL;
    }
}
