/*
 * Minimal DEFLATE (RFC 1951) + zlib wrapper (RFC 1950) decompressor.
 *
 * Written from scratch for MyOS since the kernel is freestanding and has
 * no libz. This is a straightforward bit-reader + canonical Huffman
 * decoder; it prioritizes correctness and readability over speed, since
 * it only needs to decode small OS-bundled assets (icons, a background),
 * not arbitrary large/adversarial input.
 */

#include "stdint.h"
#include "stddef.h"
#include "inflate.h"
#include "common.h"
#include "kernio.h"

/* --- bit reader ------------------------------------------------------ */

typedef struct {
    const uint8_t *data;
    uint32_t length;
    uint32_t byte_pos;
    uint32_t bit_pos; /* 0..7, next bit to read within data[byte_pos] */
} bitreader_t;

static void br_init(bitreader_t *br, const uint8_t *data, uint32_t length) {
    br->data = data;
    br->length = length;
    br->byte_pos = 0;
    br->bit_pos = 0;
}

/* Reads a single bit, LSB-first within each byte (DEFLATE bit order).
 * Returns -1 if we've run past the end of input. */
static int br_bit(bitreader_t *br) {
    if(br->byte_pos >= br->length) return -1;
    int bit = (br->data[br->byte_pos] >> br->bit_pos) & 1;
    br->bit_pos++;
    if(br->bit_pos == 8) {
        br->bit_pos = 0;
        br->byte_pos++;
    }
    return bit;
}

/* Reads `count` bits as an unsigned integer, LSB-first (used for
 * "stored" block lengths and Huffman extra-bit fields). */
static int32_t br_bits(bitreader_t *br, int count) {
    int32_t value = 0;
    for(int i = 0; i < count; i++) {
        int bit = br_bit(br);
        if(bit < 0) return -1;
        value |= (bit << i);
    }
    return value;
}

static void br_align_to_byte(bitreader_t *br) {
    if(br->bit_pos != 0) {
        br->bit_pos = 0;
        br->byte_pos++;
    }
}

/* --- canonical Huffman decoding --------------------------------------- */

/* A canonical Huffman table built from a list of code lengths (one per
 * symbol), per the DEFLATE spec's algorithm. We use a simple
 * linear-scan-by-length decode (read one bit at a time, track the
 * running code value, compare against the first/last code of each
 * length) rather than a fast lookup table, since our inputs are tiny. */
#define MAX_HUFF_BITS 15
#define MAX_HUFF_SYMBOLS 288

typedef struct {
    uint16_t counts[MAX_HUFF_BITS + 1]; /* counts[len] = number of codes of that length */
    uint16_t symbols[MAX_HUFF_SYMBOLS]; /* symbols in canonical order */
    int num_symbols;
} huffman_t;

static void huffman_build(huffman_t *h, const uint8_t *lengths, int num_symbols) {
    memset(h->counts, 0, sizeof(h->counts));
    h->num_symbols = num_symbols;

    for(int i = 0; i < num_symbols; i++) {
        h->counts[lengths[i]]++;
    }
    h->counts[0] = 0; /* length 0 means "symbol not used" */

    /* offsets[len] = index into h->symbols[] where codes of that length start */
    uint16_t offsets[MAX_HUFF_BITS + 1];
    offsets[1] = 0;
    for(int len = 1; len < MAX_HUFF_BITS; len++) {
        offsets[len + 1] = offsets[len] + h->counts[len];
    }

    for(int i = 0; i < num_symbols; i++) {
        if(lengths[i] != 0) {
            h->symbols[offsets[lengths[i]]++] = (uint16_t)i;
        }
    }
}

/* Decodes one symbol using the given Huffman table. Returns -1 on a
 * malformed/truncated stream. */
static int huffman_decode(bitreader_t *br, huffman_t *h) {
    int code = 0;
    int first = 0;
    int index = 0;

    for(int len = 1; len <= MAX_HUFF_BITS; len++) {
        int bit = br_bit(br);
        if(bit < 0) return -1;
        code |= bit;

        int count = h->counts[len];
        if(code - first < count) {
            return h->symbols[index + (code - first)];
        }
        index += count;
        first += count;
        first <<= 1;
        code <<= 1;
    }

    return -1; /* ran out of bits without matching any code -- corrupt stream */
}

/* --- DEFLATE block decoding -------------------------------------------- */

/* Length/distance extra-bit tables, straight from RFC 1951 section 3.2.5. */
static const uint16_t length_base[29] = {
    3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258
};
static const uint8_t length_extra[29] = {
    0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0
};
static const uint16_t dist_base[30] = {
    1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,
    1025,1537,2049,3073,4097,6145,8193,12289,16385,24577
};
static const uint8_t dist_extra[30] = {
    0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13
};

typedef struct {
    uint8_t *out;
    uint32_t out_capacity;
    uint32_t out_pos;
} output_buffer_t;

static int emit_byte(output_buffer_t *ob, uint8_t b) {
    if(ob->out_pos >= ob->out_capacity) {
        return 0; /* out of space -- caller under-estimated decompressed size */
    }
    ob->out[ob->out_pos++] = b;
    return 1;
}

static int inflate_block_data(bitreader_t *br, output_buffer_t *ob, huffman_t *lit_table, huffman_t *dist_table) {
    while(1) {
        int symbol = huffman_decode(br, lit_table);
        if(symbol < 0) return 0;

        if(symbol < 256) {
            if(!emit_byte(ob, (uint8_t)symbol)) return 0;
            continue;
        }

        if(symbol == 256) {
            return 1; /* end of block */
        }

        /* Length/distance back-reference. */
        int len_index = symbol - 257;
        if(len_index >= 29) return 0;

        int32_t extra = br_bits(br, length_extra[len_index]);
        if(extra < 0) return 0;
        int length = length_base[len_index] + extra;

        int dist_symbol = huffman_decode(br, dist_table);
        if(dist_symbol < 0 || dist_symbol >= 30) return 0;

        int32_t dist_extra_bits = br_bits(br, dist_extra[dist_symbol]);
        if(dist_extra_bits < 0) return 0;
        int distance = dist_base[dist_symbol] + dist_extra_bits;

        if((uint32_t)distance > ob->out_pos) {
            return 0; /* back-reference points before the start of output -- corrupt */
        }

        uint32_t src = ob->out_pos - distance;
        for(int i = 0; i < length; i++) {
            if(!emit_byte(ob, ob->out[src + i])) return 0;
        }
    }
}

static void build_fixed_tables(huffman_t *lit_table, huffman_t *dist_table) {
    uint8_t lit_lengths[288];
    int i = 0;
    for(; i < 144; i++) lit_lengths[i] = 8;
    for(; i < 256; i++) lit_lengths[i] = 9;
    for(; i < 280; i++) lit_lengths[i] = 7;
    for(; i < 288; i++) lit_lengths[i] = 8;
    huffman_build(lit_table, lit_lengths, 288);

    uint8_t dist_lengths[30];
    for(i = 0; i < 30; i++) dist_lengths[i] = 5;
    huffman_build(dist_table, dist_lengths, 30);
}

static int inflate_dynamic_block(bitreader_t *br, output_buffer_t *ob) {
    int32_t hlit = br_bits(br, 5);
    int32_t hdist = br_bits(br, 5);
    int32_t hclen = br_bits(br, 4);
    if(hlit < 0 || hdist < 0 || hclen < 0) return 0;

    hlit += 257;
    hdist += 1;
    hclen += 4;

    static const uint8_t clen_order[19] = {
        16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15
    };

    uint8_t clen_lengths[19];
    memset(clen_lengths, 0, sizeof(clen_lengths));
    for(int i = 0; i < hclen; i++) {
        int32_t v = br_bits(br, 3);
        if(v < 0) return 0;
        clen_lengths[clen_order[i]] = (uint8_t)v;
    }

    huffman_t clen_table;
    huffman_build(&clen_table, clen_lengths, 19);

    uint8_t all_lengths[288 + 30];
    memset(all_lengths, 0, sizeof(all_lengths));
    int total = hlit + hdist;
    int idx = 0;

    while(idx < total) {
        int symbol = huffman_decode(br, &clen_table);
        if(symbol < 0) return 0;

        if(symbol < 16) {
            all_lengths[idx++] = (uint8_t)symbol;
        }
        else if(symbol == 16) {
            if(idx == 0) return 0;
            int32_t repeat = br_bits(br, 2);
            if(repeat < 0) return 0;
            repeat += 3;
            uint8_t prev = all_lengths[idx - 1];
            while(repeat-- > 0 && idx < total) all_lengths[idx++] = prev;
        }
        else if(symbol == 17) {
            int32_t repeat = br_bits(br, 3);
            if(repeat < 0) return 0;
            repeat += 3;
            while(repeat-- > 0 && idx < total) all_lengths[idx++] = 0;
        }
        else if(symbol == 18) {
            int32_t repeat = br_bits(br, 7);
            if(repeat < 0) return 0;
            repeat += 11;
            while(repeat-- > 0 && idx < total) all_lengths[idx++] = 0;
        }
        else {
            return 0;
        }
    }

    huffman_t lit_table, dist_table;
    huffman_build(&lit_table, all_lengths, hlit);
    huffman_build(&dist_table, all_lengths + hlit, hdist);

    return inflate_block_data(br, ob, &lit_table, &dist_table);
}

uint32_t inflate_raw(const uint8_t *in, uint32_t in_len, uint8_t *out, uint32_t out_capacity) {
    bitreader_t br;
    br_init(&br, in, in_len);

    output_buffer_t ob;
    ob.out = out;
    ob.out_capacity = out_capacity;
    ob.out_pos = 0;

    int final_block;
    do {
        int bfinal = br_bit(&br);
        if(bfinal < 0) return 0;
        final_block = bfinal;

        int32_t btype = br_bits(&br, 2);
        if(btype < 0) return 0;

        if(btype == 0) {
            /* Stored (uncompressed) block. */
            br_align_to_byte(&br);
            if(br.byte_pos + 4 > br.length) return 0;

            uint16_t len = (uint16_t)(br.data[br.byte_pos] | (br.data[br.byte_pos + 1] << 8));
            /* NLEN (one's complement of len) follows but we don't need to
             * verify it -- we trust bundled OS assets rather than treat
             * this as untrusted/adversarial input. */
            br.byte_pos += 4;

            if(br.byte_pos + len > br.length) return 0;
            for(int i = 0; i < len; i++) {
                if(!emit_byte(&ob, br.data[br.byte_pos + i])) return 0;
            }
            br.byte_pos += len;
        }
        else if(btype == 1) {
            huffman_t lit_table, dist_table;
            build_fixed_tables(&lit_table, &dist_table);
            if(!inflate_block_data(&br, &ob, &lit_table, &dist_table)) return 0;
        }
        else if(btype == 2) {
            if(!inflate_dynamic_block(&br, &ob)) return 0;
        }
        else {
            return 0; /* btype == 3 is reserved/invalid */
        }
    } while(!final_block);

    return ob.out_pos;
}

uint32_t zlib_inflate(const uint8_t *in, uint32_t in_len, uint8_t *out, uint32_t out_capacity) {
    if(in_len < 6) {
        printf("zlib_inflate: input too short to contain a zlib header+trailer\n");
        return 0;
    }

    uint8_t cmf = in[0];
    uint8_t method = cmf & 0x0F;
    if(method != 8) {
        printf("zlib_inflate: unsupported compression method %d (expected 8/deflate)\n", method);
        return 0;
    }

    /* Skip the 2-byte zlib header; ignore the trailing 4-byte Adler32
     * (see the header comment for why we don't verify it). */
    return inflate_raw(in + 2, in_len - 2 - 4, out, out_capacity);
}
