#include "stdint.h"
#include "stddef.h"
#include "isr.h"
#include "paging.h"
#include "frame.h"
#include "kernio.h"
#include "kmalloc_early.h"
#include "common.h"
#include "kheap.h"
#include "app_loader.h"

struct page_directory *kernel_directory;
struct page_directory *current_directory;
extern uint32_t placement_address;

uint8_t initialized = 0;

void identity_map(uint32_t address, uint32_t length) {
    uint32_t curr = address & 0xFFFFF000;
    while(curr < address + length) {
        struct page *p = get_page(curr, 1, kernel_directory);
        p->present = 1;
        p->rw = 1;
        p->user = 0;
        p->frame = curr >> 12;
        curr += 0x1000;
    }
}

// Identity-maps [0, placement_address) for the kernel image itself.
// Deliberately re-reads placement_address every iteration (unlike
// identity_map() above, which takes a fixed length) because get_page()
// can itself grow placement_address by allocating a new page table via
// the early allocator as this walks up -- a fixed end computed once at
// entry could leave that freshly-grown tail unmapped.
static void identity_map_kernel_image(void) {
    uint32_t curr = 0;
    while(curr < placement_address) {
        struct page *p = get_page(curr, 1, kernel_directory);
        p->present = 1;
        p->rw = 1;
        p->user = 0;
        p->frame = curr >> 12;
        curr += 0x1000;
    }
}

void initialize_paging(uint32_t total_frames, uint32_t ident_addr, uint32_t ident_len,
                        uint32_t reserved_addr, uint32_t reserved_len) {
    init_frame_allocator(total_frames);

    /* Must happen immediately after init_frame_allocator() and before
     * any alloc_frame() call below (the kernel page tables and identity
     * mapping loop that follow are themselves alloc_frame() calls) --
     * see frame_reserve_range()'s contract in frame.h. */
    if(reserved_len) {
        frame_reserve_range(reserved_addr, reserved_len);
    }

    // Make a page directory for the kernel.
    kernel_directory = (struct page_directory *)e_kmalloc_a(sizeof (struct page_directory));
    memset(kernel_directory, 0, sizeof (struct page_directory));
    current_directory = kernel_directory;

    // Go ahead and allocate all the page tables for the kernel.
    // This is wasteful, but a lot easier than figuring out how to build
    // a kernel page allocator.
    printf("Allocating kernel page tables... ");
    uint32_t i = 0;
    for(i = 0; i < 0xFFFFFFFF;) {
        get_page(i, 1, kernel_directory);
        i += 0x1000 * 1024;
        if(i == 0) {
            break;
        }
    }
    printf("Done\n");
    // We need to identity map (phys addr = virt addr) from
    // 0x0 to the end of used memory, so we can access this
    // transparently, as if paging wasn't enabled.
    //
    // IMPORTANT: this must NOT go through alloc_frame(), because
    // alloc_frame() hands out "the next free physical frame" from
    // end_of_mem -- it has no idea the caller needs physical == virtual.
    // Once frame_reserve_range() above has pushed end_of_mem past 0 (to
    // protect the multiboot module), alloc_frame() starts handing out
    // physical frames far away from the low addresses being mapped here,
    // so page tables end up pointing kernel code's virtual addresses at
    // physical memory that has nothing to do with the kernel image. The
    // kernel keeps running fine right up until switch_page_directory()
    // turns paging on, at which point the very next instruction fetch
    // (still at a low virtual address like the code here) resolves to
    // that unrelated physical frame instead of the real code -- a page
    // fault with no usable handler in place yet, escalating straight to
    // a triple fault. identity_map_kernel_image() (above) sets
    // page->frame directly from the address instead of going through
    // the allocator, which is what's actually needed here, and re-reads
    // placement_address every iteration so a page table it has to
    // allocate along the way is covered too.
    identity_map_kernel_image();

    // Before we do anything else, disable the original kmalloc so we don't
    // start leaking into the address space.
    //
    // NOTE: this must stay AFTER every remaining get_page(..., 1, ...)
    // call below (the kheap bootstrap loop, identity_map()) that might
    // still need to allocate a brand-new page table. Until
    // switch_page_directory() actually turns paging on, get_page()'s
    // "need a new table" path goes through the early allocator
    // (e_kmalloc_ap()) rather than the real kmalloc -- disabling it too
    // early made the very first such call PANIC("kmalloc is disabled!"),
    // which looked identical to the black-screen crash from the earlier
    // missing-IDT bug but was really this, an independent ordering bug.
    uint32_t heap_start = placement_address;
    if(heap_start & 0xFFF) {
        heap_start &= 0xFFFFF000;
        heap_start += 0x1000;
    }

    printf("KHEAP_START: %x\n", heap_start);

    // Register our page fault handler before doing any more page-table
    // work below (bootstrapping the kheap pages, identity mapping) --
    // those calls can themselves trigger a page fault (e.g. allocating a
    // new page table via get_page()), and with no handler registered yet
    // that fault has nowhere to go, which is a second, independent path
    // to the same kind of unrecoverable crash as the earlier missing-IDT
    // issue.
    register_interrupt_handler(14, page_fault);

    // bootstrap the kheap with INITIAL_HEAP_PAGE_COUNT pages.
    // Kernel heap pages must be writeable -- initialize_kheap() below
    // writes block headers/footers into this range immediately after
    // paging is turned on. This happened to not fault only because
    // CR0.WP was left clear (so ring-0 writes to read-only pages are
    // allowed); marking the pages writeable here removes the dependency
    // on that.
    for(i = 0; i < INITIAL_HEAP_PAGE_COUNT; i++) {
        alloc_frame(get_page(heap_start + (i * 0x1000), 1, kernel_directory), 1, 1);
    }

    if(ident_addr) {
        identity_map(ident_addr, ident_len);
    }

    /* The multiboot module (the FAT32 disk image) also needs to be
     * identity-mapped. frame_reserve_range() above only keeps the
     * physical allocator from handing these frames out to something
     * else -- it does NOT create page table entries for them. Without
     * this, fat32_set_memory_backend() in kernel.c hands the FAT32 code
     * a raw pointer into a range with no present page-table entries,
     * and the first read/write after paging is enabled takes a page
     * fault here. */
    if(reserved_len) {
        identity_map(reserved_addr, reserved_len);
    }

    // Now that every get_page(..., 1, ...) call that could still need a
    // fresh page table has already run, it's finally safe to cut off the
    // early allocator.
    disable_early_kmalloc();

    // Now, enable paging!
    switch_page_directory(kernel_directory);
    initialized = 1;


    printf("Initializing kheap... ");
    // Set up the kernel heap!
    initialize_kheap(heap_start);
    printf("Done\n");
}

void switch_page_directory(struct page_directory *dir)
{
    current_directory = dir;
    asm volatile("mov %0, %%cr3":: "r"(&dir->tablesPhysical));
    uint32_t cr0;
    asm volatile("mov %%cr0, %0": "=r"(cr0));
    cr0 |= 0x80000000; // Enable paging!
    /* The jmp right after loading CR0 is required, not decorative: on
     * real hardware and in some emulators (this was reproduced under
     * QEMU/TCG), the instruction immediately following the write that
     * sets CR0.PG can still be fetched/decoded under the old
     * (non-paging) addressing assumptions, since enabling paging isn't
     * guaranteed to be a fully serializing operation on its own. A
     * near jump forces the next fetch to happen only after the mode
     * switch has taken full effect. Without it this often manifested
     * as an immediate page fault on the very next instruction, with a
     * garbage-looking CR2 (matching whatever had just been written to
     * CR0) -- textbook symptom of fetching under the wrong mode. */
    asm volatile("mov %0, %%cr0":: "r"(cr0));
    asm volatile("jmp 1f\n1:");
}


struct page *get_page(uint32_t address, int make, struct page_directory *dir)
{
    // Turn the address into an index.
    address /= 0x1000;
    // Find the page table containing this address.
    uint32_t table_idx = address / 1024;
    if (dir->tables[table_idx]) // If this table is already assigned
    {
        return &dir->tables[table_idx]->pages[address%1024];
    }
    else if(make)
    {
        uint32_t tmp;
        if(!initialized)
        {
            dir->tables[table_idx] = (struct page_table *)e_kmalloc_ap(sizeof(struct page_table), &tmp);
        }
        else
        {
            dir->tables[table_idx] = (struct page_table *)kmalloc_ap(sizeof(struct page_table), 1, &tmp);
        }
        memset(dir->tables[table_idx], 0, 0x1000);
        dir->tablesPhysical[table_idx] = tmp | 0x7; // PRESENT, RW, US.
        return &dir->tables[table_idx]->pages[address%1024];
    }
    else
    {
        return NULL;
    }
}

struct page *get_kernel_page(uint32_t address, int make)
{
    return get_page(address, make, kernel_directory);
}

struct page *map_kernel_page(uint32_t address, int make)
{
    struct page *p = get_page(address, make, kernel_directory);
    if(!p) return NULL;
    /* is_writeable must be 1: this is the path kheap's expand() uses to
     * map every heap page beyond the initial bootstrap range (see
     * initialize_paging()'s INITIAL_HEAP_PAGE_COUNT loop, which sets
     * writeable=1 explicitly for that same reason). Passing 0 here
     * mapped every expanded heap page read-only; that went unnoticed
     * as long as CR0.WP stayed clear, but once the heap actually needs
     * to grow past its initial size -- e.g. the kmalloc-doubling buffer
     * in png_load_from_file() decoding a background/icon image -- the
     * very next write into the newly expanded region (set_header_footer()
     * or do_kfree() in kheap.c) page-faults as "present read-only". */
    alloc_frame(p, 0, 1);
    return p;
}

void unmap_kernel_page(uint32_t address)
{
    struct page *p = get_page(address, 0, kernel_directory);
    if(p) {
        free_frame(p);
    }
}

void page_fault(registers_t regs)
{
    // A page fault has occurred.
    // The faulting address is stored in the CR2 register.
    uint32_t faulting_address;
    asm volatile("mov %%cr2, %0" : "=r" (faulting_address));

    // The error code gives us details of what happened.
    int present = !(regs.err_code & 0x1); // Page not present
    int rw = regs.err_code & 0x2;         // Write operation?
    int us = regs.err_code & 0x4;         // Processor was in user-mode?
    int reserved = regs.err_code & 0x8;   // Overwritten CPU-reserved bits of page entry?
    //int id = regs.err_code & 0x10;        // Caused by an instruction fetch?

    // Output an error message.
    printf("Page fault! ( ");
    if (present) {printf("present ");}
    if (rw) {printf("read-only ");}
    if (us) {printf("user-mode ");}
    if (reserved) {printf("reserved ");}
    printf(") at %x\n", faulting_address);

    /* A page fault caused by ring3 code while a .app is running is that
     * app's own bug, not the kernel's -- terminate just the app (via a
     * non-local jump back to app_loader_run(), see app_fault_return())
     * instead of taking down the whole system. Anything else (a fault
     * in ring0, or a stray us-flagged fault with no app actually
     * running -- shouldn't happen, but fail toward the old safe
     * behavior rather than silently continue) still PANICs exactly as
     * before: a ring0 fault means a real kernel bug, and the machine's
     * state at that point can't be trusted enough to keep running. */
    if(us && app_is_running()) {
        app_fault_return("page fault");
    }
    PANIC("Page fault");
}
