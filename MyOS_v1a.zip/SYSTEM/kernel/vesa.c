#include "common.h"
#include "realmode.h"
#include "font.h"
#include "terminal.h"
#include "vesa.h"
#include "kernio.h"


void vesa_putchar(char c);
void vesa_set_status(char *status);
void vesa_set_cursor(uint8_t x, uint8_t y);
uint32_t make_vesa_color(uint8_t r, uint8_t g, uint8_t b);

struct VbeInfoBlock {
   char VbeSignature[4];             // == "VESA"
   uint16_t VbeVersion;                 // == 0x0300 for VBE 3.0
   uint16_t OemStringPtr[2];            // isa vbeFarPtr
   uint8_t Capabilities[4];
   uint16_t VideoModePtr[2];         // isa vbeFarPtr
   uint16_t TotalMemory;             // as # of 64KB blocks
} __attribute__((packed));

struct ModeInfoBlock {
  uint16_t attributes;
  uint8_t winA,winB;
  uint16_t granularity;
  uint16_t winsize;
  uint16_t segmentA, segmentB;
  uint16_t realFctPtr[2];
  uint16_t pitch; // bytes per scanline

  uint16_t Xres, Yres;
  uint8_t Wchar, Ychar, planes, bpp, banks;
  uint8_t memory_model, bank_size, image_pages;
  uint8_t reserved0;

  uint8_t red_mask, red_position;
  uint8_t green_mask, green_position;
  uint8_t blue_mask, blue_position;
  uint8_t rsv_mask, rsv_position;
  uint8_t directcolor_attributes;

  uint32_t physbase;  // your LFB (Linear Framebuffer) address ;)
  uint32_t reserved1;
  uint16_t reserved2;
} __attribute__((packed));

#define LNG_PTR(seg, off) ((seg << 4) | off)
#define REAL_PTR(arr) LNG_PTR(arr[1], arr[0])
#define SEG(addr) (((uint32_t)addr >> 4) & 0xF000)
#define OFF(addr) ((uint32_t)addr & 0xFFFF)

struct VbeInfoBlock vib;
// VIB extends beyond size of struct. 512 is somewhat arbitrary.
struct ModeInfoBlock mib; // = 0x80000 + sizeof (struct VbeInfoBlock) + 512;
uint32_t *framebuffer = 0;

#define CHAR_ROW 16
#define CHAR_COLUMN 8
#define CHARLEN (CHAR_ROW * CHAR_COLUMN) // 8 columns * 16 rows
#define CHARCOUNT 94 // 94 printable characters

#define CHAROFF(c) ((c - 32) * CHARLEN)

uint32_t chars[CHARCOUNT * CHARLEN];

void populate_chars(uint32_t vesa_fg_color, uint32_t vesa_bg_color) {
    for(unsigned char c = ' '; c < '~'; c++) {
        unsigned short offset = (c - 31) * 16 ;

        for(int row = 0; row < CHAR_ROW; row++) {
            uint8_t mask = 1 << 7;
            uint32_t *abs_row = chars + CHAROFF(c) + (row * 8);
            for(int i = 0; i < 8; i++) {
                if(font.Bitmap[offset + row] & mask) {
                    abs_row[i] = vesa_fg_color; //0xFFFFFFFF;
                }
                else {
                    abs_row[i] = vesa_bg_color;
                }
                mask = (mask >> 1);
            }
        }
    }
}

/* Populates the global VBE info block by asking the BIOS for it. Returns
 * 1 on success, 0 if the BIOS call failed or returned something that
 * doesn't look like a real VBE info block -- callers must check this
 * before trusting vib.VideoModePtr, since chasing a bad far pointer from
 * garbage/uninitialized BIOS output is exactly the kind of "works most
 * of the time, hangs or crashes occasionally" bug that's hard to
 * pin down after the fact. */
int populate_vib() {
    struct VbeInfoBlock *loc_vib = 0x80000; // Safe low-memory

    /* The BIOS reads the VBE signature ("VESA" ASCII) out of this buffer
     * as an input too, to select between VBE2+ and legacy behavior --
     * write it before the call so we're asking for the modern structure
     * layout rather than leaving it as whatever was in memory before. */
    memset(loc_vib, 0, sizeof(struct VbeInfoBlock));
    loc_vib->VbeSignature[0] = 'V';
    loc_vib->VbeSignature[1] = 'E';
    loc_vib->VbeSignature[2] = 'S';
    loc_vib->VbeSignature[3] = 'A';

    regs16_t regs;
    memset(&regs, 0, sizeof(regs));
    regs.ax = 0x4f00;
    regs.es = 0x8000;
    regs.di = 0x0;
    int32(0x10, &regs);

    /* A successful VBE call always returns AX == 0x004F; anything else
     * (including an untouched/garbage AX if the BIOS call itself never
     * properly completed) means we cannot trust the rest of the buffer. */
    if(regs.ax != 0x004F) {
        printf("VESA: VBE controller info call failed (AX=%x)\n", regs.ax);
        return 0;
    }

    vib = *loc_vib;

    if(vib.VbeSignature[0] != 'V' || vib.VbeSignature[1] != 'E' ||
       vib.VbeSignature[2] != 'S' || vib.VbeSignature[3] != 'A') {
        printf("VESA: BIOS response missing VESA signature, refusing to trust it\n");
        return 0;
    }

    return 1;
}

/* Preference order: try the biggest/nicest modes first, fall back down to
 * the minimum-supported 800x600. Anything with bpp != 32 is skipped because
 * the rest of the graphics stack assumes a 32bpp linear framebuffer. */
static const vesa_mode_pref_t preferred_modes[] = {
    { 1920, 1080, 32 },
    { 1280,  720, 32 },
    { 1024,  768, 32 },
    {  800,  600, 32 },
};
#define NUM_PREFERRED_MODES (sizeof(preferred_modes) / sizeof(preferred_modes[0]))

static int vesa_ready = 0;

int vesa_is_ready() {
    return vesa_ready;
}

/* VBE function 4F01: fills *out for `mode`. 1 if the BIOS reported success. */
static int vbe_mode_info(uint16_t mode, struct ModeInfoBlock *out) {
    regs16_t regs;
    memset(&regs, 0, sizeof(regs));
    memset(out, 0, sizeof(*out));
    regs.ax = 0x4f01;
    regs.cx = mode;
    regs.es = SEG(out);
    regs.di = OFF(out);
    int32(0x10, &regs);
    return regs.ax == 0x004F;
}

/* attributes: bit0 = supported by the hardware, bit7 = linear framebuffer
 * available. memory_model 6 = direct colour. */
static int vbe_mode_usable(const struct ModeInfoBlock *m) {
    if(!(m->attributes & 0x01)) return 0;
    if(!(m->attributes & 0x80)) return 0;
    if(m->bpp != 32) return 0;
    if(m->memory_model != 6) return 0;
    if(m->physbase == 0) return 0;
    if(m->Xres < 640 || m->Yres < 480) return 0;
    return 1;
}

void set_vmode() {
    /* Retry the VBE controller-info call a few times before giving up --
     * on real hardware and some emulators, the very first BIOS call
     * right after the protected-mode-to-real-mode-and-back transition
     * can occasionally fail even when the BIOS is otherwise healthy
     * (timing-sensitive controller state right after boot). A handful of
     * retries costs nothing on the success path (it succeeds first try
     * the overwhelming majority of the time) and turns an intermittent
     * "sometimes doesn't boot" into a reliable boot. */
    int vib_ok = 0;
    for(int attempt = 0; attempt < 5 && !vib_ok; attempt++) {
        vib_ok = populate_vib();
    }

    if(!vib_ok) {
        printf("\nVESA FATAL: could not retrieve VBE controller info after retries.\n");
        vesa_ready = 0;
        return;
    }

    regs16_t regs;

    struct ModeInfoBlock *loc_mib = 0x80000 + sizeof (struct VbeInfoBlock) + 512;

    uint16_t *modes = (uint16_t *)REAL_PTR(vib.VideoModePtr);

    if(!modes) {
        printf("\nVESA FATAL: BIOS returned a null video mode list pointer.\n");
        vesa_ready = 0;
        return;
    }

    /* Every BIOS call below is checked: a VBE function reports success as
     * AX == 0x004F. Real BIOSes and VirtualBox list modes that cannot be
     * used here (no linear framebuffer, banked-only, not "supported" by the
     * current monitor/VRAM setup), and the old code trusted whatever the
     * info call left in the buffer and ignored whether the mode switch
     * itself worked -- when it didn't, the kernel kept drawing into a
     * framebuffer that was never switched on and the VM sat on a black
     * screen. Now a mode only counts if it is supported, has a linear
     * framebuffer, is 32 bpp direct colour, AND the switch succeeded;
     * otherwise the next candidate is tried. */
    #define MAX_VBE_MODES_TO_SCAN 512
    int success = 0;
    uint16_t found_mode = 0;

    for(uint32_t pass = 0; pass <= NUM_PREFERRED_MODES && !success; pass++) {
        for(int i = 0; i < MAX_VBE_MODES_TO_SCAN && modes[i] != 0xFFFF && !success; i++) {
            if(!vbe_mode_info(modes[i], loc_mib)) continue;
            if(!vbe_mode_usable(loc_mib)) continue;
            if(pass < NUM_PREFERRED_MODES) {
                /* exact preferred resolution, best first */
                if(loc_mib->Xres != preferred_modes[pass].width ||
                   loc_mib->Yres != preferred_modes[pass].height) continue;
            }
            /* last pass (pass == NUM_PREFERRED_MODES): any usable 32 bpp mode */

            memset(&regs, 0, sizeof(regs));
            regs.ax = 0x4F02;
            regs.bx = modes[i] | 0x4000;          /* Set Linear Frame Buffer (LFB) bit. */
            int32(0x10, &regs);
            if(regs.ax != 0x004F) {
                printf("VESA: mode %x refused by BIOS (AX=%x), trying next\n", modes[i], regs.ax);
                continue;
            }
            found_mode = modes[i];
            success = 1;
        }
    }

    if(!success) {
        printf("\nVESA FATAL: no usable 32bpp linear-framebuffer mode found.\n");
        vesa_ready = 0;
        return;
    }

    /* The mode switch reset nothing in the info buffer, but re-read it for
     * the mode we are now in so loc_mib definitely describes it. */
    if(!vbe_mode_info(found_mode, loc_mib)) {
        printf("\nVESA FATAL: cannot re-read info for mode %x.\n", found_mode);
        vesa_ready = 0;
        return;
    }

    framebuffer = (uint32_t *)loc_mib->physbase;

    terminal_putchar = vesa_putchar;
    terminal_set_status = vesa_set_status;
    terminal_set_cursor = vesa_set_cursor;
    mib = *loc_mib;
    vesa_ready = 1;
    set_vesa_color(make_vesa_color(255, 255, 255));
    set_vesa_background(make_vesa_color(0, 0, 0));
    printf("\nVESA initialized.\nSet resolution to: %dx%dx%d\n", mib.Xres, mib.Yres, mib.bpp);
}

uint32_t get_screen_width() {
    return mib.Xres;
}

uint32_t get_screen_height() {
    return mib.Yres;
}

uint32_t get_screen_pitch() {
    return mib.pitch;
}

uint32_t get_screen_bpp() {
    return mib.bpp;
}

uint32_t make_vesa_color(uint8_t r, uint8_t g, uint8_t b) {
    uint32_t red = ((uint32_t)r) << mib.red_position;
    uint32_t green = ((uint32_t)g) << mib.green_position;
    uint32_t blue = ((uint32_t)b) << mib.blue_position;
    return red | green | blue;
}

uint32_t current_fg, current_bg;

void set_vesa_color(uint32_t color) {
    current_fg = color;
    populate_chars(current_fg, current_bg);
}

void set_vesa_background(uint32_t color) {
    current_bg = color;
    populate_chars(current_fg, current_bg);
}

uint32_t get_vesa_color() {
    return current_fg;
}

uint32_t get_vesa_background() {
    return current_bg;
}

void draw_pixel_at(int x, int y, uint32_t color) {
    uint32_t *row = ((unsigned char *)framebuffer) + (y * mib.pitch);
    row[x] = color;
}

void draw_character_at(int x, int y, int c, uint32_t fg, uint32_t bg) {
    (void)fg; (void)bg; /* colors are baked into the pre-rendered glyph cache */
    uint32_t step = mib.pitch/4;
    uint32_t *chardat = chars + CHAROFF(c);
    uint32_t *abs_row = ((unsigned char *)framebuffer) + (y * mib.pitch);
    abs_row += x;
    for(int row = 0; row < CHAR_ROW *8; row+=8) {
        fastcp(abs_row, chardat + row, 32);
        abs_row += step;
    }
}

void shift_up() {
    /* Row 0 (16px tall) is reserved for the status bar and is never
     * scrolled. Everything from row 16 downward shifts up by one text
     * row (16px), and the newly-exposed bottom row is cleared to black. */
    uint32_t pitch = mib.pitch;
    uint32_t height = mib.Yres;
    uint32_t scroll_region_bytes = pitch * (height - 16 /*status*/ - 16 /*last row*/);
    fastcp(((char *)framebuffer) + (pitch * 16), ((char *)framebuffer) + (pitch * 32), scroll_region_bytes);
    memset(((char *)framebuffer) + (pitch * (height - 16)), 0, pitch * 16);
}

int currx, curry;

void vesa_newline() {
    currx = 0;
    uint32_t last_row_y = (mib.Yres / 16 - 1) * 16;
    if(curry >= (int)last_row_y) {
        curry = last_row_y;
        shift_up();
    }
    else {
        curry += 16;
    }
}

void vesa_set_cursor(uint8_t x, uint8_t y) {
    currx = x * 8;
    curry = y * 16;
}

/* Set false once the graphical boot splash (or later, the desktop)
 * takes over the screen -- see vesa_set_text_output_enabled() below.
 * Both draw pixels into exactly the same physical framebuffer this
 * function writes to (get_framebuffer_addr()), so leaving text drawing
 * on after that point would have boot-log characters and splash/desktop
 * graphics overwrite each other on screen. The log itself (whatever
 * printf() was asked to print) is unaffected either way -- this only
 * ever controlled whether those characters got drawn to the screen, not
 * whether printf() itself "worked". */
static uint8_t vesa_text_output_enabled = 1;

void vesa_set_text_output_enabled(uint8_t enabled) {
    vesa_text_output_enabled = enabled;
}

void vesa_putchar(char c) {
    if(!vesa_text_output_enabled) {
        return;
    }
    if(currx + 8 >= mib.Xres) {
        vesa_newline();
    }
    switch (c) {
    case '\n':
        vesa_newline();
        break;
    case '\t':
        vesa_putchar(' ');
        vesa_putchar(' ');
        vesa_putchar(' ');
        vesa_putchar(' ');
        break;
    case BS:
        if(currx > 0) {
            currx -= 8;
            vesa_putchar(' ');
            currx -= 8;
        }
        break;
    default:
        draw_character_at(currx, curry, c, 0xFFFFFFFF, 0);
        currx += 8;
        break;
    }

}

uint32_t get_framebuffer_addr() {
    return framebuffer;
}

uint32_t get_framebuffer_length() {
    return mib.pitch * mib.Yres;
}

void vesa_set_status(char *status) {
    int currx = 0;
    while(*status) {
        draw_character_at(currx, 0, *status++, 0xFFFFFFFF, 0);
        currx += 8;
    }
    while(currx + 8 < mib.Xres) {
        draw_character_at(currx, 0, ' ', 0xFFFFFFFF, 0);
        currx += 8;
    }
}
