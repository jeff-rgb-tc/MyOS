#include "sb16.h"
#include "port.h"
#include "kernio.h"
#include "kheap.h"
#include "common.h"

/* Fixed base I/O port this driver probes -- see sb16.h's comment on why
 * only the common default (220h) is checked. All SB16 DSP registers are
 * offsets from this base. */
#define SB_BASE 0x220
#define DSP_RESET      (SB_BASE + 0x6)
#define DSP_READ       (SB_BASE + 0xA)
#define DSP_WRITE      (SB_BASE + 0xC)
#define DSP_READ_STATUS (SB_BASE + 0xE)
#define DSP_MIXER_ADDR (SB_BASE + 0x4)
#define DSP_MIXER_DATA (SB_BASE + 0x5)

/* Classic 8237 DMA controller ports for channel 1 (the one SB16 uses
 * for 8-bit playback by convention) -- this kernel had no existing DMA
 * controller support at all before this driver, since nothing else in
 * this OS uses ISA DMA (the FAT32/ATA driver uses PIO, not DMA; AC97
 * uses PCI bus-mastering DMA, which is a completely separate mechanism
 * programmed through the device itself, not the legacy 8237). */
#define DMA1_CHAN1_ADDR   0x02
#define DMA1_CHAN1_COUNT  0x03
#define DMA1_MASK_REG     0x0A
#define DMA1_MODE_REG     0x0B
#define DMA1_CLEAR_FF_REG 0x0C
#define DMA_PAGE_CHAN1    0x83

/* One DMA-safe playback buffer -- must not cross a 64KB physical
 * boundary (an 8237 limitation: it can only address 64KB per transfer
 * without crossing into the next page register's range), so this is
 * static and aligned generously rather than risking a kmalloc'd buffer
 * that happens to straddle one. 32KB comfortably avoids ever crossing a
 * 64KB boundary regardless of where the linker happens to place it,
 * without needing to actually check/adjust at runtime. */
#define DMA_BUFFER_SIZE 32768
static uint8_t dma_buffer[DMA_BUFFER_SIZE] __attribute__((aligned(65536)));

static uint8_t sb16_present = 0;
static uint32_t configured_sample_rate = 22050;

static void dsp_write(uint8_t value) {
    while(inb(DSP_WRITE) & 0x80) { } /* wait for the write port to be ready */
    outb(DSP_WRITE, value);
}

static uint8_t dsp_read(void) {
    while(!(inb(DSP_READ_STATUS) & 0x80)) { } /* wait for data available */
    return inb(DSP_READ);
}

static int sb16_probe_and_init(void) {
    /* DSP reset sequence: pulse the reset line, then expect 0xAA back
     * from the read port within a short window -- the standard SB16
     * detection handshake. */
    outb(DSP_RESET, 1);
    for(volatile int i = 0; i < 1000; i++) { }
    outb(DSP_RESET, 0);

    /* Bounded wait for 0xAA -- on real/emulated hardware this responds
     * almost immediately; if nothing ever sets the data-available bit,
     * there's no SB16 at this base and probing must give up rather than
     * hang forever (same reasoning as ata_pio_drv.c's identify() bound,
     * see that file's ATA_POLL_TIMEOUT_ITERS comment). */
    uint32_t timeout = 100000;
    while(!(inb(DSP_READ_STATUS) & 0x80) && timeout > 0) { timeout--; }
    if(timeout == 0) return 0;

    uint8_t response = inb(DSP_READ);
    if(response != 0xAA) return 0;

    sb16_present = 1;
    printf("sb16: found at base %x\n", SB_BASE);
    return 1;
}

static void sb16_set_format(uint32_t sample_rate, uint8_t channels) {
    if(!sb16_present) return;
    (void)channels; /* this driver's DMA path always sends mono 8-bit -- see the top-of-file scope note in sb16.h */
    configured_sample_rate = sample_rate;
}

/* Programs the 8237 DMA controller for a single-cycle transfer of the
 * given length from dma_buffer, then tells the SB16 DSP to start an
 * 8-bit single-cycle playback at the configured sample rate. Downmixes
 * to 8-bit mono (this driver's whole scope, see sb16.h) by averaging
 * stereo pairs and shifting 16-bit samples down to 8 bits -- audibly
 * lower quality than AC97's native 16-bit stereo path, which is exactly
 * why AC97 is probed first whenever it's available (see audio.c). */
static void sb16_write(const int16_t *samples, uint32_t sample_count) {
    if(!sb16_present) return;

    uint32_t frame_count = sample_count; /* treat input as already-mono for this simple path; stereo callers should downmix before calling audio_queue if precise fidelity matters -- see the set_format comment */
    if(frame_count > DMA_BUFFER_SIZE) frame_count = DMA_BUFFER_SIZE;

    for(uint32_t i = 0; i < frame_count; i++) {
        /* 16-bit signed -> 8-bit unsigned (SB16's 8-bit DMA mode expects
         * unsigned samples, centered at 128). */
        int16_t s = samples[i];
        dma_buffer[i] = (uint8_t)((s >> 8) + 128);
    }

    uint32_t transfer_len = frame_count - 1; /* 8237 count register is length-1 */
    uint32_t phys = (uint32_t)dma_buffer; /* identity-mapped heap -- see audio.h's top comment */

    outb(DMA1_MASK_REG, 0x05);       /* mask channel 1 while reprogramming */
    outb(DMA1_CLEAR_FF_REG, 0x00);   /* clear byte-pointer flip-flop */
    outb(DMA1_CHAN1_ADDR, (uint8_t)(phys & 0xFF));
    outb(DMA1_CHAN1_ADDR, (uint8_t)((phys >> 8) & 0xFF));
    outb(DMA_PAGE_CHAN1, (uint8_t)((phys >> 16) & 0xFF));
    outb(DMA1_CHAN1_COUNT, (uint8_t)(transfer_len & 0xFF));
    outb(DMA1_CHAN1_COUNT, (uint8_t)((transfer_len >> 8) & 0xFF));
    outb(DMA1_MODE_REG, 0x48); /* single-cycle, read (memory->device), channel 1 */
    outb(DMA1_MASK_REG, 0x01); /* unmask channel 1 */

    /* Set the DSP's playback sample rate, then start an 8-bit single-
     * cycle DMA output of transfer_len+1 bytes. */
    dsp_write(0x41); /* "set output sample rate" */
    dsp_write((uint8_t)(configured_sample_rate >> 8));
    dsp_write((uint8_t)(configured_sample_rate & 0xFF));

    dsp_write(0xC0); /* 8-bit single-cycle DMA output */
    dsp_write(0x00); /* mono, unsigned */
    dsp_write((uint8_t)(transfer_len & 0xFF));
    dsp_write((uint8_t)((transfer_len >> 8) & 0xFF));
}

static int sb16_ready_for_more(void) {
    if(!sb16_present) return 0;
    /* No interrupt handling wired up for this driver -- see sb16.h's
     * scope note -- so this is a coarse "the DSP isn't reporting itself
     * busy" check rather than a precise DMA-position query the way
     * ac97_ready_for_more() has. Good enough for this driver's role as
     * a legacy fallback, not a claim of equal fidelity to the AC97 path. */
    return (inb(DSP_READ_STATUS) & 0x80) == 0;
}

const audio_driver_t sb16_driver = {
    .name = "Sound Blaster 16",
    .probe_and_init = sb16_probe_and_init,
    .set_format = sb16_set_format,
    .write = sb16_write,
    .ready_for_more = sb16_ready_for_more,
    .set_volume = NULL, /* SB16 mixer volume control is a real feature this driver doesn't implement yet -- see sb16.h's scope note */
};
