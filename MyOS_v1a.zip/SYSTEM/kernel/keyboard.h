#ifndef KEYBOARD_H
#define KEYBOARD_H

#include "stdint.h"

/* Special (non-ASCII) keys are delivered through the same character stream
 * as values >= 0x80 (negative as a signed char), so existing code that only
 * accepts printable characters (c >= ' ' && c < 127) naturally ignores
 * them. Ctrl+<letter> arrives as control codes 1..26 (Ctrl+C = 3, ...). */
#define KEY_UP     ((char)0x81)
#define KEY_DOWN   ((char)0x82)
#define KEY_LEFT   ((char)0x83)
#define KEY_RIGHT  ((char)0x84)
#define KEY_HOME   ((char)0x85)
#define KEY_END    ((char)0x86)
#define KEY_PGUP   ((char)0x87)
#define KEY_PGDN   ((char)0x88)
#define KEY_DELETE ((char)0x89)
#define KEY_INSERT ((char)0x8A)
#define KEY_TASKMGR ((char)0x8B)   /* Ctrl+Shift+Esc */
#define KEY_ALTTAB  ((char)0x8C)   /* Alt+Tab: switch window */
#define KEY_PRTSCN  ((char)0x8D)   /* Print Screen: save a screenshot */
#define KEY_WIN     ((char)0x8E)   /* Windows key / Ctrl+Esc: Start menu */
#define KEY_F1     ((char)0x90)
#define KEY_F2     ((char)0x91)
#define KEY_F3     ((char)0x92)
#define KEY_F4     ((char)0x93)
#define KEY_F5     ((char)0x94)
#define KEY_F6     ((char)0x95)
#define KEY_F7     ((char)0x96)
#define KEY_F8     ((char)0x97)
#define KEY_F9     ((char)0x98)
#define KEY_F10    ((char)0x99)
#define KEY_F11    ((char)0x9A)
#define KEY_F12    ((char)0x9B)

/* Bits returned by keyboard_get_modifiers(). */
#define KB_MOD_SHIFT 0x01
#define KB_MOD_CTRL  0x02
#define KB_MOD_ALT   0x04
#define KB_MOD_CAPS  0x08
#define KB_MOD_NUM   0x10

uint8_t keyboard_get_modifiers(void);

/* Turns Num Lock on/off and updates the keyboard LED. */
void keyboard_set_numlock(int on);

void initialize_keyboard();
char get_ascii_char();

/* Non-blocking variant of get_ascii_char(): returns the next buffered
 * key if one is available, or 0 immediately if the input buffer is
 * empty. Needed by the graphical desktop, which must keep rendering
 * frames (mouse cursor, window updates) while a terminal-style app
 * window is waiting for keyboard input -- unlike get_ascii_char(), this
 * never blocks the caller. */
char try_get_ascii_char();

#endif
