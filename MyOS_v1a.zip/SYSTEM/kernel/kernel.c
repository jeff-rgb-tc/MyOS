#include "stdio.h"
#include "stddef.h"
#include "stdint.h"
#include "terminal.h"
#include "gdt.h"
#include "idt.h"
#include "pit.h"
#include "pic.h"
#include "isr.h"
#include "paging.h"
#include "common.h"
#include "kheap.h"
#include "multiboot.h"
#include "keyboard.h"
#include "mouse.h"
#include "fat32.h"
#include "fat32_console.h"
#include "ata_pio_drv.h"
#include "kernio.h"
#include "vesa.h"
#include "terminal.h"
#include "desktop.h"
#include "gfx.h"
#include "boot_splash.h"
#include "serial.h"
#include "audio.h"
#include "driver_loader.h"
#include "keyboard.h"
#include "mouse.h"
#include "fpu.h"

/* This tutorial will only work for the 32-bit ix86 targets. */
#if !defined(__i386__)
#error "This tutorial needs to be compiled with a ix86-elf compiler"
#endif


#if defined(__cplusplus)
extern "C" /* Use C linkage for kernel_main. */
#endif

extern void pause();
extern void sys_sti();
extern char _binary_f32_disk_start;



/* True if the whitespace-separated kernel command line (the text after the
 * kernel path on GRUB's `multiboot` line) contains exactly `word`. */
static int cmdline_has_word(const char *cmd, const char *word) {
    if(!cmd) return 0;
    size_t wl = strlen(word);
    while(*cmd) {
        while(*cmd == ' ' || *cmd == '\t') cmd++;
        const char *start = cmd;
        while(*cmd && *cmd != ' ' && *cmd != '\t') cmd++;
        if((size_t)(cmd - start) == wl && memcmp(start, word, wl) == 0) return 1;
    }
    return 0;
}

/* Boot cannot continue. Makes sure the message is actually VISIBLE (the
 * graphical splash turns off text output) and then idles forever. Before
 * this existed, a failure here just returned from kernel_main into the
 * halt loop and the VM sat on a black/splash screen with no explanation --
 * which is what "the OS doesn't start" looked like. */
static void boot_fatal(const char *line1, const char *line2, const char *line3) {
    boot_splash_stop();   /* the spinner would draw over the message below */
    vesa_set_text_output_enabled(1);
    printf("\n\n==== MyOS cannot start ====\n");
    if(line1) printf("%s\n", line1);
    if(line2) printf("%s\n", line2);
    if(line3) printf("%s\n", line3);
    printf("\nSystem halted.\n");
    for(;;) { __asm__ volatile("sti; hlt"); }
}

extern uint32_t placement_address;

void kernel_main(struct multiboot_info *mi)
{
    terminal_initialize(COLOR_WHITE);

    /* MEMINFO (bit 1) is set in boot.nasm's multiboot header, so a
     * compliant bootloader (GRUB via our ISO) always fills in mem_upper.
     * Falling back to a conservative default if that bit somehow isn't
     * set avoids computing total_frames from uninitialized/garbage
     * memory, which would otherwise corrupt every later frame allocator
     * decision -- a plausible source of boot instability that would
     * only show up depending on whatever garbage happened to be at that
     * memory location on a given boot. */
    uint32_t low_pages = 256; // 1024 * 1024 bytes / 4096
    uint32_t high_pages;
    if(mi->flags & (1 << 0)) {
        high_pages = (mi->mem_upper * 1024) / 4096;
    }
    else {
        printf("WARNING: bootloader did not provide memory info, assuming 32MiB.\n");
        high_pages = (32 * 1024 * 1024) / 4096;
    }

    uint32_t total_frames = high_pages + low_pages;

    /* GDT and IDT must be up before set_vmode(), which switches out to
     * real mode (via int32()) and back to call VESA BIOS functions.
     * int32() does `sidt`/`lidt` to save and restore whatever IDT was
     * active on entry -- if that happens before init_idt() has run, it
     * saves and restores an empty (limit=0, base=0) IDT. Any CPU
     * exception raised afterwards (in populate_chars(), the BIOS call
     * path, or anywhere else) then has no handler to go to, which
     * escalates to a double fault and then a triple fault -- exactly
     * the "black screen, Guru Meditation, IDT is 0:0" crash this fixes.
     * Likewise init_gdt() should run before anything relies on our own
     * segment selectors rather than whatever the bootloader left set up. */
    init_gdt();
    remap_pic();
    init_idt();
    fpu_init();

    set_vmode();
    serial_init();             /* COM1 log mirror (no-op if the machine has no UART) */
    serial_install_tee();
    set_vesa_color(make_vesa_color(0x8F, 0x8F, 0x8F));

    /* Interrupts stay masked (CPU-level) until every device that owns an
     * IRQ line has been fully initialized -- PIT, keyboard, and mouse --
     * not just until the PIC/IDT tables exist. Enabling interrupts any
     * earlier leaves a window where an IRQ could fire into a handler
     * whose device state (PIT reload value, keyboard controller
     * config, mouse streaming mode) isn't set up yet, which is a classic
     * source of intermittent boot failures depending on exact timing --
     * more likely to bite on real hardware or under different emulator
     * timing than in repeated identical test runs. */
    init_timer(100);
    initialize_keyboard();
    initialize_mouse();

    sys_sti();

    /* Look for a GRUB multiboot module -- this is how the entire FAT32
     * disk image (icons, cursor, background, apps, and now the user's
     * Desktop folder) gets baked directly into the bootable ISO instead
     * of requiring a second virtual disk mounted alongside it. If none
     * is present (e.g. running the raw kernel ELF directly via `make
     * run` without an ISO), module_addr stays 0 and the FAT32 driver
     * falls back to reading the real ATA disk, so kernel-only iteration
     * during development still works. */
    uint32_t module_addr = 0;
    uint32_t module_len = 0;
    if((mi->flags & (1 << 3)) && mi->mods_count > 0) {
        struct multiboot_module *mods = (struct multiboot_module *)mi->mods_addr;
        module_addr = mods[0].mod_start;
        module_len = mods[0].mod_end - mods[0].mod_start;
        printf("Found multiboot module: %x - %x (%d bytes)\n", mods[0].mod_start, mods[0].mod_end, module_len);
    }
    else {
        printf("No multiboot module found; FAT32 will use the ATA disk.\n");
    }

    /* "live" on the kernel command line (the ISO's default menu entry) means:
     * run from the in-memory image and never mount a hard disk as the system
     * disk. That is what lets the installer run next to an empty -- or an
     * already installed -- disk without the kernel latching onto it. */
    int live_mode = 0;
    if((mi->flags & (1 << 2)) && mi->cmdline) {
        live_mode = cmdline_has_word((const char *)mi->cmdline, "live");
    }

    if(module_addr) {
        uint32_t mod_end = module_addr + module_len;

        /* The early boot allocator hands out page tables and the frame
         * stack starting at the end of the kernel image. GRUB is free to put
         * the module (the FAT32 image) right there, in which case those
         * allocations would zero the first sectors of the disk image --
         * its boot sector -- and the filesystem would then "fail to mount".
         * Start the early allocator behind the module in that case. */
        if(module_addr < placement_address + 0x1000000u && mod_end > placement_address) {
            printf("Module overlaps early allocator; moving allocator to %x.\n", mod_end);
            placement_address = (mod_end + 0xFFF) & 0xFFFFF000u;
        }

        /* The module sits in RAM and the kernel needs room for page
         * tables, the heap and the back buffer on top of it. With too
         * little RAM, GRUB fails to load it or the frame allocator runs dry
         * a moment later with an unhelpful panic. */
        if(mi->flags & (1 << 0)) {
            uint32_t ram_top = 0x100000u + mi->mem_upper * 1024u;
            if(ram_top < mod_end + 0x2000000u) {
                boot_fatal("Not enough memory for the disk image.",
                           "Give the virtual machine at least 512 MB of RAM",
                           "(VirtualBox: Settings -> System -> Base Memory).");
            }
        }
    }

    initialize_paging(total_frames, get_framebuffer_addr(), get_framebuffer_length(),
                       module_addr, module_len);
    malloc_stats();
    printf("Done setting up paging.\n");

    set_vesa_color(make_vesa_color(0xFF, 0xFF, 0xFF));
    printf("Kernel is ready to go!!!\n\n");

    // Kernel ready to go!

    /* Graphical boot splash takes over the screen from here on -- the
     * heap (needed by gfx_init()'s back-buffer allocation) is up as of
     * initialize_paging() just above, which is why this couldn't start
     * any earlier. If it fails to initialize (e.g. back buffer
     * allocation somehow failed), boot simply continues without a
     * splash screen -- the printf() log below still goes to the (now
     * invisible, since nothing is presenting the framebuffer's text
     * mode contents any more once VESA is active) console buffer either
     * way, so nothing about booting itself depends on the splash
     * succeeding. */
    uint8_t splash_active = gfx_init();
    if(splash_active) {
        /* Stop drawing printf() boot-log text to the screen from here
         * on -- see vesa_set_text_output_enabled()'s comment in vesa.h.
         * Without this, every printf() call below (ATA status messages,
         * filesystem mount messages, etc.) would draw text pixels
         * directly on top of the splash screen's graphics, corrupting
         * it -- both write to the same physical framebuffer. */
        vesa_set_text_output_enabled(0);
        boot_splash_show();
    }

    /* Pick the system disk.
     *   1. normal boot (no "live"): the first ATA disk that really holds a
     *      FAT32 volume -- either a bare filesystem or the first FAT32
     *      partition of an MBR disk (what the installer creates). Files
     *      persist there.
     *   2. otherwise the read-only disk image GRUB loaded as a module.
     * A disk that answers on the IDE bus but holds NOTHING usable (a blank
     * virtual HDD, the usual state of a fresh VirtualBox VM) is skipped
     * instead of being mounted blindly -- mounting it was what made the ISO
     * "fail to start" whenever a blank hard disk was attached. */
    boot_splash_status("Looking for disks");
    int ata_count = ata_probe_all();
    printf("ATA: %d hard disk(s) found.\n", ata_count);

    int boot_dev = -1;
    uint32_t boot_part = 0;
    if(!live_mode) {
        for(int d = 0; d < ATA_MAX_DEVICES && boot_dev < 0; d++) {
            const ata_info_t *ai = ata_device_info(d);
            if(!ai || !ai->present) continue;
            uint32_t part = 0;
            if(fat32_probe_volume(d, &part)) { boot_dev = d; boot_part = part; }
        }
    }

    if(boot_dev >= 0) {
        printf("FAT32 volume found on ATA disk %d (LBA %d) -- using it for persistent storage.\n", boot_dev, boot_part);
        boot_splash_status("Mounting the system disk");
        fat32_set_ata_backend(boot_dev, boot_part);
    } else if(module_addr) {
        printf("%s -- using the read-only disk image bundled in the ISO. "
               "Changes will NOT persist across reboots.\n",
               live_mode ? "Live mode" : "No FAT32 hard disk found");
        fat32_set_memory_backend((uint8_t *)module_addr, module_len);
    } else {
        boot_fatal("No disk with a MyOS filesystem was found.",
                   "Attach the virtual hard disk to an IDE or SATA (AHCI) controller",
                   "(VirtualBox: Settings -> Storage). NVMe / USB disks are not supported yet.");
    }
    if(splash_active) boot_splash_tick();

    printf("Creating fat32 filesystem.\n");
    master_fs = makeFilesystem("");
    if(master_fs == NULL) {
        boot_fatal("Failed to mount the FAT32 filesystem.",
                   "The disk image is damaged or is not a MyOS disk.",
                   "Rebuild the ISO / reinstall.");
    }
    if(splash_active) boot_splash_tick();

    /* Driver descriptors (/Drivers/<category>/<id>.drv) are read first so
     * audio_init() below can honour them, and the always-present input
     * and display drivers get their configured settings applied. */
    boot_splash_status("Reading drivers");
    driver_loader_init();
    ata_dma_set_enabled(driver_setting_int("ata", "dma", 0));   /* opt-in: dma=1 in /Drivers/system/ata.drv */
    keyboard_set_numlock(driver_setting_int("ps2-keyboard", "numlock", 1));
    mouse_set_sensitivity(driver_setting_int("ps2-mouse", "sensitivity", 100));
    driver_report_status("ps2-keyboard", "input", "PS/2 Keyboard", DRV_STATUS_ACTIVE);
    driver_report_status("ps2-mouse", "input", "PS/2 Mouse", DRV_STATUS_ACTIVE);
    driver_report_status("vesa-fb", "display", "VESA Framebuffer", DRV_STATUS_ACTIVE);
    driver_report_status("ata", "system", "ATA/IDE Disk", DRV_STATUS_ACTIVE);
    if(!driver_is_enabled("serial-com1")) { serial_disable(); driver_report_status("serial-com1", "system", "Serial COM1 (log)", DRV_STATUS_DISABLED); }
    else driver_report_status("serial-com1", "system", "Serial COM1 (log)", serial_present() ? DRV_STATUS_ACTIVE : DRV_STATUS_NOT_PRESENT);
    driver_report_status("pcspeaker", "sound", "PC Speaker", driver_is_enabled("pcspeaker") ? DRV_STATUS_ACTIVE : DRV_STATUS_DISABLED);

    audio_init();
    if(splash_active) boot_splash_tick();

    printf("Starting graphical desktop...\n");
    /* The splash keeps spinning through the desktop's own start-up (settings,
     * app scan, wallpaper decode); desktop_run() stops it right before the
     * first frame. */
    desktop_run();
    if(splash_active) boot_splash_stop();      /* desktop_run() returned early (graphics failure) */

    /* desktop_run() only returns if graphics initialization failed
     * outright (e.g. gfx back buffer allocation failed). Fall back to the
     * old text-mode FAT32 console so the machine is still usable --
     * re-enabling text output first, in case the boot splash had
     * disabled it earlier (see vesa_set_text_output_enabled() above);
     * otherwise this whole fallback console would run invisibly. */
    vesa_set_text_output_enabled(1);
    printf("Desktop exited unexpectedly. Falling back to FAT32 console.\n");
    fat32_console(master_fs);

    printf("FAT32 shell exited. It is safe to power off.\nSystem is in free-typing mode.\n");

    while(1) {
        char c = get_ascii_char();
        printf("%c", c);
    };
    printf("Halting.\n");

}
