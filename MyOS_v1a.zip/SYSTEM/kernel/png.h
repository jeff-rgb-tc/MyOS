#ifndef PNG_H
#define PNG_H

#include "stdint.h"

/* A decoded PNG image as a flat ARGB8888 buffer, top-down, row-major --
 * same in-memory layout as cursor_image_t, so it can feed straight into
 * gfx_blit_argb(). */
typedef struct {
    uint16_t width;
    uint16_t height;
    uint32_t *pixels; /* width * height, heap-allocated, caller owns it */
} png_image_t;

/* Decodes a PNG file already loaded into memory. Supports the common
 * real-world cases: 8-bit-per-channel truecolor (with or without alpha),
 * grayscale (with or without alpha), and palette-indexed color, all
 * non-interlaced (Adam7 interlacing is not supported -- virtually no
 * icon/asset export tool uses it by default). Returns 1 on success, 0 on
 * failure (unsupported PNG feature, corrupt file, etc). On success,
 * out->pixels is heap-allocated via kmalloc and the caller owns it. */
int png_load_from_memory(const uint8_t *data, uint32_t length, png_image_t *out);

/* Convenience wrapper: reads a file from the FAT32 disk and decodes it. */
int png_load_from_file(const char *path, png_image_t *out);

void png_free(png_image_t *img);

#endif
