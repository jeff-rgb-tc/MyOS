/**
 * This file contains the minimal C code for dispatching
 * interrupts to handlers.
 */

#include "isr.h"
#include "idt.h"
#include "kernio.h"
#include "pic.h"
#include "port.h"
#include "stdint.h"
#include "app_loader.h"

extern void halt();

isr_handler_t interrupt_handlers[256];

void register_interrupt_handler(uint8_t interrupt, isr_handler_t handler)
{
    interrupt_handlers[interrupt] = handler;
}

void isr_handler(registers_t regs)
{
    if(regs.int_no == GENERAL_PROTECTION_FAULT)
    {
        printf("General Protection Fault. Code: %d", regs.err_code);

        /* regs.cs's low 2 bits are the CPL the fault happened in
         * (RPL of the code selector active at fault time) -- 3 means
         * ring3. Same "terminate just the app, not the kernel" policy
         * as paging.c's page_fault() for a ring3 fault while a .app is
         * running; see that function's comment for the reasoning and
         * why anything else still PANICs. */
        if((regs.cs & 0x3) == 3 && app_is_running()) {
            app_fault_return("general protection fault");
        }
        PANIC("General Protection Fault!");
    }

    if(interrupt_handlers[regs.int_no])
    {
        //printf("Handling %d!\n", regs.int_no);
        interrupt_handlers[regs.int_no](regs);
        //printf("Returning!\n");
    }
//    else {
//        printf("Got ISR.\n");
//        PANIC("Unhandled ISR.\n");
//    }
}


void irq_handler(registers_t regs)
{
    //If int_no >= 40, we must reset the slave as well as the master
    if(regs.int_no >= 40)
    {
        //reset slave
        outb(SLAVE_COMMAND, PIC_RESET);
    }

    outb(MASTER_COMMAND, PIC_RESET);

    if(interrupt_handlers[regs.int_no])
    {
        interrupt_handlers[regs.int_no](regs);
    }
//    else {
//        if(regs.int_no == 33) return;
//        printf("Got IRQ.\n");
//        char buff[1024];
//        sprintf(buff, "Unhandled IRQ %d\n", regs.int_no);
//        PANIC(buff);
//    }
}
