#ifndef ATA_PIO_DRV_H
#define ATA_PIO_DRV_H

#include "stdint.h"

#define ATA_IDE_DEVICES 4   /* 0 primary master, 1 primary slave, 2 secondary master, 3 secondary slave */
#define ATA_MAX_DEVICES 10  /* 4..9: SATA disks behind an AHCI controller (ahci.c) */

typedef struct {
    uint8_t  present;   /* an ATA hard disk answered IDENTIFY */
    uint8_t  atapi;     /* a CD/DVD drive (never used as a disk) */
    uint8_t  slave;
    uint8_t  lba48;
    uint16_t io, ctl;
    uint8_t  backend;   /* 0 = legacy IDE ports, 1 = AHCI */
    uint8_t  port;      /* AHCI port slot (ahci.c) */
    uint64_t sectors;   /* 512-byte sectors */
    char     model[41];
} ata_info_t;

/* Legacy: probes only the primary master. Kept for old callers. */
uint8_t identify();

/* Finds every ATA disk on both IDE channels. Returns how many. */
int ata_probe_all(void);
const ata_info_t *ata_device_info(int dev);

/* Bus-master DMA is OFF until this is called with 1 (kernel.c does it from the ata driver descriptor). */
void ata_dma_set_enabled(int on);

/* CD/DVD drives (ATAPI, PIO). `lba` counts 2048-byte sectors. 0 = ok, -1 = no
 * medium / failed. ata_atapi_capacity() returns the medium's size in
 * 2048-byte sectors, or 0 if there is no readable medium. */
int      ata_atapi_read(int dev, uint32_t lba, uint32_t count, void *buf);
uint32_t ata_atapi_capacity(int dev);

/* Bounded, error-checked sector I/O on one device. 0 = ok, -1 = failed. */
int ata_dev_read(int dev, uint64_t lba, uint32_t count, void *buf);
int ata_dev_write(int dev, uint64_t lba, uint32_t count, const void *buf);
/* Same as ata_dev_read but skips the small-read cache (file data, FAT). */
int ata_dev_read_stream(int dev, uint64_t lba, uint32_t count, void *buf);
/* ata_defer_flush(1) postpones FLUSH CACHE after writes (nestable);
 * ata_defer_flush(0) ends the section and flushes once if needed. */
void ata_defer_flush(int on);

/* The disk the legacy ata_pio_* calls (and so the mounted filesystem) use. */
void ata_set_default_device(int dev);
int ata_get_default_device(void);

void ata_pio_read28(uint32_t LBA, uint8_t sectorcount, uint8_t *target);
void ata_pio_read48(uint64_t LBA, uint16_t sectorcount, uint8_t *target);
void ata_pio_write48(uint64_t LBA, uint16_t sectorcount, uint8_t *target);

#endif
