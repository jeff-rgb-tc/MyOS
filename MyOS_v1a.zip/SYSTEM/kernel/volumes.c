#include "volumes.h"
#include "ata_pio_drv.h"
#include "fat32.h"
#include "common.h"

static volume_t vols[VOL_MAX];
static int vol_n = 0;

static const char *const fs_names[] = {
    "Unknown", "No disc", "FAT12", "FAT16", "FAT32", "exFAT", "NTFS", "ext2", "ext3", "ext4",
    "ISO 9660", "Linux swap", "Btrfs", "XFS", "HFS+", "BitLocker"
};
const char *volumes_fs_name(fs_type_t fs) { return ((int)fs >= 0 && (int)fs < 16) ? fs_names[fs] : "Unknown"; }
int volumes_count(void) { return vol_n; }
const volume_t *volumes_get(int i) { return (i >= 0 && i < vol_n) ? &vols[i] : 0; }

static uint32_t le32(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }
static uint16_t le16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }

static void put_label(char *dst, const uint8_t *src, int n) {
    int len = 0;
    for(int i = 0; i < n && len < 23; i++) { uint8_t c = src[i]; if(c < 32 || c > 126) c = (c == 0) ? 0 : '?'; if(!c) break; dst[len++] = (char)c; }
    while(len > 0 && dst[len - 1] == ' ') len--;
    dst[len] = 0;
}

static int rd(int dev, uint64_t lba, uint8_t *buf) { return ata_dev_read_stream(dev, lba, 1, buf) == 0; }

/* Recognises the filesystem whose first sector is `base`. */
static fs_type_t detect(int dev, uint64_t base, uint64_t size, char *label) {
    uint8_t s[512], t[512];
    label[0] = 0;
    if(!rd(dev, base, s)) return FS_UNKNOWN;

    if(memcmp(s + 3, "NTFS    ", 8) == 0) return FS_NTFS;
    if(memcmp(s + 3, "EXFAT   ", 8) == 0) return FS_EXFAT;
    if(memcmp(s + 3, "-FVE-FS-", 8) == 0) return FS_BITLOCKER;
    if(memcmp(s, "XFSB", 4) == 0) return FS_XFS;

    uint16_t bps = le16(s + 11);
    uint8_t spc = s[13];
    if(s[510] == 0x55 && s[511] == 0xAA && (bps == 512 || bps == 1024 || bps == 2048 || bps == 4096) &&
       spc && !(spc & (spc - 1)) && s[16] >= 1 && s[16] <= 2 && le16(s + 14) > 0) {
        uint32_t spf = le16(s + 22) ? le16(s + 22) : le32(s + 36);
        uint32_t tot = le16(s + 19) ? le16(s + 19) : le32(s + 32);
        uint32_t root = ((uint32_t)le16(s + 17) * 32 + bps - 1) / bps;
        uint32_t meta = le16(s + 14) + (uint32_t)s[16] * spf + root;
        if(tot > meta && spf) {
            uint32_t clusters = (tot - meta) / spc;
            if(le16(s + 22) == 0 && memcmp(s + 82, "FAT32", 5) == 0) { put_label(label, s + 71, 11); return FS_FAT32; }
            if(clusters < 4085) { put_label(label, s + 43, 11); return FS_FAT12; }
            if(clusters < 65525) { put_label(label, s + 43, 11); return FS_FAT16; }
            put_label(label, s + 71, 11); return FS_FAT32;
        }
    }

    if(size >= 4 && rd(dev, base + 2, t)) {                 /* byte 1024: ext superblock / HFS+ header */
        if(t[56] == 0x53 && t[57] == 0xEF) {
            put_label(label, t + 120, 16);
            uint32_t compat = le32(t + 92), incompat = le32(t + 96);
            if(incompat & 0x40) return FS_EXT4;
            if(compat & 0x4) return FS_EXT3;
            return FS_EXT2;
        }
        if(t[0] == 'H' && (t[1] == '+' || t[1] == 'X')) return FS_HFSPLUS;
    }
    if(size >= 8 && rd(dev, base + 7, t) && memcmp(t + 502, "SWAPSPACE2", 10) == 0) return FS_SWAP;
    if(size >= 160 && rd(dev, base + 128, t) && memcmp(t + 64, "_BHRfS_M", 8) == 0) return FS_BTRFS;
    return FS_UNKNOWN;
}

static volume_t *add(int dev, uint32_t lba, uint64_t sectors, int part_no) {
    if(vol_n >= VOL_MAX) return 0;
    volume_t *v = &vols[vol_n++];
    memset(v, 0, sizeof(*v));
    v->dev = dev; v->part_lba = lba; v->sectors = sectors; v->part_no = part_no;
    const ata_info_t *ai = ata_device_info(dev);
    if(ai) { for(int i = 0; i < 40 && ai->model[i]; i++) v->model[i] = ai->model[i]; }
    return v;
}

static void add_probed(int dev, uint32_t lba, uint64_t sectors, int part_no, uint8_t type_hint) {
    volume_t *v = add(dev, lba, sectors, part_no);
    if(!v) return;
    v->fs = detect(dev, lba, sectors, v->label);
    if(v->fs == FS_UNKNOWN && type_hint == 0x82) v->fs = FS_SWAP;
    if(master_fs && master_fs->dev == dev && master_fs->part_lba == lba) v->is_system = 1;
}

static void scan_gpt(int dev) {
    uint8_t h[512], e[512];
    if(!rd(dev, 1, h) || memcmp(h, "EFI PART", 8) != 0) return;
    uint32_t first = le32(h + 72), count = le32(h + 80), esz = le32(h + 84);
    if(esz < 128 || esz > 512 || (esz & (esz - 1)) || count > 256) return;
    int part_no = 0;
    for(uint32_t i = 0; i < count; i++) {
        uint32_t off = i * esz;
        if(off % 512 == 0 && !rd(dev, first + off / 512, e)) return;
        const uint8_t *p = e + (off % 512);
        int zero = 1;
        for(int k = 0; k < 16; k++) if(p[k]) { zero = 0; break; }
        if(zero) continue;
        uint32_t lo = le32(p + 32), hi = le32(p + 40);
        part_no++;
        if(hi >= lo) add_probed(dev, lo, (uint64_t)(hi - lo) + 1, part_no, 0);
    }
}

static void scan_disk(int dev) {
    const ata_info_t *ai = ata_device_info(dev);
    uint8_t s[512];
    if(!rd(dev, 0, s)) return;

    char lab[24];
    fs_type_t whole = detect(dev, 0, ai->sectors, lab);
    if(whole != FS_UNKNOWN && whole != FS_SWAP) {              /* a filesystem straight on the disk */
        add_probed(dev, 0, ai->sectors, 0, 0);
        vols[vol_n - 1].whole_disk = 1;
        return;
    }
    if(s[510] != 0x55 || s[511] != 0xAA) {
        volume_t *v = add(dev, 0, ai->sectors, 0);
        if(v) { v->whole_disk = 1; v->fs = FS_UNKNOWN; }       /* blank / unknown disk */
        return;
    }
    for(int i = 0; i < 4; i++) if(s[446 + i * 16 + 4] == 0xEE) { scan_gpt(dev); return; }

    int part_no = 0;
    for(int i = 0; i < 4; i++) {
        const uint8_t *e = s + 446 + i * 16;
        uint8_t type = e[4];
        uint32_t start = le32(e + 8), len = le32(e + 12);
        if(type == 0 || len == 0) continue;
        part_no++;
        if(type == 0x05 || type == 0x0F || type == 0x85) {      /* extended: walk the logical partitions */
            uint32_t base = start, cur = start;
            uint8_t b[512];
            for(int n = 0; n < 16; n++) {
                if(!rd(dev, cur, b) || b[510] != 0x55 || b[511] != 0xAA) break;
                uint32_t ls = le32(b + 446 + 8), ll = le32(b + 446 + 12);
                if(b[446 + 4] && ll) { part_no = part_no < 5 ? 5 : part_no + 1; add_probed(dev, cur + ls, ll, part_no, b[446 + 4]); }
                uint32_t ns = le32(b + 462 + 8);
                uint8_t nt = b[462 + 4];
                if(!ns || (nt != 0x05 && nt != 0x0F && nt != 0x85)) break;
                cur = base + ns;
            }
            continue;
        }
        add_probed(dev, start, len, part_no, type);
    }
}

static void scan_optical(int dev) {
    const ata_info_t *ai = ata_device_info(dev);
    volume_t *v = add(dev, 0, 0, 0);
    if(!v) return;
    v->optical = 1; v->whole_disk = 1;
    (void)ai;
    uint32_t cap = ata_atapi_capacity(dev);
    if(!cap) { v->fs = FS_EMPTY; return; }
    v->sectors = (uint64_t)cap * 4;
    static uint8_t sec[2048];
    if(ata_atapi_read(dev, 16, 1, sec) == 0 && sec[0] == 1 && memcmp(sec + 1, "CD001", 5) == 0) {
        v->fs = FS_ISO9660;
        put_label(v->label, sec + 40, 32);
    }
}

int volumes_scan(void) {
    vol_n = 0;
    ata_probe_all();
    /* The image GRUB loaded into memory (Live mode) is the system volume without any disk behind it. */
    if(master_fs && master_fs->dev < 0) {
        volume_t *v = add(-1, 0, 0, 0);
        if(v) {
            const struct bios_parameter_block *b = getBPB(master_fs);
            v->sectors = b->large_sectors_on_media ? b->large_sectors_on_media : b->total_sectors;
            v->fs = FS_FAT32; v->is_system = 1; v->whole_disk = 1;
            memcpy(v->label, "MyOS Live", 10);
            memcpy(v->model, "In-memory image", 16);
        }
    }
    for(int d = 0; d < ATA_MAX_DEVICES; d++) {
        const ata_info_t *ai = ata_device_info(d);
        if(!ai) continue;
        if(ai->present) scan_disk(d);
        else if(ai->atapi) scan_optical(d);
    }
    return vol_n;
}
