#include "fat32.h"
#include "rtc.h"
#include "ata_pio_drv.h"
#include "kheap.h"
#include "common.h"
#include "kernio.h"

f32 *master_fs;

/* In-memory disk backend state. When mem_disk_base is non-NULL, every
 * sector read/write goes through this buffer (typically a GRUB
 * multiboot module already sitting in RAM) instead of the ATA driver.
 * See fat32_set_memory_backend() in fat32.h for the rationale. */
static uint8_t *mem_disk_base = NULL;
static uint32_t mem_disk_length = 0;

void fat32_set_memory_backend(uint8_t *base, uint32_t length) {
    mem_disk_base = base;
    mem_disk_length = length;
}

static int ata_backend_dev = 0;
static uint32_t ata_backend_part = 0;

void fat32_set_ata_backend(int dev, uint32_t part_lba) {
    ata_backend_dev = dev;
    ata_backend_part = part_lba;
}
//int x;

//struct f32 {
//    //FILE *f;
//    uint32_t *FAT;
//    struct bios_parameter_block bpb;
//    uint32_t partition_begin_sector;
//    uint32_t fat_begin_sector;
//    uint32_t cluster_begin_sector;
//    uint32_t cluster_size;
//    uint32_t cluster_alloc_hint;
//};

static void read_bpb(f32 *fs, struct bios_parameter_block *bpb);
static uint32_t sector_for_cluster(f32 *fs, uint32_t cluster);

static void trim_spaces(char *c, int max) {
    int i = 0;
    while(*c != ' ' && i++ < max) {
        c++;
    }
    if(*c == ' ') *c = 0;
}

static void getSector(f32 *fs, uint8_t *buff, uint32_t sector, uint32_t count) {
    if(fs->dev < 0) {
        uint64_t offset = (uint64_t)sector * 512;
        uint64_t bytes = (uint64_t)count * 512;
        if(!mem_disk_base || offset + bytes > mem_disk_length) {
            /* Reading past the end of the in-memory image would read
             * whatever happens to sit in RAM after it -- treat this as
             * a hard filesystem-corruption condition rather than
             * silently returning garbage sectors, which could otherwise
             * manifest as intermittent, hard-to-reproduce misbehavior
             * depending on what memory happened to follow the module. */
            printf("fat32: in-memory disk read out of bounds (sector %d, count %d)\n", sector, count);
            memset(buff, 0, bytes > 0xFFFFFFFF ? 0xFFFFFFFF : (uint32_t)bytes);
            return;
        }
        fastcp((char *)buff, (char *)(mem_disk_base + offset), (uint32_t)bytes);
        return;
    }

    if(ata_dev_read(fs->dev, (uint64_t)fs->part_lba + sector, count, buff) != 0) {
        printf("fat32: disk read error (sector %d, count %d)\n", sector, count);
        memset(buff, 0, count * 512);
    }
}

/* Bulk reads (file data, FAT blocks): bypass the directory cache. */
static void getSectorStream(f32 *fs, uint8_t *buff, uint32_t sector, uint32_t count) {
    if(fs->dev < 0 || count <= 0) { getSector(fs, buff, sector, count); return; }
    if(ata_dev_read_stream(fs->dev, (uint64_t)fs->part_lba + sector, count, buff) != 0) {
        printf("fat32: disk read error (sector %d, count %d)\n", sector, count);
        memset(buff, 0, count * 512);
    }
}

static void putSector(f32 *fs, uint8_t *buff, uint32_t sector, uint32_t count) {
    if(fs->dev < 0) {
        uint64_t offset = (uint64_t)sector * 512;
        uint64_t bytes = (uint64_t)count * 512;
        if(!mem_disk_base || offset + bytes > mem_disk_length) {
            printf("fat32: in-memory disk write out of bounds (sector %d, count %d)\n", sector, count);
            return;
        }
        fastcp((char *)(mem_disk_base + offset), (char *)buff, (uint32_t)bytes);
        return;
    }

    if(ata_dev_write(fs->dev, (uint64_t)fs->part_lba + sector, count, buff) != 0) {
        printf("fat32: disk write error (sector %d, count %d)\n", sector, count);
    }
}

#define FAT_BLOCK_SECTORS 128u                 /* 64 KiB */
#define FAT_BLOCK_SHIFT   14                   /* 16384 entries per block */

/* Makes sure the 64 KiB FAT block holding entry `i` is in RAM. */
static void fat_ensure(f32 *fs, uint32_t i) {
    uint32_t blk = i >> FAT_BLOCK_SHIFT;
    if(fs->fat_loaded[blk >> 3] & (1u << (blk & 7))) return;
    uint32_t first = blk * FAT_BLOCK_SECTORS;
    uint32_t n = fs->bpb.count_sectors_per_FAT32 - first;
    if(n > FAT_BLOCK_SECTORS) n = FAT_BLOCK_SECTORS;
    getSectorStream(fs, (uint8_t *)fs->FAT + (size_t)first * 512, fs->fat_begin_sector + first, n);
    fs->fat_loaded[blk >> 3] |= (uint8_t)(1u << (blk & 7));
}

static inline uint32_t fat_get(f32 *fs, uint32_t i) {
    /* A damaged chain can point past the end of the FAT: treat that as end-of-chain, never read outside the table. */
    if(i >= fs->bpb.count_sectors_per_FAT32 * 128u) return 0x0FFFFFFF;
    fat_ensure(fs, i);
    return fs->FAT[i];
}

/* Marks FAT entry `i` as changed. Every FAT modification goes through here
 * so flushFAT() knows which sectors really need to be written back. */
static void fat_set(f32 *fs, uint32_t i, uint32_t v) {
    if(i >= fs->bpb.count_sectors_per_FAT32 * 128u) return;
    fat_ensure(fs, i);
    if(fs->free_valid) {
        uint32_t old = fs->FAT[i];
        if(old == 0 && v != 0) fs->free_count--;
        else if(old != 0 && v == 0) fs->free_count++;
    }
    fs->FAT[i] = v;
    uint32_t sec = i >> 7;                         /* 128 entries per sector */
    fs->fat_dirty[sec >> 3] |= (uint8_t)(1u << (sec & 7));
    fs->fat_any_dirty = 1;
}

/* Writes back only the modified FAT sectors, merging neighbours into one
 * transfer. Before this, EVERY file create/delete rewrote the entire FAT
 * (1 MiB on a 512 MiB volume) followed by a cache flush per 64 KiB. */
static void fat_write_dirty(f32 *fs) {
    if(!fs->fat_any_dirty || !fs->fat_dirty) return;
    uint32_t n = fs->bpb.count_sectors_per_FAT32;
    uint32_t s = 0;
    while(s < n) {
        if(!(fs->fat_dirty[s >> 3] & (1u << (s & 7)))) { s++; continue; }
        uint32_t e = s;
        while(e < n && (fs->fat_dirty[e >> 3] & (1u << (e & 7)))) e++;
        putSector(fs, (uint8_t *)fs->FAT + (size_t)s * 512, fs->fat_begin_sector + s, e - s);
        s = e;
    }
    memset(fs->fat_dirty, 0, (n + 7) / 8);
    fs->fat_any_dirty = 0;
}

static void flushFAT(f32 *fs) {
    if(fs->defer_flush) return;
    fat_write_dirty(fs);
}

void fat32_flush(f32 *fs) {
    fat_write_dirty(fs);
}

static uint16_t readi16(uint8_t *buff, size_t offset)
{
    uint8_t *ubuff = buff + offset;
    return ubuff[1] << 8 | ubuff[0];
}
static uint32_t readi32(uint8_t *buff, size_t offset) {
    uint8_t *ubuff = buff + offset;
    return
        ((ubuff[3] << 24) & 0xFF000000) |
        ((ubuff[2] << 16) & 0x00FF0000) |
        ((ubuff[1] << 8) & 0x0000FF00) |
        (ubuff[0] & 0x000000FF);
}

/**
 * 11 2 The number of Bytes per sector (remember, all numbers are in the little-endian format).
 * 13 1 Number of sectors per cluster.
 * 14 2 Number of reserved sectors. The boot record sectors are included in this value.
 * 16 1 Number of File Allocation Tables (FAT's) on the storage media. Often this value is 2.
 * 17 2 Number of directory entries (must be set so that the root directory occupies entire sectors).
 * 19 2 The total sectors in the logical volume. If this value is 0, it means there are more than 65535 sectors in the volume, and the actual count is stored in "Large Sectors (bytes 32-35).
 * 21 1 This Byte indicates the media descriptor type.
 * 22 2 Number of sectors per FAT. FAT12/FAT16 only.
 * 24 2 Number of sectors per track.
 * 26 2 Number of heads or sides on the storage media.
 * 28 4 Number of hidden sectors. (i.e. the LBA of the beginning of the partition.)
 * 32 4 Large amount of sector on media. This field is set if there are more than 65535 sectors in the volume.
 */

/**
 * 36 4 Sectors per FAT. The size of the FAT in sectors.
 * 40 2 Flags.
 * 42 2 FAT version number. The high byte is the major version and the low byte is the minor version. FAT drivers should respect this field.
 * 44 4 The cluster number of the root directory. Often this field is set to 2.
 * 48 2 The sector number of the FSInfo structure.
 * 50 2 The sector number of the backup boot sector.
 * 52 12 Reserved. When the volume is formated these bytes should be zero.
 * 64 1 Drive number. The values here are identical to the values returned by the BIOS interrupt 0x13. 0x00 for a floppy disk and 0x80 for hard disks.
 * 65 1 Flags in Windows NT. Reserved otherwise.
 * 66 1 Signature (must be 0x28 or 0x29).
 * 67 4 VolumeID 'Serial' number. Used for tracking volumes between computers. You can ignore this if you want.
 * 71 11 Volume label string. This field is padded with spaces.
 * 82 8 System identifier string. Always "FAT32   ". The spec says never to trust the contents of this string for any use.
 * 90 420 Boot code.
 */

static void read_bpb(f32 *fs, struct bios_parameter_block *bpb) {
    uint8_t sector0[512];
    getSector(fs, sector0, 0, 1);

    bpb->bytes_per_sector = readi16(sector0, 11);;
    bpb->sectors_per_cluster = sector0[13];
    bpb->reserved_sectors = readi16(sector0, 14);
    bpb->FAT_count = sector0[16];
    bpb->dir_entries = readi16(sector0, 17);
    bpb->total_sectors = readi16(sector0, 19);
    bpb->media_descriptor_type = sector0[21];
    bpb->count_sectors_per_FAT12_16 = readi16(sector0, 22);
    bpb->count_sectors_per_track = readi16(sector0, 24);
    bpb->count_heads_or_sizes_on_media = readi16(sector0, 26);
    bpb->count_hidden_sectors = readi32(sector0, 28);
    bpb->large_sectors_on_media = readi32(sector0, 32);
    // EBR
    bpb->count_sectors_per_FAT32 = readi32(sector0, 36);
    bpb->flags = readi16(sector0, 40);
    bpb->FAT_version = readi16(sector0, 42);
    bpb->cluster_number_root_dir = readi32(sector0, 44);
    bpb->sector_number_FSInfo = readi16(sector0, 48);
    bpb->sector_number_backup_boot_sector = readi16(sector0, 50);
    // Skip 12 bytes
    bpb->drive_number = sector0[64];
    bpb->windows_flags = sector0[65];
    bpb->signature = sector0[66];
    bpb->volume_id = readi32(sector0, 67);
    memcpy(&bpb->volume_label, sector0 + 71, 11); bpb->volume_label[11] = 0;
    memcpy(&bpb->system_id, sector0 + 82, 8); bpb->system_id[8] = 0;
}

static uint32_t sector_for_cluster(f32 *fs, uint32_t cluster) {
    return fs->cluster_begin_sector + ((cluster - 2) * fs->bpb.sectors_per_cluster);
}

// CLUSTER NUMBERS START AT 2 (for some reason...)
void getCluster(f32 *fs, uint8_t *buff, uint32_t cluster_number) { // static
    if(cluster_number >= EOC) {
        PANIC("Can't get cluster. Hit End Of Chain.");
    }
    uint32_t sector = sector_for_cluster(fs, cluster_number);
    uint32_t sector_count = fs->bpb.sectors_per_cluster;
    getSector(fs, buff, sector, sector_count);
}

static void putCluster(f32 *fs, uint8_t *buff, uint32_t cluster_number) {
    uint32_t sector = sector_for_cluster(fs, cluster_number);
    uint32_t sector_count = fs->bpb.sectors_per_cluster;
    putSector(fs, buff, sector, sector_count);
}

uint32_t get_next_cluster_id(f32 *fs, uint32_t cluster) { // static
    return fat_get(fs, cluster) & 0x0FFFFFFF;
}

static char *parse_long_name(uint8_t *entries, uint8_t entry_count) {
    // each entry can hold 13 characters, plus room for a null terminator
    // -- nothing in the LFN entries themselves is guaranteed to supply
    // one, so the buffer must have an explicit spare byte for it or any
    // caller that treats this as a C string (strlen, strcmp/strcasecmp,
    // strdup...) reads past the allocation into whatever heap memory
    // happens to follow.
    char *name = kmalloc(entry_count * 13 + 1);
    name[entry_count * 13] = 0;
    int i, j;
    for(i = 0; i < entry_count; i++) {
        uint8_t *entry = entries + (i * 32);
        uint8_t entry_no = (uint8_t)entry[0] & 0x0F;
        if(entry_no == 0 || entry_no > entry_count) {
            /* Malformed/unexpected sequence number -- bail rather than
             * write outside the buffer via a garbage index. */
            kfree(name);
            return strdup("");
        }
        char *name_offset = name + ((entry_no - 1) * 13);

        for(j = 1; j < 10; j+=2) {
            if(entry[j] >= 32 && entry[j] <= 127) {
                *name_offset = entry[j];
            }
            else {
                *name_offset = 0;
            }
            name_offset++;
        }
        for(j = 14; j < 25; j+=2) {
            if(entry[j] >= 32 && entry[j] <= 127) {
                *name_offset = entry[j];
            }
            else {
                *name_offset = 0;
            }
            name_offset++;
        }
        for(j = 28; j < 31; j+=2) {
            if(entry[j] >= 32 && entry[j] <= 127) {
                *name_offset = entry[j];
            }
            else {
                *name_offset = 0;
            }
            name_offset++;
        }
    }
    return name;
}

static void clear_cluster(f32 *fs, uint32_t cluster) {
    uint8_t *buffer = kmalloc(fs->cluster_size);
    memset(buffer, 0, fs->cluster_size);
    putCluster(fs, buffer, cluster);
    kfree(buffer);
}

/* `clear` = zero the new cluster on disk. File data clusters are overwritten
 * right away by the caller, so zeroing them first just doubled the writes. */
static uint32_t allocateClusterEx(f32 *fs, int clear) {
    uint32_t i, ints_per_fat = (512 * fs->bpb.count_sectors_per_FAT32) / 4;
    for(i = fs->cluster_alloc_hint; i < ints_per_fat; i++) {
        if(fat_get(fs, i) == 0) {
            fat_set(fs, i, 0x0FFFFFFF);
            if(clear) clear_cluster(fs, i);
            fs->cluster_alloc_hint = i+1;
            return i;
        }
    }
    for(i = 0; i < fs->cluster_alloc_hint; i++) {
        if(fat_get(fs, i) == 0) {
            fat_set(fs, i, 0x0FFFFFFF);
            if(clear) clear_cluster(fs, i);
            fs->cluster_alloc_hint = i+1;
            return i;
        }
    }
    return 0;
}

static uint32_t allocateCluster(f32 *fs) { return allocateClusterEx(fs, 1); }

// Creates a checksum for an 8.3 filename
// must be in directory-entry format, i.e.
// fat32.c -> "FAT32   C  "
static uint8_t checksum_fname(char *fname) {
    uint32_t i;
    uint8_t checksum = 0;
    for(i = 0; i < 11; i++) {
        uint8_t highbit = (checksum & 0x1) << 7;
        checksum = ((checksum >> 1) & 0x7F) | highbit;
        checksum = checksum + fname[i];
    }
    return checksum;
}

static void write_8_3_filename(char *fname, uint8_t *buffer) {
    memset(buffer, ' ', 11);
    uint32_t namelen = strlen(fname);
    // find the extension
    int i;
    int dot_index = -1;
    for(i = namelen-1; i >= 0; i--) {
        if(fname[i] == '.') {
            // Found it!
            dot_index = i;
            break;
        }
    }

    // Write the extension
    if(dot_index >= 0) {
        for(i = 0; i < 3; i++) {
            uint32_t c_index = dot_index + 1 + i;
            uint8_t c = c_index >= namelen ? ' ' : k_toupper(fname[c_index]);
            buffer[8 + i] = c;
        }
    }
    else {
        for(i = 0; i < 3; i++) {
            buffer[8 + i] = ' ';
        }
    }

    // Write the filename.
    uint32_t firstpart_len = namelen;
    if(dot_index >= 0) {
        firstpart_len = dot_index;
    }
    if(firstpart_len > 8) {
        // Write the weird tilde thing.
        for(i = 0; i < 6; i++) {
            buffer[i] = k_toupper(fname[i]);
        }
        buffer[6] = '~';
        buffer[7] = '1'; // probably need to enumerate like files and increment.
    }
    else {
        // Just write the file name.
        uint32_t j;
        for(j = 0; j < firstpart_len; j++) {
            buffer[j] = k_toupper(fname[j]);
        }
    }
}

static uint8_t *locate_entries(f32 *fs, uint8_t *cluster_buffer, struct directory *dir, uint32_t count, uint32_t *found_cluster) {
    uint32_t dirs_per_cluster = fs->cluster_size / 32;

    uint32_t i;
    int64_t index = -1;
    uint32_t cluster = dir->cluster;
    while(1) {
        getCluster(fs, cluster_buffer, cluster);

        uint32_t in_a_row = 0;
        for(i = 0; i < dirs_per_cluster; i++) {
            uint8_t *entry = cluster_buffer + (i * 32);
            uint8_t first_byte = entry[0];
            if(first_byte == 0x00 || first_byte == 0xE5) {
                in_a_row++;
            }
            else {
                in_a_row = 0;
            }

            if(in_a_row == count) {
                index = i - (in_a_row - 1);
                break;
            }
        }
        if(index >= 0) {
            // We found a spot to put our crap!
            break;
        }

        uint32_t next_cluster = fat_get(fs, cluster);
        if(next_cluster >= EOC) {
            next_cluster = allocateCluster(fs);
            if(!next_cluster) {
                return 0;
            }
            fat_set(fs, cluster, next_cluster);
        }
        cluster = next_cluster;
    }
    *found_cluster = cluster;
    return cluster_buffer + (index * 32);
}

static void write_long_filename_entries(uint8_t *start, uint32_t num_entries, char *fname) {
    // Create a short filename to use for the checksum.
    char shortfname[12];
    shortfname[11] = 0;
    write_8_3_filename(fname, (uint8_t *)shortfname);
    uint8_t checksum = checksum_fname(shortfname);

    /* Write the long-filename entries */
    // tracks the number of characters we've written into
    // the long-filename entries.
    uint32_t writtenchars = 0;
    char *nameptr = fname;
    uint32_t namelen = strlen(fname);
    uint8_t *entry = NULL;
    uint32_t i;
    for(i = 0; i < num_entries; i++) {
        // reverse the entry order
        entry = start + ((num_entries - 1 - i) * 32);
        // Set the entry number
        entry[0] = i+1;
        entry[13] = checksum;

        // Characters are 16 bytes in long-filename entries (j+=2)
        // And they only go in certain areas in the 32-byte
        // block. (why we have three loops)
        uint32_t j;
        for(j = 1; j < 10; j+=2) {
            if(writtenchars < namelen) {
                entry[j] = *nameptr;
            }
            else {
                entry[j] = 0;
            }
            nameptr++;
            writtenchars++;
        }
        for(j = 14; j < 25; j+=2) {
            if(writtenchars < namelen) {
                entry[j] = *nameptr;
            }
            else {
                entry[j] = 0;
            }
            nameptr++;
            writtenchars++;
        }
        for(j = 28; j < 31; j+=2) {
            if(writtenchars < namelen) {
                entry[j] = *nameptr;
            }
            else {
                entry[j] = 0;
            }
            nameptr++;
            writtenchars++;
        }
        // Mark the attributes byte as LFN (Long File Name)
        entry[11] = LFN;
    }
    // Mark the last(first) entry with the end-of-long-filename bit
    entry[0] |= 0x40;
}

/* Reads the boot sector of the volume `fs` points at and, if it really is
 * FAT32, derives the layout. Returns 0 on success. */
static int mount_volume(f32 *fs) {
    read_bpb(fs, &fs->bpb);

    trim_spaces(fs->bpb.system_id, 8);
    if(strcmp(fs->bpb.system_id, "FAT32") != 0) return -1;
    if(fs->bpb.bytes_per_sector != 512 || fs->bpb.sectors_per_cluster == 0 ||
       fs->bpb.FAT_count == 0 || fs->bpb.count_sectors_per_FAT32 == 0) return -1;

    printf("Sectors per cluster: %d\n", fs->bpb.sectors_per_cluster);

    fs->partition_begin_sector = 0;
    fs->fat_begin_sector = fs->partition_begin_sector + fs->bpb.reserved_sectors;
    fs->cluster_begin_sector = fs->fat_begin_sector + (fs->bpb.FAT_count * fs->bpb.count_sectors_per_FAT32);
    fs->cluster_size = 512 * fs->bpb.sectors_per_cluster;
    fs->cluster_alloc_hint = 0;

    // The FAT is allocated but NOT read: blocks are loaded on first use.
    uint32_t fat_sectors = fs->bpb.count_sectors_per_FAT32;
    uint32_t fat_blocks = (fat_sectors + FAT_BLOCK_SECTORS - 1) / FAT_BLOCK_SECTORS;
    fs->FAT = kmalloc((size_t)fat_sectors * 512);
    fs->fat_dirty = kmalloc((fat_sectors + 7) / 8);
    fs->fat_loaded = kmalloc((fat_blocks + 7) / 8);
    if(!fs->FAT || !fs->fat_dirty || !fs->fat_loaded) return -1;
    memset(fs->fat_dirty, 0, (fat_sectors + 7) / 8);
    memset(fs->fat_loaded, 0, (fat_blocks + 7) / 8);
    fs->fat_any_dirty = 0;
    fs->free_valid = 0;
    return 0;
}

f32 *makeFilesystem(char *fatSystem) {
    (void)fatSystem;
    f32 *fs = kmalloc(sizeof (struct f32));
    memset(fs, 0, sizeof(*fs));
    if(mem_disk_base) {
        printf("Using in-memory FAT32 backend.\n");
        fs->dev = -1;
        fs->part_lba = 0;
    } else {
        /* No in-memory image: use the ATA disk chosen by the kernel
         * (fat32_set_ata_backend) -- the caller has already verified a
         * FAT32 volume is there; mount_volume() re-checks anyway. */
        ata_set_default_device(ata_backend_dev);
        fs->dev = ata_backend_dev;
        fs->part_lba = ata_backend_part;
        printf("Filesystem on ATA disk %d, partition at LBA %d.\n", fs->dev, fs->part_lba);
    }
    if(mount_volume(fs) != 0) {
        kfree(fs);
        return NULL;
    }
    return fs;
}

f32 *makeFilesystemOn(int dev, uint32_t part_lba) {
    f32 *fs = kmalloc(sizeof (struct f32));
    memset(fs, 0, sizeof(*fs));
    fs->dev = dev;
    fs->part_lba = part_lba;
    if(mount_volume(fs) != 0) {
        kfree(fs);
        return NULL;
    }
    return fs;
}

static int bpb_looks_fat32(const uint8_t *s) {
    if(s[510] != 0x55 || s[511] != 0xAA) return 0;
    if(memcmp(s + 82, "FAT32", 5) != 0) return 0;
    uint16_t bps = (uint16_t)(s[11] | (s[12] << 8));
    uint8_t spc = s[13];
    if(bps != 512) return 0;
    if(spc == 0 || (spc & (spc - 1))) return 0;       /* power of two */
    if(s[16] == 0) return 0;                           /* FAT count */
    uint32_t spf = (uint32_t)s[36] | ((uint32_t)s[37] << 8) | ((uint32_t)s[38] << 16) | ((uint32_t)s[39] << 24);
    if(spf == 0) return 0;
    return 1;
}

int fat32_probe_volume(int dev, uint32_t *part_lba) {
    uint8_t s[512];
    if(ata_dev_read(dev, 0, 1, s) != 0) return 0;

    /* A bare filesystem with no partition table (how f32.disk is laid out). */
    if(bpb_looks_fat32(s)) { *part_lba = 0; return 1; }

    /* Otherwise an MBR: take the first FAT32 partition. */
    if(s[510] != 0x55 || s[511] != 0xAA) return 0;
    for(int i = 0; i < 4; i++) {
        const uint8_t *e = s + 446 + i * 16;
        uint8_t type = e[4];
        uint32_t start = (uint32_t)e[8] | ((uint32_t)e[9] << 8) | ((uint32_t)e[10] << 16) | ((uint32_t)e[11] << 24);
        if(type != 0x0B && type != 0x0C) continue;
        if(start == 0) continue;
        uint8_t b[512];
        if(ata_dev_read(dev, start, 1, b) != 0) continue;
        if(bpb_looks_fat32(b)) { *part_lba = start; return 1; }
    }
    return 0;
}

void destroyFilesystem(f32 *fs) {
    if(fs->ops) { if(fs->ops->destroy) fs->ops->destroy(fs); kfree(fs); return; }
    printf("Destroying filesystem.\n");
    flushFAT(fs);
    kfree(fs->FAT);
    kfree(fs->fat_dirty);
    kfree(fs->fat_loaded);
    kfree(fs);
}

const struct bios_parameter_block *getBPB(f32 *fs) {
    return &fs->bpb;
}

void populate_root_dir(f32 *fs, struct directory *dir) {
    if(fs->ops) { fs->ops->root(fs, dir); return; }
    populate_dir(fs, dir, 2);
}

// Populates dirent with the directory entry starting at start
// Returns a pointer to the next 32-byte chunk after the entry
// or NULL if either start does not point to a valid entry, or
// there are not enough entries to build a struct dir_entry
static uint8_t *read_dir_entry(f32 *fs, uint8_t *start, uint8_t *end, struct dir_entry *dirent) {
    uint8_t first_byte = start[0];
    uint8_t *entry = start;
    if(first_byte == 0x00 || first_byte == 0xE5) {
        // NOT A VALID ENTRY!
        return NULL;
    }

    uint32_t LFNCount = 0;
    while(entry[11] == LFN) {
        LFNCount++;
        entry += 32;
        if(entry == end) {
            return NULL;
        }
    }
    if(LFNCount > 0) {
        dirent->name = parse_long_name(start, LFNCount);
    }
    else {
        // There's no long file name.
        // Trim up the short filename.
        dirent->name = kmalloc(13);
        memcpy(dirent->name, entry, 11);
        dirent->name[11] = 0;
        char extension[4];
        memcpy(extension, dirent->name + 8, 3);
        extension[3] = 0;
        trim_spaces(extension, 3);

        dirent->name[8] = 0;
        trim_spaces(dirent->name, 8);

        if(strlen(extension) > 0) {
            uint32_t len = strlen(dirent->name);
            dirent->name[len++] = '.';
            memcpy(dirent->name + len, extension, 4);
        }

        /* Windows/mtools mark an all-lowercase 8.3 name with two flag bits in the reserved
         * byte (bit 3 = base name, bit 4 = extension) instead of writing a long-name entry.
         * Honour them so "readme.txt" shows as typed and not as README.TXT. */
        uint8_t case_flags = entry[12];
        if(case_flags & 0x18) {
            char *dot = NULL;
            for(char *c = dirent->name; *c; c++) if(*c == '.') dot = c;
            for(char *c = dirent->name; *c; c++) {
                int in_ext = dot && c > dot;
                if(((case_flags & 0x08) && !in_ext) || ((case_flags & 0x10) && in_ext)) {
                    if(*c >= 'A' && *c <= 'Z') *c = (char)(*c + 32);
                }
            }
        }
    }

    dirent->dir_attrs = entry[11];;
    uint16_t first_cluster_high = readi16(entry, 20);
    uint16_t first_cluster_low = readi16(entry, 26);
    dirent->first_cluster = first_cluster_high << 16 | first_cluster_low;
    dirent->file_size = readi32(entry, 28);
    dirent->wr_time = readi16(entry, 22);
    dirent->wr_date = readi16(entry, 24);
    return entry + 32;
}

// This is a complicated one. It parses a directory entry into the dir_entry pointed to by target_dirent.
// root_cluster  must point to a buffer big enough for two clusters.
// entry         points to the entry the caller wants to parse, and must point to a spot within root_cluster.
// nextentry     will be modified to hold the next spot within root_entry to begin looking for entries.
// cluster       is the cluster number of the cluster loaded into root_cluster.
// secondcluster will be modified IF this function needs to load another cluster to continue parsing
//               the entry, in which case, it will be set to the value of the cluster loaded.
//
void next_dir_entry(f32 *fs, uint8_t *root_cluster, uint8_t *entry, uint8_t **nextentry, struct dir_entry *target_dirent, uint32_t cluster, uint32_t *secondcluster) {

    uint8_t *end_of_cluster = root_cluster + fs->cluster_size;
    *nextentry = read_dir_entry(fs, entry, end_of_cluster, target_dirent);
    if(!*nextentry) {
        // Something went wrong!
        // Either the directory entry spans the bounds of a cluster,
        // or the directory entry is invalid.
        // Load the next cluster and retry.

        // Figure out how much of the last cluster to "replay"
        uint32_t bytes_from_prev_chunk = end_of_cluster - entry;

        *secondcluster = get_next_cluster_id(fs, cluster);
        if(*secondcluster >= EOC) {
            // There's not another directory cluster to load
            // and the previous entry was invalid!
            // It's possible the filesystem is corrupt or... you know...
            // my software could have bugs.
            PANIC("FOUND BAD DIRECTORY ENTRY!");
        }
        // Load the cluster after the previous saved entries.
        getCluster(fs, root_cluster + fs->cluster_size, *secondcluster);
        // Set entry to its new location at the beginning of root_cluster.
        entry = root_cluster + fs->cluster_size - bytes_from_prev_chunk;

        // Retry reading the entry.
        *nextentry = read_dir_entry(fs, entry, end_of_cluster + fs->cluster_size, target_dirent);
        if(!*nextentry) {
            // Still can't parse the directory entry.
            // Something is very wrong.
            PANIC("FAILED TO READ DIRECTORY ENTRY! THE SOFTWARE IS BUGGY!\n");
        }
    }
}

// TODO: Refactor this. It is so similar to delFile that it would be nice
// to combine the similar elements.
// WARN: If you fix a bug in this function, it's likely you will find the same
// bug in delFile.
/* True if `cluster` can be a data cluster of this volume. Garbage (a damaged directory entry, text read as a
 * directory) must never reach the sector arithmetic. */
static int cluster_valid(f32 *fs, uint32_t cluster) {
    uint32_t total = fs->bpb.large_sectors_on_media ? fs->bpb.large_sectors_on_media : fs->bpb.total_sectors;
    uint32_t meta = fs->bpb.reserved_sectors + (uint32_t)fs->bpb.FAT_count * fs->bpb.count_sectors_per_FAT32;
    if(!fs->bpb.sectors_per_cluster || total <= meta) return 0;
    uint32_t clusters = (total - meta) / fs->bpb.sectors_per_cluster;
    return cluster >= 2 && cluster < clusters + 2;
}

void populate_dir(f32 *fs, struct directory *dir, uint32_t cluster) {
    if(fs->ops) { fs->ops->populate(fs, dir, cluster); return; }
    dir->cluster = cluster;
    if(!cluster_valid(fs, cluster)) {                 /* not a real directory: present it as empty instead of reading garbage */
        dir->entries = (struct dir_entry *)kmalloc(sizeof(struct dir_entry));
        dir->num_entries = 0;
        return;
    }
    uint32_t dirs_per_cluster = fs->cluster_size / 32;
    uint32_t max_dirs = 0;
    dir->entries = 0;
    uint32_t entry_count = 0;
    // Double the size in case we need to read a directory entry that
    // spans the bounds of a cluster. (Heap, not stack: the kernel stack is
    // only 32 KiB and clusters can now be up to 32 KiB.)
    uint8_t *root_cluster = kmalloc(fs->cluster_size * 2);

    while(1) {
        max_dirs += dirs_per_cluster;
        dir->entries = krealloc(dir->entries, max_dirs * sizeof (struct dir_entry));
        getCluster(fs, root_cluster, cluster);

        uint8_t *entry = root_cluster;
        while((uint32_t)(entry - root_cluster) < fs->cluster_size) {
            uint8_t first_byte = *entry;
            if(first_byte == 0x00 || first_byte == 0xE5) {
                // This directory entry has never been written
                // or it has been deleted.
                entry += 32;
                continue;
            }

            uint32_t secondcluster = 0;
            uint8_t *nextentry = NULL;
            struct dir_entry *target_dirent = dir->entries + entry_count;
            next_dir_entry(fs, root_cluster, entry, &nextentry, target_dirent, cluster, &secondcluster);
            entry = nextentry;
            if(secondcluster) {
                /* The entry straddled a cluster boundary, so the second cluster is already in
                 * the upper half of the buffer. Move it down and keep scanning it: without this
                 * every entry after the straddling one in that cluster was silently dropped (with
                 * 512-byte clusters that truncated /APPS and /SYSTEM/res/icons). */
                cluster = secondcluster;
                memcpy(root_cluster, root_cluster + fs->cluster_size, fs->cluster_size);   /* regions do not overlap */
                entry -= fs->cluster_size;
                /* we are now consuming a cluster the loop header did not budget for */
                max_dirs += dirs_per_cluster;
                dir->entries = krealloc(dir->entries, max_dirs * sizeof (struct dir_entry));
            }

            entry_count++;
        }
        cluster = get_next_cluster_id(fs, cluster);
        if(cluster >= EOC) break;
    }
    kfree(root_cluster);
    dir->num_entries = entry_count;
}

static void zero_FAT_chain(f32 *fs, uint32_t start_cluster) {
    uint32_t cluster = start_cluster;
    while(cluster < EOC && cluster != 0) {
        uint32_t next_cluster = fat_get(fs, cluster);
        fat_set(fs, cluster, 0);
        cluster = next_cluster;
    }
    flushFAT(fs);
}

// TODO: Refactor this. It is so similar to populate_dir that it would be nice
// to combine the similar elements.
// WARN: If you fix a bug in this function, it's likely you will find the same
// bug in populate_dir.
static void delFile_inner(f32 *fs, struct directory *dir, char *filename) {
    uint32_t cluster = dir->cluster;

    // Double the size in case we need to read a directory entry that
    // spans the bounds of a cluster.
    uint8_t *root_cluster = kmalloc(fs->cluster_size * 2);
    struct dir_entry target_dirent;

    // Try to locate and invalidate the directory entries corresponding to the
    // filename in dirent.
    while(1) {
        getCluster(fs, root_cluster, cluster);

        uint8_t *entry = root_cluster;
        while((uint32_t)(entry - root_cluster) < fs->cluster_size) {
            uint8_t first_byte = *entry;
            if(first_byte == 0x00 || first_byte == 0xE5) {
                // This directory entry has never been written
                // or it has been deleted.
                entry += 32;
                continue;
            }

            uint32_t secondcluster = 0;
            uint8_t *nextentry = NULL;
            next_dir_entry(fs, root_cluster, entry, &nextentry, &target_dirent, cluster, &secondcluster);

            // We have a target dirent! see if it's the one we want!
            if(strcmp(target_dirent.name, filename) == 0) {
                // We found it! Invalidate all the entries.
                memset(entry, 0, nextentry - entry);
                putCluster(fs, root_cluster, cluster);
                if(secondcluster) {
                    putCluster(fs, root_cluster + fs->cluster_size, secondcluster);
                }
                zero_FAT_chain(fs, target_dirent.first_cluster);
                kfree(target_dirent.name);
                kfree(root_cluster);
                return;
            }
            else {
                // We didn't find it. Continue.
                entry = nextentry;
                if(secondcluster) {
                    cluster = secondcluster;                     /* same straddle fix as populate_dir */
                    memcpy(root_cluster, root_cluster + fs->cluster_size, fs->cluster_size);   /* regions do not overlap */
                    entry -= fs->cluster_size;
                }
            }
            kfree(target_dirent.name);

        }
        cluster = get_next_cluster_id(fs, cluster);
        if(cluster >= EOC) { kfree(root_cluster); return; }
    }
}

/* One FLUSH CACHE per operation instead of one per disk write. */
void delFile(f32 *fs, struct directory *dir, char *filename) {
    if(fs->ops) return;
    if(fs->dev >= 0) ata_defer_flush(1);
    delFile_inner(fs, dir, filename);
    if(fs->dev >= 0) ata_defer_flush(0);
}

void free_directory(f32 *fs, struct directory *dir){
    uint32_t i;
    for(i = 0; i < dir->num_entries; i++) {
        kfree(dir->entries[i].name);
    }
    kfree(dir->entries);
}

void (*io_progress_hook)(void) = NULL;

uint8_t *readFile(f32 *fs, struct dir_entry *dirent) {
    if(fs->ops) return fs->ops->read(fs, dirent);
    uint32_t size = dirent->file_size;
    uint8_t *file = kmalloc(size);
    if(!file || size == 0) return file;
    const uint32_t cs = fs->cluster_size;
    const uint32_t spc = fs->bpb.sectors_per_cluster;
    uint32_t max_run = 128 / spc; if(max_run == 0) max_run = 1;
    uint32_t remaining = size;
    uint8_t *dst = file;
    uint32_t cluster = dirent->first_cluster;

    /* Read runs of physically consecutive clusters with ONE disk command
     * (was: one command per cluster, each with its own setup/wait). */
    while(remaining && cluster >= 2 && cluster < EOC) {
        uint32_t need = (remaining + cs - 1) / cs;
        uint32_t run = 1, last = cluster;
        while(run < need && run < max_run && get_next_cluster_id(fs, last) == last + 1) { last++; run++; }

        uint32_t full = remaining / cs;
        uint32_t direct = run < full ? run : full;
        if(direct) {
            getSectorStream(fs, dst, sector_for_cluster(fs, cluster), direct * spc);
            dst += (size_t)direct * cs;
            remaining -= direct * cs;
        }
        if(direct < run && remaining) {          /* partial last cluster */
            uint8_t *tmp = kmalloc(cs);
            getCluster(fs, tmp, cluster + direct);
            memcpy(dst, tmp, remaining);
            kfree(tmp);
            remaining = 0;
            break;
        }
        cluster = get_next_cluster_id(fs, last);
        if(io_progress_hook) io_progress_hook();
    }
    return file;
}

static void writeFile_impl_inner(f32 *fs, struct directory *dir, uint8_t *file, char *fname, uint32_t flen, uint8_t attrs, uint32_t setcluster) {
    uint32_t required_clusters = flen / fs->cluster_size;
    if(flen % fs->cluster_size != 0) required_clusters++;
    if(required_clusters == 0) required_clusters++; // Allocate at least one cluster.
    // One for the traditional 8.3 name, one for each 13 charaters in the extended name.
    // Int division truncates, so if there's a remainder from length / 13, add another entry.
    uint32_t required_entries_long_fname = (strlen(fname) / 13);
    if(strlen(fname) % 13 > 0) {
        required_entries_long_fname++;
    }

    uint32_t required_entries_total = required_entries_long_fname + 1;

    uint32_t cluster; // The cluster number that the entries are found in
    uint8_t *root_cluster = kmalloc(fs->cluster_size);   // heap: kernel stack is only 32 KiB
    uint8_t *start_entries = locate_entries(fs, root_cluster, dir, required_entries_total, &cluster);
    if(!start_entries) { kfree(root_cluster); return; }
    write_long_filename_entries(start_entries, required_entries_long_fname, fname);

    // Write the actual file entry;
    uint8_t *actual_entry = start_entries + (required_entries_long_fname * 32);
    write_8_3_filename(fname, actual_entry);

    // Actually write the file!
    uint32_t writtenbytes = 0;
    uint32_t prevcluster = 0;
    uint32_t firstcluster = 0;
    uint32_t i;
    if(setcluster) {
        // Caller knows where the first cluster is.
        // Don't allocate or write anything.
        firstcluster = setcluster;
    }
    else {
        /* Collect physically consecutive clusters into one buffer and write
         * each run with a single disk command (was: zero the cluster, then
         * write it again, one cluster at a time). */
        const uint32_t spc = fs->bpb.sectors_per_cluster;
        uint32_t run_cap = 128 / spc; if(run_cap == 0) run_cap = 1;
        uint8_t *runbuf = kmalloc((size_t)run_cap * fs->cluster_size);
        uint32_t run_start = 0, run_len = 0;
        for(i = 0; i < required_clusters; i++) {
            uint32_t currcluster = allocateClusterEx(fs, 0);
            if(!currcluster) {                    /* disk full: keep what fits */
                printf("fat32: disk full\n");
                flen = writtenbytes;
                break;
            }
            if(run_len && (currcluster != run_start + run_len || run_len == run_cap)) {
                putSector(fs, runbuf, sector_for_cluster(fs, run_start), run_len * spc);
                run_len = 0;
            }
            if(!run_len) run_start = currcluster;
            if(!firstcluster) firstcluster = currcluster;
            uint8_t *slot = runbuf + (size_t)run_len * fs->cluster_size;
            memset(slot, 0, fs->cluster_size);
            uint32_t bytes_to_write = flen - writtenbytes;
            if(bytes_to_write > fs->cluster_size) {
                bytes_to_write = fs->cluster_size;
            }
            if(bytes_to_write) memcpy(slot, file + writtenbytes, bytes_to_write);
            writtenbytes += bytes_to_write;
            run_len++;
            if(prevcluster) {
                fat_set(fs, prevcluster, currcluster);
            }
            prevcluster = currcluster;
        }
        if(run_len) putSector(fs, runbuf, sector_for_cluster(fs, run_start), run_len * spc);
        kfree(runbuf);
    }

    // Write the other fields of the actual entry
    // We do it down here because we need the first cluster
    // number.

    // attrs
    actual_entry[11] = attrs;

    // high cluster bits
    actual_entry[20] = (firstcluster >> 16) & 0xFF;
    actual_entry[21] = (firstcluster >> 24) & 0xFF;

    // low cluster bits
    actual_entry[26] = (firstcluster) & 0xFF;
    actual_entry[27] = (firstcluster >> 8) & 0xFF;

    // last-write timestamp (FAT format) from the RTC, so Explorer/cmd can
    // show real dates for files created inside MyOS
    {
        rtc_date_t d; rtc_time_t t;
        rtc_read_date(&d); rtc_read_time(&t);
        uint16_t fat_date = (uint16_t)((((d.year >= 1980 ? d.year - 1980 : 0) & 0x7F) << 9) | ((d.month & 0xF) << 5) | (d.day & 0x1F));
        uint16_t fat_time = (uint16_t)(((t.hours & 0x1F) << 11) | ((t.minutes & 0x3F) << 5) | ((t.seconds / 2) & 0x1F));
        actual_entry[22] = fat_time & 0xFF; actual_entry[23] = fat_time >> 8;
        actual_entry[24] = fat_date & 0xFF; actual_entry[25] = fat_date >> 8;
        actual_entry[16] = actual_entry[24]; actual_entry[17] = actual_entry[25]; // creation date
    }

    // file size
    actual_entry[28] = flen & 0xFF;
    actual_entry[29] = (flen >> 8) & 0xFF;
    actual_entry[30] = (flen >> 16) & 0xFF;
    actual_entry[31] = (flen >> 24) & 0xFF;

    // Write the cluster back to disk
    putCluster(fs, root_cluster, cluster);
    kfree(root_cluster);
    flushFAT(fs);
}

static void writeFile_impl(f32 *fs, struct directory *dir, uint8_t *file, char *fname, uint32_t flen, uint8_t attrs, uint32_t setcluster) {
    if(fs->dev >= 0) ata_defer_flush(1);
    writeFile_impl_inner(fs, dir, file, fname, flen, attrs, setcluster);
    if(fs->dev >= 0) ata_defer_flush(0);
}

/* Case-insensitive existence check, mirroring entry_for_path()'s
 * (stdio.c) reasoning: a short (8.3) FAT32 entry is always stored
 * upper-case on disk regardless of what case it was written with, so a
 * case-sensitive comparison here would fail to recognize
 * "settings.ini" as already existing once it comes back as
 * "SETTINGS.INI" from a real short-name-only entry -- silently letting
 * a duplicate get created instead of overwriting, exactly the bug this
 * function exists to fix. */
static int dir_has_file(struct directory *dir, const char *filename) {
    for(uint32_t i = 0; i < dir->num_entries; i++) {
        struct dir_entry *e = &dir->entries[i];
        if(e->name && !(e->dir_attrs & (LFN | DIRECTORY)) && strcasecmp(e->name, filename) == 0) {
            return 1;
        }
    }
    return 0;
}

void writeFile(f32 *fs, struct directory *dir, uint8_t *file, char *fname, uint32_t flen) {
    if(fs->ops) return;                       /* foreign filesystems are read-only */
    /* writeFile_impl()/locate_entries() below only ever look for a free
     * slot to write NEW directory entries into -- there is no check
     * anywhere in this write path for "a file with this name already
     * exists here". Calling writeFile() a second time with the same
     * filename therefore used to silently create a second, duplicate
     * directory entry rather than overwriting the first: the original
     * (now stale) entry stayed right where it was, and since directory
     * entries are read/matched in on-disk order, the OLD content kept
     * winning on every subsequent read -- from the outside, this looked
     * exactly like "saves don't take effect" (settings.c/desktop_ini.c/
     * the .lnk shortcut writer in app_explorer.c all call writeFile()
     * repeatedly with the same filename expecting an overwrite).
     * Deleting any existing same-named file first makes this a real
     * overwrite, the behavior every caller already assumed it had. This
     * needs dir->num_entries/dir->entries to be current -- callers that
     * already have a stale `dir` (e.g. after an earlier write/delete in
     * the same dir without repopulating) should repopulate it first;
     * see e.g. settings.c's ensure_user_path(), which always populates
     * dir fresh right before this is called. */
    if(dir_has_file(dir, fname)) {
        delFile(fs, dir, fname);
        /* delFile() invalidated entries and freed the old cluster chain
         * directly in the raw on-disk structures, but `dir` (the
         * in-memory struct directory the caller is holding) still
         * reflects the pre-delete listing -- repopulate it from the
         * same cluster so locate_entries() below sees the now-free
         * slot rather than stale cached entries. */
        uint32_t dir_cluster = dir->cluster;
        free_directory(fs, dir);
        populate_dir(fs, dir, dir_cluster);
    }
    writeFile_impl(fs, dir, file, fname, flen, 0, 0);
}

static void mkdir_subdirs(f32 *fs, struct directory *dir, uint32_t parentcluster) {
    writeFile_impl(fs, dir, NULL, ".", 0, DIRECTORY, dir->cluster);
    writeFile_impl(fs, dir, NULL, "..", 0, DIRECTORY, parentcluster);
}

void mkdir(f32 *fs, struct directory *dir, char *dirname) {
    if(fs->ops) return;
    writeFile_impl(fs, dir, NULL, dirname, 0, DIRECTORY, 0);

    // We need to add the subdirectories '.' and '..'
    struct directory subdir;
    populate_dir(fs, &subdir, dir->cluster);
    uint32_t i;
    for(i = 0; i < subdir.num_entries; i++) {
        if(strcmp(subdir.entries[i].name, dirname) == 0) {
            struct directory newsubdir;
            populate_dir(fs, &newsubdir, subdir.entries[i].first_cluster);
            mkdir_subdirs(fs, &newsubdir, subdir.cluster);
            free_directory(fs, &newsubdir);
        }
    }
    free_directory(fs, &subdir);
}

void print_directory(f32 *fs, struct directory *dir) {
    uint32_t i;
    uint32_t max_name = 0;
    for(i = 0; i < dir->num_entries; i++) {
        uint32_t namelen = strlen(dir->entries[i].name);
        max_name = namelen > max_name ? namelen : max_name;
    }

    char *namebuff = kmalloc(max_name + 1);
    for(i = 0; i < dir->num_entries; i++) {
//        printf("[%d] %*s %c %8d bytes ",
//               i,
//               -max_name,
//               dir->entries[i].name,
//               dir->entries[i].dir_attrs & DIRECTORY?'D':' ',
//               dir->entries[i].file_size, dir->entries[i].first_cluster);
        printf("[%d] ", i);


        uint32_t j;
        for(j = 0; j < max_name; j++) {
            namebuff[j] = ' ';
        }
        namebuff[max_name] = 0;
        for(j = 0; j < strlen(dir->entries[i].name); j++) {
            namebuff[j] = dir->entries[i].name[j];
        }

        printf("%s %c %d ",
               namebuff,
               dir->entries[i].dir_attrs & DIRECTORY?'D':' ',
               dir->entries[i].file_size);

        uint32_t cluster = dir->entries[i].first_cluster;
        uint32_t cluster_count = 1;
        while(1) {
            cluster = fat_get(fs, cluster);
            if(cluster >= EOC) break;
            if(cluster == 0) {
                PANIC("BAD CLUSTER CHAIN! FS IS CORRUPT!");
            }
            cluster_count++;
        }
        printf("clusters: [%d]\n", cluster_count);
    }
    kfree(namebuff);
}

uint32_t count_free_clusters(f32 *fs) {
    /* Counted once (loads the whole FAT), then kept up to date by fat_set(). */
    if(!fs->free_valid) {
        uint32_t clusters_in_fat = (fs->bpb.count_sectors_per_FAT32 * 512) / 4;
        uint32_t count = 0;
        for(uint32_t i = 0; i < clusters_in_fat; i++) {
            if(fat_get(fs, i) == 0) count++;
        }
        fs->free_count = count;
        fs->free_valid = 1;
    }
    return fs->free_count;
}
