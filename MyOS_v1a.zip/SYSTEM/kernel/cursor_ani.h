#ifndef CURSOR_ANI_H
#define CURSOR_ANI_H

#include "stdint.h"
#include "cursor.h"

/* Windows animated-cursor (.ani) support.
 *
 * An .ani is a RIFF file of form type "ACON":
 *   anih  - 36-byte header: frame count, step count, default display rate
 *           in jiffies (1/60 s), flags (bit 0 = frames are .cur/.ico data)
 *   rate  - optional, one uint32 per STEP: that step's duration in jiffies
 *   seq   - optional, one uint32 per STEP: which frame to show
 *   LIST fram - one "icon" chunk per FRAME, each a complete .cur file
 * Without a seq chunk the steps simply play frames 0..n-1 in order; without
 * a rate chunk every step lasts the header's default rate. The whole thing
 * loops forever. Every frame is decoded once at load time with the same
 * cursor_load_from_memory() the static .cur cursors use, so animated and
 * plain cursors share one blit path. */

#define CURSOR_ANI_MAX_FRAMES 128
#define CURSOR_ANI_MAX_STEPS  512

typedef struct {
    int frame_count;
    cursor_image_t *frames;     /* frame_count decoded images */
    int step_count;
    uint8_t *step_frame;        /* step_count entries: index into frames */
    uint16_t *step_ms;          /* step_count entries: duration in ms (>= 16) */
    uint32_t total_ms;          /* length of one full loop */
} cursor_anim_t;

/* Parses an in-memory .ani. Returns 1 on success (caller owns the result
 * and must cursor_ani_free() it), 0 on any malformed/unsupported input --
 * every length is bounds-checked, so a corrupt file can only fail. */
int cursor_ani_load_from_memory(const uint8_t *data, uint32_t length, cursor_anim_t *out);

void cursor_ani_free(cursor_anim_t *anim);

/* Which step is showing `ms` milliseconds into the (looping) animation. */
int cursor_ani_step_at(const cursor_anim_t *anim, uint32_t ms);

/* The image to draw `ms` milliseconds into the animation. */
const cursor_image_t *cursor_ani_image_at(const cursor_anim_t *anim, uint32_t ms);

#endif
