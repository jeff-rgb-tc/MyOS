#ifndef WAV_H
#define WAV_H

#include "stdint.h"

/* WAV (RIFF/WAVE) is a thin container around raw PCM -- no compression,
 * no entropy coding, just a handful of chunk headers before the actual
 * sample data. This is a complete, real decoder (unlike mp3.c/ogg.c's
 * documented partial support -- see those headers) since the format
 * itself is simple enough not to need cutting scope anywhere. */

typedef struct {
    uint32_t sample_rate;
    uint8_t channels;      /* 1 = mono, 2 = stereo */
    uint8_t bits_per_sample; /* 8 or 16 -- see wav_load_from_file()'s comment on what happens to other values */
    int16_t *samples;      /* heap-allocated, always converted to 16-bit signed PCM regardless of the file's own bit depth, interleaved if stereo -- caller owns this, free with wav_free() */
    uint32_t sample_count;  /* total INDIVIDUAL samples, not frames -- a stereo file's frame count is sample_count / 2 */
} wav_audio_t;

/* Loads and fully decodes a .wav file into 16-bit PCM ready for
 * audio_queue() (see audio.h). Returns 1 on success, 0 if the file
 * couldn't be read or isn't a WAV file this decoder understands (only
 * uncompressed PCM -- format tag 1 -- is supported; ADPCM/MP3-in-WAV/
 * other compressed WAV variants are not, and are reported as a failure
 * here rather than silently producing noise). 8-bit source files are
 * upconverted to 16-bit (centered at 0 instead of 128, scaled up) so
 * every caller only ever deals with one sample format. */
int wav_load_from_file(const char *path, wav_audio_t *out);

void wav_free(wav_audio_t *audio);

#endif
