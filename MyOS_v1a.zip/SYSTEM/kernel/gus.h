#ifndef GUS_H
#define GUS_H

#include "audio.h"

/* Gravis UltraSound -- legacy ISA sample-playback device (fixed base
 * 240h probed here). Unlike AdLib, the GUS genuinely can play PCM
 * samples -- but its architecture is very different from AC97/SB16:
 * samples must first be uploaded into the card's own onboard RAM (256KB
 * to 1MB depending on the card), then triggered by programming one of
 * its 32 "voices" to play back a region of that RAM, rather than
 * streaming samples through a DMA ring the way AC97/SB16 do. Properly
 * supporting continuous playback of an arbitrary-length WAV/MP3/OGG
 * decode stream would need chunked upload-then-trigger-then-wait-then-
 * upload-next-chunk logic against the card's RAM, which is a
 * significantly larger undertaking than this driver currently
 * implements.
 *
 * This driver implements real hardware DETECTION only (the standard
 * GUS reset/IRQ-status probe), for the same reason as adlib.c: so
 * Drivers/sound/gus.drv reflects genuine detection rather than a
 * placeholder, and audio_active_driver_name() is accurate. Its write()
 * is a documented no-op -- see gus.c's comment -- rather than silently
 * claiming playback capability this version doesn't actually have. */
extern const audio_driver_t gus_driver;

#endif
