#ifndef FSX_H
#define FSX_H

#include "fat32.h"
#include "volumes.h"

/* Mounts any volume found by volumes_scan() as a read-only (FAT32: read/write) f32 object that the
 * normal directory/file calls understand:
 *   FAT32          the regular driver (fat32.c)
 *   FAT12 / FAT16  fsx.c   (read-only)
 *   ext2/ext3/ext4 fsx.c   (read-only; extents, indirect blocks, 64-bit, flex_bg)
 *   ISO 9660       fsx.c   (read-only; Joliet long names when the disc has them)
 * Returns NULL if the volume cannot be mounted (unsupported or damaged); never crashes on bad data.
 * Free with destroyFilesystem(). NTFS / exFAT / Btrfs / XFS are recognised but not readable. */
f32 *fsx_mount(const volume_t *v);

/* Can fsx_mount() handle this filesystem? */
int fsx_supported(fs_type_t fs);

#endif
