#include "boot_splash.h"
#include "gfx.h"
#include "common.h"
#include "pit.h"
#include "vesa.h"
#include "kernio.h"

/* Spinner: a ring of dots, one bright "head" followed by a fading tail,
 * advancing one position every 50 ms from the timer interrupt. */
#define DOTS        12
#define DOT_R       3          /* dot radius in pixels (was 4) */
#define RING_R      18         /* ring radius in pixels (was 28) */
#define TAIL        5          /* number of dots in the fading tail */

/* round(sin(2*pi*i/12) * 256) and cos, 8.8 fixed point (no libm in the kernel). */
static const int sin_t[DOTS] = {   0, 128, 222, 256, 222, 128,   0,-128,-222,-256,-222,-128 };
static const int cos_t[DOTS] = { 256, 222, 128,   0,-128,-222,-256,-222,-128,   0, 128, 222 };

static volatile int active = 0;
static int head = 0;
static int cx = 0, cy = 0;
static uint8_t *fb = 0;
static uint32_t pitch = 0, scr_w = 0, scr_h = 0;

static void put_dot(int x0, int y0, uint32_t color) {
    for(int dy = -DOT_R; dy <= DOT_R; dy++) {
        int yy = y0 + dy;
        if(yy < 0 || (uint32_t)yy >= scr_h) continue;
        uint32_t *row = (uint32_t *)(fb + (uint32_t)yy * pitch);
        for(int dx = -DOT_R; dx <= DOT_R; dx++) {
            int xx = x0 + dx;
            if(xx < 0 || (uint32_t)xx >= scr_w) continue;
            if(dx * dx + dy * dy <= DOT_R * DOT_R + 1) row[xx] = color;
        }
    }
}

static uint32_t grey(int v) { return 0xFF000000u | (uint32_t)(v << 16) | (uint32_t)(v << 8) | (uint32_t)v; }

/* Redraws the whole ring (12 tiny dots: far cheaper than a frame) for the
 * current head position. Safe to run from the timer interrupt. */
static void draw_ring(void) {
    for(int i = 0; i < DOTS; i++) {
        int age = (head - i + DOTS) % DOTS;            /* 0 = head, grows along the tail */
        int v = (age < TAIL) ? 255 - age * 40 : 56;    /* 255,215,175,135,95 then dim */
        int x = cx + ((cos_t[i] * RING_R) >> 8);
        int y = cy + ((sin_t[i] * RING_R) >> 8);
        put_dot(x, y, grey(v));
    }
}

static void splash_hook(void) {
    if(!active) return;
    head = (head + 1) % DOTS;
    draw_ring();
}

void boot_splash_show(void) {
    gfx_clear(0xFF000000);

    scr_w = gfx_width();
    scr_h = gfx_height();

    /* Big title: each font pixel becomes a scale x scale block. About 1/5 of
     * the screen width, clamped so it is large but fits any resolution. */
    const char *title = "MyOS";
    int len = (int)strlen(title);
    int scale = (int)scr_w / (len * GFX_CHAR_COLS * 5);
    if(scale < 4) scale = 4;
    if(scale > 16) scale = 16;
    int title_w = len * GFX_CHAR_COLS * scale;
    int title_h = GFX_CHAR_ROWS * scale;
    int title_x = ((int)scr_w - title_w) / 2;
    int title_y = (int)scr_h / 2 - title_h - 10;   /* a bit above the middle */
    if(title_y < 8) title_y = 8;
    gfx_draw_string_scaled(title_x, title_y, title, 0xFFFFFFFF, scale);

    cx = (int)scr_w / 2;
    cy = title_y + title_h + 24 + RING_R + DOT_R;

    /* Everything static goes to the screen once; from here on only the timer
     * interrupt touches the framebuffer. */
    gfx_present();
    fb = (uint8_t *)get_framebuffer_addr();
    pitch = get_screen_pitch();
    head = 0;
    draw_ring();
    active = 1;
    pit_set_hook(splash_hook);
}

void boot_splash_status(const char *msg) {
    uint32_t secs = pit_get_ms() / 1000;
    printf("[boot %ds] %s\n", (int)secs, msg);
    if(!active || !fb) return;
    gfx_surface_t *bb = gfx_backbuffer();
    if(!bb || !bb->pixels) return;
    int y0 = cy + RING_R + DOT_R + 18, h = GFX_CHAR_ROWS + 6;
    if(y0 + h > (int)scr_h) return;
    char line[96];
    { int n = 0; while(msg[n] && n < 70) { line[n] = msg[n]; n++; } line[n] = 0; sprintf(line + n, "  (%ds)", (int)secs); }
    /* draw into the back buffer, then copy just those rows to the visible screen
     * (the spinner's own pixels are never touched) */
    gfx_fill_rect(0, y0, (int)scr_w, h, 0xFF000000);
    int tw = (int)strlen(line) * GFX_CHAR_COLS;
    gfx_draw_string(((int)scr_w - tw) / 2, y0 + 3, line, 0xFF8A8A94);
    for(int y = y0; y < y0 + h; y++)
        memcpy(fb + (uint32_t)y * pitch, bb->pixels + (uint32_t)y * bb->width, scr_w * 4);
}

void boot_splash_tick(void) {
    /* timer driven now */
}

void boot_splash_stop(void) {
    active = 0;
    pit_set_hook(0);
}
