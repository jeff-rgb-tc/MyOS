#ifndef MP3_H
#define MP3_H

#include "stdint.h"

/* MPEG-1/2 Audio Layer III decoder, covering the practical common case:
 * MPEG-1 Layer III, mono or stereo (including joint stereo), constant
 * or variable bitrate, no free-format, no MPEG-2.5, no multichannel.
 * This is a real, working decoder (Huffman decoding, dequantization,
 * stereo processing, IMDCT, polyphase synthesis filterbank) -- not a
 * stub -- but it does not attempt full spec coverage; see
 * mp3_load_from_file()'s comment for exactly what's out of scope and
 * how it fails (cleanly, with a clear reason) on unsupported input
 * rather than producing garbage audio. */

typedef struct {
    uint32_t sample_rate;
    uint8_t channels;
    int16_t *samples;   /* heap-allocated, 16-bit signed PCM, interleaved if stereo -- caller owns this, free with mp3_free() */
    uint32_t sample_count; /* individual samples, not frames -- see wav.h's identical convention */
} mp3_audio_t;

/* Decodes an entire .mp3 file into 16-bit PCM. Returns 1 on success, 0
 * if the file couldn't be read, isn't MPEG-1 Layer III, or uses a
 * feature this decoder doesn't implement (MPEG-2/2.5 sample rates,
 * free-format bitrate, more than 2 channels) -- these fail cleanly with
 * a logged reason (see mp3.c) rather than attempting a best-effort
 * decode that would produce audible garbage. ID3 tags (v1 at the end of
 * the file, v2 at the start) are detected and skipped automatically. */
int mp3_load_from_file(const char *path, mp3_audio_t *out);

void mp3_free(mp3_audio_t *audio);

/* ---- Streaming API (used by the Media Player) ----
 * Decodes one MPEG frame (1152 samples per channel) per call instead of
 * the whole file up front, so playback starts instantly and the desktop
 * never stalls on a long decode. */
typedef struct mp3_stream mp3_stream_t;
mp3_stream_t *mp3_stream_open(const char *path, uint32_t *sample_rate, uint8_t *channels, uint32_t *duration_ms);
/* pcm_out must hold at least 1152*2 int16_t. Returns the number of sample
 * FRAMES (per channel) produced, or 0 at end of stream. Output is
 * interleaved if stereo. */
int mp3_stream_read(mp3_stream_t *s, int16_t *pcm_out);
uint32_t mp3_stream_position_ms(mp3_stream_t *s);
void mp3_stream_seek_ms(mp3_stream_t *s, uint32_t ms);
void mp3_stream_close(mp3_stream_t *s);


#endif
