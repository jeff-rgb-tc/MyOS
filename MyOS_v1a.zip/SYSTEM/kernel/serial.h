#ifndef SERIAL_H
#define SERIAL_H

/* COM1 (16550 UART) driver: 115200 baud 8N1. Mirrors everything the kernel
 * prints to the serial port, so the boot log can be captured from a VM
 * (VirtualBox: Settings -> Serial Ports -> Host Pipe/File; QEMU: -serial stdio)
 * even when the screen shows only the splash. Absent hardware is detected with a
 * loopback test and the driver then stays off at no cost. */

int  serial_init(void);              /* 1 = a UART answered, 0 = none */
void serial_write_char(char c);
void serial_write(const char *s);
void serial_install_tee(void);
void serial_disable(void);           /* /Drivers/system/serial-com1.drv enabled=0 */       /* make the kernel's printf() also go to the port */

int  serial_present(void);

#endif
