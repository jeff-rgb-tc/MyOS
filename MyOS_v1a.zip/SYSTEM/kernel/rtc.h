#ifndef RTC_H
#define RTC_H

#include "stdint.h"

/* Minimal CMOS real-time-clock reader (I/O ports 0x70/0x71 -- standard on
 * every x86 PC/QEMU/Bochs, present well before ACPI). Only wall-clock
 * time is exposed for now (hours/minutes/seconds), which is all the
 * taskbar clock needs; date fields aren't read. */
typedef struct {
    uint8_t hours;   /* 0-23, always returned in 24-hour form regardless
                       * of the CMOS register's own 12/24-hour setting */
    uint8_t minutes; /* 0-59 */
    uint8_t seconds; /* 0-59 */
} rtc_time_t;

/* Reads the current wall-clock time from the CMOS RTC. Safe to call
 * repeatedly (e.g. once per desktop frame) -- internally waits out any
 * in-progress RTC update and re-reads until two consecutive reads agree,
 * so the caller never sees a torn/half-updated reading. */
void rtc_read_time(rtc_time_t *out);

typedef struct {
    uint16_t year;  /* full year, e.g. 2026 */
    uint8_t month;  /* 1-12 */
    uint8_t day;    /* 1-31 */
} rtc_date_t;

void rtc_read_date(rtc_date_t *out);

#endif
