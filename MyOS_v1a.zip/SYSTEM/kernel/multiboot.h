#ifndef MULTIBOOT_H
#define MULTIBOOT_H

//! The symbol table for a.out format.
typedef struct {
    unsigned long tab_size;
    unsigned long str_size;
    unsigned long address;
    unsigned long reserved;
} aout_symbol_table_t;

//! The section header table for ELF format.
typedef struct {
    unsigned long num;
    unsigned long size;
    unsigned long address;
    unsigned long shndx;
} elf_section_header_table_t;

struct multiboot_info
{
    unsigned long flags;
    unsigned long mem_lower;
    unsigned long mem_upper;
    unsigned long boot_device;
    unsigned long cmdline;
    unsigned long mods_count;
    unsigned long mods_addr;
    union
    {
        aout_symbol_table_t aout_sym_t;
        elf_section_header_table_t elf_sec_t;
    } u;
    unsigned long mmap_length;
    unsigned long mmap_addr;
};

/* One entry in the multiboot modules array pointed to by
 * multiboot_info::mods_addr. GRUB loads each `module` line from
 * grub.cfg as a contiguous blob in memory and describes it with one of
 * these; mod_start/mod_end give its extent so the kernel can treat it as
 * an in-memory file (see fat32_set_memory_backend()). */
struct multiboot_module
{
    unsigned long mod_start;
    unsigned long mod_end;
    unsigned long string; /* pointer to a C string: the module's command-line/name */
    unsigned long reserved;
};

#endif
