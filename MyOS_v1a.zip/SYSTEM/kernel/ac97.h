#ifndef AC97_H
#define AC97_H

#include "audio.h"

/* AC97 (Audio Codec '97) is a PCI sound device -- found via PCI class
 * 0x04 (multimedia)/subclass 0x01 (audio), see pci.h. It's the most
 * widely emulated sound device across QEMU, VirtualBox, and Bochs, and
 * was the standard PC audio interface on real hardware from the late
 * 1990s through the mid-2000s (superseded by Intel HDA later), which is
 * why this is the first driver probed (see audio.c's priority list) --
 * the single most likely one to actually be present.
 *
 * Uses two I/O-mapped BARs: NAM (Native Audio Mixer, BAR0) for volume/
 * mixer registers, and NABM (Native Audio Bus Master, BAR1) for the PCM
 * OUT DMA engine, driven via a Buffer Descriptor List (BDL) -- a small
 * ring of {physical address, length, flags} entries the hardware reads
 * from on its own once started, raising an interrupt as it finishes
 * each one, so software only needs to keep refilling buffers behind
 * where the hardware currently is rather than feeding samples one at a
 * time. */
extern const audio_driver_t ac97_driver;

#endif
