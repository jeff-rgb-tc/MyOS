#include "pci.h"
#include "port.h"

#define PCI_CONFIG_ADDRESS 0xCF8
#define PCI_CONFIG_DATA    0xCFC

static uint32_t pci_config_address(uint8_t bus, uint8_t device, uint8_t function, uint8_t offset) {
    /* Standard PCI configuration address format:
     * bit 31: enable bit (must be 1)
     * bits 30-24: reserved (0)
     * bits 23-16: bus number
     * bits 15-11: device number
     * bits 10-8: function number
     * bits 7-0: register offset (low 2 bits ignored -- always dword-aligned) */
    return (uint32_t)0x80000000
         | ((uint32_t)bus << 16)
         | ((uint32_t)(device & 0x1F) << 11)
         | ((uint32_t)(function & 0x07) << 8)
         | (offset & 0xFC);
}

uint32_t pci_config_read32(uint8_t bus, uint8_t device, uint8_t function, uint8_t offset) {
    outl(PCI_CONFIG_ADDRESS, pci_config_address(bus, device, function, offset));
    return inl(PCI_CONFIG_DATA);
}

void pci_config_write32(uint8_t bus, uint8_t device, uint8_t function, uint8_t offset, uint32_t value) {
    outl(PCI_CONFIG_ADDRESS, pci_config_address(bus, device, function, offset));
    outl(PCI_CONFIG_DATA, value);
}

uint16_t pci_config_read16(uint8_t bus, uint8_t device, uint8_t function, uint8_t offset) {
    uint32_t dword = pci_config_read32(bus, device, function, offset & 0xFC);
    if(offset & 2) {
        return (uint16_t)(dword >> 16);
    }
    return (uint16_t)(dword & 0xFFFF);
}

int pci_find_device_by_class(uint8_t class_code, uint8_t subclass, pci_device_t *out) {
    for(uint32_t bus = 0; bus < 256; bus++) {
        for(uint8_t device = 0; device < 32; device++) {
            /* Function 0 always exists if the device is present at all
             * (checked via vendor_id != 0xFFFF, "no device here"); only
             * probe functions 1-7 if function 0 reports itself as a
             * multi-function device (header type bit 7). */
            uint16_t vendor_id = pci_config_read16((uint8_t)bus, device, 0, 0x00);
            if(vendor_id == 0xFFFF) continue; /* no device at this slot */

            uint8_t header_type = (uint8_t)(pci_config_read16((uint8_t)bus, device, 0, 0x0E) & 0xFF);
            uint8_t max_function = (header_type & 0x80) ? 8 : 1;

            for(uint8_t function = 0; function < max_function; function++) {
                uint16_t fn_vendor_id = pci_config_read16((uint8_t)bus, device, function, 0x00);
                if(fn_vendor_id == 0xFFFF) continue;

                uint16_t class_subclass = pci_config_read16((uint8_t)bus, device, function, 0x0A);
                uint8_t fn_subclass = (uint8_t)(class_subclass & 0xFF);
                uint8_t fn_class = (uint8_t)(class_subclass >> 8);

                if(fn_class == class_code && fn_subclass == subclass) {
                    out->bus = (uint8_t)bus;
                    out->device = device;
                    out->function = function;
                    out->vendor_id = fn_vendor_id;
                    out->device_id = pci_config_read16((uint8_t)bus, device, function, 0x02);
                    out->class_code = fn_class;
                    out->subclass = fn_subclass;
                    out->prog_if = (uint8_t)(pci_config_read16((uint8_t)bus, device, function, 0x08) >> 8);
                    return 1;
                }
            }
        }
    }
    return 0;
}

uint32_t pci_get_bar(pci_device_t *dev, int bar_index) {
    if(bar_index < 0 || bar_index > 5) return 0;
    uint8_t offset = (uint8_t)(0x10 + bar_index * 4);
    uint32_t raw = pci_config_read32(dev->bus, dev->device, dev->function, offset);

    if(pci_bar_is_io(raw)) {
        return raw & 0xFFFFFFFC; /* low 2 bits are flags (always 01 for I/O space) */
    }
    return raw & 0xFFFFFFF0; /* low 4 bits are flags for memory space */
}

int pci_bar_is_io(uint32_t raw_bar) {
    return (raw_bar & 0x1) != 0;
}
