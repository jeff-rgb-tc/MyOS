#ifndef FRAME_H
#define FRAME_H

/**
 * Functions for allocating frames
 */

void init_frame_allocator(uint32_t system_frames);
void alloc_frame(struct page *page, int is_kernel, int is_writeable);
void free_frame(struct page *page);

/* Reserves the physical frames spanning [phys_addr, phys_addr+length) so
 * alloc_frame() will never hand them out -- used to protect a GRUB
 * multiboot module (e.g. the FAT32 disk image baked into the ISO) that
 * sits in ordinary system RAM from being silently overwritten once the
 * kernel heap grows into that address range. Must be called after
 * init_frame_allocator() and before anything else calls alloc_frame(),
 * since it works by advancing the allocator's "next free frame" cursor
 * past the reserved range rather than tracking arbitrary reserved holes. */
void frame_reserve_range(uint32_t phys_addr, uint32_t length);

#endif
