#ifndef ICON_H
#define ICON_H

#include "stdint.h"

/* An icon decoded from a Windows .ico file into a flat ARGB8888 buffer,
 * same layout as png_image_t/cursor_image_t so it plugs straight into
 * gfx_blit_argb(). */
typedef struct {
    uint16_t width;
    uint16_t height;
    uint32_t *pixels; /* width * height ARGB8888, heap-allocated */
} icon_image_t;

/* Parses raw .ico file bytes already loaded into memory. .ico files can
 * bundle multiple resolutions of the same icon; this picks the largest
 * available entry, then decodes it -- transparently handling both
 * classic BMP-encoded layers and the PNG-encoded layers that modern
 * icon tools (and Windows Vista+) commonly use for larger sizes.
 * Returns 1 on success, 0 on failure. On success, out->pixels is
 * heap-allocated via kmalloc and the caller owns it. */
int icon_load_from_memory(const uint8_t *data, uint32_t length, icon_image_t *out);

/* Convenience wrapper: reads a file from the FAT32 disk and decodes it. */
int icon_load_from_file(const char *path, icon_image_t *out);

void icon_free(icon_image_t *img);

#endif
