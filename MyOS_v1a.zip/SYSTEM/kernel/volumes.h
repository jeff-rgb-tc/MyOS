#ifndef VOLUMES_H
#define VOLUMES_H

#include "stdint.h"

/* Every storage volume the machine has and what is on it: partitions of
 * all ATA hard disks (MBR primary + logical, GPT), whole-disk filesystems
 * and CD/DVD drives. Only reads. Only FAT32 volumes can be browsed by the
 * desktop today; the rest are listed with the filesystem that was recognised. */

typedef enum {
    FS_UNKNOWN = 0, FS_EMPTY, FS_FAT12, FS_FAT16, FS_FAT32, FS_EXFAT, FS_NTFS,
    FS_EXT2, FS_EXT3, FS_EXT4, FS_ISO9660, FS_SWAP, FS_BTRFS, FS_XFS, FS_HFSPLUS, FS_BITLOCKER
} fs_type_t;

#define VOL_MAX 32

typedef struct {
    int      dev;          /* ATA device, -1 = the in-memory live image */
    uint8_t  optical;      /* CD/DVD drive */
    uint8_t  is_system;    /* the volume MyOS is running from */
    uint8_t  whole_disk;   /* no partition table */
    int      part_no;      /* 1-based partition number on its disk, 0 = whole disk */
    uint32_t part_lba;
    uint64_t sectors;      /* size in 512-byte sectors */
    fs_type_t fs;
    char     label[24];
    char     model[41];    /* drive model */
} volume_t;

/* Re-reads the partition tables and probes every volume. Returns the count. */
int  volumes_scan(void);
int  volumes_count(void);
const volume_t *volumes_get(int index);
const char *volumes_fs_name(fs_type_t fs);

#endif
