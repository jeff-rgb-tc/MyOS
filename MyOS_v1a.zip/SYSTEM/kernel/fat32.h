#ifndef FAT32_H
#define FAT32_H

#include "stdint.h"

struct bios_parameter_block {
    uint16_t bytes_per_sector;          // IMPORTANT
    uint8_t sectors_per_cluster;        // IMPORTANT
    uint16_t reserved_sectors;          // IMPORTANT
    uint8_t FAT_count;                  // IMPORTANT
    uint16_t dir_entries;
    uint16_t total_sectors;
    uint8_t media_descriptor_type;
    uint16_t count_sectors_per_FAT12_16; // FAT12/FAT16 only.
    uint16_t count_sectors_per_track;
    uint16_t count_heads_or_sizes_on_media;
    uint32_t count_hidden_sectors;
    uint32_t large_sectors_on_media;  // This is set instead of total_sectors if it's > 65535

    // Extended Boot Record
    uint32_t count_sectors_per_FAT32;   // IMPORTANT
    uint16_t flags;
    uint16_t FAT_version;
    uint32_t cluster_number_root_dir;   // IMPORTANT
    uint16_t sector_number_FSInfo;
    uint16_t sector_number_backup_boot_sector;
    uint8_t drive_number;
    uint8_t windows_flags;
    uint8_t signature;                  // IMPORTANT
    uint32_t volume_id;
    char volume_label[12];
    char system_id[9];
};

#define READONLY  1
#define HIDDEN    (1 << 1)
#define SYSTEM    (1 << 2)
#define VolumeID  (1 << 3)
#define DIRECTORY (1 << 4)
#define ARCHIVE   (1 << 5)
#define LFN (READONLY | HIDDEN | SYSTEM | VolumeID)

struct dir_entry {
    char *name;
    uint8_t dir_attrs;
    uint32_t first_cluster;
    uint32_t file_size;
    uint16_t wr_time; /* FAT-encoded last-write time (0 = not recorded) */
    uint16_t wr_date; /* FAT-encoded last-write date (0 = not recorded) */
};

struct directory {
    uint32_t cluster;
    struct dir_entry *entries;
    uint32_t num_entries;
};

// REFACTOR
// I want to get rid of this from the header. This should be internal
// implementation, but for now, it's too convenient for stdio.c impl.

// EOC = End Of Chain
#define EOC 0x0FFFFFF8

struct f32 {
    //FILE *f;
    uint32_t *FAT;
    struct bios_parameter_block bpb;
    uint32_t partition_begin_sector;
    uint32_t fat_begin_sector;
    uint32_t cluster_begin_sector;
    uint32_t cluster_size;
    uint32_t cluster_alloc_hint;
    /* Where this filesystem's sectors live: dev < 0 = the in-memory image
     * (see fat32_set_memory_backend), dev >= 0 = ATA device `dev`, with
     * every sector number offset by part_lba (the start of the partition). */
    int32_t dev;
    uint32_t part_lba;
    /* When set, writes update the in-memory FAT only; the caller flushes it
     * once (fat32_flush) -- used while bulk-copying files. */
    uint8_t defer_flush;
    /* One bit per FAT sector that was modified in RAM and not yet written
     * back. flushFAT() writes only those sectors (in contiguous runs)
     * instead of rewriting the whole FAT after every file operation. */
    uint8_t *fat_dirty;
    uint8_t fat_any_dirty;
    /* The FAT is loaded lazily in 64 KiB blocks (one bit per block): a
     * 128 GiB volume has a 16 MiB FAT, but booting only touches the first
     * block or two. */
    uint8_t *fat_loaded;
    uint32_t free_count;     /* cached count of free clusters */
    uint8_t free_valid;

    const struct fs_ops *ops;    /* NULL = native FAT32 */
    void *priv;                  /* driver state of a foreign filesystem */
};

/* Foreign filesystems (ext2/3/4, ISO 9660, FAT12/16 -- see fsx.c) plug in here: when `ops` is set the
 * read-side primitives below (populate_root_dir, populate_dir, readFile) are routed to it, and every
 * write-side primitive does nothing, so such a volume is browsable and strictly read-only. A directory is
 * identified by an opaque 32-bit handle (what FAT32 calls the first cluster). */
struct f32;
struct fs_ops {
    const char *name;
    void (*root)(struct f32 *fs, struct directory *dir);
    void (*populate)(struct f32 *fs, struct directory *dir, uint32_t handle);
    uint8_t *(*read)(struct f32 *fs, struct dir_entry *entry);      /* kmalloc'd, entry->file_size bytes */
    void (*destroy)(struct f32 *fs);
};

typedef struct f32 f32;

void getCluster(f32 *fs, uint8_t *buff, uint32_t cluster_number);
uint32_t get_next_cluster_id(f32 *fs, uint32_t cluster);

// END REFACTOR

f32 *makeFilesystem(char *fatSystem);

/* Mounts the FAT32 volume starting at LBA `part_lba` of ATA device `dev`
 * (an independent instance -- used by the installer to write the target
 * disk while the running system keeps using master_fs). NULL if there is
 * no valid FAT32 volume there. */
f32 *makeFilesystemOn(int dev, uint32_t part_lba);

/* Looks for a FAT32 volume on ATA device `dev`: either a bare ("superfloppy")
 * filesystem at sector 0 or one in an MBR partition. Returns 1 and the
 * volume's first LBA in *part_lba, or 0 if the disk holds no FAT32 volume
 * (blank, unformatted, some other filesystem). Never writes. */
int fat32_probe_volume(int dev, uint32_t *part_lba);

/* Chooses the disk (and partition offset) makeFilesystem() mounts when no
 * in-memory image is set. Defaults: device 0, offset 0. */
void fat32_set_ata_backend(int dev, uint32_t part_lba);

/* Writes the in-memory FAT back to disk (first FAT copy). */
void fat32_flush(f32 *fs);
void destroyFilesystem(f32 *fs);

const struct bios_parameter_block *getBPB(f32 *fs);

void populate_root_dir(f32 *fs, struct directory *dir);
void populate_dir(f32 *fs, struct directory *dir, uint32_t cluster);
void free_directory(f32 *fs, struct directory *dir);

/* Called every few clusters while a file is being read, if set. The desktop
 * points it at its busy-cursor updater so the spinner keeps turning during
 * long reads. Must be quick and must not touch the filesystem. */
extern void (*io_progress_hook)(void);

uint8_t *readFile(f32 *fs, struct dir_entry *dirent);
void writeFile(f32 *fs, struct directory *dir, uint8_t *file, char *fname, uint32_t flen);
void mkdir(f32 *fs, struct directory *dir, char *dirname);
void delFile(f32 *fs, struct directory *dir, char *filename);

void print_directory(f32 *fs, struct directory *dir);
uint32_t count_free_clusters(f32 *fs);

/* Points the FAT32 driver at a disk image already sitting in memory
 * (e.g. a GRUB multiboot module) instead of reading/writing through the
 * ATA driver. This lets the entire filesystem -- and therefore every
 * icon, cursor, background, and app resource on it -- be baked directly
 * into the bootable ISO rather than requiring a second virtual disk
 * mounted alongside it. Call this (if at all) before makeFilesystem();
 * writes are mirrored into this same buffer, so changes don't persist
 * once the machine is powered off (the ISO itself is read-only), which
 * matches how a live-CD-style OS image behaves.
 *
 * Passing base=NULL reverts to the real ATA disk backend. */
void fat32_set_memory_backend(uint8_t *base, uint32_t length);

extern f32 *master_fs;

#endif
