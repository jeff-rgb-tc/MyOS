[bits 32]

extern gdt_entries

section .text
global load_gdt

load_gdt:
    mov     eax, DWORD [esp + 4]
    lgdt    [eax]

    mov     ax, 10h
    mov     ds, ax
    mov     es, ax
    mov     fs, ax
    mov     gs, ax
    mov     ss, ax
    jmp    08h:flush
flush:
    ret

; void load_tss(void)
; Loads the task register with the TSS selector. GDT entry 5 (see
; gdt.c's TSS_GDT_ENTRY / tss.c's init_tss call site) at selector
; index 5*8 = 0x28; | 3 sets the RPL to 3, which is required here even
; though the TSS itself is a ring0 structure -- ltr checks the selector's
; RPL against the descriptor's DPL and historically/by convention this is
; set to match the ring the task is associated with switching *from*;
; 0x28 (RPL 0) is also commonly used and works identically for a TSS
; that's never entered via a hardware task switch (as here) -- either
; works, but 0x2B (RPL 3) is what most reference OSDev TSS setups use,
; so it's used here for consistency with tss.c's comments.
global load_tss
load_tss:
    mov     ax, 0x2B
    ltr     ax
    ret

; void gdt_set_tss_gate(int32_t entry, uint32_t base, uint32_t limit)
; Writes a TSS-type GDT descriptor directly (distinct from the general
; code/data descriptor gdt_set_gate() in gdt.c builds) -- access byte
; 0x89 = present(1) DPL(00) S(0, system segment) type(1001 = 32-bit
; available TSS); granularity byte 0x00 (byte granularity, not
; page-granularity -- a TSS's limit is its exact byte size, not rounded
; up to 4K pages the way code/data segment limits are).
global gdt_set_tss_gate
gdt_set_tss_gate:
    push    ebx
    mov     eax, DWORD [esp + 8]    ; entry
    mov     ebx, DWORD [esp + 12]   ; base
    mov     ecx, DWORD [esp + 16]   ; limit

    ; gdt_entries is a C array of 8-byte packed structs; &gdt_entries[entry] == gdt_entries_base + entry*8
    mov     edx, eax
    shl     edx, 3
    add     edx, gdt_entries        ; edx = &gdt_entries[entry]

    mov     WORD [edx], cx          ; limit_low = limit & 0xFFFF
    mov     WORD [edx + 2], bx      ; base_low = base & 0xFFFF
    shr     ebx, 16
    mov     BYTE [edx + 4], bl      ; base_middle = (base >> 16) & 0xFF
    mov     BYTE [edx + 5], 0x89    ; access
    mov     BYTE [edx + 6], 0x00    ; granularity (limit high nibble = 0, flags = 0)
    mov     BYTE [edx + 7], bh      ; base_high = (base >> 24) & 0xFF

    pop     ebx
    ret
