#include "pit.h"
#include "isr.h"
#include "port.h"
#include "kernio.h"
#include "vesa.h"
#include "app_loader.h"

#define PIT_NATURAL_FREQ 1193180

#define PIT_DATA0 0x40
#define PIT_DATA1 0x41
#define PIT_DATA2 0x42
#define PIT_COMMAND 0x43

#define DRAW_MODULO 10
uint8_t draw_modcount = 0;

uint8_t normal_color;

long long tick = 0;

/* When the graphical desktop takes over the screen, it owns every pixel
 * of every frame it draws, including row 0 where this timer used to print
 * a live debug status line. Leaving that enabled would tear a text line
 * into the desktop's own back-buffer-composited frame. The desktop calls
 * pit_set_status_line_enabled(0) once it starts running. */
static uint8_t status_line_enabled = 1;

static void (*volatile pit_hooks[3])(void) = { 0, 0, 0 };
static uint8_t pit_hook_phase = 0;

void pit_set_hook_slot(int slot, void (*fn)(void)) {
    if(slot >= 0 && slot < 3) pit_hooks[slot] = fn;
}

void pit_set_hook(void (*fn)(void)) {
    pit_set_hook_slot(0, fn);
}

void pit_set_status_line_enabled(uint8_t enabled) {
    status_line_enabled = enabled;
}

long long pit_get_ticks(void) {
    return tick;
}

/* Milliseconds since boot, 10 ms resolution: the PIT fires at 100 Hz
 * (see init_timer(100) in kernel.c) and `tick` only advances every
 * DRAW_MODULO (10) of those interrupts, so the sub-tick phase is simply
 * draw_modcount * 10 ms. Re-read until `tick` is stable so a read that
 * races the timer IRQ can never jump backwards by 100 ms. Wraps after
 * ~49 days, which every caller (animation timing, timeouts) tolerates. */
uint32_t pit_get_ms(void) {
    long long t;
    uint8_t phase;
    do {
        t = tick;
        phase = draw_modcount;
    } while(t != tick);
    return (uint32_t)(t * 100) + (uint32_t)phase * 10;
}

extern uint32_t allocated_frames;
extern uint32_t total_frames;
extern uint32_t heap_free;
extern uint32_t allocations;

#define BUFFSIZE 77

static void timer_callback(registers_t regs)
{
    /* Watchdog for .app programs: only while the interrupt hit RING-3
     * code (cs RPL 3), i.e. the app is computing without calling into
     * the kernel. See app_loader.h. */
    if(app_is_running() && (regs.cs & 3) == 3) {
        app_watchdog_check();
    }
    draw_modcount = (draw_modcount + 1) % DRAW_MODULO;

    /* 100 Hz timer -> hook every 5th interrupt = every 50 ms. */
    if(++pit_hook_phase >= 5) {
        pit_hook_phase = 0;
        for(int h = 0; h < 3; h++) {
            void (*hook)(void) = pit_hooks[h];
            if(hook) hook();
        }
    }

    if(draw_modcount == 0)
    {
        tick++;

        if(!status_line_enabled) {
            return;
        }

        uint32_t used = (allocated_frames * 0x1000) / 1024 / 1024;
        uint32_t available = (total_frames * 0x1000) / 1024 / 1024;

        char buffer[BUFFSIZE];
        sprintf(buffer, "Frames: %d Mem: %d/%d MiB Heap-Free: %d Allocs: %d",
               allocated_frames,
               used, available,
               heap_free,
               allocations);
        uint32_t fg = get_vesa_color();
        uint32_t bg = get_vesa_background();
        set_vesa_color(make_vesa_color(0, 0, 0));
        set_vesa_background(make_vesa_color(0xFF, 0xFF, 0xFF));
        set_status(buffer);
        set_vesa_color(fg);
        set_vesa_background(bg);
    }
}

void init_timer(uint32_t frequency)
{
    printf("Initializing PIT timer\n");
    register_interrupt_handler(IRQ0, &timer_callback);

    uint32_t divisor;
    if(frequency)
        divisor = PIT_NATURAL_FREQ / frequency;
    else
        divisor = 0;
    /*
      http://wiki.osdev.org/Programmable_Interval_Timer#I.2FO_Ports

      Channel  Access Mode        Operating Mode    BCD/Binary
      0x36 == 0011 0110 == 00       11 (lobyte/hibyte) 011 (square Wave) 0 (16-bit bin

      )
    */
    outb(PIT_COMMAND, 0x36);

    //Chop freq up into bytes and send to data0 port
    uint8_t low = (uint8_t)(divisor & 0xFF);
    uint8_t high = (uint8_t)((divisor >> 8) & 0xFF);

    outb(PIT_DATA0, low);
    outb(PIT_DATA0, high);
}
