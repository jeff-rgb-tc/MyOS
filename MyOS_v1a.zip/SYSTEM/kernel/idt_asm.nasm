[bits 32]
section .text
global load_idt

load_idt:
    mov    eax, [esp + 4]
    lidt   [eax]
    ret

;; num %1
%macro isr_noerr 1
global isr%1
isr%1:
    cli
    push 0
    push %1
    jmp isr_stub
%endmacro


%macro isr_err 1
global isr%1
isr%1:
    cli
    push %1
    jmp isr_stub
%endmacro

isr_noerr 0
isr_noerr 1
isr_noerr 2
isr_noerr 3
isr_noerr 4
isr_noerr 5
isr_noerr 6
isr_noerr 7
isr_err 8
isr_noerr 9
isr_err 10
isr_err 11
isr_err 12
isr_err 13
isr_err 14
isr_noerr 15
isr_noerr 16
isr_noerr 17
isr_noerr 18
isr_noerr 19
isr_noerr 20
isr_noerr 21
isr_noerr 22
isr_noerr 23
isr_noerr 24
isr_noerr 25
isr_noerr 26
isr_noerr 27
isr_noerr 28
isr_noerr 29
isr_noerr 30
isr_noerr 31

extern isr_handler
isr_stub:
    pusha

    mov     ax, ds
    push	eax
    mov     esi, eax

    mov 	ax, 10h
    mov 	ds, ax
    mov 	es, ax
    mov 	fs, ax
    mov 	gs, ax

    call	isr_handler

    pop	    eax
    mov		eax, esi

    mov	    ds, ax
    mov 	ds, ax
    mov 	es, ax
    mov 	fs, ax
    mov 	gs, ax

    popa
    add	    esp, 8
    sti
    iret

; int 0x80 syscall gate. Distinct from the isr_noerr/isr_err-generated
; stubs above: those all funnel into isr_stub -> isr_handler, which is
; built around registers_t (int_no/err_code + whatever pusha captured)
; and has no notion of "syscall arguments" -- the syscall ABI here
; instead passes arguments in eax (syscall number)/ebx/ecx/edx/esi/edi
; per syscall.h, and returns a value in eax, which this stub is
; responsible for actually writing back into the ring3 caller's saved
; eax (pusha's saved eax, so it's what gets restored into the real eax
; on popa/iret) -- isr_stub's generic path never does that, since
; ISRs/IRQs don't return values to their caller the way a syscall does.
global isr128
isr128:
    ; No cli here (unlike the isr_noerr/isr_err macros above) --
    ; syscalls should run with interrupts enabled throughout (the timer
    ; IRQ must still be able to fire during a syscall, or the desktop's
    ; own scheduling-by-timer-tick assumptions would break for the
    ; whole time any app is in a syscall); syscall_dispatch itself briefly
    ; disables interrupts only where it actually touches shared kernel
    ; state that isn't otherwise interrupt-safe, not for its entire
    ; duration.
    pusha                    ; saves eax,ecx,edx,ebx,esp(dummy),ebp,esi,edi in that pushed order

    mov     ax, ds
    push    eax
    mov     esi, eax

    mov     ax, 0x10
    mov     ds, ax
    mov     es, ax
    mov     fs, ax
    mov     gs, ax

    ; syscall_dispatch(uint32_t num, uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4)
    ; reads its arguments the normal cdecl way (the stack), so build that
    ; call frame from the pusha'd register values. PUSHA's fixed push
    ; order is eax,ecx,edx,ebx,esp_orig,ebp,esi,edi -- since the stack
    ; grows down, the LAST value pushed (edi) ends up at the lowest
    ; address. After pusha + the "push eax" (ds) above, esp-relative
    ; offsets are: [esp+0]=saved ds, [esp+4]=edi, [esp+8]=esi,
    ; [esp+12]=ebp, [esp+16]=esp_orig (unused), [esp+20]=ebx,
    ; [esp+24]=edx, [esp+28]=ecx, [esp+32]=eax.
    ;
    ; Each push below shifts esp down by 4 for every subsequent [esp+N]
    ; reference, INCLUDING references to registers already read in an
    ; earlier push in this same sequence -- e.g. edx's offset grows from
    ; its base +24 to +32 by the time it's actually read (after 2 prior
    ; pushes: +24 + 2*4 = +32), and ebx's independently reaches the same
    ; +32 at ITS read point (base +20 + 3 prior pushes*4 = +32) -- both
    ; numbers being 32 is a coincidence of timing, not a collision (each
    ; is evaluated against a different actual esp value). Verified by
    ; explicit step-by-step stack simulation, not just arithmetic, since
    ; the arithmetic alone reads as suspicious here.
    push    dword [esp + 4]   ; arg4 = edi
    push    dword [esp + 12]  ; arg3 = esi
    push    dword [esp + 32]  ; arg2 = edx
    push    dword [esp + 32]  ; arg1 = ebx
    push    dword [esp + 48]  ; num  = eax
    call    syscall_dispatch
    add     esp, 20           ; pop the 5 call args back off

    ; Write the return value into the pusha-saved eax slot, so that when
    ; we popa below, the ring3 caller sees it as if int 0x80 itself
    ; "returned" this value in eax.
    mov     [esp + 32], eax

    pop     eax
    mov     eax, esi

    mov     ds, ax
    mov     es, ax
    mov     fs, ax
    mov     gs, ax

    popa
    iret

extern syscall_dispatch

;; num %1 map %2
%macro irq 2
global irq%1
irq%1:
    cli
    push    0
    push    %2
    jmp     irq_stub
%endmacro

irq 0, 32
irq 1, 33
irq 2, 34
irq 3, 35
irq 4, 36
irq 5, 37
irq 6, 38
irq 7, 39
irq 8, 40
irq 9, 41
irq 10, 42
irq 11, 43
irq 12, 44
irq 13, 45
irq 14, 46
irq 15, 47

    
extern irq_handler
irq_stub:
    pusha

    mov	    ax, ds
    push	eax
    mov 	esi, eax

    mov 	ax, 10h
    mov 	ds, ax
    mov 	es, ax
    mov 	fs, ax
    mov 	gs, ax

    call	irq_handler

    pop	    ebx
    mov 	ebx, esi

    mov 	ds, bx
    mov 	es, bx
    mov 	fs, bx
    mov 	gs, bx

    popa
    add     esp, 8
    sti
    iret
