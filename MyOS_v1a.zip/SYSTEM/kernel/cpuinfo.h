#ifndef CPUINFO_H
#define CPUINFO_H
/* CPUID helpers. The kernel itself is 32-bit (x86); these report what the machine could do. */
int  cpu_has_cpuid(void);
int  cpu_has_long_mode(void);         /* 1 = a 64-bit (x86-64) processor */
void cpu_brand(char out[49]);         /* "Intel(R) Core(TM) ...", or "Unknown processor" */
#endif
