/*
 * Windows .ico icon file parser.
 *
 * Structurally identical to the .cur container (see cursor.c's header
 * comment for the full ICONDIR/ICONDIRENTRY layout) -- the difference is
 * that ICONDIRENTRY's hotspot_x/hotspot_y fields are instead "planes" and
 * "bit count" for icons, and we don't care about either since icons have
 * no cursor hotspot.
 *
 * Modern .ico files (Windows Vista onward, and virtually every icon
 * exported by current tools for sizes >= 32x32) embed each layer as a
 * full PNG file rather than a raw BMP, since BMP has no way to represent
 * sizes over 256x256 in the classic header. We detect this by checking
 * for the PNG signature at the start of the entry's image data and
 * delegate to png.c when present; otherwise we fall back to the same
 * BMP+mask decoding cursor.c uses for classic .cur/.ico layers.
 */

#include "stdint.h"
#include "stddef.h"
#include "icon.h"
#include "png.h"
#include "kheap.h"
#include "common.h"
#include "kernio.h"
#include "stdio.h"

#pragma pack(push, 1)
typedef struct {
    uint16_t reserved;
    uint16_t type;
    uint16_t count;
} icondir_t;

typedef struct {
    uint8_t  width;
    uint8_t  height;
    uint8_t  color_count;
    uint8_t  reserved;
    uint16_t planes;     /* unused for icons */
    uint16_t bit_count;  /* unused for icons -- real bpp comes from the bitmap/PNG header */
    uint32_t data_size;
    uint32_t data_offset;
} icondirentry_t;
#pragma pack(pop)

static uint16_t read_u16(const uint8_t *p) {
    return (uint16_t)(p[0] | (p[1] << 8));
}

static uint32_t read_u32(const uint8_t *p) {
    return (uint32_t)(p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24));
}

static int is_png_signature(const uint8_t *data, uint32_t length) {
    static const uint8_t sig[8] = {0x89, 'P', 'N', 'G', '\r', '\n', 0x1A, '\n'};
    return length >= 8 && memcmp(data, sig, 8) == 0;
}

/* Classic BMP-encoded layer decoding, structurally the same approach as
 * cursor.c's BMP path but without a hotspot (icons don't have one). */
static int decode_bmp_layer(const uint8_t *img, uint32_t data_size, uint32_t dir_w, uint32_t dir_h, icon_image_t *out) {
    if(data_size < 40) {
        printf("icon: BMP layer too small for BITMAPINFOHEADER\n");
        return 0;
    }

    uint32_t header_size = read_u32(img + 0);
    if(header_size < 40) {
        printf("icon: unsupported bitmap header size %d\n", header_size);
        return 0;
    }

    int32_t bmp_width = (int32_t)read_u32(img + 4);
    int32_t bmp_height = (int32_t)read_u32(img + 8); /* doubled: XOR + AND masks */
    uint16_t bpp = read_u16(img + 14);
    uint32_t compression = read_u32(img + 16);

    if(compression != 0) {
        printf("icon: compressed BMP layers are not supported\n");
        return 0;
    }

    uint32_t img_h = (uint32_t)(bmp_height / 2);
    uint32_t img_w = (uint32_t)bmp_width;

    if(img_w != dir_w || img_h != dir_h) {
        img_w = (uint32_t)bmp_width;
        img_h = (uint32_t)(bmp_height / 2);
    }

    if(img_w == 0 || img_h == 0 || img_w > 512 || img_h > 512) {
        printf("icon: implausible dimensions %dx%d\n", img_w, img_h);
        return 0;
    }

    const uint8_t *pixel_data = img + header_size;

    uint32_t palette_count = 0;
    if(bpp <= 8) {
        palette_count = read_u32(img + 32);
        if(palette_count == 0) palette_count = 1u << bpp;
        pixel_data = img + header_size + palette_count * 4;
    }
    const uint8_t *palette = img + header_size;

    uint32_t xor_row_bytes;
    if(bpp == 32) xor_row_bytes = img_w * 4;
    else if(bpp == 24) xor_row_bytes = img_w * 3;
    else if(bpp == 8) xor_row_bytes = img_w;
    else if(bpp == 4) xor_row_bytes = (img_w + 1) / 2;
    else if(bpp == 1) xor_row_bytes = (img_w + 7) / 8;
    else {
        printf("icon: unsupported bit depth %d\n", bpp);
        return 0;
    }
    xor_row_bytes = (xor_row_bytes + 3) & ~3u;

    uint32_t xor_size = xor_row_bytes * img_h;
    const uint8_t *and_data = pixel_data + xor_size;
    uint32_t and_row_bytes = ((img_w + 7) / 8 + 3) & ~3u;

    int has_alpha_channel = (bpp == 32);

    uint32_t *out_pixels = (uint32_t *)kmalloc(img_w * img_h * sizeof(uint32_t));
    if(!out_pixels) {
        printf("icon: out of memory allocating %dx%d icon\n", img_w, img_h);
        return 0;
    }

    for(uint32_t y = 0; y < img_h; y++) {
        uint32_t src_row = img_h - 1 - y;
        const uint8_t *xor_row = pixel_data + src_row * xor_row_bytes;
        const uint8_t *and_row = and_data + src_row * and_row_bytes;

        for(uint32_t x = 0; x < img_w; x++) {
            uint8_t r = 0, g = 0, b = 0, a = 255;

            if(bpp == 32) {
                const uint8_t *px = xor_row + x * 4;
                b = px[0]; g = px[1]; r = px[2]; a = px[3];
            }
            else if(bpp == 24) {
                const uint8_t *px = xor_row + x * 3;
                b = px[0]; g = px[1]; r = px[2];
            }
            else if(bpp == 8) {
                uint8_t idx = xor_row[x];
                const uint8_t *pal = palette + idx * 4;
                b = pal[0]; g = pal[1]; r = pal[2];
            }
            else if(bpp == 4) {
                uint8_t byte = xor_row[x / 2];
                uint8_t idx = (x % 2 == 0) ? (byte >> 4) : (byte & 0x0F);
                const uint8_t *pal = palette + idx * 4;
                b = pal[0]; g = pal[1]; r = pal[2];
            }
            else if(bpp == 1) {
                uint8_t byte = xor_row[x / 8];
                uint8_t bit = (byte >> (7 - (x % 8))) & 1;
                const uint8_t *pal = palette + bit * 4;
                b = pal[0]; g = pal[1]; r = pal[2];
            }

            if(!has_alpha_channel) {
                uint8_t and_byte = and_row[x / 8];
                uint8_t and_bit = (and_byte >> (7 - (x % 8))) & 1;
                a = and_bit ? 0 : 255;
            }

            out_pixels[y * img_w + x] = ((uint32_t)a << 24) | ((uint32_t)r << 16) | ((uint32_t)g << 8) | b;
        }
    }

    out->width = (uint16_t)img_w;
    out->height = (uint16_t)img_h;
    out->pixels = out_pixels;
    return 1;
}

int icon_load_from_memory(const uint8_t *data, uint32_t length, icon_image_t *out) {
    if(!data || !out || length < sizeof(icondir_t)) {
        return 0;
    }

    memset(out, 0, sizeof(icon_image_t));

    uint16_t reserved = read_u16(data + 0);
    uint16_t type = read_u16(data + 2);
    uint16_t count = read_u16(data + 4);

    if(reserved != 0 || type != 1 || count == 0) {
        printf("icon: not a valid .ico file (reserved=%d type=%d count=%d)\n", reserved, type, count);
        return 0;
    }

    if(length < sizeof(icondir_t) + sizeof(icondirentry_t) * (uint32_t)count) {
        printf("icon: truncated .ico directory\n");
        return 0;
    }

    /* Pick the largest available layer. */
    uint32_t best_index = 0;
    uint32_t best_area = 0;
    for(uint32_t i = 0; i < count; i++) {
        const uint8_t *entry = data + sizeof(icondir_t) + i * sizeof(icondirentry_t);
        uint32_t w = entry[0] == 0 ? 256 : entry[0];
        uint32_t h = entry[1] == 0 ? 256 : entry[1];
        uint32_t area = w * h;
        if(area > best_area) {
            best_area = area;
            best_index = i;
        }
    }

    const uint8_t *entry = data + sizeof(icondir_t) + best_index * sizeof(icondirentry_t);
    uint32_t dir_w = entry[0] == 0 ? 256 : entry[0];
    uint32_t dir_h = entry[1] == 0 ? 256 : entry[1];
    uint32_t data_size = read_u32(entry + 8);
    uint32_t data_offset = read_u32(entry + 12);

    if((uint64_t)data_offset + data_size > length) {
        printf("icon: layer data out of bounds\n");
        return 0;
    }

    const uint8_t *layer = data + data_offset;

    if(is_png_signature(layer, data_size)) {
        png_image_t png;
        if(!png_load_from_memory(layer, data_size, &png)) {
            printf("icon: embedded PNG layer failed to decode\n");
            return 0;
        }
        out->width = png.width;
        out->height = png.height;
        out->pixels = png.pixels; /* ownership transferred to caller via icon_free() */
        return 1;
    }

    return decode_bmp_layer(layer, data_size, dir_w, dir_h, out);
}

int icon_load_from_file(const char *path, icon_image_t *out) {
    memset(out, 0, sizeof(icon_image_t));

    FILE *f = fopen(path, NULL);
    if(!f) {
        return 0;
    }

    uint32_t capacity = 65536;
    uint32_t total = 0;
    uint8_t *buffer = (uint8_t *)kmalloc(capacity);
    if(!buffer) {
        fclose(f);
        return 0;
    }

    size_t chunk;
    while((chunk = fread(buffer + total, 1, capacity - total, f)) > 0) {
        total += chunk;
        if(total >= capacity) {
            uint32_t new_capacity = capacity * 2;
            uint8_t *new_buffer = (uint8_t *)kmalloc(new_capacity);
            if(!new_buffer) {
                kfree(buffer);
                fclose(f);
                return 0;
            }
            fastcp((char *)new_buffer, (char *)buffer, total);
            kfree(buffer);
            buffer = new_buffer;
            capacity = new_capacity;
        }
    }
    fclose(f);

    int ok = icon_load_from_memory(buffer, total, out);
    kfree(buffer);
    return ok;
}

void icon_free(icon_image_t *img) {
    if(img && img->pixels) {
        kfree(img->pixels);
        img->pixels = NULL;
    }
}
