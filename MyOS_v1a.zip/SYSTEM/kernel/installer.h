#ifndef INSTALLER_H
#define INSTALLER_H

#include "stdint.h"
#include "myos/abi.h"

/* ===========================================================================
 * System installer service (kernel side of /APPS/installer/installer.app)
 *
 * Installing MyOS onto a hard disk means: pick a disk, write an MBR with a
 * GRUB boot loader, create a FAT32 partition, and copy the whole running
 * system onto it. It is done in small steps so the installer window stays
 * alive and can show a progress bar: the app calls installer_step() in a
 * loop and each call performs one bounded unit of work.
 *
 * Layout written to the target disk:
 *     LBA 0          MBR (GRUB boot.img + partition table)
 *     LBA 1..2047    GRUB core.img (embedded in the gap before partition 1)
 *     LBA 2048..     partition 1, FAT32, type 0x0C, bootable
 * The partition uses the whole disk up to INST_MAX_PART_SECTORS (128 GiB).
 * The FAT driver keeps the whole FAT in RAM, so the cluster size grows with
 * the partition (2 KiB ... 32 KiB) to keep the FAT at <= 16 MiB; only the
 * modified FAT sectors are written back. Any disk space beyond the cap is
 * left alone.
 * =========================================================================== */

#define INST_PART_START        2048u
#define INST_MAX_PART_SECTORS  268435456u    /* 128 GiB */
#define INST_MIN_DISK_SECTORS  524288u       /* 256 MiB */
#define INST_MIN_SECTORS_PER_CLUSTER 4u
#define INST_MAX_CLUSTERS_TARGET 4194304u    /* FAT <= 16 MiB */
#define INST_PAYLOAD_PATH      "/SYSTEM/install/bootsect.bin"

/* Number of selectable disks and their description. Never writes. */
int installer_disk_count(void);
int installer_disk_info(int index, myos_diskinfo_t *out);

/* Starts an installation onto disk `index` (as numbered by installer_disk_*).
 * Returns MYOS_OK or a negative MYOS_E_* / MYOS_E_INST_*. */
#define INST_FLAG_BACKUP 0x1   /* keep /Users: copied to RAM before formatting, written back at the end */
#define INST_FLAG_X64    0x2   /* reserved: install the 64-bit system (not available yet, refused) */
int installer_begin(int index, uint32_t flags);

/* Starts an in-place update of an installed MyOS found on a hard disk, using the
 * running system (the Live ISO) as the source. Nothing is partitioned or
 * formatted; /Users is not touched. Progress is polled with installer_step(). */
int installer_begin_update(void);

/* Does the next chunk of work. Fills *st. Returns MYOS_OK while running
 * and after finishing (check st->state); negative on a hard error. */
int installer_step(myos_install_status_t *st);

/* Abandons a running installation (the disk is left in whatever state it
 * reached -- it is simply not bootable yet). */
void installer_cancel(void);

#endif
