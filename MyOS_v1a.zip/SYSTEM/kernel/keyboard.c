#include "stdint.h"
#include "keyboard.h"
#include "kernio.h"
#include "isr.h"
#include "port.h"
#include "terminal.h"

/*
 * Scan code   Key                         Scan code   Key                     Scan code   Key                     Scan code   Key
 * 0x01        escape pressed              0x02        1 pressed               0x03        2 pressed
 * 0x04        3 pressed                   0x05        4 pressed               0x06        5 pressed               0x07        6 pressed
 * 0x08        7 pressed                   0x09        8 pressed               0x0A        9 pressed               0x0B        0 (zero) pressed
 * 0x0C        - pressed                   0x0D        = pressed               0x0E        backspace pressed       0x0F        tab pressed
 * 0x10        Q pressed                   0x11        W pressed               0x12        E pressed               0x13        R pressed
 * 0x14        T pressed                   0x15        Y pressed               0x16        U pressed               0x17        I pressed
 * 0x18        O pressed                   0x19        P pressed               0x1A        [ pressed               0x1B        ] pressed
 * 0x1C        enter pressed               0x1D        left control pressed    0x1E        A pressed               0x1F        S pressed
 * 0x20        D pressed                   0x21        F pressed               0x22        G pressed               0x23        H pressed
 * 0x24        J pressed                   0x25        K pressed               0x26        L pressed               0x27        ; pressed
 * 0x28        ' (single quote) pressed    0x29        ` (back tick) pressed   0x2A        left shift pressed      0x2B        \ pressed
 * 0x2C        Z pressed                   0x2D        X pressed               0x2E        C pressed               0x2F        V pressed
 * 0x30        B pressed                   0x31        N pressed               0x32        M pressed               0x33        , pressed
 * 0x34        . pressed                   0x35        / pressed               0x36        right shift pressed     0x37        (keypad) * pressed
 * 0x38        left alt pressed            0x39        space pressed           0x3A        CapsLock pressed        0x3B        F1 pressed
 * 0x3C        F2 pressed                  0x3D        F3 pressed              0x3E        F4 pressed              0x3F        F5 pressed
 * 0x40        F6 pressed                  0x41        F7 pressed              0x42        F8 pressed              0x43        F9 pressed
 * 0x44        F10 pressed                 0x45        NumberLock pressed      0x46        ScrollLock pressed      0x47        (keypad) 7 pressed
 * 0x48        (keypad) 8 pressed          0x49        (keypad) 9 pressed      0x4A        (keypad) - pressed      0x4B        (keypad) 4 pressed
 * 0x4C        (keypad) 5 pressed          0x4D        (keypad) 6 pressed      0x4E        (keypad) + pressed      0x4F        (keypad) 1 pressed
 * 0x50        (keypad) 2 pressed          0x51        (keypad) 3 pressed      0x52        (keypad) 0 pressed      0x53        (keypad) . pressed
 * 0x57        F11 pressed                 0x58        F12 pressed
 */

// Scancode -> ASCII
const uint8_t lower_ascii_codes[256] = {
    0x00,  ESC,  '1',  '2',     /* 0x00 */
     '3',  '4',  '5',  '6',     /* 0x04 */
     '7',  '8',  '9',  '0',     /* 0x08 */
     '-',  '=',   BS, '\t',     /* 0x0C */
     'q',  'w',  'e',  'r',     /* 0x10 */
     't',  'y',  'u',  'i',     /* 0x14 */
     'o',  'p',  '[',  ']',     /* 0x18 */
    '\n', 0x00,  'a',  's',     /* 0x1C */
     'd',  'f',  'g',  'h',     /* 0x20 */
     'j',  'k',  'l',  ';',     /* 0x24 */
    '\'',  '`', 0x00, '\\',     /* 0x28 */
     'z',  'x',  'c',  'v',     /* 0x2C */
     'b',  'n',  'm',  ',',     /* 0x30 */
     '.',  '/', 0x00,  '*',     /* 0x34 */
    0x00,  ' ', 0x00, 0x00,     /* 0x38 */
    0x00, 0x00, 0x00, 0x00,     /* 0x3C */
    0x00, 0x00, 0x00, 0x00,     /* 0x40 */
    0x00, 0x00, 0x00,  '7',     /* 0x44 */
     '8',  '9',  '-',  '4',     /* 0x48 */
     '5',  '6',  '+',  '1',     /* 0x4C */
     '2',  '3',  '0',  '.',     /* 0x50 */
    0x00, 0x00, 0x00, 0x00,     /* 0x54 */
    0x00, 0x00, 0x00, 0x00      /* 0x58 */
};

// Scancode -> ASCII
const uint8_t upper_ascii_codes[256] = {
    0x00,  ESC,  '!',  '@',     /* 0x00 */
     '#',  '$',  '%',  '^',     /* 0x04 */
     '&',  '*',  '(',  ')',     /* 0x08 */
     '_',  '+',   BS, '\t',     /* 0x0C */
     'Q',  'W',  'E',  'R',     /* 0x10 */
     'T',  'Y',  'U',  'I',     /* 0x14 */
     'O',  'P',  '{',  '}',     /* 0x18 */
    '\n', 0x00,  'A',  'S',     /* 0x1C */
     'D',  'F',  'G',  'H',     /* 0x20 */
     'J',  'K',  'L',  ':',     /* 0x24 */
     '"',  '~', 0x00,  '|',     /* 0x28 */
     'Z',  'X',  'C',  'V',     /* 0x2C */
     'B',  'N',  'M',  '<',     /* 0x30 */
     '>',  '?', 0x00,  '*',     /* 0x34 */
    0x00,  ' ', 0x00, 0x00,     /* 0x38 */
    0x00, 0x00, 0x00, 0x00,     /* 0x3C */
    0x00, 0x00, 0x00, 0x00,     /* 0x40 */
    0x00, 0x00, 0x00,  '7',     /* 0x44 */
     '8',  '9',  '-',  '4',     /* 0x48 */
     '5',  '6',  '+',  '1',     /* 0x4C */
     '2',  '3',  '0',  '.',     /* 0x50 */
    0x00, 0x00, 0x00, 0x00,     /* 0x54 */
    0x00, 0x00, 0x00, 0x00      /* 0x58 */
};


const uint8_t lower_ascii_codes_dvorak[256] = {
    0x00,  ESC,  '1',  '2',     /* 0x00 */
     '3',  '4',  '5',  '6',     /* 0x04 */
     '7',  '8',  '9',  '0',     /* 0x08 */
     '[',  ']',   BS, '\t',     /* 0x0C */
    '\'',  ',',  '.',  'p',     /* 0x10 */
     'y',  'f',  'g',  'c',     /* 0x14 */
     'r',  'l',  '/',  '=',     /* 0x18 */
    '\n', 0x00,  'a',  'o',     /* 0x1C */
     'e',  'u',  'i',  'd',     /* 0x20 */
     'h',  't',  'n',  's',     /* 0x24 */
     '-',  '`', 0x00, '\\',     /* 0x28 */
     ';',  'q',  'j',  'k',     /* 0x2C */
     'x',  'b',  'm',  'w',     /* 0x30 */
     'v',  'z', 0x00,  '*',     /* 0x34 */
    0x00,  ' ', 0x00, 0x00,     /* 0x38 */
    0x00, 0x00, 0x00, 0x00,     /* 0x3C */
    0x00, 0x00, 0x00, 0x00,     /* 0x40 */
    0x00, 0x00, 0x00,  '7',     /* 0x44 */
     '8',  '9',  '[',  '4',     /* 0x48 */
     '5',  '6',  '}',  '1',     /* 0x4C */
     '2',  '3',  '0',  'v',     /* 0x50 */
    0x00, 0x00, 0x00, 0x00,     /* 0x54 */
    0x00, 0x00, 0x00, 0x00      /* 0x58 */
};

// Scancode -> ASCII
const uint8_t upper_ascii_codes_dvorak[256] = {
    0x00,  ESC,  '!',  '@',     /* 0x00 */
     '#',  '$',  '%',  '^',     /* 0x04 */
     '&',  '*',  '(',  ')',     /* 0x08 */
     '{',  '}',   BS, '\t',     /* 0x0C */
     '"',  '<',  '>',  'P',     /* 0x10 */
     'Y',  'F',  'G',  'C',     /* 0x14 */
     'R',  'L',  '?',  '+',     /* 0x18 */
    '\n', 0x00,  'A',  'O',     /* 0x1C */
     'E',  'U',  'I',  'D',     /* 0x20 */
     'H',  'T',  'N',  'S',     /* 0x24 */
     '_',  '~', 0x00,  '|',     /* 0x28 */
     ':',  'Q',  'J',  'K',     /* 0x2C */
     'X',  'B',  'M',  'W',     /* 0x30 */
     'V',  'Z', 0x00,  '*',     /* 0x34 */
    0x00,  ' ', 0x00, 0x00,     /* 0x38 */
    0x00, 0x00, 0x00, 0x00,     /* 0x3C */
    0x00, 0x00, 0x00, 0x00,     /* 0x40 */
    0x00, 0x00, 0x00,  '7',     /* 0x44 */
     '8',  '9',  '[',  '4',     /* 0x48 */
    '5',  '6',  '}',  '1',     /* 0x4C */
     '2',  '3',  '0',  'v',     /* 0x50 */
    0x00, 0x00, 0x00, 0x00,     /* 0x54 */
    0x00, 0x00, 0x00, 0x00      /* 0x58 */
};

/* ---------------------------------------------------------------------
 * Modifier / lock state
 * ------------------------------------------------------------------- */
uint8_t shift;   /* bit 0 = left shift, bit 1 = right shift */
uint8_t ctrl;    /* bit 0 = left ctrl,  bit 1 = right ctrl  */
static uint8_t alt;       /* bit 0 = left alt,   bit 1 = AltGr/right alt */
static uint8_t caps_lock = 0;
static uint8_t num_lock = 1;   /* keypad starts in digit mode */

#define BUFFLEN 128
/* New characters are added to hd. characters are pulled off of tl. */
uint8_t kb_buff[BUFFLEN];
uint8_t kb_buff_hd;
uint8_t kb_buff_tl;

/* 0xE0 prefix: the NEXT scancode belongs to an "extended" key (arrows,
 * Home/End, PgUp/PgDn, Insert/Delete, right Ctrl/Alt, keypad Enter...). */
static uint8_t kb_extended = 0;
/* 0xE1 prefix is only used by Pause/Break, which sends 5 more bytes
 * that must be swallowed whole -- otherwise the embedded 0x1D (Ctrl)
 * would leave Ctrl "stuck" until the next press. */
static uint8_t kb_skip = 0;

#define PS2_DATA   0x60
#define PS2_STATUS 0x64
#define PS2_STATUS_OBF 0x01   /* output buffer full: a byte is waiting      */
#define PS2_STATUS_AUX 0x20   /* ...and that byte came from the MOUSE port  */

/* True only if a byte is waiting AND it belongs to the keyboard. The old
 * driver read port 0x60 unconditionally. That is wrong twice over: when
 * nothing is pending it just returns the previous byte again (phantom
 * repeated keys), and when the byte is a mouse packet byte it steals it
 * from the mouse driver (cursor jumps) while feeding garbage into the
 * scancode decoder (keys that "randomly don't work"). */
static inline int kb_byte_ready(void) {
    return (inb(PS2_STATUS) & (PS2_STATUS_OBF | PS2_STATUS_AUX)) == PS2_STATUS_OBF;
}

static void kb_push(uint8_t c) {
    uint8_t next = (kb_buff_hd + 1) % BUFFLEN;
    if(next == kb_buff_tl) return;   /* buffer full: drop, never overwrite */
    kb_buff[kb_buff_hd] = c;
    kb_buff_hd = next;
}

static void kb_wait_input_clear(void) {
    for(int i = 0; i < 100000; i++) {
        if((inb(PS2_STATUS) & 0x02) == 0) return;
    }
}

/* Caps/Num Lock LEDs. The keyboard answers each byte with an ACK (0xFA),
 * which simply comes back through the normal byte path and is ignored. */
static void kb_update_leds(void) {
    kb_wait_input_clear();
    outb(PS2_DATA, 0xED);
    kb_wait_input_clear();
    outb(PS2_DATA, (uint8_t)((caps_lock ? 0x04 : 0) | (num_lock ? 0x02 : 0)));
}

/* Letters respond to Shift XOR Caps Lock; everything else only to Shift,
 * exactly like a real keyboard. */
static uint8_t kb_translate(uint8_t sc) {
    uint8_t lower = lower_ascii_codes[sc];
    if(sc == 0x56) lower = '\\';              /* extra ISO key next to left shift */
    if(lower == 0) return 0;

    int shifted = shift != 0;
    if(lower >= 'a' && lower <= 'z') {
        if(caps_lock) shifted = !shifted;
    }
    if(!shifted) return lower;
    if(sc == 0x56) return '|';
    return upper_ascii_codes[sc];
}

static void kb_process_byte(uint8_t byte) {
    /* Keyboard replies that are not key events: ACK, resend, echo,
     * buffer overrun/error markers. NOTE: 0xAA must NOT be filtered
     * here even though it is also the "self-test passed" reply -- it is
     * exactly the release code of left Shift (0x2A | 0x80), and
     * swallowing it would leave Shift stuck on. */
    if(byte == 0xFA || byte == 0xFE || byte == 0xEE || byte == 0x00 || byte == 0xFF) {
        return;
    }

    if(kb_skip) { kb_skip--; return; }

    if(byte == 0xE1) { kb_skip = 5; return; }

    if(byte == 0xE0) {
        kb_extended = 1;
        return;
    }

    int released = (byte & 0x80) != 0;
    uint8_t sc = byte & 0x7F;

    if(kb_extended) {
        kb_extended = 0;

        /* Modifiers first -- they matter on release too. */
        if(sc == 0x1D) { if(released) ctrl &= (uint8_t)~0x02; else ctrl |= 0x02; return; }
        if(sc == 0x38) { if(released) alt &= (uint8_t)~0x02; else alt |= 0x02; return; }
        if(released) return;   /* also swallows the fake-shift E0 AA / E0 B7 pairs */

        switch(sc) {
            case 0x48: kb_push((uint8_t)KEY_UP); break;
            case 0x50: kb_push((uint8_t)KEY_DOWN); break;
            case 0x4B: kb_push((uint8_t)KEY_LEFT); break;
            case 0x4D: kb_push((uint8_t)KEY_RIGHT); break;
            case 0x47: kb_push((uint8_t)KEY_HOME); break;
            case 0x4F: kb_push((uint8_t)KEY_END); break;
            case 0x49: kb_push((uint8_t)KEY_PGUP); break;
            case 0x51: kb_push((uint8_t)KEY_PGDN); break;
            case 0x52: kb_push((uint8_t)KEY_INSERT); break;
            case 0x53: kb_push((uint8_t)KEY_DELETE); break;
            case 0x1C: kb_push('\n'); break;   /* keypad Enter */
            case 0x35: kb_push('/'); break;    /* keypad / */
            case 0x37: kb_push((uint8_t)KEY_PRTSCN); break;   /* Print Screen */
            case 0x5B: case 0x5C: kb_push((uint8_t)KEY_WIN); break;   /* left / right Windows key */
            default: break;                    /* Win keys, Menu, PrtSc, media keys */
        }
        return;
    }

    /* ---- modifiers (tracked on both press and release) ---- */
    if(sc == 0x2A) { if(released) shift &= (uint8_t)~0x01; else shift |= 0x01; return; }
    if(sc == 0x36) { if(released) shift &= (uint8_t)~0x02; else shift |= 0x02; return; }
    if(sc == 0x1D) { if(released) ctrl &= (uint8_t)~0x01; else ctrl |= 0x01; return; }
    if(sc == 0x38) { if(released) alt &= (uint8_t)~0x01; else alt |= 0x01; return; }

    if(released) return;

    /* No software key-repeat filtering here any more: the keyboard's own
     * typematic logic already provides the initial delay and rate. The
     * old filter swallowed the first 9 repeats and hiccuped (one extra
     * character) every time its 8-bit counter wrapped. */

    /* ---- lock keys ---- */
    if(sc == 0x3A) { caps_lock = !caps_lock; kb_update_leds(); return; }
    if(sc == 0x45) { num_lock = !num_lock;   kb_update_leds(); return; }
    if(sc == 0x46) { return; }   /* Scroll Lock: nothing to do */

    /* ---- function keys ---- */
    if(sc >= 0x3B && sc <= 0x44) { kb_push((uint8_t)(KEY_F1 + (sc - 0x3B))); return; }
    if(sc == 0x57) { kb_push((uint8_t)KEY_F11); return; }
    if(sc == 0x58) { kb_push((uint8_t)KEY_F12); return; }

    /* ---- keypad navigation when Num Lock is off ---- */
    if(!num_lock && sc >= 0x47 && sc <= 0x53 && sc != 0x4A && sc != 0x4E) {
        switch(sc) {
            case 0x47: kb_push((uint8_t)KEY_HOME);   return;
            case 0x48: kb_push((uint8_t)KEY_UP);     return;
            case 0x49: kb_push((uint8_t)KEY_PGUP);   return;
            case 0x4B: kb_push((uint8_t)KEY_LEFT);   return;
            case 0x4D: kb_push((uint8_t)KEY_RIGHT);  return;
            case 0x4F: kb_push((uint8_t)KEY_END);    return;
            case 0x50: kb_push((uint8_t)KEY_DOWN);   return;
            case 0x51: kb_push((uint8_t)KEY_PGDN);   return;
            case 0x52: kb_push((uint8_t)KEY_INSERT); return;
            case 0x53: kb_push((uint8_t)KEY_DELETE); return;
            default: break;   /* 0x4C (keypad 5) has no navigation meaning */
        }
        return;
    }

    /* ---- Alt+Tab ---- */
    if(alt && sc == 0x0F) { kb_push((uint8_t)KEY_ALTTAB); return; }

    /* ---- Ctrl combinations ---- */
    if(ctrl) {
        if(sc == 0x01 && shift) { kb_push((uint8_t)KEY_TASKMGR); return; }  /* Ctrl+Shift+Esc */
        if(sc == 0x01) { kb_push((uint8_t)KEY_WIN); return; }               /* Ctrl+Esc */
        uint8_t base = lower_ascii_codes[sc];
        if(base >= 'a' && base <= 'z') {
            /* Ctrl+letter -> control code 1..26 (Ctrl+C = 3, Ctrl+V = 22, ...) */
            kb_push((uint8_t)(base - 'a' + 1));
        }
        else if(sc == 0x0E) {
            kb_push(0x7F);   /* Ctrl+Backspace -> DEL */
        }
        return;
    }

    uint8_t ascii = kb_translate(sc);
    if(ascii != 0) kb_push(ascii);
}

/* Drains every keyboard byte currently pending. Bounded, so a stuck
 * status line can never hang an interrupt handler. */
static void kb_drain(void) {
    for(int i = 0; i < 32 && kb_byte_ready(); i++) {
        kb_process_byte(inb(PS2_DATA));
    }
}

void keyboard_handler(registers_t regs) {
    (void)regs;
    kb_drain();
}

void keyboard_set_numlock(int on) {
    num_lock = on ? 1 : 0;
    kb_update_leds();
}

uint8_t keyboard_get_modifiers(void) {
    uint8_t m = 0;
    if(shift)     m |= KB_MOD_SHIFT;
    if(ctrl)      m |= KB_MOD_CTRL;
    if(alt)       m |= KB_MOD_ALT;
    if(caps_lock) m |= KB_MOD_CAPS;
    if(num_lock)  m |= KB_MOD_NUM;
    return m;
}

/* ---- 8042 helpers with real timeouts (real controllers are slow; the old
 * code read port 0x60 blindly, which returns stale bytes when the answer has
 * not arrived yet). ---------------------------------------------------- */
static int ps2_in_wait_clear(void) {
    for(int i = 0; i < 200000; i++) if((inb(PS2_STATUS) & 0x02) == 0) return 1;
    return 0;
}
static int ps2_out_wait_full(void) {
    for(int i = 0; i < 400000; i++) if(inb(PS2_STATUS) & PS2_STATUS_OBF) return 1;
    return 0;
}
static void ps2_flush_output(void) {
    for(int i = 0; i < 64 && (inb(PS2_STATUS) & PS2_STATUS_OBF); i++) (void)inb(PS2_DATA);
}
static void ps2_cmd(uint8_t c) { ps2_in_wait_clear(); outb(0x64, c); }
static void ps2_data(uint8_t d) { ps2_in_wait_clear(); outb(PS2_DATA, d); }
static int ps2_read(uint8_t *out) {
    if(!ps2_out_wait_full()) return 0;
    *out = inb(PS2_DATA);
    return 1;
}

void initialize_keyboard() {
    printf("Initializing keyboard.\n");

    /* Silence both ports while the controller is reconfigured, and throw away
     * anything the firmware/bootloader left in the output buffer. */
    ps2_cmd(0xAD);                     /* disable keyboard port */
    ps2_cmd(0xA7);                     /* disable mouse port    */
    ps2_flush_output();

    /* Remember the firmware's configuration byte (scancode translation, bit 6,
     * is deliberately kept exactly as the firmware set it -- see below). */
    uint8_t saved = 0x45;
    ps2_cmd(0x20);
    if(!ps2_read(&saved)) {
        printf("PS/2: no answer to 'read config' -- is there a PS/2 controller at all?\n");
        saved = 0x45;
    }
    printf("PS/2 config byte: %x\n", saved);

    /* Controller self-test. Some real controllers RESET their configuration
     * byte as a side effect, so it is rewritten afterwards. */
    uint8_t result = 0;
    ps2_cmd(0xAA);
    if(!ps2_read(&result)) {
        printf("PS/2 controller did not answer the self-test. Trying to continue.\n");
    }
    else if(result == 0x55) {
        printf("PS/2 controller test passed.\n");
    }
    else if(result == 0xFC) {
        printf("PS/2 controller test failed.\n");
    }
    else {
        printf("PS/2 controller responded to test with unknown code %x\n", result);
        printf("Trying to continue.\n");
    }

    /* Scancode translation (bit 6) stays as the firmware set it: forcing it
     * either way scrambles every scancode on some emulators (that is what once
     * killed the keyboard under VirtualBox). IRQ1 on, keyboard clock on. */
    uint8_t config = saved;
    config |= 0x01;                    /* IRQ1 enabled          */
    config &= (uint8_t)~0x10;          /* keyboard clock enabled */
    ps2_cmd(0x60);
    ps2_data(config);

    ps2_cmd(0xAE);                     /* enable the keyboard port again */
    ps2_flush_output();

    /* Make sure the keyboard is scanning (BIOS may have left it disabled). */
    ps2_data(0xF4);
    uint8_t ack;
    if(ps2_read(&ack)) { if(ack != 0xFA) printf("Keyboard answered %x to 'enable scanning'\n", ack); }
    else printf("Keyboard did not answer 'enable scanning' (no PS/2 keyboard?)\n");
    ps2_flush_output();

    register_interrupt_handler(IRQ1, keyboard_handler);

    kb_update_leds();   /* Num Lock starts on */
    ps2_flush_output(); /* the LED command's ACKs: an unread byte blocks every further IRQ */

    printf("Keyboard ready to go!\n\n");
}

extern void pause();
extern void sys_cli();
extern void sys_sti();

/* This can race with the keyboard_handler, so interrupts are stopped
 * while the buffer is touched. Polling the controller here as well (it
 * is safe now that the status register is checked) means a key is never
 * lost if an IRQ1 was missed or coalesced. */
char get_ascii_char() {
    while(1) {
        sys_cli();
        kb_drain();
        if(kb_buff_hd != kb_buff_tl) {
            char c = (char)kb_buff[kb_buff_tl];
            kb_buff_tl = (kb_buff_tl + 1) % BUFFLEN;
            sys_sti();
            return c;
        }
        sys_sti();
        pause();
    }
}

char try_get_ascii_char() {
    sys_cli();
    kb_drain();
    if(kb_buff_hd != kb_buff_tl) {
        char c = (char)kb_buff[kb_buff_tl];
        kb_buff_tl = (kb_buff_tl + 1) % BUFFLEN;
        sys_sti();
        return c;
    }
    sys_sti();
    return 0;
}
