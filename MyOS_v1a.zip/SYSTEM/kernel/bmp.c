/*
 * Minimal uncompressed 32bpp BMP encoder. BMP's on-disk layout for this
 * case is just a fixed header followed by bottom-up BGRA rows (no
 * padding needed at 32bpp since 4-byte pixels are always 4-byte
 * aligned), so this is a direct byte-reordering job with no compression
 * involved -- unlike PNG, which needs a working DEFLATE compressor to
 * write, not just to read.
 */

#include "stdint.h"
#include "stddef.h"
#include "bmp.h"
#include "kheap.h"
#include "common.h"
#include "kernio.h"
#include "stdio.h"

#define BMP_FILE_HEADER_SIZE 14
#define BMP_INFO_HEADER_SIZE 40
#define BMP_HEADER_SIZE (BMP_FILE_HEADER_SIZE + BMP_INFO_HEADER_SIZE)

static void write_u16(uint8_t *p, uint16_t v) {
    p[0] = v & 0xFF;
    p[1] = (v >> 8) & 0xFF;
}

static void write_u32(uint8_t *p, uint32_t v) {
    p[0] = v & 0xFF;
    p[1] = (v >> 8) & 0xFF;
    p[2] = (v >> 16) & 0xFF;
    p[3] = (v >> 24) & 0xFF;
}

uint8_t *bmp_encode(const uint32_t *pixels, uint16_t width, uint16_t height, uint32_t *out_length) {
    if(!pixels || width == 0 || height == 0) {
        return NULL;
    }

    uint32_t pixel_data_size = (uint32_t)width * height * 4;
    uint32_t file_size = BMP_HEADER_SIZE + pixel_data_size;

    uint8_t *buf = (uint8_t *)kmalloc(file_size);
    if(!buf) {
        printf("bmp: out of memory allocating %d bytes\n", file_size);
        return NULL;
    }

    memset(buf, 0, BMP_HEADER_SIZE);

    /* BITMAPFILEHEADER */
    buf[0] = 'B';
    buf[1] = 'M';
    write_u32(buf + 2, file_size);
    /* bytes 6-9 reserved, left 0 */
    write_u32(buf + 10, BMP_HEADER_SIZE); /* offset to pixel data */

    /* BITMAPINFOHEADER */
    write_u32(buf + 14, BMP_INFO_HEADER_SIZE);
    write_u32(buf + 18, width);
    write_u32(buf + 22, height); /* positive height = bottom-up rows, standard BMP orientation */
    write_u16(buf + 26, 1);      /* planes */
    write_u16(buf + 28, 32);     /* bpp */
    write_u32(buf + 30, 0);      /* compression = BI_RGB (none) */
    write_u32(buf + 34, pixel_data_size);
    write_u32(buf + 38, 2835);   /* ~72 DPI, x */
    write_u32(buf + 42, 2835);   /* ~72 DPI, y */
    /* colors used / important left 0 (means "all") */

    uint8_t *dst = buf + BMP_HEADER_SIZE;
    for(int y = 0; y < height; y++) {
        /* BMP rows are stored bottom-up; our source buffer is top-down. */
        const uint32_t *src_row = pixels + (height - 1 - y) * width;
        uint8_t *dst_row = dst + y * width * 4;

        for(int x = 0; x < width; x++) {
            uint32_t px = src_row[x];
            uint8_t a = (px >> 24) & 0xFF;
            uint8_t r = (px >> 16) & 0xFF;
            uint8_t g = (px >> 8) & 0xFF;
            uint8_t b = px & 0xFF;

            dst_row[x * 4 + 0] = b;
            dst_row[x * 4 + 1] = g;
            dst_row[x * 4 + 2] = r;
            dst_row[x * 4 + 3] = a;
        }
    }

    *out_length = file_size;
    return buf;
}

int bmp_save_to_file(const uint32_t *pixels, uint16_t width, uint16_t height,
                      f32 *fs, struct directory *dir, char *filename) {
    uint32_t length;
    uint8_t *data = bmp_encode(pixels, width, height, &length);
    if(!data) {
        return 0;
    }

    writeFile(fs, dir, data, filename, length);
    kfree(data);
    return 1;
}
