#include "fpu.h"
#include "stdint.h"

void fpu_init(void) {
    uint32_t cr0, cr4;

    asm volatile("mov %%cr0, %0" : "=r"(cr0));
    /* CR0.EM (bit 2, "emulation") must be CLEAR -- set would make every
     * x87 instruction trap instead of executing (used for software FPU
     * emulation on CPUs with no real FPU, which no x86 CPU running this
     * kernel actually needs). CR0.MP (bit 1, "monitor coprocessor") must
     * be SET so that a WAIT/FWAIT instruction actually checks for a
     * pending FPU exception -- without it some FPU error conditions go
     * unreported. CR0.TS (bit 3, "task switched") is left as whatever it
     * already was; this kernel does no lazy-FPU-context-switching (it's
     * single-tasking at the kernel/desktop level -- see app_loader.c's
     * "only one app at a time" comment), so there's no per-task FPU
     * state to defer saving/restoring. */
    cr0 &= ~(1u << 2); /* clear EM */
    cr0 |= (1u << 1);  /* set MP */
    asm volatile("mov %0, %%cr0" :: "r"(cr0));

    /* CR4.OSFXSR (bit 9) tells the CPU the OS supports the
     * FXSAVE/FXRSTOR instruction format and SSE in general -- without
     * it, SSE instructions (which GCC may emit for `float` code on this
     * -m32 target even though this kernel's CFLAGS don't force
     * -mno-sse) fault with #UD (invalid opcode), not just #NM. CR4.OSXMMEXCPT
     * (bit 10) lets unmasked SSE floating-point exceptions (rather than
     * silently producing NaN/Inf results) raise as a proper, catchable
     * interrupt instead of a more severe fault -- not strictly required
     * for correctness here, but a real OS always sets it alongside
     * OSFXSR, so this does too. */
    asm volatile("mov %%cr4, %0" : "=r"(cr4));
    cr4 |= (1u << 9) | (1u << 10);
    asm volatile("mov %0, %%cr4" :: "r"(cr4));

    /* Initializes the x87 FPU to its default state (clears exception
     * flags, sets the control word to its power-on defaults) -- the
     * standard way to bring the FPU to a known-good state before first
     * use, equivalent to what a real BIOS/bootloader would normally
     * have already done, except this kernel can't assume that happened
     * (GRUB doesn't guarantee it) and needs it done explicitly instead. */
    asm volatile("fninit");
}
