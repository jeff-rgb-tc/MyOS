#ifndef INI_H
#define INI_H

#include "stdint.h"

#define INI_MAX_SECTIONS 32
#define INI_MAX_KEYS_PER_SECTION 8
#define INI_MAX_NAME_LEN 32
#define INI_MAX_VALUE_LEN 64

typedef struct {
    char key[INI_MAX_NAME_LEN];
    char value[INI_MAX_VALUE_LEN];
} ini_kv_t;

typedef struct {
    char name[INI_MAX_NAME_LEN]; /* the part between [ and ], e.g. "icon0" */
    ini_kv_t kv[INI_MAX_KEYS_PER_SECTION];
    int kv_count;
} ini_section_t;

typedef struct {
    ini_section_t sections[INI_MAX_SECTIONS];
    int section_count;
} ini_document_t;

/* Parses a small, simple INI-style document: [section] headers followed
 * by key=value lines. No nested sections, no comments, no quoting --
 * just enough structure for desktop.ini (see desktop_ini.h), which is
 * MyOS's own format, not a general-purpose config file reader. Returns
 * 1 on success (even for an empty/all-invalid file -- it just yields
 * zero sections), 0 only if the input is too large to fit the fixed
 * limits above. */
int ini_parse(const char *text, uint32_t length, ini_document_t *out);

/* Looks up a key within a named section. Returns NULL if the section or
 * key doesn't exist. */
const char *ini_get(const ini_document_t *doc, const char *section, const char *key);

/* Parses a key's value as a decimal integer (no sign, no validation
 * beyond what coerce_int in common.c already does). Returns 1 on
 * success and writes to *out, 0 if the key is missing or not numeric. */
int ini_get_int(const ini_document_t *doc, const char *section, const char *key, int *out);

#endif
