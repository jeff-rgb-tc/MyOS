#include "fsx.h"
#include "ata_pio_drv.h"
#include "kheap.h"
#include "common.h"

/* ------------------------------------------------------------------------------------------ */
/* block reader: byte offsets on a partition (512-byte sectors) or an optical disc (2048)      */
/* ------------------------------------------------------------------------------------------ */
typedef struct { int dev; uint32_t base; int optical; uint32_t ss; uint8_t *tmp; } blk_t;

static int blk_init(blk_t *b, int dev, uint32_t base, int optical) {
    b->dev = dev; b->base = base; b->optical = optical; b->ss = optical ? 2048 : 512;
    b->tmp = (uint8_t *)kmalloc(b->ss);
    return b->tmp != 0;
}

static int blk_raw(blk_t *b, uint64_t sec, uint32_t n, void *buf, int cached) {
    if(b->optical) return ata_atapi_read(b->dev, (uint32_t)sec, n, buf);
    if(cached && n == 1) return ata_dev_read(b->dev, (uint64_t)b->base + sec, 1, buf);
    return ata_dev_read_stream(b->dev, (uint64_t)b->base + sec, n, buf);
}

/* Reads len bytes at byte offset `off`. 0 = ok. */
static int blk_read(blk_t *b, uint64_t off, void *buf, uint32_t len) {
    uint8_t *out = (uint8_t *)buf;
    while(len) {
        uint32_t shift = b->optical ? 11 : 9;                    /* sector size is 2048 or 512: no 64-bit division in the kernel */
        uint64_t sec = off >> shift;
        uint32_t inoff = (uint32_t)(off & (b->ss - 1));
        if(inoff == 0 && len >= b->ss) {
            uint32_t n = len / b->ss, maxn = b->optical ? 32u : 128u;
            if(n > maxn) n = maxn;
            if(blk_raw(b, sec, n, out, 0) != 0) return -1;
            out += (size_t)n * b->ss; off += (uint64_t)n * b->ss; len -= n * b->ss;
        } else {
            if(blk_raw(b, sec, 1, b->tmp, 1) != 0) return -1;
            uint32_t take = b->ss - inoff;
            if(take > len) take = len;
            memcpy(out, b->tmp + inoff, take);
            out += take; off += take; len -= take;
        }
    }
    return 0;
}

static uint16_t le16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t le32(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }

/* ------------------------------------------------------------------------------------------ */
/* directory builder                                                                           */
/* ------------------------------------------------------------------------------------------ */
typedef struct { struct directory *d; uint32_t cap; } dirb_t;

static void dirb_begin(dirb_t *b, struct directory *d, uint32_t handle) {
    d->cluster = handle; d->entries = 0; d->num_entries = 0; b->d = d; b->cap = 0;
}

static void dirb_add(dirb_t *b, const char *name, int len, uint8_t attrs, uint32_t handle, uint32_t size) {
    if(len <= 0 || len > 255) return;
    struct directory *d = b->d;
    if(d->num_entries == b->cap) {
        uint32_t ncap = b->cap ? b->cap * 2 : 32;
        struct dir_entry *n = (struct dir_entry *)krealloc(d->entries, ncap * sizeof(struct dir_entry));
        if(!n) return;
        d->entries = n; b->cap = ncap;
    }
    char *copy = (char *)kmalloc((uint32_t)len + 1);
    if(!copy) return;
    memcpy(copy, name, (size_t)len); copy[len] = 0;
    struct dir_entry *e = &d->entries[d->num_entries++];
    memset(e, 0, sizeof(*e));
    e->name = copy; e->dir_attrs = attrs; e->first_cluster = handle; e->file_size = size;
}

static void dirb_end(dirb_t *b) {
    if(!b->d->entries) { b->d->entries = (struct dir_entry *)kmalloc(sizeof(struct dir_entry)); }   /* free_directory() frees it */
}

#ifdef FSX_DEBUG
#define FAILHERE() do { printf("fsx: mount failed at line %d\n", __LINE__); goto fail; } while(0)
#else
#define FAILHERE() goto fail
#endif

#define MAX_FILE_BYTES (512u * 1024u * 1024u)

/* ------------------------------------------------------------------------------------------ */
/* ext2 / ext3 / ext4                                                                          */
/* ------------------------------------------------------------------------------------------ */
typedef struct {
    blk_t b;
    uint32_t bs, ipg, inode_size, bpg, first_data, ngroups, incompat, desc_size, inodes_count;
    uint64_t blocks_count;
    uint8_t *gdt;
} ext_t;

typedef struct { uint16_t mode; uint64_t size; uint32_t flags; uint8_t iblock[60]; } ext_inode_t;

static int ext_read_block(ext_t *e, uint64_t blk, void *buf) {
    if(blk >= e->blocks_count) return -1;
    return blk_read(&e->b, blk * e->bs, buf, e->bs);
}

static int ext_inode(ext_t *e, uint32_t ino, ext_inode_t *out) {
    if(ino == 0 || ino > e->inodes_count) return -1;
    uint32_t group = (ino - 1) / e->ipg, idx = (ino - 1) % e->ipg;
    if(group >= e->ngroups) return -1;
    const uint8_t *gd = e->gdt + (size_t)group * e->desc_size;
    uint64_t table = le32(gd + 8);
    if(e->desc_size >= 64) table |= (uint64_t)le32(gd + 0x28) << 32;
    uint8_t raw[128];
    if(blk_read(&e->b, table * e->bs + (uint64_t)idx * e->inode_size, raw, 128) != 0) return -1;
    out->mode = le16(raw);
    out->size = le32(raw + 4);
    if((out->mode & 0xF000) == 0x8000) out->size |= (uint64_t)le32(raw + 108) << 32;   /* regular file: i_size_high */
    out->flags = le32(raw + 32);
    memcpy(out->iblock, raw + 40, 60);
    return 0;
}

/* Logical block of the file -> physical block (0 = hole / not mapped). */
static uint64_t ext_bmap(ext_t *e, const ext_inode_t *in, uint32_t lblk, uint8_t *scratch) {
    if(in->flags & 0x80000) {                                    /* extent tree */
        uint8_t node[60];
        memcpy(node, in->iblock, 60);
        const uint8_t *cur = node;
        for(int depth_guard = 0; depth_guard < 6; depth_guard++) {
            if(le16(cur) != 0xF30A) return 0;
            uint32_t entries = le16(cur + 2), depth = le16(cur + 6);
            if(depth == 0) {
                for(uint32_t i = 0; i < entries; i++) {
                    const uint8_t *x = cur + 12 + 12 * i;
                    if(x + 12 > cur + (cur == node ? 60 : e->bs)) break;
                    uint32_t first = le32(x), len = le16(x + 4);
                    if(len > 32768) return 0;                    /* uninitialised extent reads as zeros */
                    if(lblk >= first && lblk < first + len)
                        return (((uint64_t)le16(x + 6) << 32) | le32(x + 8)) + (lblk - first);
                }
                return 0;
            }
            uint64_t leaf = 0; int found = 0;
            for(uint32_t i = 0; i < entries; i++) {
                const uint8_t *x = cur + 12 + 12 * i;
                if(x + 12 > cur + (cur == node ? 60 : e->bs)) break;
                if(le32(x) <= lblk) { leaf = le32(x + 4) | ((uint64_t)le16(x + 8) << 32); found = 1; } else break;
            }
            if(!found) return 0;
            if(ext_read_block(e, leaf, scratch) != 0) return 0;
            cur = scratch;
        }
        return 0;
    }
    /* classic indirect blocks */
    uint32_t n = e->bs / 4;
    if(lblk < 12) return le32(in->iblock + 4 * lblk);
    lblk -= 12;
    uint64_t blk;
    if(lblk < n) {
        blk = le32(in->iblock + 48);
        if(!blk || ext_read_block(e, blk, scratch) != 0) return 0;
        return le32(scratch + 4 * lblk);
    }
    lblk -= n;
    if(lblk < (uint64_t)n * n) {
        blk = le32(in->iblock + 52);
        if(!blk || ext_read_block(e, blk, scratch) != 0) return 0;
        blk = le32(scratch + 4 * (lblk / n));
        if(!blk || ext_read_block(e, blk, scratch) != 0) return 0;
        return le32(scratch + 4 * (lblk % n));
    }
    lblk -= n * n;
    blk = le32(in->iblock + 56);
    if(!blk || ext_read_block(e, blk, scratch) != 0) return 0;
    blk = le32(scratch + 4 * ((lblk / n / n) % n));
    if(!blk || ext_read_block(e, blk, scratch) != 0) return 0;
    blk = le32(scratch + 4 * ((lblk / n) % n));
    if(!blk || ext_read_block(e, blk, scratch) != 0) return 0;
    return le32(scratch + 4 * (lblk % n));
}

/* Whole file (or directory) contents. */
static uint8_t *ext_read_all(ext_t *e, const ext_inode_t *in, uint32_t size) {
    uint8_t *buf = (uint8_t *)kmalloc(size ? size : 1);
    uint8_t *scratch = (uint8_t *)kmalloc(e->bs);
    if(!buf || !scratch) { if(buf) kfree(buf); if(scratch) kfree(scratch); return 0; }
    if(size == 0) { kfree(scratch); return buf; }
    uint32_t nblocks = (size + e->bs - 1) / e->bs;
    uint32_t i = 0;
    while(i < nblocks) {
        uint64_t phys = ext_bmap(e, in, i, scratch);
        uint32_t chunk_off = i * e->bs;
        if(phys == 0) {                                          /* hole */
            uint32_t n = size - chunk_off < e->bs ? size - chunk_off : e->bs;
            memset(buf + chunk_off, 0, n);
            i++;
            continue;
        }
        uint32_t run = 1;                                        /* merge physically consecutive blocks into one read */
        while(i + run < nblocks && run < 64 && ext_bmap(e, in, i + run, scratch) == phys + run) run++;
        uint32_t bytes = run * e->bs;
        if(chunk_off + bytes > size) bytes = size - chunk_off;
        if(phys + run > e->blocks_count || blk_read(&e->b, phys * e->bs, buf + chunk_off, bytes) != 0) {
            kfree(buf); kfree(scratch); return 0;
        }
        i += run;
    }
    kfree(scratch);
    return buf;
}

static void ext_populate(f32 *fs, struct directory *dir, uint32_t ino) {
    ext_t *e = (ext_t *)fs->priv;
    dirb_t b; dirb_begin(&b, dir, ino);
    ext_inode_t in;
    if(ext_inode(e, ino, &in) == 0 && (in.mode & 0xF000) == 0x4000 && in.size > 0 && in.size <= 16u * 1024 * 1024) {
        uint8_t *data = ext_read_all(e, &in, (uint32_t)in.size);
        if(data) {
            uint32_t pos = 0, size = (uint32_t)in.size;
            while(pos + 8 <= size) {
                uint32_t child = le32(data + pos);
                uint32_t rec_len = le16(data + pos + 4);
                uint32_t name_len = data[pos + 6];
                if(rec_len < 8 || (rec_len & 3) || pos + rec_len > size || name_len + 8 > rec_len) break;   /* damaged: stop, never overrun */
                if(child != 0 && name_len > 0) {
                    const char *name = (const char *)(data + pos + 8);
                    int dots = (name_len == 1 && name[0] == '.') || (name_len == 2 && name[0] == '.' && name[1] == '.');
                    if(!dots) {
                        ext_inode_t ci;
                        if(ext_inode(e, child, &ci) == 0) {
                            uint16_t t = ci.mode & 0xF000;
                            if(t == 0x4000) dirb_add(&b, name, (int)name_len, DIRECTORY, child, 0);
                            else if(t == 0x8000) dirb_add(&b, name, (int)name_len, ARCHIVE, child, ci.size > 0xFFFFFFFFu ? 0xFFFFFFFFu : (uint32_t)ci.size);
                            /* symlinks, devices, sockets: not shown */
                        }
                    }
                }
                pos += rec_len;
            }
            kfree(data);
        }
    }
    dirb_end(&b);
}

static void ext_root(f32 *fs, struct directory *dir) { ext_populate(fs, dir, 2); }

static uint8_t *ext_readfile(f32 *fs, struct dir_entry *ent) {
    ext_t *e = (ext_t *)fs->priv;
    ext_inode_t in;
    if(ent->file_size > MAX_FILE_BYTES) return 0;
    if(ext_inode(e, ent->first_cluster, &in) != 0 || (in.mode & 0xF000) != 0x8000) return 0;
    uint32_t size = in.size > ent->file_size ? ent->file_size : (uint32_t)in.size;
    return ext_read_all(e, &in, size);
}

static void ext_destroy(f32 *fs) {
    ext_t *e = (ext_t *)fs->priv;
    if(!e) return;
    kfree(e->gdt); kfree(e->b.tmp); kfree(e);
}

static const struct fs_ops ext_ops = { "ext", ext_root, ext_populate, ext_readfile, ext_destroy };

/* ------------------------------------------------------------------------------------------ */
/* ISO 9660 (+ Joliet)                                                                         */
/* ------------------------------------------------------------------------------------------ */
typedef struct { blk_t b; int joliet; uint32_t root_lba, root_size; } iso_t;

static void iso_populate(f32 *fs, struct directory *dir, uint32_t extent) {
    iso_t *c = (iso_t *)fs->priv;
    dirb_t b; dirb_begin(&b, dir, extent);
    uint8_t first[2048];
    if(blk_read(&c->b, (uint64_t)extent * 2048, first, 2048) == 0) {
        uint32_t size = le32(first + 10);                        /* the "." record describes the directory itself */
        if(size > 0 && size <= 8u * 1024 * 1024 && first[0] >= 34) {
            uint8_t *data = (uint8_t *)kmalloc(size);
            if(data && blk_read(&c->b, (uint64_t)extent * 2048, data, size) == 0) {
                uint32_t pos = 0;
                while(pos < size) {
                    uint32_t len = data[pos];
                    if(len == 0) { pos = (pos / 2048 + 1) * 2048; continue; }        /* records never span sectors */
                    if(len < 34 || pos + len > size) break;
                    uint32_t lba = le32(data + pos + 2), fsize = le32(data + pos + 10);
                    uint8_t flags = data[pos + 25], nlen = data[pos + 32];
                    if(33u + nlen > len) break;
                    const uint8_t *nm = data + pos + 33;
                    int skip = (nlen == 1 && (nm[0] == 0 || nm[0] == 1));
                    if(!skip && nlen > 0) {
                        char name[256]; int n = 0;
                        if(c->joliet) {
                            for(int i = 0; i + 1 < nlen && n < 255; i += 2) {
                                uint16_t ch = (uint16_t)((nm[i] << 8) | nm[i + 1]);
                                name[n++] = (ch < 128 && ch >= 32) ? (char)ch : '?';
                            }
                        } else {
                            for(int i = 0; i < nlen && n < 255; i++) name[n++] = (char)nm[i];
                        }
                        /* strip ";1" version suffixes and a trailing dot (plain ISO 9660 names) */
                        for(int i = 0; i < n; i++) if(name[i] == ';') { n = i; break; }
                        if(n > 0 && name[n - 1] == '.') n--;
                        if(flags & 2) dirb_add(&b, name, n, DIRECTORY, lba, 0);
                        else dirb_add(&b, name, n, ARCHIVE, lba, fsize);
                    }
                    pos += len;
                }
            }
            if(data) kfree(data);
        }
    }
    dirb_end(&b);
}

static void iso_root(f32 *fs, struct directory *dir) { iso_populate(fs, dir, ((iso_t *)fs->priv)->root_lba); }

static uint8_t *iso_readfile(f32 *fs, struct dir_entry *ent) {
    iso_t *c = (iso_t *)fs->priv;
    if(ent->file_size > MAX_FILE_BYTES) return 0;
    uint8_t *buf = (uint8_t *)kmalloc(ent->file_size ? ent->file_size : 1);
    if(!buf) return 0;
    if(ent->file_size && blk_read(&c->b, (uint64_t)ent->first_cluster * 2048, buf, ent->file_size) != 0) { kfree(buf); return 0; }
    return buf;
}

static void iso_destroy(f32 *fs) { iso_t *c = (iso_t *)fs->priv; if(!c) return; kfree(c->b.tmp); kfree(c); }
static const struct fs_ops iso_ops = { "iso9660", iso_root, iso_populate, iso_readfile, iso_destroy };

/* ------------------------------------------------------------------------------------------ */
/* FAT12 / FAT16                                                                               */
/* ------------------------------------------------------------------------------------------ */
typedef struct {
    blk_t b;
    int fat12;
    uint32_t spc, cluster_bytes, root_entries, root_sectors, root_lba, data_lba, clusters;
    uint8_t *fat; uint32_t fat_bytes;
} fat16_t;

static uint32_t fat16_next(fat16_t *c, uint32_t cl) {
    if(cl < 2 || cl >= c->clusters + 2) return 0xFFFFFFFFu;
    if(c->fat12) {
        uint32_t off = cl + cl / 2;
        if(off + 1 >= c->fat_bytes) return 0xFFFFFFFFu;
        uint32_t v = c->fat[off] | (c->fat[off + 1] << 8);
        v = (cl & 1) ? (v >> 4) : (v & 0xFFF);
        return v >= 0xFF8 ? 0xFFFFFFFFu : v;
    }
    if(cl * 2 + 1 >= c->fat_bytes) return 0xFFFFFFFFu;
    uint32_t v = le16(c->fat + cl * 2);
    return v >= 0xFFF8 ? 0xFFFFFFFFu : v;
}

/* Reads a whole cluster chain (or `limit` bytes of it). */
static uint8_t *fat16_chain(fat16_t *c, uint32_t first, uint32_t limit, uint32_t *got) {
    uint32_t cap = c->cluster_bytes * 16, len = 0;
    uint8_t *buf = (uint8_t *)kmalloc(cap);
    if(!buf) return 0;
    uint32_t cl = first, guard = 0;
    while(cl != 0xFFFFFFFFu && cl >= 2 && guard++ < c->clusters + 2 && len < limit) {
        if(len + c->cluster_bytes > cap) {
            uint32_t ncap = cap * 2;
            uint8_t *nb = (uint8_t *)kmalloc(ncap);
            if(!nb) { kfree(buf); return 0; }
            memcpy(nb, buf, len); kfree(buf); buf = nb; cap = ncap;
        }
        uint64_t lba = (uint64_t)c->data_lba + (uint64_t)(cl - 2) * c->spc;
        if(blk_read(&c->b, lba * 512, buf + len, c->cluster_bytes) != 0) { kfree(buf); return 0; }
        len += c->cluster_bytes;
        cl = fat16_next(c, cl);
    }
    *got = len;
    return buf;
}

static void fat16_populate(f32 *fs, struct directory *dir, uint32_t handle) {
    fat16_t *c = (fat16_t *)fs->priv;
    dirb_t b; dirb_begin(&b, dir, handle);
    uint8_t *data = 0; uint32_t len = 0;
    if(handle == 0) {
        len = c->root_sectors * 512;
        data = (uint8_t *)kmalloc(len ? len : 1);
        if(data && blk_read(&c->b, (uint64_t)c->root_lba * 512, data, len) != 0) { kfree(data); data = 0; }
    } else {
        data = fat16_chain(c, handle, 4u * 1024 * 1024, &len);
    }
    if(data) {
        char lfn[260]; int lfn_len = 0, lfn_valid = 0;
        for(uint32_t pos = 0; pos + 32 <= len; pos += 32) {
            const uint8_t *e = data + pos;
            if(e[0] == 0) break;
            if(e[0] == 0xE5) { lfn_valid = 0; continue; }
            if(e[11] == 0x0F) {                                  /* long-name piece */
                int seq = e[0] & 0x1F;
                if(e[0] & 0x40) { memset(lfn, 0, sizeof(lfn)); lfn_len = 0; lfn_valid = 1; }
                if(!lfn_valid || seq < 1 || seq > 20) { lfn_valid = 0; continue; }
                static const int offs[13] = { 1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30 };
                for(int k = 0; k < 13; k++) {
                    uint16_t ch = le16(e + offs[k]);
                    int idx = (seq - 1) * 13 + k;
                    if(idx >= 255) break;
                    lfn[idx] = (ch == 0 || ch == 0xFFFF) ? 0 : (ch < 128 && ch >= 32 ? (char)ch : '?');
                    if(ch && ch != 0xFFFF && idx + 1 > lfn_len) lfn_len = idx + 1;
                }
                continue;
            }
            if(e[11] & 0x08) { lfn_valid = 0; continue; }       /* volume label */
            char name[300]; int n = 0;
            if(lfn_valid && lfn_len > 0) { for(int i = 0; i < lfn_len; i++) name[n++] = lfn[i]; }
            else {
                int bl = 8; while(bl > 0 && e[bl - 1] == ' ') bl--;
                int el = 3; while(el > 0 && e[8 + el - 1] == ' ') el--;
                for(int i = 0; i < bl; i++) { char ch = (char)e[i]; if((e[12] & 0x08) && ch >= 'A' && ch <= 'Z') ch += 32; name[n++] = ch; }
                if(el > 0) { name[n++] = '.'; for(int i = 0; i < el; i++) { char ch = (char)e[8 + i]; if((e[12] & 0x10) && ch >= 'A' && ch <= 'Z') ch += 32; name[n++] = ch; } }
            }
            lfn_valid = 0;
            if(n == 0 || (n == 1 && name[0] == '.') || (n == 2 && name[0] == '.' && name[1] == '.')) continue;
            uint32_t cl = le16(e + 26);
            if(e[11] & 0x10) dirb_add(&b, name, n, DIRECTORY, cl ? cl : 0xFFFFFFF0u, 0);
            else dirb_add(&b, name, n, ARCHIVE, cl, le32(e + 28));
        }
        kfree(data);
    }
    dirb_end(&b);
}

static void fat16_root(f32 *fs, struct directory *dir) { fat16_populate(fs, dir, 0); }

static uint8_t *fat16_readfile(f32 *fs, struct dir_entry *ent) {
    fat16_t *c = (fat16_t *)fs->priv;
    if(ent->file_size > MAX_FILE_BYTES) return 0;
    uint32_t got = 0;
    if(ent->file_size == 0) return (uint8_t *)kmalloc(1);
    uint8_t *all = fat16_chain(c, ent->first_cluster, ent->file_size, &got);
    if(!all) return 0;
    if(got < ent->file_size) { kfree(all); return 0; }
    return all;                                                   /* allocated >= file_size */
}

static void fat16_destroy(f32 *fs) { fat16_t *c = (fat16_t *)fs->priv; if(!c) return; kfree(c->fat); kfree(c->b.tmp); kfree(c); }
static const struct fs_ops fat16_ops = { "fat12/16", fat16_root, fat16_populate, fat16_readfile, fat16_destroy };

/* ------------------------------------------------------------------------------------------ */
/* mounting                                                                                    */
/* ------------------------------------------------------------------------------------------ */
static f32 *new_f32(int dev, uint32_t base, const struct fs_ops *ops, void *priv) {
    f32 *fs = (f32 *)kmalloc(sizeof(f32));
    if(!fs) return 0;
    memset(fs, 0, sizeof(*fs));
    fs->dev = dev; fs->part_lba = base; fs->cluster_size = 512; fs->ops = ops; fs->priv = priv;
    return fs;
}

static f32 *mount_ext(const volume_t *v) {
    ext_t *e = (ext_t *)kmalloc(sizeof(ext_t));
    if(!e) return 0;
    memset(e, 0, sizeof(*e));
    if(!blk_init(&e->b, v->dev, v->part_lba, 0)) { kfree(e); return 0; }
    uint8_t sb[1024];
    if(blk_read(&e->b, 1024, sb, 1024) != 0 || le16(sb + 56) != 0xEF53) FAILHERE();
    uint32_t lbs = le32(sb + 24);
    if(lbs > 6) FAILHERE();
    e->bs = 1024u << lbs;
    e->blocks_count = le32(sb + 4);
    e->bpg = le32(sb + 32); e->ipg = le32(sb + 40); e->first_data = le32(sb + 20);
    e->inodes_count = le32(sb + 0);
    uint32_t rev = le32(sb + 76);
    e->inode_size = rev >= 1 ? le16(sb + 88) : 128;
    e->incompat = rev >= 1 ? le32(sb + 96) : 0;
    e->desc_size = 32;
    if(e->incompat & 0x80) { e->desc_size = le16(sb + 254); if(e->desc_size < 64 || e->desc_size > 1024) FAILHERE(); e->blocks_count |= (uint64_t)le32(sb + 0x150) << 32; }
    /* features we cannot read correctly: compression (0x1), inline data (0x8000), encryption (0x10000), meta_bg (0x10) */
    if(e->incompat & (0x1 | 0x10 | 0x8000 | 0x10000)) FAILHERE();
    if(!e->bpg || !e->ipg || e->inode_size < 128 || e->inode_size > e->bs || !e->blocks_count) FAILHERE();
    if(e->blocks_count >> 32) FAILHERE();                         /* > 16 TB with 4K blocks: not supported */
    e->ngroups = ((uint32_t)e->blocks_count - e->first_data + e->bpg - 1) / e->bpg;
    if(e->ngroups == 0 || e->ngroups > 65536) FAILHERE();
    uint32_t gdt_bytes = e->ngroups * e->desc_size;
    e->gdt = (uint8_t *)kmalloc(gdt_bytes);
    if(!e->gdt) FAILHERE();
    if(blk_read(&e->b, (uint64_t)(e->bs == 1024 ? 2 : 1) * e->bs, e->gdt, gdt_bytes) != 0) FAILHERE();
    { f32 *fs = new_f32(v->dev, v->part_lba, &ext_ops, e); if(fs) return fs; }
fail:
    kfree(e->gdt); kfree(e->b.tmp); kfree(e);
    return 0;
}

static f32 *mount_iso(const volume_t *v) {
    iso_t *c = (iso_t *)kmalloc(sizeof(iso_t));
    if(!c) return 0;
    memset(c, 0, sizeof(*c));
    if(!blk_init(&c->b, v->dev, v->part_lba, v->optical)) { kfree(c); return 0; }
    /* on a hard-disk image sectors are 512 bytes but ISO addresses are still 2048-byte units: handled by blk_read offsets */
    uint8_t vd[2048];
    int have_pvd = 0;
    for(uint32_t lba = 16; lba < 40; lba++) {
        if(blk_read(&c->b, (uint64_t)lba * 2048, vd, 2048) != 0) break;
        if(memcmp(vd + 1, "CD001", 5) != 0) break;
        if(vd[0] == 255) break;
        if(vd[0] == 1 && !have_pvd) { have_pvd = 1; c->root_lba = le32(vd + 156 + 2); c->root_size = le32(vd + 156 + 10); }
        if(vd[0] == 2 && vd[88] == '%' && vd[89] == '/' && (vd[90] == '@' || vd[90] == 'C' || vd[90] == 'E')) {
            c->joliet = 1; c->root_lba = le32(vd + 156 + 2); c->root_size = le32(vd + 156 + 10);
            break;                                                /* prefer the Joliet tree: real long names */
        }
    }
    if(!have_pvd && !c->joliet) { kfree(c->b.tmp); kfree(c); return 0; }
    f32 *fs = new_f32(v->dev, v->part_lba, &iso_ops, c);
    if(!fs) { kfree(c->b.tmp); kfree(c); return 0; }
    return fs;
}

static f32 *mount_fat16(const volume_t *v) {
    fat16_t *c = (fat16_t *)kmalloc(sizeof(fat16_t));
    if(!c) return 0;
    memset(c, 0, sizeof(*c));
    if(!blk_init(&c->b, v->dev, v->part_lba, 0)) { kfree(c); return 0; }
    uint8_t s[512];
    if(blk_read(&c->b, 0, s, 512) != 0) FAILHERE();
    uint32_t bps = le16(s + 11), reserved = le16(s + 14), nfats = s[16];
    c->spc = s[13]; c->root_entries = le16(s + 17);
    uint32_t total = le16(s + 19) ? le16(s + 19) : le32(s + 32);
    uint32_t spf = le16(s + 22);
    if(bps != 512 || !c->spc || (c->spc & (c->spc - 1)) || !nfats || !spf || !reserved || !total) FAILHERE();
    c->cluster_bytes = c->spc * 512;
    c->root_sectors = (c->root_entries * 32 + 511) / 512;
    c->root_lba = reserved + nfats * spf;
    c->data_lba = c->root_lba + c->root_sectors;
    if(total <= c->data_lba) FAILHERE();
    c->clusters = (total - c->data_lba) / c->spc;
    c->fat12 = c->clusters < 4085;
    c->fat_bytes = spf * 512;
    c->fat = (uint8_t *)kmalloc(c->fat_bytes);
    if(!c->fat || blk_read(&c->b, (uint64_t)reserved * 512, c->fat, c->fat_bytes) != 0) FAILHERE();
    { f32 *fs = new_f32(v->dev, v->part_lba, &fat16_ops, c); if(fs) return fs; }
fail:
    kfree(c->fat); kfree(c->b.tmp); kfree(c);
    return 0;
}


/* ------------------------------------------------------------------------------------------ */
/* exFAT (read-only)                                                                           */
/* ------------------------------------------------------------------------------------------ */
#define EXFAT_NOFAT 0x80000000u            /* bit 31 of a handle: the data is contiguous (NoFatChain), no FAT lookups */
typedef struct { uint32_t cluster, size; } exfat_dirinfo_t;
typedef struct {
    blk_t b;
    uint32_t spc_shift, bps_shift, fat_off, fat_len, heap_off, clusters, root, cluster_bytes;
    uint8_t *fat; uint32_t fat_bytes;
    exfat_dirinfo_t dirs[128]; uint32_t ndirs;          /* directories seen with NoFatChain: cluster -> byte length */
} exfat_t;

static uint32_t exfat_next(exfat_t *c, uint32_t cl) {
    if(cl < 2 || cl >= c->clusters + 2 || (cl + 1) * 4 > c->fat_bytes) return 0xFFFFFFFFu;
    uint32_t v = le32(c->fat + cl * 4);
    return (v < 2 || v >= 0xFFFFFFF7u || v >= c->clusters + 2) ? 0xFFFFFFFFu : v;
}

/* Reads up to `limit` bytes of a cluster chain / contiguous run. */
static uint8_t *exfat_data(exfat_t *c, uint32_t handle, uint32_t known_size, uint32_t limit, uint32_t *got) {
    int contiguous = (handle & EXFAT_NOFAT) != 0;
    uint32_t cl = handle & ~EXFAT_NOFAT;
    uint32_t want = known_size ? known_size : limit;
    if(!known_size && !contiguous) {                         /* a FAT-chained directory: size it by walking the chain, not 8 MB */
        uint32_t cnt = 0, walk = cl, guard = 0;
        while(walk != 0xFFFFFFFFu && walk >= 2 && walk < c->clusters + 2 && cnt * c->cluster_bytes < limit && guard++ <= c->clusters) { cnt++; walk = exfat_next(c, walk); }
        want = cnt * c->cluster_bytes;
    }
    if(want > limit) want = limit;
    uint32_t nclusters = (want + c->cluster_bytes - 1) / c->cluster_bytes;
    if(nclusters == 0) nclusters = 1;
    uint8_t *buf = (uint8_t *)kmalloc(nclusters * c->cluster_bytes);
    if(!buf) return 0;
    uint32_t len = 0, guard = 0;
    while(cl != 0xFFFFFFFFu && cl >= 2 && cl < c->clusters + 2 && len < want && guard++ <= c->clusters) {
        if(len + c->cluster_bytes > nclusters * c->cluster_bytes) break;
        uint64_t sec = (uint64_t)c->heap_off + ((uint64_t)(cl - 2) << c->spc_shift);
        if(blk_read(&c->b, sec << c->bps_shift, buf + len, c->cluster_bytes) != 0) { kfree(buf); return 0; }
        len += c->cluster_bytes;
        cl = contiguous ? cl + 1 : exfat_next(c, cl);
    }
    *got = len;
    return buf;
}

static void exfat_populate(f32 *fs, struct directory *dir, uint32_t handle) {
    exfat_t *c = (exfat_t *)fs->priv;
    dirb_t b; dirb_begin(&b, dir, handle);
    uint32_t size = 0;
    if(handle & EXFAT_NOFAT) for(uint32_t i = 0; i < c->ndirs; i++) if(c->dirs[i].cluster == handle) size = c->dirs[i].size;
    uint32_t got = 0;
    uint8_t *data = (handle & EXFAT_NOFAT) && !size ? 0 : exfat_data(c, handle, size, 8u * 1024 * 1024, &got);
    if(data) {
        uint32_t avail = got;
        if(size && size < avail) avail = size;
        for(uint32_t pos = 0; pos + 32 <= avail; pos += 32) {
            const uint8_t *e = data + pos;
            if(e[0] == 0) break;                                   /* end of directory */
            if(e[0] != 0x85) continue;                             /* only in-use file/directory entry sets */
            uint32_t sec = e[1];
            if(sec < 2 || pos + 32 * (sec + 1) > avail) continue;
            uint16_t attrs = le16(e + 4);
            const uint8_t *st = e + 32;
            if(st[0] != 0xC0) continue;
            uint8_t flags = st[1], nlen = st[3];
            uint32_t first = le32(st + 20);
            uint64_t dlen = (uint64_t)le32(st + 24) | ((uint64_t)le32(st + 28) << 32);
            if(nlen == 0) continue;
            char name[256]; int n = 0;
            for(uint32_t k = 2; k <= sec && n < nlen; k++) {
                const uint8_t *ne = e + 32 * k;
                if(ne[0] != 0xC1) break;
                for(int j = 0; j < 15 && n < nlen; j++) { uint16_t ch = le16(ne + 2 + j * 2); name[n++] = (ch >= 32 && ch < 127) ? (char)ch : '?'; }
            }
            if(n != nlen) continue;
            uint32_t h = first | ((flags & 2) ? EXFAT_NOFAT : 0);
            if(attrs & 0x10) {
                if(flags & 2) {                                  /* remember the length of a contiguous directory (updated in place, never duplicated) */
                    uint32_t sz = dlen > 0x7FFFFFFFu ? 0x7FFFFFFFu : (uint32_t)dlen, k;
                    for(k = 0; k < c->ndirs; k++) if(c->dirs[k].cluster == h) break;
                    if(k == c->ndirs && c->ndirs < 128) c->ndirs++;
                    else if(k == c->ndirs) k = (uint32_t)(h % 128);          /* table full: overwrite one slot */
                    c->dirs[k].cluster = h; c->dirs[k].size = sz;
                }
                dirb_add(&b, name, n, DIRECTORY, h, 0);
            }
            else dirb_add(&b, name, n, ARCHIVE, h, dlen > 0xFFFFFFFFu ? 0xFFFFFFFFu : (uint32_t)dlen);
        }
        kfree(data);
    }
    dirb_end(&b);
}

static void exfat_root(f32 *fs, struct directory *dir) { exfat_populate(fs, dir, ((exfat_t *)fs->priv)->root); }

static uint8_t *exfat_readfile(f32 *fs, struct dir_entry *ent) {
    exfat_t *c = (exfat_t *)fs->priv;
    if(ent->file_size > MAX_FILE_BYTES) return 0;
    if(ent->file_size == 0) return (uint8_t *)kmalloc(1);
    uint32_t got = 0;
    uint8_t *all = exfat_data(c, ent->first_cluster, ent->file_size, ent->file_size, &got);
    if(!all || got < ent->file_size) { if(all) kfree(all); return 0; }
    return all;
}

static void exfat_destroy(f32 *fs) { exfat_t *c = (exfat_t *)fs->priv; if(!c) return; kfree(c->fat); kfree(c->b.tmp); kfree(c); }
static const struct fs_ops exfat_ops = { "exfat", exfat_root, exfat_populate, exfat_readfile, exfat_destroy };

static f32 *mount_exfat(const volume_t *v) {
    exfat_t *c = (exfat_t *)kmalloc(sizeof(exfat_t));
    if(!c) return 0;
    memset(c, 0, sizeof(*c));
    if(!blk_init(&c->b, v->dev, v->part_lba, 0)) { kfree(c); return 0; }
    uint8_t s[512];
    if(blk_read(&c->b, 0, s, 512) != 0 || memcmp(s + 3, "EXFAT   ", 8) != 0) FAILHERE();
    c->bps_shift = s[108]; c->spc_shift = s[109];
    if(c->bps_shift != 9 || c->spc_shift > 16) FAILHERE();                       /* 512-byte sectors only */
    c->fat_off = le32(s + 80); c->fat_len = le32(s + 84); c->heap_off = le32(s + 88);
    c->clusters = le32(s + 92); c->root = le32(s + 96);
    c->cluster_bytes = 512u << c->spc_shift;
    if(!c->clusters || c->clusters > 0x10000000u || c->root < 2 || c->root >= c->clusters + 2 || !c->fat_len) FAILHERE();
    c->fat_bytes = c->fat_len * 512;
    if(c->fat_bytes > 64u * 1024 * 1024) FAILHERE();
    c->fat = (uint8_t *)kmalloc(c->fat_bytes);
    if(!c->fat || blk_read(&c->b, (uint64_t)c->fat_off * 512, c->fat, c->fat_bytes) != 0) FAILHERE();
    { f32 *fs = new_f32(v->dev, v->part_lba, &exfat_ops, c); if(fs) return fs; }
fail:
    kfree(c->fat); kfree(c->b.tmp); kfree(c);
    return 0;
}


/* ------------------------------------------------------------------------------------------ */
/* NTFS (read-only): MFT records with fixups, resident / non-resident data (sparse runs),      */
/* attribute lists, directory B-trees ($INDEX_ROOT + $INDEX_ALLOCATION).                       */
/* Not supported: compressed and encrypted files (they read as unreadable).                    */
/* ------------------------------------------------------------------------------------------ */
typedef struct { uint64_t vcn, len, lcn; uint8_t sparse; } ntfs_run_t;
#define NTFS_MAX_RUNS 16384

typedef struct {
    blk_t b;
    uint32_t cs, cs_shift, recsize, idxsize;
    uint64_t total_clusters;
    ntfs_run_t *mft_runs; uint32_t mft_nruns;
} ntfs_t;

typedef struct {
    int found, resident;
    uint8_t *res; uint32_t res_len;
    ntfs_run_t *runs; uint32_t nruns, cap;
    uint64_t real_size, init_size; uint16_t flags;
} ntfs_attr_t;

static uint64_t le64(const uint8_t *p) { return (uint64_t)le32(p) | ((uint64_t)le32(p + 4) << 32); }
static uint64_t le48(const uint8_t *p) { return (uint64_t)le32(p) | ((uint64_t)le16(p + 4) << 32); }

static void ntfs_attr_free(ntfs_attr_t *a) { if(a->res) kfree(a->res); if(a->runs) kfree(a->runs); memset(a, 0, sizeof(*a)); }

/* Undoes the "update sequence": the last 2 bytes of every 512-byte sector were replaced by a counter. */
static int ntfs_fixup(uint8_t *rec, uint32_t size) {
    uint32_t usa_off = le16(rec + 4), usa_cnt = le16(rec + 6);
    if(usa_cnt < 2 || usa_off < 8 || usa_off + usa_cnt * 2 > size || (usa_cnt - 1) * 512 > size) return -1;
    const uint8_t *usa = rec + usa_off;
    for(uint32_t i = 1; i < usa_cnt; i++) {
        uint8_t *end = rec + i * 512 - 2;
        if(end[0] != usa[0] || end[1] != usa[1]) return -1;                   /* torn write / damaged */
        end[0] = usa[2 * i]; end[1] = usa[2 * i + 1];
    }
    return 0;
}

/* Reads `len` bytes at byte offset `off` of a stream described by a run list. */
static int ntfs_stream_read(ntfs_t *c, const ntfs_run_t *runs, uint32_t nruns, uint64_t off, uint8_t *out, uint32_t len) {
    while(len) {
        uint32_t i;
        uint64_t vcn = off >> c->cs_shift;
        for(i = 0; i < nruns; i++) if(vcn >= runs[i].vcn && vcn < runs[i].vcn + runs[i].len) break;
        if(i == nruns) { memset(out, 0, len); return 0; }                         /* beyond the mapped area: reads as zeros */
        uint64_t in_run = off - (runs[i].vcn << c->cs_shift);
        uint64_t run_bytes = (runs[i].len << c->cs_shift) - in_run;
        uint32_t take = run_bytes > len ? len : (uint32_t)run_bytes;
        if(runs[i].sparse) memset(out, 0, take);
        else if(blk_read(&c->b, (runs[i].lcn << c->cs_shift) + in_run, out, take) != 0) return -1;
        out += take; off += take; len -= take;
    }
    return 0;
}

static int ntfs_decode_runs(const uint8_t *p, const uint8_t *end, uint64_t vcn, ntfs_attr_t *a) {
    int64_t lcn = 0;
    if(a->nruns) { const ntfs_run_t *l = &a->runs[a->nruns - 1]; lcn = (int64_t)l->lcn; if(l->sparse) lcn = 0; }
    while(p < end && *p) {
        uint32_t lsz = *p & 15, osz = *p >> 4;
        if(lsz == 0 || lsz > 8 || osz > 8 || p + 1 + lsz + osz > end) return -1;
        uint64_t len = 0;
        for(uint32_t i = 0; i < lsz; i++) len |= (uint64_t)p[1 + i] << (8 * i);
        int64_t delta = 0;
        for(uint32_t i = 0; i < osz; i++) delta |= (int64_t)((uint64_t)p[1 + lsz + i] << (8 * i));
        if(osz && (p[lsz + osz] & 0x80) && osz < 8) delta |= -((int64_t)1 << (8 * osz));       /* sign extend */
        p += 1 + lsz + osz;
        if(a->nruns >= NTFS_MAX_RUNS) return -1;
        if(a->nruns == a->cap) {
            uint32_t ncap = a->cap ? a->cap * 2 : 16;
            ntfs_run_t *nr = (ntfs_run_t *)krealloc(a->runs, ncap * sizeof(ntfs_run_t));
            if(!nr) return -1;
            a->runs = nr; a->cap = ncap;
        }
        ntfs_run_t *r = &a->runs[a->nruns++];
        r->vcn = vcn; r->len = len;
        if(osz == 0) { r->sparse = 1; r->lcn = 0; }
        else { lcn += delta; if(lcn < 0) return -1; r->sparse = 0; r->lcn = (uint64_t)lcn; }
        vcn += len;
    }
    return 0;
}

/* Reads MFT record `no` into buf (recsize bytes), fixups applied. */
static int ntfs_record(ntfs_t *c, uint64_t no, uint8_t *buf) {
    if(ntfs_stream_read(c, c->mft_runs, c->mft_nruns, no * c->recsize, buf, c->recsize) != 0) return -1;     /* recsize*no: a multiply, not a division */
    if(memcmp(buf, "FILE", 4) != 0 || ntfs_fixup(buf, c->recsize) != 0) return -1;
    return 0;
}

static int utf16_is(const uint8_t *name, uint32_t nlen, const char *ascii) {
    uint32_t n = 0; while(ascii[n]) n++;
    if(n != nlen) return 0;
    for(uint32_t i = 0; i < n; i++) if(name[2 * i] != (uint8_t)ascii[i] || name[2 * i + 1] != 0) return 0;
    return 1;
}

/* Adds one attribute instance (resident value or a run-list extent) to `out`. */
static int ntfs_take_attr(ntfs_t *c, const uint8_t *rec, const uint8_t *a, ntfs_attr_t *out) {
    (void)c;
    uint32_t alen = le32(a + 4);
    if(a[8] == 0) {                                                  /* resident */
        uint32_t vlen = le32(a + 16), voff = le16(a + 20);
        if(voff + vlen > alen) return -1;
        out->res = (uint8_t *)kmalloc(vlen ? vlen : 1);
        if(!out->res) return -1;
        memcpy(out->res, a + voff, vlen);
        out->res_len = vlen; out->resident = 1; out->real_size = vlen; out->init_size = vlen;
    } else {
        uint64_t svcn = le64(a + 16);
        uint32_t roff = le16(a + 32);
        if(roff >= alen) return -1;
        if(out->nruns == 0) { out->real_size = le64(a + 48); out->init_size = le64(a + 56); out->flags = le16(a + 12); }
        if(ntfs_decode_runs(a + roff, a + alen, svcn, out) != 0) return -1;
    }
    out->found = 1;
    (void)rec;
    return 0;
}

/* Finds attribute (type, name) of file record `base`. name == NULL: the unnamed one. Follows $ATTRIBUTE_LIST. */
static int ntfs_get_attr(ntfs_t *c, uint64_t base, uint32_t type, const char *name, ntfs_attr_t *out) {
    memset(out, 0, sizeof(*out));
    uint8_t *rec = (uint8_t *)kmalloc(c->recsize), *other = (uint8_t *)kmalloc(c->recsize);
    int rc = -1;
    if(!rec || !other) goto done;
    if(ntfs_record(c, base, rec) != 0) goto done;
    uint32_t off = le16(rec + 20), used = le32(rec + 24);
    if(used > c->recsize) used = c->recsize;
    const uint8_t *list = 0;
    for(uint32_t guard = 0; off + 16 <= used && guard < 64; guard++) {
        const uint8_t *a = rec + off;
        uint32_t t = le32(a), alen = le32(a + 4);
        if(t == 0xFFFFFFFFu || alen < 16 || (alen & 7) || off + alen > used) break;
        if(t == 0x20) list = a;
        off += alen;
    }
    if(!list) {
        off = le16(rec + 20);
        for(uint32_t guard = 0; off + 16 <= used && guard < 64; guard++) {
            const uint8_t *a = rec + off;
            uint32_t t = le32(a), alen = le32(a + 4);
            if(t == 0xFFFFFFFFu || alen < 16 || (alen & 7) || off + alen > used) break;
            uint8_t nl = a[9]; uint32_t no = le16(a + 10);
            int name_ok = name ? (nl && no + nl * 2 <= alen && utf16_is(a + no, nl, name)) : (nl == 0);
            if(t == type && name_ok) { rc = ntfs_take_attr(c, rec, a, out); goto done; }
            off += alen;
        }
        rc = 0;                                                         /* not present: out->found stays 0 */
        goto done;
    }
    /* attribute list: read it, then visit the extents in order */
    {
        ntfs_attr_t lst; memset(&lst, 0, sizeof(lst));
        if(ntfs_take_attr(c, rec, list, &lst) != 0) { ntfs_attr_free(&lst); goto done; }
        uint32_t llen = lst.resident ? lst.res_len : (uint32_t)(lst.real_size > 4u * 1024 * 1024 ? 4u * 1024 * 1024 : lst.real_size);
        uint8_t *ldata = lst.resident ? lst.res : (uint8_t *)kmalloc(llen ? llen : 1);
        int ok = ldata != 0;
        if(ok && !lst.resident) ok = ntfs_stream_read(c, lst.runs, lst.nruns, 0, ldata, llen) == 0;
        if(ok) {
            for(uint32_t p = 0; p + 26 <= llen; ) {
                const uint8_t *e = ldata + p;
                uint32_t et = le32(e), elen = le16(e + 4);
                if(elen < 26 || p + elen > llen) break;
                uint8_t nl = e[6]; uint32_t no = e[7];
                int name_ok = name ? (nl && no + nl * 2 <= elen && utf16_is(e + no, nl, name)) : (nl == 0);
                if(et == type && name_ok) {
                    uint64_t rno = le48(e + 16), evcn = le64(e + 8);
                    const uint8_t *r = rec;
                    if(rno != base) { if(ntfs_record(c, rno, other) != 0) { ok = 0; break; } r = other; }
                    uint32_t o2 = le16(r + 20), used2 = le32(r + 24);
                    if(used2 > c->recsize) used2 = c->recsize;
                    int taken = 0;
                    for(uint32_t g = 0; o2 + 16 <= used2 && g < 64; g++) {
                        const uint8_t *a = r + o2;
                        uint32_t t2 = le32(a), al2 = le32(a + 4);
                        if(t2 == 0xFFFFFFFFu || al2 < 16 || (al2 & 7) || o2 + al2 > used2) break;
                        uint8_t nl2 = a[9]; uint32_t no2 = le16(a + 10);
                        int nm = name ? (nl2 && no2 + nl2 * 2 <= al2 && utf16_is(a + no2, nl2, name)) : (nl2 == 0);
                        if(t2 == type && nm && (a[8] == 0 || le64(a + 16) == evcn)) { if(ntfs_take_attr(c, r, a, out) != 0) ok = 0; taken = 1; break; }
                        o2 += al2;
                    }
                    if(!ok || !taken) { ok = taken ? 0 : ok; }
                    if(!ok) break;
                }
                p += elen;
            }
        }
        if(!lst.resident && ldata) kfree(ldata);
        ntfs_attr_free(&lst);
        rc = ok ? 0 : -1;
    }
done:
    if(rec) kfree(rec);
    if(other) kfree(other);
    if(rc != 0) ntfs_attr_free(out);
    return rc;
}

/* File size from the record (the index copy can be stale). */
static uint64_t ntfs_file_size(ntfs_t *c, uint64_t rno, uint64_t fallback) {
    ntfs_attr_t a;
    if(ntfs_get_attr(c, rno, 0x80, 0, &a) != 0 || !a.found) { ntfs_attr_free(&a); return fallback; }
    uint64_t r = a.real_size;
    ntfs_attr_free(&a);
    return r;
}

typedef struct { ntfs_t *c; dirb_t *b; uint64_t dir; ntfs_attr_t alloc; int have_alloc; uint32_t blocks; uint32_t count; int detail; } ntfs_walk_t;

static void ntfs_entry(ntfs_walk_t *w, const uint8_t *e) {
    uint32_t keylen = le16(e + 10);
    if(keylen < 66 || le16(e + 8) < 16 + keylen) return;
    const uint8_t *k = e + 16;
    uint32_t nlen = k[64], ns = k[65];
    if(nlen == 0 || 66 + nlen * 2 > keylen || ns == 2) return;                    /* skip DOS 8.3 duplicates */
    uint64_t rno = le48(e);
    char name[256]; int n = 0;
    for(uint32_t i = 0; i < nlen && n < 255; i++) { uint16_t ch = le16(k + 66 + i * 2); name[n++] = (ch >= 32 && ch < 127) ? (char)ch : '?'; }
    if(n == 1 && name[0] == '.') return;
    if(w->dir == 5 && rno < 24) return;                                             /* $MFT, $Bitmap ... */
    if(name[0] == '$' && rno < 24) return;
    int is_dir = (le32(k + 56) & 0x10000000u) != 0;
    uint64_t isize = le64(k + 48);
    if(is_dir) dirb_add(w->b, name, n, DIRECTORY, (uint32_t)rno, 0);
    else {
        uint64_t sz = w->detail ? ntfs_file_size(w->c, rno, isize) : isize;
        dirb_add(w->b, name, n, ARCHIVE, (uint32_t)rno, sz > 0xFFFFFFFFu ? 0xFFFFFFFFu : (uint32_t)sz);
    }
    w->count++;
}

static void ntfs_walk_entries(ntfs_walk_t *w, const uint8_t *p, const uint8_t *end, int depth);

static void ntfs_walk_block(ntfs_walk_t *w, uint64_t vcn, int depth) {
    ntfs_t *c = w->c;
    if(depth > 12 || !w->have_alloc || ++w->blocks > 200000) return;
    uint8_t *blk = (uint8_t *)kmalloc(c->idxsize);
    if(!blk) return;
    uint32_t unit_shift = c->idxsize >= c->cs ? c->cs_shift : 9;
    if(ntfs_stream_read(c, w->alloc.runs, w->alloc.nruns, vcn << unit_shift, blk, c->idxsize) == 0 &&
       memcmp(blk, "INDX", 4) == 0 && ntfs_fixup(blk, c->idxsize) == 0) {
        uint32_t eoff = le32(blk + 24), tot = le32(blk + 28);
        if(24 + eoff < c->idxsize && 24 + tot <= c->idxsize && eoff <= tot)
            ntfs_walk_entries(w, blk + 24 + eoff, blk + 24 + tot, depth + 1);
    }
    kfree(blk);
}

static void ntfs_walk_entries(ntfs_walk_t *w, const uint8_t *p, const uint8_t *end, int depth) {
    while(p + 16 <= end) {
        uint32_t elen = le16(p + 8), flags = le16(p + 12);
        if(elen < 16 || (elen & 7) || p + elen > end) break;
        if((flags & 1) && elen >= 24) ntfs_walk_block(w, le64(p + elen - 8), depth);      /* subtree first */
        if(flags & 2) break;                                                              /* last entry: no key */
        ntfs_entry(w, p);
        p += elen;
    }
}

static void ntfs_populate(f32 *fs, struct directory *dir, uint32_t handle) {
    ntfs_t *c = (ntfs_t *)fs->priv;
    dirb_t b; dirb_begin(&b, dir, handle);
    ntfs_walk_t w; memset(&w, 0, sizeof(w));
    ntfs_attr_t root; memset(&root, 0, sizeof(root));
    w.c = c; w.b = &b; w.dir = handle;
    if(ntfs_get_attr(c, handle, 0x90, "$I30", &root) == 0 && root.found && root.resident && root.res_len >= 32) {
        const uint8_t *v = root.res;
        uint32_t eoff = le32(v + 16), tot = le32(v + 20);
        if(le32(v + 8) >= 512 && le32(v + 8) <= 65536) c->idxsize = le32(v + 8);
        if(16 + eoff <= root.res_len && 16 + tot <= root.res_len && eoff <= tot) {
            if(ntfs_get_attr(c, handle, 0xA0, "$I30", &w.alloc) == 0 && w.alloc.found) w.have_alloc = 1;
            /* sizes come from each file's own record while the directory is small enough for that to be quick */
            w.detail = 1;
            ntfs_walk_entries(&w, v + 16 + eoff, v + 16 + tot, 0);
        }
    }
    ntfs_attr_free(&w.alloc);
    ntfs_attr_free(&root);
    dirb_end(&b);
}

static void ntfs_root(f32 *fs, struct directory *dir) { ntfs_populate(fs, dir, 5); }

static uint8_t *ntfs_readfile(f32 *fs, struct dir_entry *ent) {
    ntfs_t *c = (ntfs_t *)fs->priv;
    if(ent->file_size > MAX_FILE_BYTES) return 0;
    ntfs_attr_t a;
    if(ntfs_get_attr(c, ent->first_cluster, 0x80, 0, &a) != 0 || !a.found) { ntfs_attr_free(&a); return ent->file_size ? 0 : (uint8_t *)kmalloc(1); }
    if(!a.resident && (a.flags & 0x4001)) { ntfs_attr_free(&a); return 0; }        /* compressed / encrypted */
    uint8_t *buf = (uint8_t *)kmalloc(ent->file_size ? ent->file_size : 1);
    if(!buf) { ntfs_attr_free(&a); return 0; }
    memset(buf, 0, ent->file_size);
    uint32_t n = ent->file_size;
    int ok = 1;
    if(a.resident) { if(n > a.res_len) n = a.res_len; memcpy(buf, a.res, n); }
    else {
        if((uint64_t)n > a.init_size) n = (uint32_t)a.init_size;                   /* beyond the initialised size: zeros */
        if(n) ok = ntfs_stream_read(c, a.runs, a.nruns, 0, buf, n) == 0;
    }
    ntfs_attr_free(&a);
    if(!ok) { kfree(buf); return 0; }
    return buf;
}

static void ntfs_destroy(f32 *fs) { ntfs_t *c = (ntfs_t *)fs->priv; if(!c) return; kfree(c->mft_runs); kfree(c->b.tmp); kfree(c); }
static const struct fs_ops ntfs_ops = { "ntfs", ntfs_root, ntfs_populate, ntfs_readfile, ntfs_destroy };

static f32 *mount_ntfs(const volume_t *v) {
    ntfs_t *c = (ntfs_t *)kmalloc(sizeof(ntfs_t));
    if(!c) return 0;
    memset(c, 0, sizeof(*c));
    uint8_t *rec = 0;
    if(!blk_init(&c->b, v->dev, v->part_lba, 0)) { kfree(c); return 0; }
    uint8_t s[512];
    if(blk_read(&c->b, 0, s, 512) != 0 || memcmp(s + 3, "NTFS    ", 8) != 0) FAILHERE();
    uint32_t bps = le16(s + 11), spc = s[13];
    if(bps != 512 || !spc || (spc & (spc - 1))) FAILHERE();
    c->cs = bps * spc;
    c->cs_shift = 9; { uint32_t t = spc; while(t > 1) { t >>= 1; c->cs_shift++; } }
    int8_t cpr = (int8_t)s[64], cpi = (int8_t)s[68];
    c->recsize = cpr > 0 ? (uint32_t)cpr * c->cs : (cpr > -32 ? 1u << (-cpr) : 0);
    c->idxsize = cpi > 0 ? (uint32_t)cpi * c->cs : (cpi > -32 ? 1u << (-cpi) : 4096);
    if(c->recsize < 512 || c->recsize > 65536 || (c->recsize & (c->recsize - 1))) FAILHERE();
    if(c->idxsize < 512 || c->idxsize > 65536) FAILHERE();
    uint64_t mft_lcn = le64(s + 48);
    c->total_clusters = le64(s + 40) >> (c->cs_shift - 9);
    if(!mft_lcn || mft_lcn >= c->total_clusters) FAILHERE();
    /* record 0 ($MFT) describes where the whole MFT is */
    rec = (uint8_t *)kmalloc(c->recsize);
    if(!rec || blk_read(&c->b, mft_lcn << c->cs_shift, rec, c->recsize) != 0) FAILHERE();
    if(memcmp(rec, "FILE", 4) != 0 || ntfs_fixup(rec, c->recsize) != 0) FAILHERE();
    {
        ntfs_attr_t a; memset(&a, 0, sizeof(a));
        uint32_t off = le16(rec + 20), used = le32(rec + 24);
        if(used > c->recsize) used = c->recsize;
        for(uint32_t guard = 0; off + 16 <= used && guard < 64; guard++) {
            const uint8_t *at = rec + off;
            uint32_t t = le32(at), alen = le32(at + 4);
            if(t == 0xFFFFFFFFu || alen < 16 || (alen & 7) || off + alen > used) break;
            if(t == 0x80 && at[8] == 1 && at[9] == 0) { if(ntfs_take_attr(c, rec, at, &a) != 0) { ntfs_attr_free(&a); FAILHERE(); } break; }
            off += alen;
        }
        if(!a.found || a.nruns == 0) { ntfs_attr_free(&a); FAILHERE(); }
        c->mft_runs = a.runs; c->mft_nruns = a.nruns; a.runs = 0;
        ntfs_attr_free(&a);
    }
    kfree(rec); rec = 0;
    { f32 *fs = new_f32(v->dev, v->part_lba, &ntfs_ops, c); if(fs) return fs; }
fail:
    if(rec) kfree(rec);
    kfree(c->mft_runs); kfree(c->b.tmp); kfree(c);
    return 0;
}

int fsx_supported(fs_type_t fs) {
    return fs == FS_FAT32 || fs == FS_FAT16 || fs == FS_FAT12 || fs == FS_EXT2 || fs == FS_EXT3 || fs == FS_EXT4 || fs == FS_ISO9660 || fs == FS_EXFAT || fs == FS_NTFS;
}

f32 *fsx_mount(const volume_t *v) {
    if(!v || v->dev < 0) return 0;
    switch(v->fs) {
        case FS_FAT32:   return makeFilesystemOn(v->dev, v->part_lba);
        case FS_FAT16: case FS_FAT12: return mount_fat16(v);
        case FS_EXT2: case FS_EXT3: case FS_EXT4: return mount_ext(v);
        case FS_ISO9660: return mount_iso(v);
        case FS_EXFAT:   return mount_exfat(v);
        case FS_NTFS:    return mount_ntfs(v);
        default: return 0;
    }
}
