#ifndef AUDIO_H
#define AUDIO_H

#include "stdint.h"

/* Kernel-side audio API: a single active "driver" (see audio_driver_t)
 * that knows how to push 16-bit stereo PCM to whatever hardware is
 * actually present, and a small mixer/queue in front of it so callers
 * (app_music.c, system sounds, ...) don't need to know which driver is
 * active or handle hardware buffering themselves.
 *
 * Drivers are probed in priority order at boot (see audio_init()) --
 * AC97 first (the most commonly emulated/real sound device from the
 * PCI era onward), then the legacy ISA devices (SB16, then AdLib/OPL,
 * then Gravis UltraSound) as fallbacks for older real hardware or
 * emulators that don't expose AC97. Whichever probe succeeds first
 * becomes the active driver; the desktop and apps never talk to a
 * specific driver directly, only through this header.
 *
 * This mirrors the point 5 request for /Drivers/sound/<name>.drv -- see
 * driver_loader.h for how a .drv file on disk maps to one of these
 * audio_driver_t implementations. */

typedef struct {
    const char *name; /* shown in Settings/diagnostics, e.g. "AC97" */

    /* Probes for the hardware this driver knows how to talk to (PCI
     * scan for AC97, fixed ISA ports for SB16/AdLift/GUS) and, if
     * found, initializes it. Returns 1 on success (this driver is now
     * the active one), 0 if the hardware isn't present. */
    int (*probe_and_init)(void);

    /* Configures the output format -- called once after probe_and_init
     * succeeds, and again if a caller ever needs a different sample
     * rate (e.g. switching between a 44100Hz music file and a 22050Hz
     * system sound). channels is 1 (mono) or 2 (stereo); bits_per_sample
     * is always 16 in this version (see audio.h's own top comment --
     * every decoder in this OS converts to 16-bit PCM before handing
     * data to this API, so no driver needs to support anything else). */
    void (*set_format)(uint32_t sample_rate, uint8_t channels);

    /* Queues PCM samples for playback -- blocks (spins) only long
     * enough to hand the buffer to the hardware's own DMA queue, not
     * for the audio to actually finish playing; returns once the driver
     * has accepted the data. `samples` is raw signed 16-bit PCM,
     * interleaved if stereo (L,R,L,R,...); sample_count is the number
     * of individual 16-bit samples (NOT frames -- a stereo frame is 2
     * samples), matching how audio_queue() itself is called. */
    void (*write)(const int16_t *samples, uint32_t sample_count);

    /* Returns 1 if the driver's output queue has room for more data
     * without blocking, 0 if it's still working through what's already
     * queued -- callers (see app_music.c) poll this before calling
     * write() again rather than write() blocking internally, so the
     * desktop's own render loop never stalls waiting on audio. */
    int (*ready_for_more)(void);

    /* 0-100 master volume, if the hardware supports it in a way this
     * driver can control (AC97 does, via its mixer registers; the
     * legacy ISA drivers may not -- see each driver's own
     * set_volume comment for what it actually does). May be NULL if
     * volume control isn't supported at all, in which case
     * audio_set_volume() is a no-op. */
    void (*set_volume)(uint8_t volume_percent);
    /* Optional: drop everything queued and stop (track change / seek). */
    void (*flush)(void);
    /* Optional: pause (1) / resume (0) without losing queued audio. */
    void (*pause)(int paused);
} audio_driver_t;

/* Probes every known driver in priority order and activates the first
 * one that reports hardware present. Safe to call even if nothing is
 * found (audio_is_available() then returns 0, and every other audio_*
 * call becomes a harmless no-op) -- this kernel runs fine with no sound
 * hardware at all, same as it always has. */
void audio_init(void);

int audio_is_available(void);
const char *audio_active_driver_name(void); /* NULL if audio_is_available() is 0 */

void audio_set_format(uint32_t sample_rate, uint8_t channels);
void audio_queue(const int16_t *samples, uint32_t sample_count);
int audio_ready_for_more(void);
/* Master volume, 0-100, applied in software to all audio_queue() data
 * (works on every driver, even ones with no hardware mixer). */
void audio_set_volume(uint8_t volume_percent);
uint8_t audio_get_volume(void);
void audio_set_muted(int muted);
int audio_is_muted(void);
/* Drops queued audio (call before starting a new track or seeking). */
void audio_flush(void);
/* Pauses/resumes hardware playback of already-queued audio. */
void audio_pause(int paused);

#endif
