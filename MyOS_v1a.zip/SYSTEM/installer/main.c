/* installer -- the MyOS installer.
 *
 * A small wizard: Welcome -> choose a disk -> confirm -> install -> done.
 * All the real work (MBR + boot loader, FAT32 format, copying the system and
 * the apps-sdk) happens in the kernel's installer service; this program only
 * asks for the disk, calls myos_install_step() repeatedly and draws progress.
 * It is the only program the kernel gives the "system" permission to. */
#include <myos/myos.h>
#include <myos/ui.h>

enum { PAGE_WELCOME, PAGE_DISK, PAGE_CONFIRM, PAGE_PROGRESS, PAGE_DONE, PAGE_FAILED };

#define MAX_DISKS 4
#define W 520
#define H 360

static myos_diskinfo_t disks[MAX_DISKS];
static int disk_count = 0;

static const char *error_text(int err) {
    switch(err) {
        case MYOS_E_INST_PAYLOAD: return "Boot loader files are missing from the install disk.";
        case MYOS_E_INST_DISK:    return "This disk cannot be used.";
        case MYOS_E_INST_IO:      return "The disk reported a read/write error.";
        case MYOS_E_INST_BUSY:    return "An installation is already running.";
        case MYOS_E_NOMEM:        return "Out of memory.";
        case MYOS_E_PERM:         return "The installer has no system permission.";
        case MYOS_E_ARG:          return "The selected disk is no longer available.";
        case MYOS_E_FAIL:         return "The system disk is not available.";
        default:                  return "Unexpected error.";
    }
}

/* What to tell the user to do about it (shown under the error). */
static const char *error_hint(int err) {
    switch(err) {
        case MYOS_E_INST_PAYLOAD: return "Rebuild the ISO: sudo apt install grub-pc-bin, then make bootsect iso.";
        case MYOS_E_INST_DISK:    return "Use a disk of at least 256 MB that MyOS is not running from.";
        case MYOS_E_INST_IO:      return "Check the disk is attached as IDE/ATA (not AHCI/NVMe) and retry.";
        case MYOS_E_PERM:         return "Start it from /APPS/installer/installer.app.";
        default:                  return "";
    }
}

static void load_disks(void) {
    disk_count = myos_disk_count();
    if(disk_count < 0) disk_count = 0;
    if(disk_count > MAX_DISKS) disk_count = MAX_DISKS;
    for(int i = 0; i < disk_count; i++) {
        if(myos_disk_info(i, &disks[i]) < 0) disks[i].usable = 0;
    }
}

static void fmt_size(char *out, int max, uint32_t mb) {
    if(mb >= 1024) snprintf(out, max, "%d.%d GB", (int)(mb / 1024), (int)((mb % 1024) * 10 / 1024));
    else snprintf(out, max, "%d MB", (int)mb);
}

int app_main(void) {
    int win = myos_window_create("MyOS Installer", W, H);
    if(win < 0) return 1;

    myos_ui_t ui;
    myos_ui_init(&ui, win);

    int backup = 0, x64_note = 0;        /* backup is off by default; x86 is the only system type */
    int page = PAGE_WELCOME;
    int selected = -1;
    int understood = 0;
    int fail_err = 0;
    char fail_detail[64] = "";
    myos_install_status_t st;
    memset(&st, 0, sizeof(st));
    int installing = 0;

    for(;;) {
        myos_clear(win, MYOS_COLOR_BG);
        myos_text_scaled(win, 24, 18, "MyOS Setup", MYOS_COLOR_TEXT, 2);

        if(page == PAGE_WELCOME) {
            myos_ui_label(&ui, 24, 70, "Welcome! This wizard installs MyOS on a hard disk.", MYOS_COLOR_TEXT);
            myos_ui_label(&ui, 24, 100, "It will:", MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 40, 122, "- erase the disk you choose and create a new partition", MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 40, 144, "- install the boot loader and copy MyOS", MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 40, 166, "- install the apps-sdk, so you can write your own apps", MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 24, 210, "Tip: boot from the install disc with the first menu entry (Live).", MYOS_COLOR_TEXT_DIM);
            if(myos_ui_button(&ui, 1, W - 250, H - 56, 110, 34, "Close", MYOS_UI_NORMAL)) return 0;
            if(myos_ui_button(&ui, 2, W - 130, H - 56, 110, 34, "Next", MYOS_UI_ACCENT)) {
                load_disks();
                selected = -1;
                for(int i = 0; i < disk_count; i++) if(disks[i].usable) { selected = i; break; }
                page = PAGE_DISK;
            }
        }
        else if(page == PAGE_DISK) {
            myos_ui_label(&ui, 24, 64, "Where do you want to install MyOS?", MYOS_COLOR_TEXT);
            if(disk_count == 0) {
                myos_ui_label(&ui, 24, 100, "No hard disk found.", MYOS_COLOR_WARN);
                myos_ui_label(&ui, 24, 124, "Attach the virtual disk to an IDE controller and restart.", MYOS_COLOR_TEXT_DIM);
            }
            for(int i = 0; i < disk_count; i++) {
                int y = 92 + i * 52;
                myos_ui_panel(&ui, 24, y, W - 48, 44);
                char sz[24], line[96];
                fmt_size(sz, sizeof(sz), disks[i].size_mb);
                snprintf(line, sizeof(line), "Disk %d: %s", i + 1, disks[i].model);
                myos_ui_label(&ui, 36, y + 6, line, disks[i].usable ? MYOS_COLOR_TEXT : MYOS_COLOR_TEXT_DIM);
                if(!disks[i].usable) {
                    myos_ui_label(&ui, 36, y + 24,
                        disks[i].reason == 2 ? "In use: MyOS is running from this disk" : "Too small (256 MB needed)", MYOS_COLOR_WARN);
                } else {
                    snprintf(line, sizeof(line), "%s%s", sz, disks[i].has_filesystem ? "  -  contains data, will be erased" : "");
                    myos_ui_label(&ui, 36, y + 24, line, disks[i].has_filesystem ? MYOS_COLOR_WARN : MYOS_COLOR_TEXT_DIM);
                    if(myos_ui_button(&ui, 10 + i, W - 150, y + 8, 90, 28, selected == i ? "Selected" : "Select",
                                      selected == i ? MYOS_UI_ACCENT : MYOS_UI_NORMAL)) selected = i;
                }
            }
            if(myos_ui_button(&ui, 3, W - 250, H - 56, 110, 34, "Back", MYOS_UI_NORMAL)) page = PAGE_WELCOME;
            if(selected >= 0 && myos_ui_button(&ui, 4, W - 130, H - 56, 110, 34, "Next", MYOS_UI_ACCENT)) {
                understood = 0; page = PAGE_CONFIRM;
            }
        }
        else if(page == PAGE_CONFIRM) {
            char line[96], sz[24];
            fmt_size(sz, sizeof(sz), disks[selected].size_mb);
            myos_ui_label(&ui, 24, 64, "Ready to install", MYOS_COLOR_TEXT);
            snprintf(line, sizeof(line), "Target: Disk %d - %s (%s)", selected + 1, disks[selected].model, sz);
            myos_ui_label(&ui, 24, 96, line, MYOS_COLOR_TEXT_DIM);
            fmt_size(sz, sizeof(sz), disks[selected].part_mb);
            snprintf(line, sizeof(line), "A %s MyOS partition will be created.", sz);
            myos_ui_label(&ui, 24, 118, line, MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 24, 146, "WARNING: everything on this disk will be erased.", MYOS_COLOR_DANGER);
            myos_ui_checkbox(&ui, 20, 24, 172, "I understand, erase the disk", &understood);
            myos_ui_checkbox(&ui, 21, 24, 198, "Keep my files: back up /Users first, restore after (up to 48 MB)", &backup);
            myos_ui_label(&ui, 24, 228, "System type:", MYOS_COLOR_TEXT_DIM);
            myos_ui_button(&ui, 22, 120, 222, 130, 28, "x86 (32-bit)", MYOS_UI_ACCENT);
            if(myos_ui_button(&ui, 23, 258, 222, 130, 28, "x64 (64-bit)", MYOS_UI_NORMAL)) x64_note = 1;
            if(x64_note) myos_ui_label(&ui, 24, 254, "x64 is not available in this build yet: installing x86.", MYOS_COLOR_WARN);
            if(myos_ui_button(&ui, 5, W - 250, H - 56, 110, 34, "Back", MYOS_UI_NORMAL)) page = PAGE_DISK;
            if(understood && myos_ui_button(&ui, 6, W - 130, H - 56, 110, 34, "Install", MYOS_UI_DANGER)) {
                int rc = myos_install_begin_ex(selected, backup ? MYOS_INSTALL_BACKUP : 0);
                if(rc < 0) { fail_err = rc; fail_detail[0] = 0; page = PAGE_FAILED; }
                else { installing = 1; memset(&st, 0, sizeof(st)); page = PAGE_PROGRESS; myos_busy(1); }
            }
        }
        else if(page == PAGE_PROGRESS) {
            myos_ui_label(&ui, 24, 70, st.stage[0] ? st.stage : "Starting...", MYOS_COLOR_TEXT);
            myos_ui_progress(&ui, 24, 100, W - 48, 14, (int)st.percent, 100);
            char line[64];
            snprintf(line, sizeof(line), "%d%%", (int)st.percent);
            myos_ui_label(&ui, 24, 124, line, MYOS_COLOR_TEXT_DIM);
            if(st.files_total) {
                snprintf(line, sizeof(line), "Files: %d / %d", (int)st.files_done, (int)st.files_total);
                myos_ui_label(&ui, 24, 146, line, MYOS_COLOR_TEXT_DIM);
            }
            myos_ui_label(&ui, 24, 178, st.detail, MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 24, 230, "Do not turn off the computer.", MYOS_COLOR_WARN);
        }
        else if(page == PAGE_DONE) {
            myos_ui_label(&ui, 24, 70, "MyOS has been installed.", MYOS_COLOR_OK);
            myos_ui_label(&ui, 24, 102, "Remove the install disc (or eject the ISO), then restart.", MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 24, 130, "The apps-sdk is in /SYSTEM/apps-sdk -- see docs/GUIDE.md.", MYOS_COLOR_TEXT_DIM);
            if(myos_ui_button(&ui, 7, W - 250, H - 56, 110, 34, "Close", MYOS_UI_NORMAL)) return 0;
            if(myos_ui_button(&ui, 8, W - 130, H - 56, 110, 34, "Restart now", MYOS_UI_ACCENT)) myos_reboot();
        }
        else { /* PAGE_FAILED */
            myos_ui_label(&ui, 24, 70, "Installation failed.", MYOS_COLOR_DANGER);
            myos_ui_label(&ui, 24, 102, error_text(fail_err), MYOS_COLOR_TEXT);
            myos_ui_label(&ui, 24, 130, fail_detail, MYOS_COLOR_TEXT_DIM);
            myos_ui_label(&ui, 24, 160, error_hint(fail_err), MYOS_COLOR_WARN);
            { char code[40]; snprintf(code, sizeof(code), "Error code: %d", fail_err);
              myos_ui_label(&ui, 24, 190, code, MYOS_COLOR_TEXT_DIM); }
            if(myos_ui_button(&ui, 9, W - 250, H - 56, 110, 34, "Close", MYOS_UI_NORMAL)) return 0;
            if(myos_ui_button(&ui, 11, W - 130, H - 56, 110, 34, "Start over", MYOS_UI_ACCENT)) page = PAGE_WELCOME;
        }
        myos_ui_end_frame(&ui);

        /* While installing: one bounded unit of work per loop, then let the
         * desktop paint (the wait below runs a frame). */
        if(installing) {
            int rc = myos_install_step(&st);
            if(rc < 0 || st.state == MYOS_INST_FAILED) {
                installing = 0; myos_busy(0);
                fail_err = rc < 0 ? rc : st.error;
                memcpy(fail_detail, st.detail, sizeof(fail_detail));
                page = PAGE_FAILED;
            } else if(st.state == MYOS_INST_DONE) {
                installing = 0; myos_busy(0);
                page = PAGE_DONE;
            }
        }

        myos_event_t ev;
        int got = myos_wait_event(win, &ev, installing ? 1 : -1);
        if(got) {
            if(ev.type == MYOS_EV_CLOSE) {
                if(installing) continue;          /* cannot abort half way through */
                break;
            }
            myos_ui_event(&ui, &ev);
        }
        while(myos_poll_event(win, &ev)) {
            if(ev.type == MYOS_EV_CLOSE) { if(!installing) return 0; continue; }
            myos_ui_event(&ui, &ev);
        }
    }
    return 0;
}
