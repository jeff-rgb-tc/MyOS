# Cursors

Static cursors are `.cur` files; two are animated `.ani` files that replace
their `.cur` when present:

| kind | file | used when |
|---|---|---|
| Busy | `busy.ani` (fallback `busy.cur`) | something blocks: an app is loading, or an app asked for it with `myos_busy(1)` |
| Working in background | `working_in_background.ani` (fallback `working_in_background.cur`) | for ~1.2 s after you start something, so the click gets feedback |

To use your own animation, replace the `.ani` with any standard Windows
animated cursor (32-bit frames, any rate, optional `seq`/`rate` chunks). If a
file is missing or damaged the still `.cur` is used. Animation can be turned
off in `/Drivers/display/vesa-fb.drv` (`cursor_animation=0`).
