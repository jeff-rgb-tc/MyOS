# Drivers

`/Drivers/<category>/<id>.drv` describes one driver and controls how the kernel
uses it. Categories are the folder names: `sound`, `input`, `display`. The disk
builder copies this tree onto the disk image; the kernel reads it at boot
(`kernel/driver_loader.c`) before any driver starts.

A `.drv` is a small INI text file -- **it contains no machine code**. It binds
to a driver built into the kernel by its `id`, which means a bad or malicious
file can mis-configure a driver but can never run code in ring 0. You can
enable, disable, reorder and tune drivers without rebuilding the kernel.

## Format

```ini
; lines starting with ; or # are comments
[driver]
id=ac97                       ; must match the built-in driver's id
name=Intel AC'97 Audio        ; shown in Task Manager
category=sound
version=1.0.0
vendor=Intel / QEMU
description=PCI audio controller, 16-bit stereo PCM, DMA playback

[load]
enabled=1                     ; 0 = never start this driver
priority=100                  ; higher is probed first (sound: first one that finds hardware wins)
required=0                    ; 1 = cannot be disabled

[match]
pci=8086:2415                 ; informational

[settings]                    ; driver-specific, see the table below
```

Missing files mean defaults: a built-in driver with no descriptor is enabled
with its built-in priority, so an empty `/Drivers` never breaks boot.

## Shipped drivers

| id | category | built-in priority | settings |
|---|---|---|---|
| `ac97` | sound | 100 | -- |
| `sb16` | sound | 80 | -- |
| `adlib` | sound | 60 | -- |
| `gus` | sound | 40 | -- |
| `ps2-keyboard` | input | required | `numlock` = 1 (keypad starts as digits) or 0 |
| `ps2-mouse` | input | required | `sensitivity` = pointer speed in %, 25-400 (the scroll wheel is detected automatically) |
| `vesa-fb` | display | required | `cursor_animation` = 1 (animated .ani cursors) or 0 (still .cur) |

Examples: to prefer the Sound Blaster, set `priority=200` in `sb16.drv`; to
silence audio entirely set `enabled=0` in every sound `.drv`; for a slower
pointer set `sensitivity=60`.

## What you can see

Task Manager's **Drivers** tab lists every driver with its live status:
*Active*, *Standby* (enabled, but a higher-priority driver took the job),
*No hardware* (enabled, but the device wasn't found -- normal for sound cards
QEMU isn't emulating), *Disabled*, or *Installed*.

## Adding a driver to the kernel

1. Write the driver (see `kernel/ac97.c` for the shape: a `probe_and_init`
   function and the audio driver vtable in `kernel/audio.h`).
2. Add it to `builtin_audio[]` in `kernel/audio.c` with an id and a default priority.
3. Ship `Drivers/<category>/<id>.drv` so users can control it.
4. Report status with `driver_report_status()` (the audio code shows how).

Loadable binary drivers (a `.drv` that carries code) are not supported yet.

## Notes on the shipped drivers

* **ac97** runs the codec at a fixed 48000 Hz and resamples other source rates in
  software. Re-programming the codec's sample rate makes an emulated AC97 re-open
  its host audio stream, which can stall for seconds on some hosts.
* **ps2-mouse** asks for the IntelliMouse wheel protocol at start-up and falls
  back to plain 3-byte packets if the device does not answer with ID 3/4.
